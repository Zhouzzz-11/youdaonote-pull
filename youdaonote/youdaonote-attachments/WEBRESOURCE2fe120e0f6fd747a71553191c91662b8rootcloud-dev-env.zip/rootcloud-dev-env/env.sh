#!/bin/bash

set -e

echo "Setting up evnironemnt varibles..."

# avoid WARNING
export KAFKA_BOOTSTRAP_SERVER_ADDRESS=""
export FLINK_JOB_MANAGER_ADDRESS=""
export INFLUXDB_ADDRESS=""
export MONGO_ADDRESS=""
export REDIS_ADDRESS=""
export RABBITMQ_ADDRESS=""
export FILE_SERVER_ADDRESS=""
export WITH_GRAFANA=""
export EMQX_HOST=""
export EMQX_PORT=""
export WITH_HIVE=""
export HIVE_JDBC_URI=""
export JAEGER_ENABLED=""
export JAEGER_ENTRY_POINT=""
export HUB_SUPER_TOKEN="hub-super-user"

export DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export RELEASE_VERSION=$(node -p "require('$DIR/package.json').version")
export ECA_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-eca']")
export HISTORIAN_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-historian']")
export HUB_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-hub']")
export INFLUXDB_PROXY_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-influx-cluster']")
export EMQX_AUTH_ACL_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-emqx-auth-acl']")
export EMQX_KAFKA_BRIDGE_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-emqx-kafka-bridge']")
export PLATFORM_METRICS_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-platform-metrics']")
export INSTRUCTION_PROXY_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-instruction-proxy']")
export IOTWORKS_API_VERSION=$(node -p "require('$DIR/package.json').dependencies['@rootcloud/rootcloud-data-analysis']")

export REDIS_VERSION=4.0
export FLINK_VERSION=1.9.3
export INFLUXDB_VERSION=1.7.8
export MONGODB_VERSION=4.2.6
export EMQ_VERSION=v3.2.6-1
export EMBEDDED_HIVE_VERSION=0.1.4

export PARALLELISM=${PARALLELISM:-1}

if [[ "${DOCKER_REGISTRY}" == "" ]]; then
  export DOCKER_REGISTRY="private-registry.rootcloud.com/cicd"
fi

check_cmd() {
  (which "$1" &> /dev/null && echo "[installed] $1") || (echo "[not installed] $1"; exit 1)
}

check_cmd docker
check_cmd docker-compose
check_cmd node
check_cmd yarn
check_cmd curl
check_cmd git
check_cmd nc
