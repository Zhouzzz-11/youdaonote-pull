#!/bin/sh

echo "start emq in backgroud"

/usr/bin/start.sh &

retry=3

echo "Waiting until emq broker is ready..."

while [ "$(emqx ping)" != "pong" ] || [ "$(curl -o /dev/null -s -w "%{http_code}\n" --connect-timeout 1 http://localhost:18083)" != "200" ]
do
    echo "emq is not ready, retry after ${retry}s"
    sleep ${retry}
done

echo "emq is ready."

echo "use ${HUB_ADDRESS}"

result="$(curl -s -X POST -u admin:public 'http://localhost:18083/api/v3/resources' -H 'content-type: application/json' -d "{\"type\":\"web_hook\", \"config\":{\"headers\":{},\"method\":\"PUT\", \"url\":\"${HUB_ADDRESS}/device/status\"},\"description\":\"\"}")"
resourceid="$(echo "${result}" | jq -r '.data.id')"

curl -o /dev/null -s -X POST -u admin:public 'http://localhost:18083/api/v3/rules' \
    -H 'content-type: application/json' \
    -d   "{\"for\":\"client.connected\",\"rawsql\":\"SELECT * FROM \\\"client.connected\\\" WHERE connack=0 \",\"actions\":[{\"name\":\"data_to_webserver\",\"params\":{\"\$resource\":\"${resourceid}\"}}],\"description\":\"\"}"

curl -o /dev/null -s -X POST -u admin:public 'http://localhost:18083/api/v3/rules' \
    -H 'content-type: application/json' \
    -d   "{\"for\":\"client.disconnected\",\"rawsql\":\"SELECT * FROM \\\"client.disconnected\\\"\",\"actions\":[{\"name\":\"data_to_webserver\",\"params\":{\"\$resource\":\"${resourceid}\"}}],\"description\":\"\"}"

echo "eqm webhook and rules created."

# to avoid exiting
tail -f /dev/null
