#!/bin/bash

code=$( curl -o /dev/null -s -w "%{http_code}\n" --connect-timeout 1 $1)
if [[  $code == '200' ]]; then
  echo "service $2 is ready"
  exit 0
fi
echo "service $2 is unavaliable (status = ${code})"
exit 1
