#!/usr/bin/env bash

url=${1}
container=${2}
retry=${3}

if [[ "${retry}" == "" ]]; then
  retry=5
fi

until curl -o /dev/null -s --connect-timeout 1 "http://${url}";
do
    if [[ "${container}" == "" ]]; then
      echo "no container specified and retry after ${retry}s"
      sleep ${retry};
    elif [[ $(docker inspect -f "{{.State.Running}}" "${container}") == 'true' ]]; then
      echo "${container} is still alive and retry after ${retry}s"
      curl -o /dev/null -s --connect-timeout 1 "http://${url}" || sleep ${retry};
    else
      echo "${container} is dead and exit with 1"
      exit 1;
    fi
done
