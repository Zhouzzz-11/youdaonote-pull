#!/bin/bash

set -e

tenantId=$1

echo "Waiting until deployer is ready..."
"$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"/../util/checkAlive.sh localhost:8445/version deployer 3

echo "Delete job for ${tenantId} on existing"
curl -o /dev/null -s -X DELETE "http://localhost:8445/job/t1?force=true" -H "accept: application/json" || echo "No job has been deployed for ${tenantId}"

code=$(curl -o /dev/null -s -w "%{http_code}\n" \
  -X POST "http://localhost:8445/job" \
  -H "accept: application/json" \
  -H "Content-Type: application/json" \
  -d "{\"tenantId\":\"${tenantId}\",\"topicPrefix\":\"${tenantId}\"}")

if [[ $code == '200' ]]; then
  echo "Deploy ECA topology successfully"
  exit 0
fi
echo "Fail to deploy ECA topology, unavaliable (status = ${code})"
exit 1
