#!/bin/bash

retry=3

echo "Waiting until Kafka is ready..."

until echo dump | nc localhost 2181 | grep brokers &>/dev/null;
do
    if [[ $(docker inspect -f "{{.State.Running}}" kafka) == 'true' ]]; then
      echo "kafka is not ready but still alive, retry after ${retry}s"
      sleep ${retry};
    else
      echo "kafka is dead, exit with 1"
      exit 1;
    fi
done

echo "Kafka is ready. Creating topics..."

docker exec kafka sh -c "/opt/createTopics.sh" || exit 1;

echo "Topics created."
