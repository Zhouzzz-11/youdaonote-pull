#!/bin/bash

set -m # Enable Job Control

tenants=(
  "t2"
  "t1_a"
  "t1_b"
  "t2_a"
  "share"
)

topicSuffixes=(
  "input"
  "meta"
  "event"
  "logical"
  "logical_persistent"
  "actionable"
  "error"
  "mgmtreq"
  "mgmtrsp"
)

for tenant in "${tenants[@]}"; do
  for topicSuffix in "${topicSuffixes[@]}"; do
    /opt/kafka/bin/kafka-topics.sh --zookeeper localhost:2181 \
      --create --topic "${tenant}_${topicSuffix}" --replication-factor 1 --partitions 1 --if-not-exists &
  done
done

# Wait for all parallel jobs to finish
while true; do fg 2> /dev/null; [ $? == 1 ] && break; done
