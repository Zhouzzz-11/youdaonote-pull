#!/bin/bash
if [[ -z "$1" ]]; then
  echo "Please specify a topic name";
else
echo "Ensuring topic $1 exists";
docker exec kafka sh -c "kafka-topics --zookeeper localhost:2181 \
      --create --topic '${1}' --replication-factor 1 --partitions 1";
echo
echo "Creating producer for topic $1";
echo "Please use ':' as the splitter between key and value, e.g. key1:value1";
docker exec -it kafka sh -c "kafka-console-producer \
  --broker-list localhost:9092 \
  --topic $1 \
  --property \"parse.key=true\" \
  --property \"key.separator=:\"";
fi
