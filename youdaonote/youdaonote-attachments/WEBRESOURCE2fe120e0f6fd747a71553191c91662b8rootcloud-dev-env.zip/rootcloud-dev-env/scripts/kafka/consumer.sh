#!/bin/bash
if [ -z "$1" ];
then echo "Please specify a topic name";
else
echo "Creating consumer for topic $1";
echo "Note: character ':' is printed as the splitter between key and value";
docker exec -it kafka sh -c "kafka-console-consumer \
  --bootstrap-server localhost:9092 \
  --property print.key=true --property key.separator=":" \
  --topic $1";
fi
