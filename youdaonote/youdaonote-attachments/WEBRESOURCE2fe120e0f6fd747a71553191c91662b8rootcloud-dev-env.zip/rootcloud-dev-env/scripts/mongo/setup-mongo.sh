#!/bin/bash
set -ex

if [[ "$MONGO_REPLICA_ENABLE" = "true" ]]; then
  mongoContainerName=$1
  maxTxRequestTimeoutMillis=$2
  touch /etc/mongorc.js
  echo "rs.slaveOk()" >> /etc/mongorc.js
  echo "********************************************** starting mongo replica containers with 3 nodes... container name = $mongoContainerName"
  MONGODB1=${mongoContainerName}
  MONGODB2=${mongoContainerName}
  MONGODB3=${mongoContainerName}

  if [[ ! -d /data/db1 ]];then
        mkdir -p /data/db1
  fi
  if [[ ! -d /data/db2 ]];then
        mkdir -p /data/db2
  fi
  if [[ ! -d /data/db3 ]];then
        mkdir -p /data/db3
  fi

  mongod --bind_ip_all --replSet rs0 -port 27018 --dbpath /data/db2 &
  mongod --bind_ip_all --replSet rs0 -port 27019 --dbpath /data/db3 &

  until mongo -port 27018 --eval "db.adminCommand('ping')" && mongo -port 27019 --eval "db.adminCommand('ping')"
  do
    printf '.'
    sleep 1
  done
  echo "mongo cluster's slaves Started.."

  mongod --bind_ip_all --replSet rs0 -port 27017 --dbpath /data/db1 &
  until mongo -port 27017 --eval "db.adminCommand('ping')"
  do
    printf '.'
    sleep 1
  done
  echo "mongo cluster's master Started.."

  echo SETUP.sh time now: `date +"%T" `
  mongo --host ${MONGODB1}:27017 <<EOF
var cfg = {
   _id : "rs0",
   members: [
      { _id: 0, host: "${MONGODB1}:27017" },
      { _id: 1, host: "${MONGODB2}:27018", priority:0 },
      { _id: 2, host: "${MONGODB3}:27019", priority:0 }
   ]
};
rs.initiate(cfg, { force: true });
rs.reconfig(cfg, { force: true });
rs.slaveOk();
db.getMongo().setReadPref('primary');
db.getMongo().setSlaveOk();
db.adminCommand( { setParameter: 1, maxTransactionLockRequestTimeoutMillis: ${maxTxRequestTimeoutMillis} });
EOF

else
  if [[ ! -d /data/db ]];then
        mkdir -p /data/db
  fi
  mongod --bind_ip_all -port 27017 --dbpath /data/db &
fi
