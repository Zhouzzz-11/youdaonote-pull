#!/usr/bin/env bash

[[ -d ./logs ]] || mkdir -p ./logs
docker ps -a --format "echo 'dump log for {{.Names}}'; docker logs {{.ID}} &> ./logs/{{.Names}}-{{.ID}}.log" | bash || echo "dump log fail"
