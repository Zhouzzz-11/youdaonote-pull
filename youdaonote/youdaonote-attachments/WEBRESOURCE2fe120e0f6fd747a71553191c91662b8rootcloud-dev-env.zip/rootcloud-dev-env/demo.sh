#!/bin/sh

sh ./start.sh -g
node ./demo/e2e/resources/importData.js
curl -X PATCH "http://localhost:8444/draft/logicalInterfaces/397bf29baf204f3a92ab937bec0f0f9b"\
     -H "accept: application/json"\
     -H "Content-Type: application/json"\
     -d "{\"operation\":\"activate\"}";
curl -X POST "http://localhost:8442/v1/data"\
     -H "Content-Type: application/json"\
     -H "Accept: application/json"\
     -d "{\"tempevt\" : {\"temp\": 100} }"
