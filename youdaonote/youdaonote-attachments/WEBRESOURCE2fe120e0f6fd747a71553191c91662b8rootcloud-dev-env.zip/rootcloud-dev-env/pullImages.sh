#!/bin/bash

source "$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"/env.sh

dockerComposeFiles=""
while IFS=  read -r -d $'\0'; do
    dockerComposeFiles+="-f $REPLY "
done < <(find . -name "docker-compose*" -print0)

sh -c "docker-compose ${dockerComposeFiles} pull"

echo "Pulling Development Environment Images Finished!"
