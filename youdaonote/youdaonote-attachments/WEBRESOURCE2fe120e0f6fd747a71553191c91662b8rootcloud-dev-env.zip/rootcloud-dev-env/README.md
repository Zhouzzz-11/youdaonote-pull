# Rootcloud Development Environment

## Dependencies

1. docker, docker-compose
2. nodejs@10.x, yarn
3. git, curl, nc

## How to use

0. Install decencies
```shell script
yarn
```

1. Pull latest images of each component by
```shell script
# login private docker registry
docker login private-registry.rootcloud.com/cicd/

# (Optional) pull images of current version
./pullImages.sh
```

2. Start the development environment by
```shell script
./start.sh
```

> **Options**
> + -h | --help: (Optional) display usage
> + -u | --update: (Optional) update dev env without destroy exisiting one
> + -k | --kafka-zookeeper-address: (Optional) specify the kafka zookeeper address, start local Kafka cluster on missing
> + -f | --flink-jobmanager-address: (Optional) specify the kafka zookeeper address, start local Kafka cluster on missing
> + -i | --influxdb-address: (Optional) specify the influxdb address, start local influxdb on missing
> + -e | --emqx-address: (Optional) specify the emq-enterprise address, start local emq-enterprise on missing
> + -m | --mongodb-address: (Optional) specify the mongodb address, start local mongodb on missing
> + -g | --with-grafana: (Optional) declare to start local grafana
> + --with-hive [jdbc-hive-address]: (Optional) declare to access hive for data export, and give a jdbc uri
> + -j | --with-jaeger: (Optional) declare to start jaeger and connected it with components "
> + --debug-eca: (Optional) do not start flink cluster and submit job

3. Performing E2E pytest
```shell script
yarn test
```

4. Destroy the development environment by
```shell script
./destroy.sh
```

#### Component Accessibility

![deployment](http://www.plantuml.com/plantuml/png/LPBDRi8m48Jl-nGhxdc3gk8d852KGzLMzBhOIsjXx9R4eLNLTw_jTHJWG4RppMoyLkPTJvS-d2s0yvfHys0K8tLOmrVWmBXkdzv0MHyqRgnnfyGs-0k8kJ1ZHTMPZ9ibi5ujxi3LEEsl8zh37y04DNzQ_yEN4TU5nJTM3HrFXCexnwht4bcL4sMMZAOKFi8X1xQloz4nNMmPSk8_lu2cdWxKCHftjE6xNYQmc-oj6JXd9-litRkNO5lcakgDTtImZ1rVXd9sN03KM5MFSbchB1jvYhMubK8RVAZYBor-g_SG_sJO1jhaozNiaioRn2tljKIABaFQCL9KXD2CIeP9IwIKjfCjKkmvEvs-a7y0)

#### Data Flow

![dataFlow](http://www.plantuml.com/plantuml/png/L8xBJiD034NtynLMz_q7shHHKKd5WmgspenJHfdOPHuf2F7lv94eOdlEkPRlGaGVK-DKg2rVqMC3XYfCBkR2yOGDmUOP7X_WN5Y-G7PIB8QwfhMQ00Fir6UYHB0ldjwLTf8CvCvotRiSVXJ0C5YHndM3bbUzs6URV-9csSXjLc_gLuskExe-ObKZQ64c7SKFKQQMhQ6has_oytf-QDnrx3Z57waSciDvEnCRkeiMUUGlhyfWn183WUNAfQ_TjXVt2pxObePsGOtmHSQmcEwYZbOOIqSGoBVJRx1HdH0FVusKJsyIGHZ6x_if9juPmnyy46AaGACIZwINNZJsA5xy0CLs2m7QfK6n_WbDArlMWoojHcWtnI-px-pij_2TVLSw9JPuVdxpl3FlysJkmUKFi2R1EqSqfv5KDOmYIoGUiagEhQKu71p3g2tUJyJ-EEpDvTH5EPz8H4k-YoX41aIKKbnq6hutz6Tji0wDagQj9RaSps7OeDF-h2LQDX8t_gNqxTE5IAkWe8wUXaUc7Er2ywCSdQ7i_puHTTUeu0Wr11F06UXmO8DfqmmKyqgDnGoNewzYq0sydXXysQo5svwS7mhd10RjpPhkBUSzQ5pftXivLano9bqFh3xCpcJz4tIRkeC-JD4PpiY6q9N3L8KO3bjdELP8SIQihdyrXF50VFW5mzsWk_VqzGlZ6UrBiOYb4UlK_KiJElqbCZJtW-knyKHPOiDoR3sDwUs1TK6x4SUsT4yDbD1HTPCXakBqG0eAp1rY3IKlbbpESD-pnUUVeZ-XlC9lvz1oy5NkL9o_VRNrvhbggNvgu_-FqHFZInUpdC7t8xoIVlTb50UXVuhVBsSvqGiY2YK6L3cSSBl-LzJlWelAtpGbo_MuQ2Z5f74gPCo9uhsJVwpxFk0hEV9Dh_Ibu1AiYh4b_v4iBJNA8CRAINxxvJ5InOei6eKTf_yXt762wulb-ZtQghrKl_OV)


## The APIs
Each of the services has a Swagger UI for easy try & play. The E2E demo steps are much easier to do via the Swagger UI.

- The Device Simulator Swagger UI -
http://localhost:8442/v1/ui

- The Historian Service Swagger UI -
http://localhost:8443/swagger

- The Metadata Management Swagger UI -
http://localhost:8444/swagger

- The ECA Deployer Swagger UI -
http://localhost:8445/swagger


## Run the E2E Demo
In the folder of demo/e2e/resources, there are some predefined resources can be used for a quick setup. Here are the configured resources -
- TenantId --------------- t1
- Device Type ------------ TSensor
- Device Instance -------- tSensor
- Event Type ------------- tempevt
- Physical Interface Id -- a822dec7ecc54cecad50938b7e97df24
- Logical Interface Id --- 397bf29baf204f3a92ab937bec0f0f9b
- Rule ------------------- -temperature > 50 || temperature < 40


1. Import the pre-defined resources.
    ```shell script
    cd demo/e2e/resources
    node importData.js
    ```

2. Send an event record. Open the Device Simulator Swagger UI (or curl command from a terminal) to send a data record via the API as follows -
    ```shell script
    curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' -d '{ \
      "tempevt": { \
        "temp": 45 \
      } \
    }' 'http://localhost:8442/v1/data'
    ```
    Note that, the pre-defined EventType is tempevt, so the evtTypeId should be 'tempevt' in the payload. Since there are no logical interfaces and rules activated yet, there is no output to the topic of t1_actionable or t1_logical, but should have some data in the t1_event.

3. Retrieve the prefined logical interface from the Metadata Management Server.
    ```shell script
    curl -X GET "http://localhost:8444/draft/logicalInterfaces" -H "accept: application/json"
    ```

4. Activate the logical interface from the Metadata Management Server.
    ```shell script
    curl -X PATCH "http://localhost:8444/draft/logicalInterfaces/397bf29baf204f3a92ab937bec0f0f9b" -H "accept: application/json" -H "Content-Type: application/json" -d "{\"operation\":\"activate\"}"
    ```

5. Send another event record from the Device Simulator, which may trigger the rules (either >50 or < 40).
    ```shell script
    curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' -d '{ \
      "tempevt": { \
        "temp": 90 \
      } \
    }' 'http://localhost:8442/v1/data'
    ```
    Note. Since the logical interface and rule was activated, there should be output to the topic of t1_actionable or t1_logical, and the t1_event as well.

6. Check the output from the Historian API Server.

    From the realtime apis to get the latest device state.
    ```shell script
    curl -X GET "http://localhost:8443/realtime/logicaltypes/397bf29baf204f3a92ab937bec0f0f9b/devices/tSensor" -H "accept: application/json"
    ```

    From the historian apis to query states between a time range.
    ```shell script
    curl -X GET "http://localhost:8443/historian/logicaltypes/397bf29baf204f3a92ab937bec0f0f9b/devices/tSensor?properties=%5B%22temperature%22%5D&startTime=2019-09-24T06%3A01%3A48.367Z&endTime=2019-09-24T08%3A01%3A48.367Z" -H "accept: application/json"
    ```
    Note - You may need to adjust the time range to get any results.
