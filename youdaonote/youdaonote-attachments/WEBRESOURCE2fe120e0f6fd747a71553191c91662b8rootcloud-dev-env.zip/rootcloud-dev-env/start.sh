#!/bin/bash

set -e

Usage() {
  echo ""
  echo "Usage: ./start.sh"
  echo ""
  echo "Options:"
  echo -e "\t-h | --help: (Optional) display usage"
  echo -e "\t-k | --kafka-zookeeper-address: (Optional) specify the kafka zookeeper address, start local Kafka cluster on missing"
  echo -e "\t-f | --flink-jobmanager-address: (Optional) specify the kafka zookeeper address, start local Kafka cluster on missing"
  echo -e "\t-i | --influxdb-address: (Optional) specify the influxdb address, start local influxdb on missing"
  echo -e "\t-r | --redis-address: (Optional) specify the redis address, start local redis on missing"
  echo -e "\t-e | --emqx-address: (Optional) specify the emq-enterprise address, start local emq-enterprise on missing"
  echo -e "\t-m | --mongodb-address: (Optional) specify the mongodb address, start local mongodb on missing"
  echo -e "\t-g | --with-grafana: (Optional) declare to start local grafana"
  echo -e "\t-u | --update: (Optional) update dev env without destroy existing one"
  echo -e "\t--with-hive [jdbc-hive-address]: (Optional) declare to access hive for data export, and give a jdbc uri "
  echo -e "\t-j | --with-jaeger: (Optional) declare to start jaeger and connected it with components "
  echo -e "\t--debug-eca: (Optional) do not start flink cluster and submit job"
  echo "Example: ./start.sh"
  echo ""
  exit 0
}

Parse_Arguments() {
  while [[ $# -gt 0 ]]; do
    case $1 in
      --help | -h)
        HELPINFO=true
        ;;
      --kafka-zookeeper-address | -k)
        shift
        export KAFKA_BOOTSTRAP_SERVER_ADDRESS="$1"
        ;;
      --flink-jobmanager-address | -f)
        shift
        export FLINK_JOB_MANAGER_ADDRESS="$1"
        ;;
      --influxdb-address | -i)
        shift
        export INFLUXDB_ADDRESS="$1"
        ;;
      --redis-address | -r)
        shift
        export REDIS_ADDRESS="$1"
        ;;
      --mongodb-address | -m)
        shift
        export MONGO_ADDRESS="$1"
        ;;
      --with-grafana | -g)
        shift
        export WITH_GRAFANA=true
        ;;
      --with-hive)
        export WITH_HIVE=true
        if [[ "$2" =~ ^\-.* ]] || [[ "$2" == "" ]]; then
          export HIVE_JDBC_URI="jdbc:hive2://embeddedhive:10000/"
        else
          shift
          export HIVE_JDBC_URI="$1"
        fi
        ;;
      --update | -u)
        export UPDATE_ENV=true
        ;;
      --with-jaeger | -j)
        export JAEGER_ENABLED=true
        export JAEGER_ENTRY_POINT="http://jaeger:14268/api/traces"
        ;;
      --debug-eca)
        export DEBUG_ECA=true
        ;;
      --emq-address | -e)
        shift
        case $1 in
          (*:*) export EMQX_HOST=${1%:*} EMQX_PORT=${1##*:};;
          (*)   export EMQX_HOST=$1      EMQX_PORT=1883;;
        esac
    esac
    shift
  done
}

CWD=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${CWD}"/env.sh

export TENANT_ID="t1"
export IOT_DATA_DIR="${HOME}/.iot4-dev-env"
mkdir -p "${IOT_DATA_DIR}"

# pull images in background in parallel
"${CWD}"/pullImages.sh &> /dev/null &

Parse_Arguments $@

if [[ "${HELPINFO}" == "true" ]]; then
    Usage
fi

DOCKER_COMPOSE_FILES="-f docker-compose.yaml -f docker-compose-lbs.yaml "

if [[ "${JAEGER_ENABLED}" == "true" ]]; then
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-jaeger.yaml "
  echo "start Jaeger@${JAEGER_ENTRY_POINT}"
fi

if [[ "${KAFKA_BOOTSTRAP_SERVER_ADDRESS}" == "" ]]; then
  export KAFKA_BOOTSTRAP_SERVER_ADDRESS="kafka:9092";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-kafka.yaml "
  echo "start local Kafka@${KAFKA_BOOTSTRAP_SERVER_ADDRESS}"
else
  echo "use remote Kafka@${KAFKA_BOOTSTRAP_SERVER_ADDRESS}"
fi

if [[ "${FLINK_JOB_MANAGER_ADDRESS}" == "" && "${DEBUG_ECA}" == "" ]]; then
  export FLINK_JOB_MANAGER_ADDRESS="jobmanager:8081";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-flink.yaml "
  echo "start local Flink@${FLINK_JOB_MANAGER_ADDRESS}"
elif [[  "${DEBUG_ECA}" == "true" ]]; then
  echo "debuging eca"
else
  echo "use remote Flink@${FLINK_JOB_MANAGER_ADDRESS}"
fi

if [[ "${INFLUXDB_ADDRESS}" == "" ]]; then
  export INFLUXDB_ADDRESS="influxproxy:8086";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-influxdb.yaml "
  echo "start local Influxdb@${INFLUXDB_ADDRESS}"
else
  echo "use remote Influxdb@${INFLUXDB_ADDRESS}"
fi

if [[ "${HBASE_PHOENIX_ADDRESS}" == "" ]]; then
  export HBASE_PHOENIX_ADDRESS="hbase-phoenix:8765";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-hbase20.yaml "
  echo "start local hbase@${HBASE_PHOENIX_ADDRESS}"
else
  echo "use remote hbase@${HBASE_PHOENIX_ADDRESS}"
fi

if [[ "${REDIS_ADDRESS}" == "" ]]; then
  export REDIS_ADDRESS="redis://redis:6379";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-redis.yaml "
  echo "start local redis@${REDIS_ADDRESS}"
else
  echo "use remote redis@${REDIS_ADDRESS}"
fi

if [[ "${MONGO_ADDRESS}" == "" ]]; then
  export MONGO_ADDRESS="mongodb://mongodb:27017,mongodb:27018,mongodb:27019";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-mongodb.yaml "
  echo "start local Mongodb@${MONGO_ADDRESS}"
else
  echo "use remote Mongodb@${MONGO_ADDRESS}"
fi

if [[ "${RABBITMQ_ADDRESS}" == "" ]]; then
  export RABBITMQ_ADDRESS="test:test@rabbitmq:5672";
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-rabbitmq.yaml "
  echo "start local RABBITMQ@${RABBITMQ_ADDRESS}"
else
  echo "use remote RABBITMQ@${RABBITMQ_ADDRESS}"
fi


if [[ "${WITH_GRAFANA}" == "true" ]]; then
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-grafana.yaml "
  echo "start local Grafana@localhost:3000"
fi

if [[ "${WITH_HIVE}" == "true" ]]; then
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-hive.yaml "
fi

if [[ "${EMQX_HOST}" == "" ]]; then
  export EMQX_HOST="emq";
  export EMQX_PORT=1883;
  DOCKER_COMPOSE_FILES="${DOCKER_COMPOSE_FILES} -f docker-compose-emq.yaml "
  echo "start local EmqX@${EMQX_HOST}:${EMQX_PORT}"
else
  echo "use remote EmqX@${EMQX_HOST}:${EMQX_PORT}"
fi

if [[ "${UPDATE_ENV}" == "" ]]; then
  ./destroy.sh
fi

if [[ "${WITH_HIVE}" == "true" ]]; then
  echo "starting hive@${HIVE_JDBC_URI}"
  sh -c "docker-compose ${DOCKER_COMPOSE_FILES} up -d embeddedhive"
  "${CWD}"/scripts/util/checkAlive.sh localhost:10002 embeddedhive 3
  echo "hive@${HIVE_JDBC_URI} is ready."
fi

echo "Starting Development Environment... "

sh -c "docker-compose ${DOCKER_COMPOSE_FILES} up -d"

if [[ "${KAFKA_BOOTSTRAP_SERVER_ADDRESS}" == "kafka:9092" ]]; then
  ./scripts/kafka/initLocalCluster.sh
fi

echo "wait for emq ready"
"${CWD}"/scripts/util/checkAlive.sh localhost:18083 emq
echo "emq is ready"

if [[  "${DEBUG_ECA}" == "" ]]; then
  echo "Submitting System Topology ..."
#  ./scripts/eca/submitJob.sh "${TENANT_ID}"
fi

echo "Development Environment is ready!"
echo "Device Simulator entrypoint: http://localhost:8442/v1/ui/"
echo "Historian entrypoint: http://localhost:8443/swagger"
echo "Hub entrypoint: http://localhost:8444/swagger"
echo "Eca Deployer entrypoint: http://localhost:8445/swagger"
echo "Platform Metrics entrypoint: http://localhost:8446/swagger"
