import time
import pytest
from iot.hub.data import demo_data as data
from iot.util import get_time_stamp, my_assert, my_assert_mes
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS126(object):
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.t571_post_schema_list}],
                             indirect=True)
    def test_post_schema(self,
                         fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.t571_query_schema_list}],
                             indirect=True)
    def test_query_schema(self,
                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.t571_post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': data.t571_post_event_type_list}], indirect=True)
    def test_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.t571_post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': data.t571_query_event_type_list}], indirect=True)
    def test_query_event_type(self,
                              fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.t571_post_schema_for_pi_list}], indirect=True)
    def test_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.t571_query_schema_for_pi_list}], indirect=True)
    def test_query_schema_for_pi(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.t571_post_pi_list[0]['data']['schemaId'] = _schema_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_post_expression_for_pi_list}], indirect=True)
    def test_post_expression_for_pi(self,
                                    fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.t571_post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id
        data.t571_put_expression_with_temp_add_10_list[0]['id'] = _expression_id
        data.t571_put_expression_with_temp_multiply_2_subtract_20_list[0]['id'] = _expression_id
        data.t571_put_expression_from_temp_to_t[0]['id'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.t571_post_pi_list}], indirect=True)
    def test_post_pi(self,
                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.t571_query_pi_list}], indirect=True)
    def test_query_pi(self,
                      fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.t571_post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.t571_active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.t571_post_device_type_list}], indirect=True)
    def test_post_device_type(self,
                              fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.t571_query_device_type_list}], indirect=True)
    def test_query_device_type(self,
                               fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.t571_active_pi_list}], indirect=True)
    def test_active_pi(self,
                       fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.t571_post_device_list}],
                             indirect=True)
    def test_post_device(self,
                         fix_device):
        verifyData.res_e2e_payload = verifyData.res_text['payload']
        verifyData.mqtt_e2e_client = get_connection(verifyData.res_e2e_payload)

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.t571_query_device_list}],
                             indirect=True)
    def test_query_device(self,
                          fix_device):
        my_assert(verifyData.res_text['payload'][requestsData.deviceId], data.post_device_data[1])

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.t571_post_schema_for_li_list}], indirect=True)
    def test_post_schema_for_li(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.t571_query_schema_for_li_list}], indirect=True)
    def test_query_schema_for_li(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.t571_post_li_list[0]['data'][requestsData.schemaId] = _schema_id

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_post_li_list}], indirect=True)
    def test_post_li(self,
                     fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_query_li_list}], indirect=True)
    def test_query_li_list(self,
                           fix_draft_logical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_logical_interface_data[1])
        verifyData.logical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_post_expression_list}], indirect=True)
    def test_post_expression(self,
                             fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_query_expression_list}], indirect=True)
    def test_query_expression(self,
                              fix_draft_expression):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_expression_for_mapping[1])
        verifyData.expression_id = verifyData.res_text['payload'][0]['expressionId']
        data.t571_post_mapping_list[0]['data'][requestsData.physicalInterfaceId] = verifyData.physical_interface_id
        data.t571_post_mapping_list[0]['data'][requestsData.logicalInterfaceId] = verifyData.logical_interface_id
        data.t571_post_mapping_list[0]['data'][requestsData.propertyMappings][
            0][requestsData.expressionId] = verifyData.expression_id
        data.t571_active_li_list[0]['id'] = verifyData.logical_interface_id
        data.t571_put_schema_list[0]['id'] = verifyData.schema_id
        data.t571_query_data_from_actionable_list[0]['logicaltype_id'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.t571_post_mapping_list}],
                             indirect=True)
    def test_post_mapping(self,
                          fix_draft_mapping):
        pass

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.t571_query_mapping_list}],
                             indirect=True)
    def test_query_mapping(self,
                           fix_draft_mapping):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_mapping_data[1])

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_active_li_list}], indirect=True)
    def test_active_li(self,
                       fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_post_expression_with_temp_bigger_50_list}], indirect=True)
    def test_post_expression_with_temp_bigger_50(self,
                                                 fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_query_expression_with_temp_bigger_50_list}], indirect=True)
    def test_query_expression_with_temp_bigger_50(self,
                                                  fix_draft_expression):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_expression_for_rule_1[1])
        verifyData.expression_id = verifyData.res_text['payload'][0]['expressionId']
        data.t571_post_rule_with_temp_bigger_50_list[0][
            'data']['expressionId'] = verifyData.expression_id
        data.t571_post_rule_with_temp_bigger_50_list[0]['data'][
            'logicalInterfaceId'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_rule', [
                             {'data_list': data.t571_post_rule_with_temp_bigger_50_list}], indirect=True)
    def test_post_rule_with_temp_bigger_50(self,
                                           fix_draft_rule):
        pass

    @pytest.mark.parametrize('fix_draft_rule', [
                             {'data_list': data.t571_query_rule_with_temp_bigger_50_list}], indirect=True)
    def test_query_rule_with_temp_bigger_50(self,
                                            fix_draft_rule):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_rule_data[1])

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_post_expression_with_temp_less_40_list}], indirect=True)
    def test_post_expression_with_temp_less_40(self,
                                               fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_query_expression_with_temp_less_40_list}], indirect=True)
    def test_query_expression_with_temp_less_40(self,
                                                fix_draft_expression):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_expression_for_rule_2[1])
        verifyData.expression_id = verifyData.res_text['payload'][0]['expressionId']
        data.t571_post_rule_with_temp_less_40_list[0][
            'data']['expressionId'] = verifyData.expression_id
        data.t571_post_rule_with_temp_less_40_list[0]['data'][
            'logicalInterfaceId'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_rule', [
                             {'data_list': data.t571_post_rule_with_temp_less_40_list}], indirect=True)
    def test_post_rules_with_temp_less_40(self,
                                          fix_draft_rule):
        pass

    @pytest.mark.parametrize('fix_draft_rule', [
                             {'data_list': data.t571_query_rule_with_temp_less_40_list}], indirect=True)
    def test_get_rules_with_temp_less_40(self,
                                         fix_draft_rule):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_rule_data1[1])
        _create_time = verifyData.res_text['payload'][0]['created']
        _start_time, _end_time = get_time_stamp(_create_time, 200)
        verifyData.e2e_start_time, verifyData.e2e_end_time = get_time_stamp(_create_time, 2000)

        data.t571_query_data_from_historian_list[0]['query_string'] = f"?properties={requestsData.historian_properties}" \
            f"&startTime={_start_time}&endTime={_end_time}"
        data.t571_query_data_from_actionable_list[0][
            'query_string'] = f"?properties={requestsData.actionable_properties}" f"&startTime={_start_time}&endTime={_end_time}"
        data.t571_query_data_from_historian_list[0]['logicaltype_id'] = verifyData.logical_interface_id
        data.t571_deactive_li_list[0]['id'] = verifyData.logical_interface_id
        data.t571_query_li_after_deactive[0]['id'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
        {'data_list': data.t571_active_pi_list}], indirect=True)
    def test_active_pi_2(self,
                       fix_draft_physical_interface):
        time.sleep(1)

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_active_li_list}], indirect=True)
    def test_active_li_2(self,
                         fix_draft_logical_interface):
        post_data(verifyData.mqtt_e2e_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.t571_query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], data.e2e_res_1)

    @pytest.mark.parametrize('fix_logical_interface',
                             [{'data_list': data.t571_deactive_li_list}],
                             indirect=True)
    def test_deactivate(self,
                        fix_logical_interface):
        time.sleep(2)

    @pytest.mark.parametrize('fix_logical_interface', [
                             {'data_list': data.t571_query_li_after_deactive}], indirect=True)
    def test_get_li_after_deactivate(self,
                                     fix_logical_interface):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_physical_interface', [
        {'data_list': data.t571_active_pi_list}], indirect=True)
    def test_active_pi_3(self,
                         fix_draft_physical_interface):
        time.sleep(1)

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_active_li_list}], indirect=True)
    def test_active_li_3(self,
                         fix_draft_logical_interface):
        time.sleep(1)
        post_data(verifyData.mqtt_e2e_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.t571_query_data_from_historian_list, 'num': 2}], indirect=True)
    def test_query_data_from_historian_2(self,
                                         fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_res_2)

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_put_expression_with_temp_add_10_list}], indirect=True)
    def test_put_expression_with_temp_add_10(self,
                                             fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
        {'data_list': data.t571_active_pi_list}], indirect=True)
    def test_active_pi_4(self,
                         fix_draft_physical_interface):
        time.sleep(1)

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_active_li_list}], indirect=True)
    def test_active_li_4(self,
                         fix_draft_logical_interface):
        time.sleep(1)
        post_data(verifyData.mqtt_e2e_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.t571_query_data_from_historian_list, 'num': 3}], indirect=True)
    def test_query_data_after_temp_add_10(self,
                                          fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_res_3)

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_put_expression_with_temp_multiply_2_subtract_20_list}],
                             indirect=True)
    def test_put_expression_with_temp_multiply_2_subtract_20(self,
                                                             fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
        {'data_list': data.t571_active_pi_list}], indirect=True)
    def test_active_pi_5(self,
                         fix_draft_physical_interface):
        time.sleep(0.5)

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_active_li_list}], indirect=True)
    def test_active_li_5(self,
                         fix_draft_logical_interface):
        time.sleep(0.5)
        post_data(verifyData.mqtt_e2e_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.t571_query_data_from_historian_list, 'num': 4}], indirect=True)
    def test_query_data_after_temp_multiply_2_subtract_20(self,
                                                          fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_res_4)

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.t571_put_schema_list}],
                             indirect=True)
    def test_put_schema_property_from_temp_to_t(self,
                                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.t571_put_expression_from_temp_to_t}], indirect=True)
    def test_put_expression_from_temp_to_t(self,
                                           fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
        {'data_list': data.t571_active_pi_list}], indirect=True)
    def test_active_pi_6(self,
                         fix_draft_physical_interface):
        time.sleep(0.5)

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.t571_active_li_list}], indirect=True)
    def test_active_6(self,
                      fix_draft_logical_interface):
        time.sleep(0.5)
        post_data(verifyData.mqtt_e2e_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.t571_query_data_from_historian_list, 'num': 5}], indirect=True)
    def test_query_data_after_temp_to_t(self,
                                        fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_res_4)

    @pytest.mark.parametrize('fix_rule',
                             [{'data_list': data.t571_query_rule_2_list}],
                             indirect=True)
    def test_get_rule_by_query_string(self,
                                      fix_rule):
        verifyData.actionable_id = verifyData.res_text['payload'][0]['ruleId']
        verifyData.e2e_actionable_id = verifyData.actionable_id
        data.t571_query_data_from_actionable_list[0]['actionable_id'] = verifyData.actionable_id

    @pytest.mark.parametrize('fix_historian_actionable', [
                             {'data_list': data.t571_query_data_from_actionable_list, 'num': 3}], indirect=True)
    def test_query_data_from_actionable(self,
                                        fix_historian_actionable):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], data.e2e_res_2)
        time.sleep(requestsData.sleep_time)
