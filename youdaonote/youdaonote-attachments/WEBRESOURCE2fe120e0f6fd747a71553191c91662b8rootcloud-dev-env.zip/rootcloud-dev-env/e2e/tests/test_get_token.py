import pytest
from iot import requestsData
from iot.hub.data.tasks import rcdcs815a_data
from iot.hub.data.tasks import rcdcs815b_data
from iot.hub.data.tasks2.gypt8579 import gypt8579a_data
from iot.hub.data.tasks2.gypt8579 import gypt8579b_data
from iot.identity.data import identity_data as data


class TGYPT26958GetTokens(object):
    """
       use iam to get token
    """
    @pytest.mark.parametrize('fix_login_user', [{'data_list': data.post_login_super_admin_list}],
                             indirect=True)
    def test_26958_login_super_admin(self,
                                     fix_login_user):
        pass

    @pytest.mark.parametrize('fix_company', [{'data_list': data.post_company_list}], indirect=True)
    def test_26958_post_company(self,
                                fix_company):
        pass

    @pytest.mark.parametrize('fix_login_user', [{'data_list': data.post_login_super_user_list}],
                             indirect=True)
    def test_26958_login_super_user(self,
                                    fix_login_user):
        pass

    @pytest.mark.parametrize('fix_service', [{'data_list': data.post_service_license_list}], indirect=True)
    def test_26958_assign_service_license(self,
                                          fix_service):
        pass

    def test_set_token(self):
        requestsData.headers['Authorization'] = requestsData.get_header(requestsData.tenant_id)
        rcdcs815a_data.headers_a['Authorization'] = requestsData.get_header(requestsData.tenant_a)
        rcdcs815b_data.headers_b['Authorization'] = requestsData.get_header(requestsData.tenant_b)
        gypt8579a_data.headers_a['Authorization'] = requestsData.get_header(requestsData.tenant_shared_a)
        gypt8579b_data.headers_b['Authorization'] = requestsData.get_header(requestsData.tenant_shared_b)
