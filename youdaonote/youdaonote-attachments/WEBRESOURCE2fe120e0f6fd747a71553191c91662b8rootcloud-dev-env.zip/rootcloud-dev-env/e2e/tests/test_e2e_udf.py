import time
import pytest
from iot.hub.data import udf_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.util import get_time_stamp, my_assert
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS32(object):
    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.ud_t1_1_data_list}], indirect=True)
    def test_rcdcs32_post_schema(self,
                         fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.ud_t1_2_data_list}], indirect=True)
    def test_rcdcs32_get_schema_by_query_name(self,
                                      fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.ud_t1_3_data_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [{'data_list': data.ud_t1_3_data_list}], indirect=True)
    def test_rcdcs32_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.ud_t1_4_data_list[0]['query_string'] = f"?eventTypeId={verifyData.event_type_id}"
        data.ud_t1_9_data_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_event_type', [{'data_list': data.ud_t1_4_data_list}], indirect=True)
    def test_rcdcs32_get_event_type_by_query_id(self,
                                        fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.ud_t1_5_data_list}], indirect=True)
    def test_rcdcs32_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.ud_t1_6_data_list}], indirect=True)
    def test_rcdcs32_get_schema_for_ci_by_query_name(self,
                                             fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.ud_t1_9_data_list[0]['data']['schemaId'] = _schema_id

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.ud_t1_7_data_list}], indirect=True)
    def test_rcdcs32_post_expression_for_ci(self,
                                    fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.ud_t1_9_data_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.ud_t1_9_data_list}],
                             indirect=True)
    def test_rcdcs32_post_physical_interface(self,
                                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.ud_t1_10_data_list}],
                             indirect=True)
    def test_rcdcs32_get_physical_interface_by_query_name(self,
                                                  fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.ud_t1_11_data_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.ud_t1_13_data_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type', [{'data_list': data.ud_t1_11_data_list}], indirect=True)
    def test_rcdcs32_post_draft_device_type(self,
                                    fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [{'data_list': data.ud_t1_12_data_list}], indirect=True)
    def test_rcdcs32_get_draft_device_type_by_id(self,
                                         fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.ud_t1_13_data_list}],
                             indirect=True)
    def test_rcdcs32_active_physical_interface(self,
                                       fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.ud_t1_14_data_list}], indirect=True)
    def test_rcdcs32_post_device(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device', [{'data_list': data.ud_t1_15_data_list}], indirect=True)
    def test_rcdcs32_get_device_by_id(self,
                              fix_device):
        my_assert(verifyData.res_text['payload'][requestsData.deviceId], data.post_device_data[1])

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.ud_t1_16_data_list}], indirect=True)
    def test_rcdcs32_post_schema_for_logical_interface(self,
                                               fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.ud_t1_17_data_list}], indirect=True)
    def test_rcdcs32_get_schema_for_logical_interface_by_query_name(self,
                                                            fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.ud_t1_18_data_list[0]['data'][requestsData.schemaId] = _schema_id

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.ud_t1_18_data_list}], indirect=True)
    def test_rcdcs32_post_logical_interface(self,
                                    fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.ud_t1_19_data_list}], indirect=True)
    def test_rcdcs32_get_logical_interface_by_query_name(self,
                                                 fix_draft_logical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_logical_interface_data[1])
        verifyData.logical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]

    @pytest.mark.parametrize('fix_udf', [{'data_list': data.ud_t1_20_data_list}], indirect=True)
    def test_rcdcs32_post_udf(self,
                      fix_udf):
        verifyData.udf_id = verifyData.res_text['payload']['udfId']
        data.ud_t1_21_data_list[0]['id'] = verifyData.udf_id
        data.ud_t1_34_data_list[0]['id'] = verifyData.udf_id
        data.ud_t1_41_data_list[0]['id'] = verifyData.udf_id

    @pytest.mark.parametrize('fix_udf', [{'data_list': data.ud_t1_21_data_list}], indirect=True)
    def test_rcdcs32_get_udf(self,
                     fix_udf):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.ud_t1_22_data_list}],
                             indirect=True)
    def test_rcdcs32_post_expression(self,
                             fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.ud_t1_23_data_list}],
                             indirect=True)
    def test_rcdcs32_get_expression_by_query_name(self,
                                          fix_draft_expression):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_expression_for_mapping[1])
        verifyData.expression_id = verifyData.res_text['payload'][0]['expressionId']
        data.ud_t1_24_data_list[0]['data'][requestsData.physicalInterfaceId] = verifyData.physical_interface_id
        data.ud_t1_24_data_list[0]['data'][requestsData.logicalInterfaceId] = verifyData.logical_interface_id
        data.ud_t1_24_data_list[0]['data'][requestsData.propertyMappings][0][requestsData.expressionId] = \
            verifyData.expression_id
        data.ud_t1_26_data_list[0]['id'] = verifyData.logical_interface_id
        data.ud_t1_30_data_list[0]['logicaltype_id'] = verifyData.logical_interface_id
        data.ud_t1_33_data_list[0]['id'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_mapping', [{'data_list': data.ud_t1_24_data_list}], indirect=True)
    def test_rcdcs32_post_mapping(self,
                          fix_draft_mapping):
        pass

    @pytest.mark.parametrize('fix_draft_mapping', [{'data_list': data.ud_t1_25_data_list}], indirect=True)
    def test_rcdcs32_get_mapping_by_query_name(self,
                                       fix_draft_mapping):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_mapping_data[1])
        _create_time = verifyData.res_text['payload'][0]['created']
        _start_time, _end_time = get_time_stamp(_create_time, 200)

        data.ud_t1_30_data_list[0]['query_string'] = f"?properties={requestsData.historian_properties}" \
            f"&startTime={_start_time}&endTime={_end_time}"

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.ud_t1_26_data_list}], indirect=True)
    def test_rcdcs32_active_1(self,
                      fix_draft_logical_interface):
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.ud_t1_30_data_list, 'num': 1}],
                             indirect=True)
    def test_rcdcs32_get_data_from_historian_1(self,
                                       fix_historian_logical):
        assert verifyData.res_text['payload'][-1]['rows'][-1][1]
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.ud_t1_30_data_list, 'num': 2}],
                             indirect=True)
    def test_rcdcs32_get_data_from_historian_2(self,
                                       fix_historian_logical):
        assert not verifyData.res_text['payload'][-1]['rows'][-1][1]

    @pytest.mark.parametrize('fix_logical_interface', [{'data_list': data.ud_t1_33_data_list}],
                             indirect=True)
    def test_rcdcs32_deactivate(self,
                        fix_logical_interface):
        time.sleep(3)

    @pytest.mark.parametrize('fix_udf', [{'data_list': data.ud_t1_34_data_list}], indirect=True)
    def test_rcdcs32_put_udf(self,
                     fix_udf):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.ud_t1_26_data_list}], indirect=True)
    def test_rcdcs32_active_2(self,
                      fix_draft_logical_interface):
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.ud_t1_30_data_list, 'num': 3}],
                             indirect=True)
    def test_rcdcs32_get_data_from_historian_3(self,
                                       fix_historian_logical):
        assert not verifyData.res_text['payload'][-1]['rows'][-1][1]
        post_data(verifyData.mqtt_client, data.post_data2)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.ud_t1_30_data_list, 'num': 4}],
                             indirect=True)
    def test_rcdcs32_get_data_from_historian_4(self,
                                       fix_historian_logical):
        assert verifyData.res_text['payload'][-1]['rows'][-1][1]

    @pytest.mark.parametrize('fix_logical_interface', [{'data_list': data.ud_t1_33_data_list}],
                             indirect=True)
    def test_rcdcs32_deactivate2(self,
                             fix_logical_interface):
        time.sleep(1)

    @pytest.mark.parametrize('fix_udf', [{'data_list': data.ud_t1_41_data_list}], indirect=True)
    def test_rcdcs32_delete_udf(self,
                            fix_udf):
        pass
