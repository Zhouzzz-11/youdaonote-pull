from tests.test_e2e_hub import *
from tests.test_e2e_udf import *
from tests.test_e2e import *
from tests.test_e2e_deployer import *
from tests.tasks.test_rcdcs441 import *
from tests.tasks.test_rcdcs713 import *
from tests.tasks.test_rcdcs752 import *
from tests.tasks.test_rcdcs754 import *
from tests.tasks.test_rcdcs756 import *
from tests.tasks.test_rcdcs790 import *
from tests.tasks.test_rcdcs802 import *
from tests.tasks.test_rcdcs815a import *
from tests.tasks.test_rcdcs815b import *
from tests.tasks.test_rcdcs836 import *
from tests.tasks.test_rcdcs965 import *
from tests.tasks.test_rcdcs1051 import *
from tests.tasks2.test_gypt6931 import *
from tests.tasks2.test_gypt8424 import *
from tests.tasks2.test_gypt8512 import *
from tests.tasks2.test_gypt8568 import *
from tests.tasks2.test_gypt8578 import *
from tests.tasks2.gypt8585.gypt8585_e2e_1.test_gypt8585 import *
from tests.tasks2.gypt8585.gypt8585_e2e_1.test_gypt8585_e2e import *
from tests.tasks2.gypt8585.gypt8585_e2e_2.test_gypt8585_property_e2e import *
from tests.tasks2.gypt8585.test_gypt8586 import *
from tests.tasks2.test_gypt8582 import *
from tests.tasks2.test_gypt8594 import *
from tests.tasks2.gypt8579.test_gypt8579a import *
from tests.tasks2.gypt8579.test_gypt8579b import *
from tests.tasks2.test_gypt10927 import *
from tests.tasks2.test_gypt11108 import *
from tests.tasks2.test_gypt15984 import *
from tests.tasks2.test_gypt16765 import *
from tests.tasks2.test_gypt16902 import *
from tests.tasks2.test_gypt20113 import *
from tests.tasks2.test_gypt22008 import *
from tests.tasks2.test_gypt22209 import *
from tests.tasks2.test_gypt22688 import *
from tests.test_get_token import *



@pytest.mark.skipif(test_server not in ['qa', 'pre', 'dev'], reason='only run on qa')
@pytest.mark.demo
class TestGetToken(TGYPT26958GetTokens):
    pass



@pytest.mark.demo2
class TestMetricBefore(TGYPT8582Before):
    pass




@pytest.mark.demo
class TestMultiTenantPrepare(TRCDCS815A, TRCDCS815B):
    pass



@pytest.mark.skip4
class TestMultiTenantQueryHistorian(TRCDCS815APostData, TRCDCS815BPostData):
    pass


#skip3
@pytest.mark.demo
class TestMultiTenantDelete(TRCDCS815ADelete, TRCDCS815BDelete):
    pass


@pytest.mark.demo
class TestPreRegression(TRCDCS274):
    pass


@pytest.mark.demo
class TestSharedTenantPrepare(TGYPT8579A, TGYPT8579B):
    pass


@pytest.mark.skip4
class TestSharedTenantQueryHistorian(TGYPT8579APostData, TGYPT8579BPostData):
    pass


@pytest.mark.skip4
class TestSharedTenantAlarm(TGYPT8579AAlarm, TGYPT8579BAlarm):
    pass


@pytest.mark.demo
class TestRabbitMQConsumerBefore(TGYPT16902ConsumerBefore):
    pass

#TRCDCS1051, TRCDCS1051B, TRCDCS1051C
@pytest.mark.skip4
class TestWindow(TRCDCS1051, TRCDCS1051B, TRCDCS1051C):
    pass



# TGYPT22008

#skip TestRabbitMQConsumerE2E TRCDCS126
@pytest.mark.skip4
class TestRabbitMQConsumerE2E(TRCDCS126):
    pass


@pytest.mark.demo
class TestRabbitMQConsumerAfter(TGYPT16902ConsumerAfter):
    pass

#TestRegression skip TRCDCS221, TGYPT8568, TRCDCS441, TRCDCS802,TRCDCS32
@pytest.mark.demo
class TestRegression(TRCDCS162, TRCDCS173, TRCDCS208, TRCDCS220, TRCDCS790):
    pass



#so many problem
#TestRegression1 skip  TRCDCS752,TRCDCS713,TGYPT11108,TGYPT15984,TGYPT6931,TGYPT8424,TGYPT8594
@pytest.mark.skip4
class TestRegression1(TRCDCS752,TRCDCS754, TRCDCS756, TRCDCS965,
                       TGYPT8512, TGYPT10927, TGYPT16765RuleCRUD,
                       TGYPT20113, TGYPT22688):
    pass

#TestMqttPostData skip  TGYPT8357ReplaceAsset
@pytest.mark.demo
class TestMqttPostData(TGYPT8578Device, TGYPT8578Gateway, TGYPT8578GatewayDevice):
    pass


@pytest.mark.demo
class TestRabbitMQConsumerAlarmBefore(TGYPT17243ConsumerBefore):
    pass


@pytest.mark.demo
class TestAlarm(TRCDCS836, TRCDCS836AlarmEveryTime, TRCDCS836AlarmBecomesTrue, TRCDCS836AlarmPeriod):
    pass


@pytest.mark.demo
class TestRabbitMQConsumerAlarmAfter(TGYPT17243ConsumerAfter):
    pass


@pytest.mark.demo
class TestThing1(TGYPT8585Node1, TGYPT8585):
    pass


@pytest.mark.demo
class TestThing2(TGYPT8585ThingCRUD):
    pass

#skip TestThing3 TGYPT8586ThingE2E
@pytest.mark.demo
class TestThing3(TGYPT8585Node2, TGYPT8585ThingProperty):
    pass


@pytest.mark.demo2
class TestMetricAfter(TGYPT8582After):
    pass


@pytest.mark.demo
class TestClearRegressionEnv(TRCDCS274ClearJob):
    pass




