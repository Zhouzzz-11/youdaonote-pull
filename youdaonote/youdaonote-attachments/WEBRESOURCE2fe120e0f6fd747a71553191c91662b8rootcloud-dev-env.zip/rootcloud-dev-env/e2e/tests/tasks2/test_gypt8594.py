import pytest
from iot.util import my_assert
from iot.verify import verifyData
from iot.hub.data.tasks2 import gypt8594_data as data


class TGYPT8594(object):
    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_2_list}], indirect=True)
    def test_8594_post_device(self,
                              fix_device):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.get_device_by_li_id_list}], indirect=True)
    def test_8594_get_device_by_li_id(self,
                                      fix_device):
        # GYPT-11032
        _payload = verifyData.res_text['payload']
        my_assert(len(_payload), 2)
        my_assert(_payload[0]['name'], data.post_device_data[2])
        my_assert(_payload[0]['deviceId'], data.post_device_data[1])
        my_assert(_payload[1]['name'], data.post_device_data_2[2])
        my_assert( _payload[1]['deviceId'], data.post_device_data_2[1])
