import time
import pytest
from iot import util
from iot.clients.mqtt.help import post_data, get_connection
from iot.hub.data.tasks2 import gypt22008_data as data
from iot.util import my_assert
from iot.verify import verifyData


class TGYPT22008(object):
    """
        GYPT-22008：windows 10s and 30s
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_22008_post_device_type(self,
                                    fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_22008_post_device_type_properties(self,
                                               fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_list}], indirect=True)
    def test_22008_active_pi(self,
                             fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_list}], indirect=True)
    def test_22008_post_device(self,
                               fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        data.query_data_from_historian_list[0]['query_string'] = \
            f"?&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        verifyData.current_time = int(time.time())
        verifyData.current_time = int(verifyData.current_time / 60) * 60 * 1000 + 30000
        data.post_data0['body']['things'][0]['items'][0]['ts'] = verifyData.current_time
        data.post_data1['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 5000
        data.post_data2['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 10000
        data.post_data3['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 15000
        data.post_data4['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 20000
        data.post_data5['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 25000
        data.post_data6['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 30000
        data.post_data7['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 35000
        data.post_data8['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 40000
        data.post_data9['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 45000
        data.post_data10['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 50000
        data.post_data11['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 55000
        data.post_data12['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 60000
        data.post_data13['body']['things'][0]['items'][0]['ts'] = verifyData.current_time + 95000
        post_data(verifyData.mqtt_client, data.post_data0, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data1, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data2, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data3, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data4, sleep_time=0.5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_22008_query_data_from_historian_at_10s(self,
                                                    fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 1.0)
        post_data(verifyData.mqtt_client, data.post_data5, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data6, sleep_time=0.5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 2}], indirect=True)
    def test_22008_query_data_from_historian_at_15s(self,
                                                    fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 1.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][1][1], 5.0)
        post_data(verifyData.mqtt_client, data.post_data7, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data8, sleep_time=0.5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 3}], indirect=True)
    def test_22008_query_data_from_historian_at_20s(self,
                                                    fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 1.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][1][1], 5.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][2][1], 9.0)
        post_data(verifyData.mqtt_client, data.post_data9, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data10, sleep_time=0.5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 4}], indirect=True)
    def test_22008_query_data_from_historian_at_25s(self,
                                                    fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 1.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][1][1], 5.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][2][1], 9.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][3][1], 13.0)
        post_data(verifyData.mqtt_client, data.post_data11, sleep_time=0.5)
        post_data(verifyData.mqtt_client, data.post_data12, sleep_time=0.5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 5}], indirect=True)
    def test_22008_query_data_from_historian_at_30s(self,
                                                    fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][2], 1.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][1][2], 5.0)
        # temperatureB
        my_assert(verifyData.res_text['payload'][0]['rows'][2][1], 15.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][2][2], 9.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][3][2], 13.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][4][2], 17.0)
        post_data(verifyData.mqtt_client, data.post_data13, sleep_time=0.5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 8}], indirect=True)
    def test_22008_query_data_from_historian_at_35s(self,
                                                    fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][2], 1.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][1][2], 5.0)
        # temperatureB
        my_assert(verifyData.res_text['payload'][0]['rows'][2][1], 15.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][2][2], 9.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][3][2], 13.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][4][2], 17.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][5][2], 21.0)
        # temperatureB
        my_assert(verifyData.res_text['payload'][0]['rows'][5][1], 51.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][6][2], 12.0)
        my_assert(verifyData.res_text['payload'][0]['rows'][7][2], 3333.0)
