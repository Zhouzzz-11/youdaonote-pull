import pytest
from iot import util
from iot.hub.data.tasks2.gypt8585.gypt8585_e2e_2 import gypt8585_node2_property_data as node2_data,\
    gypt8585_thing_property_data as data
from iot.verify import verifyData
from iot import requestsData


class TGYPT8585Node2(object):
    """
        GYPT-8585: 物模型一把梭
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': node2_data.post_device_type_list}],
                             indirect=True)
    def test_8585_node2_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': node2_data.post_device_type_properties_list}],
                             indirect=True)
    def test_8585_node2_post_device_type_properties(self,
                                                    fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': node2_data.active_pi_list}], indirect=True)
    def test_8585_node2_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': node2_data.post_device_list}], indirect=True)
    def test_8585_node2_post_device(self,
                              fix_device):
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        data.query_data_from_historian_list[0]['query_string'] = \
            f"?properties={requestsData.historian_properties}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': node2_data.post_li_list}],
                             indirect=True)
    def test_8585_node2_post_li(self,
                          fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_li_properties',
                             [{'data_list': node2_data.post_li_properties_list}],
                             indirect=True)
    def test_8585_node2_post_li_properties(self,
                                     fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': node2_data.active_li_list}], indirect=True)
    def test_8585_node2_active_li(self,
                            fix_draft_logical_interface):
        pass


class TGYPT8585ThingProperty(object):
    """
        GYPT-8585: 物模型一把梭
    """
    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.post_li_list}],
                             indirect=True)
    def test_8585_thing_property_post_li(self,
                                         fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_thing_mapping',
                             [{'data_list': data.post_thing_mapping_list}],
                             indirect=True)
    def test_8585_thing_property_post_thing_mapping(self,
                                                    fix_draft_thing_mapping):
        pass

    @pytest.mark.parametrize('fix_li_properties',
                             [{'data_list': data.post_li_properties_list}],
                             indirect=True)
    def test_8585_thing_property_post_li_properties(self,
                                     fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.active_li_list}], indirect=True)
    def test_8585_thing_property_active_li(self,
                            fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_li_properties', [{'data_list': data.put_li_properties_list}], indirect=True)
    def test_8585_thing_property_put_li_properties(self,
                                    fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.active_li_list}], indirect=True)
    def test_8585_thing_property_active_li1(self,
                             fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_li_properties', [{'data_list': data.delete_li_properties_list}], indirect=True)
    def test_8585_thing_property_delete_li_properties(self,
                                       fix_li_properties):
        pass