import pytest
import time
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks2.gypt8585 import gypt8586_data as data
from iot.verify import verifyData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT8586ThingE2E(object):
    """
        GYPT-8586: thing e2e
    """
    @pytest.mark.parametrize('fix_draft_device_type', [{'data_list': data.post_device_type_list}], indirect=True)
    def test_8586_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties', [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_8586_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.active_pi_list}], indirect=True)
    def test_8586_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_1_list}], indirect=True)
    def test_post_device1(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_2_list}], indirect=True)
    def test_post_device2(self,
                          fix_device):
        verifyData.res_payload2 = verifyData.res_text['payload']
        verifyData.mqtt_client_1 = get_connection(verifyData.res_payload2)

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_3_list}], indirect=True)
    def test_post_device3(self,
                          fix_device):
        verifyData.res_payload3 = verifyData.res_text['payload']
        verifyData.mqtt_client_2 = get_connection(verifyData.res_payload3)

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.post_li_list}], indirect=True)
    def test_8586_post_li(self,
                          fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_thing_mapping', [{'data_list': data.post_thing_mapping_list}], indirect=True)
    def test_8586_post_thing_mapping(self,
                                     fix_draft_thing_mapping):
        pass

    @pytest.mark.parametrize('fix_li_properties', [{'data_list': data.post_li_properties_list}], indirect=True)
    def test_8586_post_li_properties(self,
                                     fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.active_li_list}], indirect=True)
    def test_8586_active_li(self,
                            fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.post_thing_list}], indirect=True)
    def test_8586_post_thing(self,
                             fix_thing):
        pass

    def test_8586_post_data(self):
        post_data(verifyData.mqtt_client, data.post_data1, sleep_time=0.1)
        post_data(verifyData.mqtt_client_1, data.post_data2, sleep_time=0.1)
        post_data(verifyData.mqtt_client_2, data.post_data3, sleep_time=0.1)
        time.sleep(0.5)
        data.query_data_from_pi_historian_1_list[0]['query_string'] = util.get_query_string(data.t)
        data.query_data_from_pi_historian_2_list[0]['query_string'] = util.get_query_string(data.t)
        data.query_data_from_pi_historian_3_list[0]['query_string'] = util.get_query_string(data.t)
        data.query_data_from_thing_historian_list[0]['query_string'] = util.get_query_string(data.t)

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi_historian_1_list, 'num': 1}],
                             indirect=True)
    def test_8586_query_pi_device_1_historian(self,
                                              fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows'][0][1:]
        my_assert(_get_res, data.ver_res_1)

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi_historian_2_list, 'num': 1}],
                             indirect=True)
    def test_8586_query_pi_device_2_historian(self,
                                              fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows'][0][1:]
        my_assert(_get_res, data.ver_res_2)

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi_historian_3_list, 'num': 1}],
                             indirect=True)
    def test_8586_query_pi_device_3_historian(self,
                                              fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows'][0][1:]
        my_assert(_get_res, data.ver_res_3)

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_thing_historian_list, 'num': 3}],
                             indirect=True)
    def test_8586_query_thing_historian(self,
                                        fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows']
        my_assert(_get_res[0][1], 10.0)
        my_assert(_get_res[1][1], 10.0)
        my_assert(_get_res[2][1], 10.0)

    def test_8568_post_data2(self):
        post_data(verifyData.mqtt_client, data.post_data4, sleep_time=0.1)
        post_data(verifyData.mqtt_client_1, data.post_data5, sleep_time=0.1)
        post_data(verifyData.mqtt_client_2, data.post_data6, sleep_time=0.1)

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi_historian_1_list, 'num': 4}],
                             indirect=True)
    def test_8586_query_pi_device_1_historian2(self,
                                               fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows']
        my_assert(_get_res[1][1], '工作')
        my_assert(_get_res[2][1], '离线')

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi_historian_2_list, 'num': 4}],
                             indirect=True)
    def test_8586_query_pi_device_2_historian2(self,
                                               fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows']
        my_assert(_get_res[1][1], '待机')
        my_assert(_get_res[2][1], '离线')

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi_historian_3_list, 'num': 4}],
                             indirect=True)
    def test_8586_query_pi_device_3_historian2(self,
                                               fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows']
        my_assert(_get_res[1][1], '停机')
        my_assert(_get_res[2][1], '离线')

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_thing_historian_list, 'num': 8}],
                             indirect=True)
    def test_8586_query_thing_historian2(self,
                                         fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows']
        my_assert(_get_res[3][2], '工作')