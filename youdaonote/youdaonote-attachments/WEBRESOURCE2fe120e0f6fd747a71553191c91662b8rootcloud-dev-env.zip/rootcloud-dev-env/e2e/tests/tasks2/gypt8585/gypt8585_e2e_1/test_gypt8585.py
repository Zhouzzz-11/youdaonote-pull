import pytest
from iot.hub.data.tasks2.gypt8585.gypt8585_e2e_1 import gypt8585_thing_data as data
from iot.verify import verifyData
from iot.util import my_assert, my_assert_mes


class TGYPT8585ThingCRUD(object):
    @pytest.mark.parametrize('fix_draft_thing_mapping', [{'data_list': data.get_thing_mappings_by_li_id_list}],
                             indirect=True)
    def test_8585_thing_mapping_get_by_li_id(self,
                                             fix_draft_thing_mapping):
        verifyData.thing_mapping_id = verifyData.res_text['payload'][0]['mappingId']
        my_assert(data.gypt8585_data.post_logical_interface_data[2], verifyData.thing_mapping_id)

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.post_thing_list}], indirect=True)
    def test_8585_thing_post(self,
                             fix_thing):
        my_assert(verifyData.res_text['payload']['thingId'], data.post_thing_data[1])
        verifyData.thing_id = verifyData.res_text['payload']['id']

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.get_thing_by_id_list}], indirect=True)
    def test_8585_thing_get_by_id(self,
                                  fix_thing):
        my_assert(verifyData.res_text['payload']['id'], verifyData.thing_id)

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.put_thing_list}], indirect=True)
    def test_8585_thing_put(self,
                            fix_thing):
        my_assert(verifyData.res_text['payload']['description'], data.des_str_put)

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.delete_thing_list}], indirect=True)
    def test_8585_thing_delete(self,
                               fix_thing):
        pass

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.get_thing_by_name_list}], indirect=True)
    def test_8585_thing_get_by_name(self,
                                    fix_thing):
        assert verifyData.res_text['payload'] == []

    @pytest.mark.parametrize('fix_draft_thing_mapping', [{'data_list': data.put_thing_mappings_list}],
                             indirect=True)
    def test_8585_thing_mapping_put(self,
                                    fix_draft_thing_mapping):
        my_assert(verifyData.res_text['payload']['mappingId'], verifyData.thing_mapping_id)
        my_assert(verifyData.res_text['payload']['description'], data.des_str_put)

    @pytest.mark.parametrize('fix_draft_thing_mapping', [{'data_list': data.delete_thing_mapping_list}],
                             indirect=True)
    def test_8585_thing_mapping_delete(self,
                                       fix_draft_thing_mapping):
        pass

    @pytest.mark.parametrize('fix_draft_thing_mapping', [{'data_list': data.get_thing_mapping_by_id_list}],
                             indirect=True)
    def test_8585_thing_mapping_get_by_id(self,
                                          fix_draft_thing_mapping):
        my_assert_mes(verifyData.res_text['message'], data.mes_not_exist)
