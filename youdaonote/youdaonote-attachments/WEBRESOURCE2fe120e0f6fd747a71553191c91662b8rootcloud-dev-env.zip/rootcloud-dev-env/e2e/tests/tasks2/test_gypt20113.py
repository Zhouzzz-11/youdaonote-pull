import time
import pytest
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks2 import gypt20113_data as data
from iot.verify import verifyData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT20113(object):
    """
        GYPT-20113: 修改预置属性位置信息的历史数据保存方式（由变化保存修改成上报保存）
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_20113_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_20113_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_list}], indirect=True)
    def test_20113_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_list}], indirect=True)
    def test_20113_post_device(self,
                              fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        post_data(verifyData.mqtt_client, data.post_data)
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        data.query_data_from_historian_list[0]['query_string'] = f"?startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        time.sleep(data.sleep_time)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_20113_query_data_from_historian(self,
                                             fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1]['city'], "上海城区")
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_20113_query_data_from_historian1(self,
                                             fix_historian_logical):
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 2}], indirect=True)
    def test_20113_query_data_from_historian2(self,
                                             fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][1][1]['city'], "南阳市")

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.put_pi_properties_list}],
                             indirect=True)
    def test_20113_put_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_list}], indirect=True)
    def test_20113_active_pi1(self,
                              fix_draft_physical_interface):
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 3}], indirect=True)
    def test_20113_query_data_from_historian_after_change(self,
                                                          fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][2][1]['city'], "南阳市")
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 4}], indirect=True)
    def test_20113_query_data_from_historian_after_change1(self,
                                                          fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][3][1]['city'], "南阳市")
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 5}], indirect=True)
    def test_20113_query_data_from_historian_after_change2(self,
                                                           fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][4][1]['city'], "上海城区")
