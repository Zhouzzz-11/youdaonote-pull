import pytest
from iot.util import my_assert, my_assert_mes
from iot.hub.data.tasks2 import gypt8568_data as data
from iot.verify import verifyData


class TGYPT8568(object):
    """
        GYPT-8568: device type field: directlyLinked
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_8568_post_device_type(self,
                                   fix_draft_device_type):
        assert not verifyData.res_text['payload']['directlyLinked']

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_gateway_device_type_list}],
                             indirect=True)
    def test_8568_post_gateway_device_type(self,
                                           fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.put_device_type_list}],
                             indirect=True)
    def test_8568_put_device_type(self,
                                  fix_draft_device_type):
        assert not verifyData.res_text['payload']['directlyLinked']

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_2_list}],
                             indirect=True)
    def test_8568_post_device_type_with_direct_link(self,
                                                    fix_draft_device_type):
        assert verifyData.res_text['payload']['directlyLinked']

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.get_device_type_without_direct_link_list}],
                             indirect=True)
    def test_8568_get_device_type_without_direct_link(self,
                                                      fix_draft_device_type):
        my_assert(len(verifyData.res_text['payload']), 2)
        assert not verifyData.res_text['payload'][0]['directlyLinked']
        assert verifyData.res_text['payload'][1]['directlyLinked']

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.get_device_type_with_direct_link_true_list}],
                             indirect=True)
    def test_8568_get_device_type_with_direct_link_true(self,
                                                        fix_draft_device_type):
        my_assert(len(verifyData.res_text['payload']), 1)
        assert verifyData.res_text['payload'][0]['directlyLinked']

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.get_device_type_with_direct_link_false_list}],
                             indirect=True)
    def test_8568_get_device_type_without_direct_link(self,
                                                      fix_draft_device_type):
        my_assert(len(verifyData.res_text['payload']), 1)
        assert not verifyData.res_text['payload'][0]['directlyLinked']

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_without_gateway_id_and_direct_link_list}], indirect=True)
    def test_8568_post_device_without_gateway_id_and_direct_link(self,
                                                                 fix_device):
        my_assert_mes(verifyData.res_text['message'], data.mes_mis_gateway_id)

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_list}], indirect=True)
    def test_8568_post_gateway(self,
                               fix_device):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_with_gateway_list}], indirect=True)
    def test_8568_post_device_with_gateway_id(self,
                                              fix_device):
        my_assert(verifyData.res_text['payload']['deviceId'], data.post_device_data3[1])