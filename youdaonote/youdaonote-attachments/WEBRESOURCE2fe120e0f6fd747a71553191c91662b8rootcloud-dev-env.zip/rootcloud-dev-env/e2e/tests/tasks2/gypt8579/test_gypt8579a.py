import time
import pytest
import json
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks2.gypt8579 import gypt8579a_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT8579A(object):
    @pytest.mark.parametrize('fix_callback', [{'data_list': data.jd_t1_a_1_data_list}], indirect=True)
    def test_8579a_post_job(self,
                           fix_callback):
        time.sleep(5)

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.post_manufacturer_list}], indirect=True)
    def test_8579a_post_manufacturer(self,
                                    fix_manufacturer):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_list}],
                             indirect=True)
    def test_8579a_post_schema(self,
                         fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.query_schema_list}],
                             indirect=True)
    def test_8579a_query_schema(self,
                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.post_event_type_list}],
                             indirect=True)
    def test_8579a_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.query_event_type_list}],
                             indirect=True)
    def test_8579a_query_event_type(self,
                              fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_pi_list}],
                             indirect=True)
    def test_8579a_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_pi_list}], indirect=True)
    def test_8579a_query_schema_for_pi(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_pi_list[0]['data']['schemaId'] = _schema_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.post_expression_for_pi_list}], indirect=True)
    def test_8579a_post_expression_for_pi(self,
                                    fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.post_pi_list}], indirect=True)
    def test_8579a_post_pi(self,
                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.query_pi_list}], indirect=True)
    def test_8579a_query_pi(self,
                      fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_8579a_post_device_type(self,
                              fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.query_device_type_list}], indirect=True)
    def test_8579a_query_device_type(self,
                               fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.active_pi_list}], indirect=True)
    def test_8579a_active_pi(self,
                       fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.post_device_list}],
                             indirect=True)
    def test_8579a_post_device(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.query_device_list}],
                             indirect=True)
    def test_8579a_query_device(self,
                          fix_device):
        my_assert(verifyData.res_text['payload'][requestsData.deviceId], data.post_device_data[1])

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_li_list}],
                             indirect=True)
    def test_8579a_post_schema_for_li(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_li_list}], indirect=True)
    def test_8579a_query_schema_for_li(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_li_list[0]['data'][requestsData.schemaId] = _schema_id

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.post_li_list}], indirect=True)
    def test_8579a_post_li(self,
                     fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.query_li_list}], indirect=True)
    def test_8579a_query_li(self,
                      fix_draft_logical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_logical_interface_data[1])

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.post_expression_list}],
                             indirect=True)
    def test_8579a_post_expression(self,
                             fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.query_expression_list}],
                             indirect=True)
    def test_8579a_query_expression(self,
                              fix_draft_expression):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_expression_for_mapping_tenant_shared_a[1])
        verifyData.expression_id = verifyData.res_text['payload'][0]['expressionId']
        data.post_mapping_list[0]['data'][requestsData.physicalInterfaceId] = verifyData.physical_interface_id
        data.post_mapping_list[0]['data'][requestsData.propertyMappings][
            0][requestsData.expressionId] = verifyData.expression_id

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.post_mapping_list}],
                             indirect=True)
    def test_8579a_post_mapping(self,
                          fix_draft_mapping):
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.query_mapping_list}],
                             indirect=True)
    def test_8579a_query_mapping(self,
                           fix_draft_mapping):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_mapping_data[1])

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.active_li_list}], indirect=True)
    def test_8579a_active_li(self,
                       fix_draft_logical_interface):
        pass


class TGYPT8579APostData(object):
    def test_8579a_set_value(self):
        data.query_data_from_historian_list[0]['query_string'] = f"?properties={requestsData.historian_properties}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_8579a_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 40)


class TGYPT8579AAlarm(object):
    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.query_alarm_severity_list}],
                             indirect=True)
    def test_8579a_query_alarm_severity(self,
                                        fix_alarm_severity):
        pass

    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.post_alarm_category_list}],
                             indirect=True)
    def test_8579a_post_alarm_category(self,
                                       fix_alarm_category):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.post_draft_alarm_type_list}],
                             indirect=True)
    def test_8579a_post_draft_alarm_type(self,
                                         fix_draft_alarm_type):
        _alarm_type_id = verifyData.res_text['payload']['alarmTypeId']
        data.patch_draft_alarm_type_list[0]['id'] = _alarm_type_id
        verifyData.alarm_type_id = _alarm_type_id

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.patch_draft_alarm_type_list}],
                             indirect=True)
    def test_8579a_patch_draft_alarm_type(self,
                                          fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.delete_multi_alarm_list}], indirect=True)
    def test_8579a_delete_tenant_alarm(self,
                                       fix_alarm):
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 1}], indirect=True)
    def test_8579a_query_all_alarm(self,
                                   fix_alarm):
        my_assert(verifyData.res_text['payload'][-1]['alarmTopicId'], verifyData.alarm_type_id)
        my_assert(json.loads(verifyData.res_text['payload'][-1]['variables'])['li_temperature'], 70)

    @pytest.mark.parametrize('fix_callback', [{'data_list': data.jd_a_data_list}], indirect=True)
    def test_8579a_clear_job(self,
                            fix_callback):
        pass
