import time
import pytest
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks2.mqtt4 import gypt8578_data as data
from iot.hub.data.tasks2.mqtt4 import gypt8357_data as data2
from iot.verify import verifyData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT8578Device(object):
    """
        GYPT-8578：4.0协议上数
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_8578_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_8578_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_list}], indirect=True)
    def test_8578_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_list}], indirect=True)
    def test_8578_post_device(self,
                              fix_device):
        _payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(_payload)
        # GYPT-14763: post neg data first then normal data successfully
        post_data(verifyData.mqtt_client, data.post_neg_data)
        time.sleep(1)
        post_data(verifyData.mqtt_client, data.post_data)
        data.query_data_from_historian_list[0]['query_string'] = util.get_query_string(data.ts, data.historian_properties1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_8578_query_data_from_historian(self,
                                            fix_historian_logical):
        #my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 41)
        pass

class TGYPT8578Gateway(object):
    """
        GYPT-8578：4.0协议上数gateway
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_2_list}],
                             indirect=True)
    def test_8578_1_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_2_list}],
                             indirect=True)
    def test_8578_1_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_2_list}], indirect=True)
    def test_8578_1_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_2_list}], indirect=True)
    def test_8578_1_post_device(self,
                              fix_device):
        _payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(_payload)
        post_data(verifyData.mqtt_client, data.post_data2)
        data.query_data_from_historian_2_list[0]['query_string'] = util.get_query_string(data.ts,
                                                                                       data.historian_properties1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_2_list, 'num': 1}], indirect=True)
    def test_8578_1_query_data_from_historian(self,
                                            fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 43)


class TGYPT8578GatewayDevice(object):
    """
        GYPT-8578：4.0协议上数 非直连设备
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_3_list}],
                             indirect=True)
    def test_8578_2_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_3_list}],
                             indirect=True)
    def test_8578_2_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_3_list}], indirect=True)
    def test_8578_2_active_pi(self,
                              fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_3_list}], indirect=True)
    def test_8578_2_post_device(self,
                              fix_device):
        post_data(verifyData.mqtt_client, data.post_data3)
        data.query_data_from_historian_3_list[0]['query_string'] = util.get_query_string(data.ts,
                                                                                         data.historian_properties1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_3_list, 'num': 1}], indirect=True)
    def test_8578_2_query_data_from_historian(self,
                                            fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 45)


class TGYPT8357ReplaceAsset(object):
    """
        GYPT-8357：变更资产id之后上数
    """
    @pytest.mark.parametrize('fix_device', [{'data_list': data2.put_device_list}], indirect=True)
    def test_8357_put_device(self,
                             fix_device):
        _payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(_payload)
        post_data(verifyData.mqtt_client, data2.post_data3)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 2}], indirect=True)
    def test_8578_query_data_from_historian3(self,
                                             fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 41)
        my_assert(verifyData.res_text['payload'][0]['rows'][1][1], 43)