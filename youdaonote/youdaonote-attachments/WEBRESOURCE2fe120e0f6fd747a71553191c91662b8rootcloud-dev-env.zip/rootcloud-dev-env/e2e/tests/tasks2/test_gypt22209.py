import pytest
import time
from iot import util
from iot.hub.data.tasks2 import gypt22209_data as data
from iot.verify import verifyData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT22209(object):
    """
        GYPT-22209: thing e2e
    """
    @pytest.mark.parametrize('fix_draft_device_type', [{'data_list': data.post_device_type_list}], indirect=True)
    def test_22209_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties', [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_22209_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.active_pi_list}], indirect=True)
    def test_22209_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device1_list}], indirect=True)
    def test_post_device1(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device2_list}], indirect=True)
    def test_post_device2(self,
                          fix_device):
        verifyData.res_payload2 = verifyData.res_text['payload']
        verifyData.mqtt_client_1 = get_connection(verifyData.res_payload2)
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        data.query_data_from_pi1_historian_list[0]['query_string'] = \
            f"?&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        data.query_data_from_li_historian_list[0]['query_string'] = \
            f"?&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        data.query_data_from_thing1_historian_list[0]['query_string'] = \
            f"?&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        data.query_data_from_thing2_historian_list[0]['query_string'] = \
            f"?&startTime={verifyData.start_time}&endTime={verifyData.end_time}"

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.post_li1_list}],
                             indirect=True)
    def test_22209_post_li(self,
                           fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_li_properties',
                             [{'data_list': data.post_li1_properties_list}],
                             indirect=True)
    def test_22209_post_li_properties(self,
                                      fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.active_li1_list}], indirect=True)
    def test_22209_active_li(self,
                             fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.post_li_list}], indirect=True)
    def test_22209_post_li_thing(self,
                          fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_thing_mapping', [{'data_list': data.post_thing_mapping_list}], indirect=True)
    def test_22209_post_thing_mapping(self,
                                     fix_draft_thing_mapping):
        pass

    @pytest.mark.parametrize('fix_li_properties', [{'data_list': data.post_li_properties_list}], indirect=True)
    def test_22209_post_li_thing_properties(self,
                                     fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [{'data_list': data.active_li_list}], indirect=True)
    def test_22209_active_li_thing(self,
                            fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_thing', [{'data_list': data.post_thing_list}], indirect=True)
    def test_22209_post_thing(self,
                             fix_thing):
        pass

    def test_22209_post_data(self):
        verifyData.current_time = int(time.time())
        verifyData.current_time = int(verifyData.current_time / 30) * 30 + 60000
        for i in range(len(data.post_data_list1)):
            _data1 = data.post_data_list1[i]
            _data2 = data.post_data_list2[i]
            _data1['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 5000*i
            _data2['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 5000*i
            post_data(verifyData.mqtt_client, _data1, sleep_time=0.1)
            post_data(verifyData.mqtt_client_1, _data2, sleep_time=0.1)

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_pi1_historian_list, 'num': 8}],
                             indirect=True)
    def test_22209_query_pi1_device_historian(self,
                                              fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows'][0][1:]

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_li_historian_list, 'num': 8}],
                             indirect=True)
    def test_22209_query_li_device_historian(self,
                                              fix_historian_logical):
        _get_res = verifyData.res_text['payload'][0]['rows'][0][1:]

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_thing1_historian_list, 'num': 8}],
                             indirect=True)
    def test_22209_query_thing1_historian(self,
                                          fix_historian_logical):
        pass

    @pytest.mark.parametrize('fix_historian_logical',
                             [{'data_list': data.query_data_from_thing2_historian_list, 'num': 8}],
                             indirect=True)
    def test_22209_query_thing2_historian(self,
                                          fix_historian_logical):

        pass
