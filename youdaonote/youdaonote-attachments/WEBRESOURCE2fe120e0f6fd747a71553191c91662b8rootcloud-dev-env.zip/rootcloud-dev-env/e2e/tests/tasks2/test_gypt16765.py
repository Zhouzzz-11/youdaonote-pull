import pytest
from iot.hub.data.tasks2 import gypt16765_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.util import my_assert


class TGYPT16765RuleCRUD(object):
    """
        GYPT-16765: rule
    """

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_li_list}],
                             indirect=True)
    def test_16765_post_schema(self,
                               fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.query_schema_for_li_list}], indirect=True)
    def test_16765_query_schema_for_li(self,
                                       fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_li_list[0]['data'][requestsData.schemaId] = _schema_id

    @pytest.mark.parametrize('fix_draft_logical_interface', [
        {'data_list': data.post_li_list}], indirect=True)
    def test_16765_post_li(self,
                           fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [
        {'data_list': data.query_li_list}], indirect=True)
    def test_16765_query_li_list(self,
                                 fix_draft_logical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_logical_interface_data[1])
        verifyData.logical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.post_rule_list[0]['data']['logicalInterfaceId'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.post_expression_list}],
                             indirect=True)
    def test_16765_post_expression(self,
                                   fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.query_expression_for_li_list}], indirect=True)
    def test_16765_query_expression_for_rule(self,
                                             fix_draft_expression):
        verifyData.expression_id = verifyData.res_text['payload'][0][requestsData.expressionId]
        data.post_rule_list[0]['data']['expressionId'] = verifyData.expression_id

    @pytest.mark.parametrize('fix_draft_rule',
                             [{'data_list': data.post_rule_list}],
                             indirect=True)
    def test_16765_post_rule(self,
                             fix_draft_rule):
        pass

    @pytest.mark.parametrize('fix_draft_rule',
                             [{'data_list': data.query_rule_list}],
                             indirect=True)
    def test_16765_query_rule(self,
                              fix_draft_rule):
        verifyData.rule_id = verifyData.res_text['payload'][0][requestsData.ruleId]
        data.put_rule_list[0]['id'] = verifyData.rule_id
        data.put_rule_list[0]['data']['logicalInterfaceId'] = verifyData.logical_interface_id
        data.put_rule_list[0]['data']['expressionId'] = verifyData.expression_id
        data.delete_rule_list[0]['id'] = verifyData.rule_id

    @pytest.mark.parametrize('fix_draft_rule',
                             [{'data_list': data.put_rule_list}],
                             indirect=True)
    def test_16765_put_rule(self,
                            fix_draft_rule):
        pass

    @pytest.mark.parametrize('fix_draft_rule',
                             [{'data_list': data.delete_rule_list}],
                             indirect=True)
    def test_16765_delete_rule(self,
                               fix_draft_rule):
        pass
