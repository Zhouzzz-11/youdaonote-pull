import pytest
from iot.verify.verifyData import *
from iot.metrics.data import metrics_data as data
from iot.clients.kafka.kafka_help import *
from iot import requestsData
from iot.util import my_assert


class TGYPT8582Before(object):
    @pytest.mark.parametrize('fix_metrics', [{'data_list': data.post_metrics_list}], indirect=True)
    def test_8582_before_post_metric(self,
                                     fix_metrics):
        metric_tenant_dict['tenant_before_num'], metric_tenant_dict['tenant_before_list'] = get_overview_metric()
        metric_device_dict['device_before_num'] = get_detail_metric()
        print(metric_tenant_dict)
        print(metric_device_dict)


class TGYPT8582After(object):
    @pytest.mark.parametrize('fix_metrics', [{'data_list': data.post_metrics_list}], indirect=True)
    def test_8582_after_post_metric(self,
                                    fix_metrics):
        metric_tenant_dict['tenant_after_num'], metric_tenant_dict['tenant_after_list'] = get_overview_metric()
        metric_device_dict['device_after_num'] = get_detail_metric()
        for i in tenant_list:
            if i in metric_tenant_dict['tenant_before_list']:
                metric_tenant_dict['tenant_before_num'] -= 1
        my_assert(metric_tenant_dict['tenant_after_num'] - metric_tenant_dict['tenant_before_num'], len(requestsData.tenant_list))
        print(metric_tenant_dict)
        print(metric_device_dict)
