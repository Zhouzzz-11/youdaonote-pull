import pytest
from iot.util import my_assert
from iot.verify import verifyData
from iot.hub.data.tasks2 import gypt8512_data as data


class TGYPT8512(object):
    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.post_manufacturer_list}], indirect=True)
    def test_8512_post_manufacturer(self,
                                    fix_manufacturer):
        pass

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.post_manufacturer_1_list}], indirect=True)
    def test_8512_post_manufacturer_with_invalid_len(self,
                                                     fix_manufacturer):
        my_assert(verifyData.res_text['message'], data.mes_invalid_manufacturer)

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.post_manufacturer_2_list}], indirect=True)
    def test_8512_post_manufacturer_invalid_start_char(self,
                                                       fix_manufacturer):
        my_assert(verifyData.res_text['message'], data.mes_invalid_manufacturer)

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.query_manufacturer_by_name_list}], indirect=True)
    def test_8512_query_manufacturer_by_name(self,
                                             fix_manufacturer):
        my_assert(verifyData.res_text['payload'][0]['manufacturerId'], data.manufacturer_id)
        my_assert(verifyData.res_text['payload'][0]['name'], data.manufacturer_name)

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.put_manufacturer_list}], indirect=True)
    def test_8512_put_manufacturer(self,
                                   fix_manufacturer):
        my_assert(verifyData.res_text['payload']['manufacturerId'], data.manufacturer_id)
        my_assert(verifyData.res_text['payload']['name'], data.put_manufacturer_data['name'])

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.delete_manufacturer_list}], indirect=True)
    def test_8512_delete_manufacturer(self,
                                      fix_manufacturer):
        pass

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.query_manufacturer_by_id_list}], indirect=True)
    def test_8512_query_manufacturer_by_id(self,
                                           fix_manufacturer):
        pass