import pytest
from iot.util import my_assert
from iot.requestsData import rabbitMq_dict, test_server
from iot.clients.rabbitMQ.rabbitmq import RabbitMqClient


class TGYPT16902ConsumerBefore(object):
    """
        RabbitMQ Consumer before test
    """
    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_16902_consume_rabbitmq_thing_sync(self):
        queue = rabbitMq_dict['thing_sync']['queue']
        exchange = rabbitMq_dict['thing_sync']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange)
        _ = rabbitMqClient.consumer_mes()

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_16902_consume_rabbitmq_thing_del(self):
        queue = rabbitMq_dict['thing_del']['queue']
        exchange = rabbitMq_dict['thing_del']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange)
        _ = rabbitMqClient.consumer_mes()

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_16902_consume_rabbitmq_device(self):
        queue = rabbitMq_dict['device']['queue']
        exchange = rabbitMq_dict['device']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange)
        _ = rabbitMqClient.consumer_mes()


class TGYPT16902ConsumerAfter(object):
    """
        RabbitMQ Consumer after test
    """

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_16902_consume_rabbitmq_thing_sync(self):
        queue = rabbitMq_dict['thing_sync']['queue']
        exchange = rabbitMq_dict['thing_sync']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange)
        consumer = rabbitMqClient.consumer_mes()
        my_assert(len(consumer), 6)

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_16902_consume_rabbitmq_thing_del(self):
        queue = rabbitMq_dict['thing_del']['queue']
        exchange = rabbitMq_dict['thing_del']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange)
        consumer = rabbitMqClient.consumer_mes()
        my_assert(len(consumer), 1)

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_16902_consume_rabbitmq_device(self):
        queue = rabbitMq_dict['device']['queue']
        exchange = rabbitMq_dict['device']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange)
        consumer = rabbitMqClient.consumer_mes()
        my_assert(len(consumer), 1)


class TGYPT17243ConsumerBefore:
    """
        RabbitMQ Consumer Alarm before test
    """
    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_17243_consume_rabbitmq_alarm_open(self):
        queue = rabbitMq_dict['alarm_open']['queue']
        exchange = rabbitMq_dict['alarm_open']['exchange']
        routing = rabbitMq_dict['alarm_open']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange, routing_key=routing)
        _ = rabbitMqClient.consumer_mes()

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_17243_consume_rabbitmq_alarm_close(self):
        queue = rabbitMq_dict['alarm_close']['queue']
        exchange = rabbitMq_dict['alarm_close']['exchange']
        routing = rabbitMq_dict['alarm_close']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange, routing_key=routing)
        _ = rabbitMqClient.consumer_mes()


class TGYPT17243ConsumerAfter:
    """
        RabbitMQ Consumer Alarm after test
    """
    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_17243_consume_rabbitmq_alarm_open(self):
        queue = rabbitMq_dict['alarm_open']['queue']
        exchange = rabbitMq_dict['alarm_open']['exchange']
        routing = rabbitMq_dict['alarm_open']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange, routing_key=routing)
        consumer = rabbitMqClient.consumer_mes()
        my_assert(len(consumer), 7)

    @pytest.mark.skipif(not test_server == 'localhost', reason='only run on local')
    def test_17243_consume_rabbitmq_alarm_close(self):
        queue = rabbitMq_dict['alarm_close']['queue']
        exchange = rabbitMq_dict['alarm_close']['exchange']
        routing = rabbitMq_dict['alarm_close']['exchange']
        rabbitMqClient = RabbitMqClient(queue, exchange, routing_key=routing)
        consumer = rabbitMqClient.consumer_mes()
        my_assert(len(consumer), 8)