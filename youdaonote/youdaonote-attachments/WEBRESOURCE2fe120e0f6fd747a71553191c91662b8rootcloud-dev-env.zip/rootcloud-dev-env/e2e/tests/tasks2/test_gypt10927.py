import pytest
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks2 import gypt10927_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT10927(object):
    """
        GYPT-10927: test schema property change type from num to string
    """
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_list}],
                             indirect=True)
    def test_10927_post_schema(self,
                             fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.query_schema_list}],
                             indirect=True)
    def test_10927_query_schema(self,
                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id
        data.put_schema_list[0]['id'] = verifyData.schema_id
        data.put_schema_to_boolean_list[0]['id'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.post_event_type_list}],
                             indirect=True)
    def test_10927_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.query_event_type_list}],
                             indirect=True)
    def test_10927_query_event_type(self,
                              fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_pi_list}],
                             indirect=True)
    def test_10927_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_pi_list}], indirect=True)
    def test_10927_query_schema_for_pi(self,
                                 fix_draft_schema):
        verifyData.schema_pi_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_pi_list[0]['data']['schemaId'] = verifyData.schema_pi_id
        data.put_schema_list[1]['id'] = verifyData.schema_pi_id
        data.put_schema_to_boolean_list[1]['id'] = verifyData.schema_pi_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.post_expression_for_pi_list}], indirect=True)
    def test_10927_post_expression_for_pi(self,
                                    fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.post_pi_list}], indirect=True)
    def test_10927_post_pi(self,
                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.query_pi_list}], indirect=True)
    def test_10927_query_pi(self,
                      fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_10927_post_device_type(self,
                              fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.query_device_type_list}], indirect=True)
    def test_10927_query_device_type(self,
                               fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.active_pi_list}], indirect=True)
    def test_10927_active_pi(self,
                          fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.post_device_list}],
                             indirect=True)
    def test_10927_post_device(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        data.query_data_from_historian_list[0]['query_string'] = f"?properties={requestsData.historian_properties1}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        data.query_data_from_historian_list[0]['logicaltype_id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.query_device_list}],
                             indirect=True)
    def test_10927_query_device(self,
                          fix_device):
        my_assert(verifyData.res_text['payload'][requestsData.deviceId], data.post_device_data[1])
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_10927_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 31)

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.put_schema_list}], indirect=True)
    def test_10927_put_schema(self,
                              fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.active_pi_list}], indirect=True)
    def test_10927_active_pi_after_retype(self,
                                          fix_draft_physical_interface):
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 2}], indirect=True)
    def test_10927_query_str_data_from_historian(self,
                                                 fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][1][1], 'abc')

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.put_schema_to_boolean_list}], indirect=True)
    def test_19698_put_schema(self,
                              fix_draft_schema):
        #TODO: GYPT-13516
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.active_pi_list}], indirect=True)
    def test_19698_active_pi_after_retype(self,
                                          fix_draft_physical_interface):
        post_data(verifyData.mqtt_client, data.post_data2)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 3}], indirect=True)
    def test_19698_query_boolean_data_from_historian(self,
                                                     fix_historian_logical):
        assert not verifyData.res_text['payload'][0]['rows'][2][1]
        post_data(verifyData.mqtt_client, data.post_data3)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 4}], indirect=True)
    def test_19698_query_boolean_data_from_historian2(self,
                                                      fix_historian_logical):
        assert verifyData.res_text['payload'][0]['rows'][3][1]
        post_data(verifyData.mqtt_client, data.post_data4)

    @pytest.mark.parametrize('fix_historian_logical', [
            {'data_list': data.query_data_from_historian_list, 'num': 5}], indirect=True)
    def test_19698_query_boolean_data_from_historian3(self,
                                                      fix_historian_logical):
        assert verifyData.res_text['payload'][0]['rows'][4][1]
