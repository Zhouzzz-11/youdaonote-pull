import pytest
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks2 import gypt6931_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TGYPT6931(object):
    """
        GYPT6931：expression priority
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_6931_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_6931_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_list}], indirect=True)
    def test_6931_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_list}], indirect=True)
    def test_6931_post_device(self,
                              fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        data.query_data_from_historian_list[0]['query_string'] = \
            f"?properties={requestsData.historian_properties2}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.post_li_list}],
                             indirect=True)
    def test_6931_post_li(self,
                          fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_li_properties',
                             [{'data_list': data.post_li_properties_list}],
                             indirect=True)
    def test_6931_post_li_properties(self,
                                     fix_li_properties):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.get_device_by_id}], indirect=True)
    def test_19635_get_first_data_time(self,
                                         fix_device):
        """
            GYPT-19635: 设备接入时长
        """
        assert not verifyData.res_text['payload'].get('firstDataTime', False)

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.get_device_status_by_id}], indirect=True)
    def test_19635_get_first_data_time_by_status(self,
                                                 fix_device_status):
        assert not verifyData.res_text['payload'].get('firstDataTime', False)

    @pytest.mark.parametrize('fix_draft_logical_interface',
                             [{'data_list': data.active_li_list}], indirect=True)
    def test_6931_active_li(self,
                            fix_draft_logical_interface):
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.get_device_status_by_id}], indirect=True)
    def test_19635_get_first_data_time_by_status_after_post_data(self,
                                                                 fix_device_status):
        assert verifyData.res_text['payload']['firstDataTime']

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_6931_query_data_from_historian(self,
                                            fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 49)
