import time
import pytest
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks import rcdcs965_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS965(object):
    """
        RCDCS-965：support binary,json,array as the property of the data
    """
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_list}],
                             indirect=True)
    def test_965_post_schema(self,
                             fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.query_schema_list}],
                             indirect=True)
    def test_965_query_schema(self,
                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.post_event_type_list}],
                             indirect=True)
    def test_965_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_pi_list}],
                             indirect=True)
    def test_965_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_pi_list}], indirect=True)
    def test_965_query_schema_for_pi(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_pi_list[0]['data']['schemaId'] = _schema_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.post_expression_for_pi_bin_list}], indirect=True)
    def test_965_post_expression_for_pi_bin(self,
                                            fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.post_expression_for_pi_array_list}],
                             indirect=True)
    def test_965_post_expression_for_pi_array(self,
                                              fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][1]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.post_expression_for_pi_json_list}],
                             indirect=True)
    def test_965_post_expression_for_pi_json(self,
                                             fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][2]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.post_pi_list}], indirect=True)
    def test_965_post_pi(self,
                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.query_pi_list}], indirect=True)
    def test_965_query_pi(self,
                      fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_965_post_device_type(self,
                              fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.query_device_type_list}], indirect=True)
    def test_965_query_device_type(self,
                               fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.active_pi_list}], indirect=True)
    def test_965_active_pi(self,
                       fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.post_device_list}],
                             indirect=True)
    def test_965_post_device(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.query_device_list}],
                             indirect=True)
    def test_965_query_device(self,
                          fix_device):
        assert verifyData.res_text['payload'][requestsData.deviceId] == data.post_device_data[1]

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_li_list}],
                             indirect=True)
    def test_965_post_schema_for_li(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_li_list}], indirect=True)
    def test_965_query_schema_for_li(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_li_list[0]['data'][requestsData.schemaId] = _schema_id

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.post_li_list}], indirect=True)
    def test_965_post_li(self,
                     fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.query_li_list}], indirect=True)
    def test_965_query_li(self,
                      fix_draft_logical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_logical_interface_data[1])

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.post_expression_for_mapping_bin_list}],
                             indirect=True)
    def test_965_post_expression_for_mapping_bin(self,
                                                 fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_mapping_list[0]['data'][requestsData.physicalInterfaceId] = verifyData.physical_interface_id
        data.post_mapping_list[0]['data'][requestsData.propertyMappings][0][requestsData.expressionId] =\
            _expression_id

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.post_expression_for_mapping_array_list}],
                             indirect=True)
    def test_965_post_expression_for_mapping_array(self,
                                                   fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_mapping_list[0]['data'][requestsData.propertyMappings][1][requestsData.expressionId] = \
            _expression_id

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.post_expression_for_mapping_json_list}],
                             indirect=True)
    def test_965_post_expression_for_mapping_json(self,
                                                  fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_mapping_list[0]['data'][requestsData.propertyMappings][2][requestsData.expressionId] = \
            _expression_id

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.post_mapping_list}],
                             indirect=True)
    def test_965_post_mapping(self,
                          fix_draft_mapping):
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.query_mapping_list}],
                             indirect=True)
    def test_965_query_mapping(self,
                           fix_draft_mapping):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_mapping_data[1])

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.active_li_list}], indirect=True)
    def test_965_active_li(self,
                       fix_draft_logical_interface):
        data.query_data_from_historian_list[0]['query_string'] = util.get_query_string(data.t)
        time.sleep(1)
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.query_data_from_historian_list, 'num': 3}], indirect=True)
    def test_965_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        _res_row = verifyData.res_text['payload'][0]['rows']
        for i in range(len(_res_row)):
            my_assert(_res_row[i][1:], data.ver_data[i])
