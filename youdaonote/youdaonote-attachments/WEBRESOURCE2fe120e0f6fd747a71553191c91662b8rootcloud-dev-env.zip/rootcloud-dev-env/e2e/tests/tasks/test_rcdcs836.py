import json
import pytest
from iot import util
from iot.util import my_assert, my_assert_mes
from iot.hub.data.tasks import rcdcs836_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS836(object):
    """
        RCDCS-836: test alarm e2e
    """
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_list}],
                             indirect=True)
    def test_836_post_schema(self,
                         fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.query_schema_list}],
                             indirect=True)
    def test_836_query_schema(self,
                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.post_event_type_list}],
                             indirect=True)
    def test_836_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.query_event_type_list}],
                             indirect=True)
    def test_836_query_event_type(self,
                              fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_pi_list}],
                             indirect=True)
    def test_836_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_pi_list}], indirect=True)
    def test_836_query_schema_for_pi(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_pi_list[0]['data']['schemaId'] = _schema_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.post_expression_for_pi_list}], indirect=True)
    def test_836_post_expression_for_pi(self,
                                    fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.post_pi_list}], indirect=True)
    def test_836_post_pi(self,
                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.query_pi_list}], indirect=True)
    def test_836_query_pi(self,
                      fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_836_post_device_type(self,
                              fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.query_device_type_list}], indirect=True)
    def test_836_query_device_type(self,
                               fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.active_pi_list}], indirect=True)
    def test_836_active_pi(self,
                          fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.post_device_list}],
                             indirect=True)
    def test_836_post_device(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.query_device_list}],
                             indirect=True)
    def test_836_query_device(self,
                          fix_device):
        my_assert(verifyData.res_text['payload'][requestsData.deviceId], data.post_device_data[1])
        data.query_data_from_historian_list[0]['query_string'] = f"?properties={requestsData.historian_properties1}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        data.query_data_from_historian_list[0]['logicaltype_id'] = verifyData.physical_interface_id
        data.query_realtime_data_with_li_di[0]['logicaltype_id'] = verifyData.physical_interface_id
        data.post_draft_alarm_type_list[0]['data']['logicalInterfaceId'] = verifyData.physical_interface_id
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_836_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 30)


class TRCDCS836AlarmEveryTime(object):
    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.query_alarm_severity_list}],
                             indirect=True)
    def test_836_1_query_alarm_severity(self,
                                       fix_alarm_severity):
        pass

    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.post_alarm_category_list}],
                             indirect=True)
    def test_836_1_post_alarm_category(self,
                                       fix_alarm_category):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.post_draft_alarm_type_list}],
                             indirect=True)
    def test_836_1_post_draft_alarm_type(self,
                                         fix_draft_alarm_type):
        _alarm_type_id = verifyData.res_text['payload']['alarmTypeId']
        data.patch_draft_alarm_type_list[0]['id'] = _alarm_type_id
        verifyData.alarm_type_id = _alarm_type_id

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.patch_draft_alarm_type_list}],
                             indirect=True)
    def test_836_1_patch_draft_alarm_type(self,
                                          fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.delete_multi_alarm_list}], indirect=True)
    def test_836_1_delete_tenant_alarm(self,
                                       fix_alarm):
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 1}], indirect=True)
    def test_836_1_query_all_alarm(self,
                                   fix_alarm):
        my_assert(verifyData.res_text['payload'][-1]['alarmTopicId'], verifyData.alarm_type_id)
        my_assert(json.loads(verifyData.res_text['payload'][-1]['variables'])['temperature'], 60)
        verifyData.alarm_id = verifyData.res_text['payload'][-1]['id']
        data.query_alarm_count_with_type_list[0]['query_string'] = f"?typeIds=[\"{verifyData.physical_interface_id}\"]"
        data.query_alarm_count_with_device_and_type_list[0]['type_id'] = verifyData.physical_interface_id
        data.query_alarm_with_id_list[0]['alarm_id'] = verifyData.alarm_id
        data.put_alarm_with_id_list[0]['alarm_id'] = verifyData.alarm_id
        data.delete_alarm_with_id_list[0]['alarm_id'] = verifyData.alarm_id
        data.query_alarm_after_delete_list[0]['alarm_id'] = verifyData.alarm_id
        data.put_draft_alarm_type_2_list[0]['id'] = verifyData.alarm_type_id
        data.put_draft_alarm_type_2_list[0]['data']['logicalInterfaceId'] = verifyData.physical_interface_id
        data.put_draft_alarm_type_3_list[0]['id'] = verifyData.alarm_type_id
        data.put_draft_alarm_type_3_list[0]['data']['logicalInterfaceId'] = verifyData.physical_interface_id
        data.put_draft_alarm_type_4_list[0]['id'] = verifyData.alarm_type_id
        data.put_draft_alarm_type_4_list[0]['data']['logicalInterfaceId'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_with_subject_list, 'num': 1}],
                             indirect=True)
    def test_836_1_query_all_alarm_with_subject(self,
                                                fix_alarm):
        my_assert(verifyData.res_text['payload'][-1]['alarmTopicId'], verifyData.alarm_type_id)
        my_assert(json.loads(verifyData.res_text['payload'][-1]['variables'])['temperature'], 60)
        # test GYPT-17890:断线缓存
        post_data(verifyData.mqtt_client, data.post_data1_history, topic=requestsData.topic_dict['history_1.1'])

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 1}],
                             indirect=True)
    def test_836_1_query_alarm_count_with_type(self,
                                               fix_alarm):
        my_assert(verifyData.res_text['payload']['totalNum'], 1)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.query_data_from_historian_list, 'num': 3}],
                             indirect=True)
    def test_17890_query_history(self,
                                 fix_historian_logical):
        pass

    @pytest.mark.parametrize('fix_realtime', [{'data_list': data.query_realtime_data_with_li_di}],
                             indirect=True)
    def test_17890_query_realtime(self,
                                  fix_realtime):
        my_assert(verifyData.res_text['payload'][0]['data']['temperature']['value'], 60)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_device_and_type_list,
                                            'count': 1}],
                             indirect=True)
    def test_836_1_query_alarm_count_with_device_and_type(self,
                                                          fix_alarm):
        my_assert(verifyData.res_text['payload']['totalNum'], 1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_with_id_list, 'num': 1}],
                             indirect=True)
    def test_836_1_query_alarm_with_id(self,
                                       fix_alarm):
        my_assert(verifyData.res_text['payload']['alarmTopicId'], verifyData.alarm_type_id)
        my_assert(json.loads(verifyData.res_text['payload']['variables'])['temperature'], 60)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.put_alarm_with_id_list}],
                             indirect=True)
    def test_836_1_close_alarm_with_id(self,
                                       fix_alarm):
        assert verifyData.res_text['payload']['closed']

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.delete_alarm_with_id_list}],
                             indirect=True)
    def test_836_1_delete_alarm_with_id(self,
                                        fix_alarm):
        pass

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_with_id_list, 'num': 0}],
                             indirect=True)
    def test_836_1_query_alarm_with_id(self,
                                       fix_alarm):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 0}], indirect=True)
    def test_836_1_query_all_alarm_1(self,
                                     fix_alarm):
        assert verifyData.res_text['payload'] == []
        post_data(verifyData.mqtt_client, data.post_data1_disorder)
        post_data(verifyData.mqtt_client, data.post_data1_disorder)

    # GYPT-21651: 乱序的工况直接扔掉
    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 1}], indirect=True)
    def test_21651_query_all_alarm_1(self,
                                     fix_alarm):
        my_assert(len(verifyData.res_text['payload']), 1)
        post_data(verifyData.mqtt_client, data.post_data1_disorder)
        post_data(verifyData.mqtt_client, data.post_data1_disorder1)
        post_data(verifyData.mqtt_client, data.post_data1_disorder2)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 2}], indirect=True)
    def test_21651_query_all_alarm_2(self,
                                     fix_alarm):
        my_assert(len(verifyData.res_text['payload']), 2)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.delete_multi_alarm_list}], indirect=True)
    def test_836_1_delete_multi_alarm(self,
                                      fix_alarm):
        pass

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 0}], indirect=True)
    def test_836_1_query_all_alarm_after_delete_multi_alarm(self,
                                                            fix_alarm):
        assert verifyData.res_text['payload'] == []


class TRCDCS836AlarmBecomesTrue(object):
    # update alarm type
    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.put_draft_alarm_type_2_list}],
                             indirect=True)
    def test_836_2_put_draft_alarm_type(self,
                                        fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.patch_draft_alarm_type_list}],
                             indirect=True)
    def test_836_2_patch_draft_alarm_type(self,
                                          fix_draft_alarm_type):
        post_data(verifyData.mqtt_client, data.post_data21)
        post_data(verifyData.mqtt_client, data.post_data22)
        post_data(verifyData.mqtt_client, data.post_data23)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 1}],
                             indirect=True)
    def test_836_2_query_alarm_count_with_type(self,
                                               fix_alarm):
        my_assert(verifyData.res_text['payload']['totalNum'], 1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 1}], indirect=True)
    def test_836_2_query_all_alarm(self,
                                   fix_alarm):
        _alarm_id_1 = verifyData.res_text['payload'][0]['id']
        data.put_alarm_with_id_2_list[0]['alarm_id'] = _alarm_id_1

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.put_alarm_with_id_2_list}],
                             indirect=True)
    def test_836_2_close_alarm_with_id(self,
                                       fix_alarm):
        assert verifyData.res_text['payload']['closed']

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 1}],
                             indirect=True)
    def test_836_2_query_alarm_count_with_type_after_close(self,
                                                           fix_alarm):
        my_assert(verifyData.res_text['payload']['totalNum'], 1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.delete_multi_alarm_list}], indirect=True)
    def test_836_2_delete_multi_alarm_for_becomes_true(self,
                                                       fix_alarm):
        pass

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 0}], indirect=True)
    def test_836_2_query_all_alarm_after_delete_multi_alarm(self,
                                                            fix_alarm):
        assert verifyData.res_text['payload'] == []


class TRCDCS836AlarmPeriod(object):
    # update alarm type
    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.put_draft_alarm_type_3_list}],
                             indirect=True)
    def test_836_3_put_draft_alarm_type_with_period(self,
                                                    fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.patch_draft_alarm_type_list}],
                             indirect=True)
    def test_836_3_patch_draft_alarm_type(self,
                                          fix_draft_alarm_type):
        post_data(verifyData.mqtt_client, data.post_data31, sleep_time=0.1)
        post_data(verifyData.mqtt_client, data.post_data32, sleep_time=0.1)
        post_data(verifyData.mqtt_client, data.post_data33, sleep_time=1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 1}],
                             indirect=True)
    def test_836_3_query_alarm_count_with_type(self,
                                               fix_alarm):
        my_assert(verifyData.res_text['payload']['totalNum'], 1)
        post_data(verifyData.mqtt_client, data.post_data34, sleep_time=0.1)
        post_data(verifyData.mqtt_client, data.post_data35, sleep_time=0.1)
        post_data(verifyData.mqtt_client, data.post_data36, sleep_time=1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 3}],
                             indirect=True)
    def test_836_3_query_alarm_count_with_type_2(self,
                                              fix_alarm):
        my_assert(verifyData.res_text['payload']['totalNum'], 3)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.delete_multi_alarm_list}], indirect=True)
    def test_836_3_delete_multi_alarm(self,
                                      fix_alarm):
        pass

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_all_alarm_list, 'num': 0}], indirect=True)
    def test_836_3_query_all_alarm_after_delete_multi_alarm(self,
                                                            fix_alarm):
        assert verifyData.res_text['payload'] == []


class TRCDCS836Alarm2(object):
    # update alarm type
    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.put_draft_alarm_type_4_list}],
                             indirect=True)
    def test_836_4_put_draft_alarm_type_with_period(self,
                                                    fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.patch_draft_alarm_type_list}],
                             indirect=True)
    def test_836_4_patch_draft_alarm_type(self,
                                          fix_draft_alarm_type):
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 1}],
                             indirect=True)
    def test_836_4_query_alarm_count_with_type_3(self,
                                                 fix_alarm):
        assert verifyData.res_text['payload']['totalNum'] == 1
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)

        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)
        post_data(data.post_data3, verifyData.res_payload, 1)

    @pytest.mark.parametrize('fix_alarm', [{'data_list': data.query_alarm_count_with_type_list, 'count': 2}],
                             indirect=True)
    def test_836_5_query_alarm_count_with_type_3(self,
                                                 fix_alarm):
        assert verifyData.res_text['payload']['totalNum'] == 1
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)
        post_data(data.post_data4, verifyData.res_payload, 1)