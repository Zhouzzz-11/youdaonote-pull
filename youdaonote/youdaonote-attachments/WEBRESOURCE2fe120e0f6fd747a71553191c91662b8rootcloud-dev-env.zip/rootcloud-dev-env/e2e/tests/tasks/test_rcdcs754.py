import pytest
from iot.hub.data.tasks import rcdcs754_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.util import my_assert


class TRCDCS754(object):
    def test_set_value_754(self):
        data.query_data_from_actionable_list[0]['query_string'] = f"?properties={requestsData.actionable_properties}" \
            f"&startTime={verifyData.e2e_start_time}&endTime={verifyData.e2e_end_time}"
        data.query_data_from_actionable_list[0]['actionable_id'] = verifyData.e2e_actionable_id
        data.patch_actionable_data_list[0]['actionable_id'] = verifyData.e2e_actionable_id

        data.query_data_with_agg_from_device_type_list[0]['query_string'] = f"?startTime={verifyData.e2e_start_time}" \
            f"&endTime={verifyData.e2e_end_time}&devices=[\"{data.device_id}\"]&timeInterval=10000m" \
            f"&aggProperties=[\"FIRST(li_temperature)\"]"

        data.query_data_device_set_with_device_type_list[0]['query_string'] = f"?startTime={verifyData.e2e_start_time}" \
            f"&endTime={verifyData.e2e_end_time}&devices=[\"{data.device_id}\"]&" \
            f"properties={requestsData.historian_properties}"

        data.query_data_with_device_id_type_list[0]['query_string'] = f"?startTime={verifyData.e2e_start_time}" \
            f"&endTime={verifyData.e2e_end_time}&properties={requestsData.historian_properties}"

    @pytest.mark.parametrize('fix_historian_actionable', [
                             {'data_list': data.query_data_from_actionable_list, 'num': 3}], indirect=True)
    def test_query_data_with_actionable_id(self,
                                           fix_historian_actionable):
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_res_4)
        _time = verifyData.res_text['payload'][0]['rows'][-1][0]
        data.patch_actionable_data_list[0]['data'][0]['time'] = _time

    @pytest.mark.parametrize('fix_historian_actionable', [{'data_list': data.patch_actionable_data_list}],
                             indirect=True)
    def test_patch_data_with_actionable_id(self,
                                           fix_historian_actionable):
        pass

    @pytest.mark.parametrize('fix_historian_actionable', [
        {'data_list': data.query_data_from_actionable_list, 'num': 3}], indirect=True)
    def test_query_patch_data_with_actionable_id(self,
                                                 fix_historian_actionable):
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_data_7)
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][0],\
               data.patch_actionable_data[0]['time'])
