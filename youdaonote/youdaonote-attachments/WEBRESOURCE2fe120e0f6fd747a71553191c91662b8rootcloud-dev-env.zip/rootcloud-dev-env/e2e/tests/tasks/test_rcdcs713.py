import pytest
from iot import util
from iot.util import my_assert
from iot.hub.data.tasks import rcdcs713_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS713(object):
    """
        RCDCS-713：Default_event regression
        RCDCS-988: introduction support min/max verify
    """
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_list}],
                             indirect=True)
    def test_713_post_schema(self,
                         fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.query_schema_list}],
                             indirect=True)
    def test_713_query_schema(self,
                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.post_event_type_list}],
                             indirect=True)
    def test_713_post_event_type(self,
                             fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_event_type',
                             [{'data_list': data.query_event_type_list}],
                             indirect=True)
    def test_713_query_event_type(self,
                              fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_pi_list}],
                             indirect=True)
    def test_713_post_schema_for_pi(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_pi_list}], indirect=True)
    def test_713_query_schema_for_pi(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_pi_list[0]['data']['schemaId'] = _schema_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': data.post_expression_for_pi_list}], indirect=True)
    def test_713_post_expression_for_pi(self,
                                    fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.post_pi_list}], indirect=True)
    def test_713_post_pi(self,
                     fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.query_pi_list}], indirect=True)
    def test_713_query_pi(self,
                      fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_physical_interface_data[1])
        verifyData.physical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]
        data.post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_713_post_device_type(self,
                              fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': data.query_device_type_list}], indirect=True)
    def test_713_query_device_type(self,
                               fix_draft_device_type):
        my_assert(verifyData.res_text['payload'][requestsData.deviceTypeId], data.post_device_type_data[1])

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': data.active_pi_list}], indirect=True)
    def test_713_active_pi(self,
                       fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.post_device_list}],
                             indirect=True)
    def test_713_post_device(self,
                         fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': data.query_device_list}],
                             indirect=True)
    def test_713_query_device(self,
                          fix_device):
        my_assert(verifyData.res_text['payload'][requestsData.deviceId], data.post_device_data[1])

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': data.post_schema_for_li_list}],
                             indirect=True)
    def test_713_post_schema_for_li(self,
                                fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': data.query_schema_for_li_list}], indirect=True)
    def test_713_query_schema_for_li(self,
                                 fix_draft_schema):
        _schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_li_list[0]['data'][requestsData.schemaId] = _schema_id

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.post_li_list}], indirect=True)
    def test_713_post_li(self,
                     fix_draft_logical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.query_li_list}], indirect=True)
    def test_713_query_li(self,
                      fix_draft_logical_interface):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_logical_interface_data[1])
        verifyData.logical_interface_id = verifyData.res_text['payload'][0][requestsData.interfaceId]

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.post_expression_list}],
                             indirect=True)
    def test_713_post_expression(self,
                             fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_expression',
                             [{'data_list': data.query_expression_list}],
                             indirect=True)
    def test_713_query_expression(self,
                              fix_draft_expression):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_expression_for_mapping[1])
        verifyData.expression_id = verifyData.res_text['payload'][0]['expressionId']
        data.post_mapping_list[0]['data'][requestsData.physicalInterfaceId] = verifyData.physical_interface_id
        data.post_mapping_list[0]['data'][requestsData.logicalInterfaceId] = verifyData.logical_interface_id
        data.post_mapping_list[0]['data'][requestsData.propertyMappings][
            0][requestsData.expressionId] = verifyData.expression_id
        data.active_li_list[0]['id'] = verifyData.logical_interface_id

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.post_mapping_list}],
                             indirect=True)
    def test_713_post_mapping(self,
                          fix_draft_mapping):
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)

    @pytest.mark.parametrize('fix_draft_mapping',
                             [{'data_list': data.query_mapping_list}],
                             indirect=True)
    def test_713_query_mapping(self,
                           fix_draft_mapping):
        my_assert(verifyData.res_text['payload'][0]['name'], data.post_mapping_data[1])

    @pytest.mark.parametrize('fix_draft_logical_interface', [
                             {'data_list': data.active_li_list}], indirect=True)
    def test_713_active_li(self,
                       fix_draft_logical_interface):
        data.query_data_from_historian_list[0]['query_string'] = f"?properties={requestsData.historian_properties}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        data.query_data_from_historian_list[0]['logicaltype_id'] = verifyData.logical_interface_id
        post_data(verifyData.mqtt_client, data.post_data)


    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_713_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['deviceId'], data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], 71)
