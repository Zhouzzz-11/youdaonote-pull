import pytest
from iot.hub.data.tasks import rcdcs756_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.util import my_assert


class TRCDCS756(object):
    def test_set_value_756(self):
        data.query_realtime_data_with_actionable_list[0]['query_string'] = \
            f"?properties={requestsData.actionable_properties}"
        data.query_realtime_data_with_actionable_list[0]['actionable_id'] = verifyData.e2e_actionable_id

    @pytest.mark.parametrize('fix_realtime', [{'data_list': data.query_realtime_data_with_li_di}],
                             indirect=True)
    def test_query_realtime_data_with_li_di(self,
                                            fix_realtime):
        assert verifyData.res_text['payload'][0]['data'].get('li_temperature')
        assert not verifyData.res_text['payload'][0]['data'].get('state.li_temperature')
        my_assert(verifyData.res_text['payload'][0]['data']['li_temperature']['value'], data.e2e_res_4)

    @pytest.mark.parametrize('fix_realtime', [{'data_list': data.query_realtime_data_with_li}],
                             indirect=True)
    def test_query_realtime_data_with_li(self,
                                            fix_realtime):
        assert verifyData.res_text['payload'][0]['data'].get('li_temperature')
        assert not verifyData.res_text['payload'][0]['data'].get('state.li_temperature')
        my_assert(verifyData.res_text['payload'][0]['data']['li_temperature']['value'], data.e2e_res_4)

    @pytest.mark.parametrize('fix_realtime', [{'data_list': data.post_query_realtime_with_device_list}],
                             indirect=True)
    def test_post_query_realtime(self,
                                 fix_realtime):
        my_assert(verifyData.res_text['payload'][0]['data']['li_temperature']['value'], data.e2e_res_4)
        assert not verifyData.res_text['payload'][0]['data'].get('state.li_temperature')

    @pytest.mark.parametrize('fix_realtime', [{'data_list': data.query_realtime_data_with_actionable_list}],
                             indirect=True)
    def test_query_with_actionable(self,
                                   fix_realtime):
        my_assert(verifyData.res_text['payload'][0]['data']['state.li_temperature']['value'], data.e2e_data_7)
