import pytest
from iot.hub.data.tasks import rcdcs790_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.util import my_assert


class TRCDCS790(object):
    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.post_alarm_category_list}],
                             indirect=True)
    def test_post_alarm_category(self,
                                 fix_alarm_category):
        pass

    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.query_alarm_category_list}],
                             indirect=True)
    def test_query_alarm_category(self,
                                  fix_alarm_category):
        my_assert(verifyData.res_text['payload'][-1]['cid'], data.post_alarm_category_data[1])

    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.put_alarm_category_list}],
                             indirect=True)
    def test_update_alarm_category(self,
                                   fix_alarm_category):
        pass

    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.query_alarm_category_by_id_list}],
                             indirect=True)
    def test_query_alarm_category_by_id(self,
                                        fix_alarm_category):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    @pytest.mark.parametrize('fix_alarm_category', [{'data_list': data.delete_and_query_alarm_category_list}],
                             indirect=True)
    def test_delete_and_query_alarm_category(self,
                                             fix_alarm_category):
        pass

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.post_alarm_severity_list}],
                             indirect=True)
    def test_post_alarm_severity(self,
                                 fix_alarm_severity):
        pass

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.query_alarm_severity_list}],
                             indirect=True)
    def test_query_alarm_severity(self,
                                  fix_alarm_severity):
        my_assert(verifyData.res_text['payload'][-1]['level'], data.severity_level)

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.put_alarm_severity_list}],
                             indirect=True)
    def test_put_alarm_severity(self,
                                fix_alarm_severity):
        pass

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.query_alarm_severity_by_id_list}],
                             indirect=True)
    def test_query_alarm_severity_by_id(self,
                                        fix_alarm_severity):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.delete_and_query_alarm_severity_list}],
                             indirect=True)
    def test_delete_and_query_alarm_severity(self,
                                             fix_alarm_severity):
        pass

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.post_alarm_severity_list}],
                             indirect=True)
    def test_post_alarm_severity_for_type(self,
                                          fix_alarm_severity):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.post_draft_alarm_type_list}],
                             indirect=True)
    def test_post_draft_alarm_type(self,
                                   fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.query_draft_alarm_type_list}],
                             indirect=True)
    def test_query_draft_alarm_type(self,
                                    fix_draft_alarm_type):
        _alarm_type_id = verifyData.res_text['payload'][0]['alarmTypeId']
        data.put_draft_alarm_type_list[0]['id'] = _alarm_type_id
        data.query_draft_alarm_type_by_id_list[0]['id'] = _alarm_type_id
        data.patch_draft_alarm_type_list[0]['id'] = _alarm_type_id
        data.query_alarm_type_by_id_list[0]['id'] = _alarm_type_id
        data.patch_alarm_type_list[0]['id'] = _alarm_type_id
        data.delete_and_query_drafte_alarm_type_list[0]['id'] = _alarm_type_id
        data.delete_and_query_drafte_alarm_type_list[1]['id'] = _alarm_type_id

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.put_draft_alarm_type_list}],
                             indirect=True)
    def test_put_draft_alarm_type(self,
                                  fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.query_draft_alarm_type_by_id_list}],
                             indirect=True)
    def test_query_draft_alarm_type_by_id(self,
                                          fix_draft_alarm_type):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.patch_draft_alarm_type_list}],
                             indirect=True)
    def test_patch_draft_alarm_type(self,
                                    fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_alarm_type', [{'data_list': data.query_alarm_type_list}],
                             indirect=True)
    def test_query_alarm_type(self,
                              fix_alarm_type):
        pass

    @pytest.mark.parametrize('fix_alarm_type', [{'data_list': data.query_alarm_type_by_id_list}],
                             indirect=True)
    def test_query_alarm_type_by_id(self,
                                    fix_alarm_type):
        pass

    @pytest.mark.parametrize('fix_alarm_type', [{'data_list': data.patch_alarm_type_list}],
                             indirect=True)
    def test_patch_alarm_type(self,
                              fix_alarm_type):
        pass

    @pytest.mark.parametrize('fix_draft_alarm_type', [{'data_list': data.delete_and_query_drafte_alarm_type_list}],
                             indirect=True)
    def test_delete_and_query_draft_alarm_type(self,
                                               fix_draft_alarm_type):
        pass

    @pytest.mark.parametrize('fix_alarm_severity', [{'data_list': data.delete_and_query_alarm_severity_list}],
                             indirect=True)
    def test_delete_and_query_alarm_severity_for_type(self,
                                                      fix_alarm_severity):
        pass
