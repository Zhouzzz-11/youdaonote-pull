import time
import pytest
from iot import util
from iot.util import my_assert, my_assert_mes
from iot.hub.data.tasks import rcdcs1051_data as data
from iot.hub.data.tasks import rcdcs1051b_data as dataB
from iot.hub.data.tasks import rcdcs1051c_data as dataC
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS1051(object):
    """
        RCDCS-1051：一把梭
        RCDCS-1052: windows regression with expression
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_1051_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': data.post_device_type_properties_list}],
                             indirect=True)
    def test_1051_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': data.active_pi_list}], indirect=True)
    def test_1051_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_list}], indirect=True)
    def test_1051_post_device(self,
                              fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        data.query_data_from_historian_list[0]['query_string'] = \
            f"?properties={requestsData.historian_properties1}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        verifyData.current_time = int(time.time()) + 60000
        data.post_data['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000
        data.post_data1['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000
        data.post_data2['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 6000
        data.post_data3['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 6000
        data.post_data4['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 7000
        data.post_data5['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 7000
        post_data(verifyData.mqtt_client, data.post_data)
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 0}], indirect=True)
    def test_1051_query_data_from_historian(self,
                                            fix_historian_logical):
        post_data(verifyData.mqtt_client, data.post_data2)
        post_data(verifyData.mqtt_client, data.post_data3)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 6}], indirect=True)
    def test_23813_query_data_from_historian1(self,
                                            fix_historian_logical):
        _raws = verifyData.res_text['payload'][0]['rows']
        res = []
        for i in range(len(_raws)):
            res.append(_raws[i][1])
        my_assert(res, data.window_output_list)
        post_data(verifyData.mqtt_client, data.post_data4)
        post_data(verifyData.mqtt_client, data.post_data5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 7}], indirect=True)
    def test_1051_query_data_from_historian2(self,
                                             fix_historian_logical):
        _raws = verifyData.res_text['payload'][0]['rows']
        res = []
        for i in range(len(_raws)):
            res.append(_raws[i][1])
        my_assert(res, data.window_output2_list)


class TRCDCS1051B(object):
    """
        RCDCS-1051：一把梭
        RCDCS-1052: windows regression
    """
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': dataB.post_device_type_list}],
                             indirect=True)
    def test_1051b_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': dataB.post_device_type_properties_list}],
                             indirect=True)
    def test_1051b_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface',
                             [{'data_list': dataB.active_pi_list}], indirect=True)
    def test_1051b_active_pi(self,
                            fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': dataB.post_device_list}], indirect=True)
    def test_1051b_post_device(self,
                              fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)
        dataB.query_data_from_historian_list[0]['query_string'] = \
            f"?properties={requestsData.historian_properties1}" \
            f"&startTime={verifyData.start_time}&endTime={verifyData.end_time}"
        verifyData.current_time = int(time.time()) + 60000
        dataB.post_data['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000
        dataB.post_data1['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000
        dataB.post_data2['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 6000
        dataB.post_data3['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 6000
        dataB.post_data4['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 7000
        dataB.post_data5['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000 + 7000
        # GYPT-21183
        dataB.post_data6['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000
        dataB.post_data7['body']['things'][0]['items'][0]['ts'] = verifyData.current_time * 1000
        post_data(verifyData.mqtt_client, dataB.post_data)
        post_data(verifyData.mqtt_client, dataB.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': dataB.query_data_from_historian_list, 'num': 0}], indirect=True)
    def test_1051b_query_data_from_historian(self,
                                            fix_historian_logical):
        post_data(verifyData.mqtt_client, dataB.post_data2)
        post_data(verifyData.mqtt_client, dataB.post_data3)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': dataB.query_data_from_historian_list, 'num': 5}], indirect=True)
    def test_23813b_query_data_from_historian1(self,
                                            fix_historian_logical):
        _raws = verifyData.res_text['payload'][0]['rows']
        res = []
        for i in range(len(_raws)):
            res.append(_raws[i][1])
        my_assert(res, dataB.window_output_list)
        post_data(verifyData.mqtt_client, dataB.post_data4)
        post_data(verifyData.mqtt_client, dataB.post_data5)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': dataB.query_data_from_historian_list, 'num': 6}], indirect=True)
    def test_1051b_query_data_from_historian2(self,
                                             fix_historian_logical):
        _raws = verifyData.res_text['payload'][0]['rows']
        res = []
        for i in range(len(_raws)):
            res.append(_raws[i][1])
        my_assert(res, dataB.window_output2_list)
        post_data(verifyData.mqtt_client, dataB.post_data6, topic=requestsData.topic_dict['history_1.1'])
        post_data(verifyData.mqtt_client, dataB.post_data7, topic=requestsData.topic_dict['history_1.1'])

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': dataB.query_data_from_historian_list, 'num': 6}], indirect=True)
    def test_21183_query_data_from_historian(self,
                                             fix_historian_logical):
        _raws = verifyData.res_text['payload'][0]['rows']
        res = []
        for i in range(len(_raws)):
            res.append(_raws[i][1])
        my_assert(res, dataB.window_output2_list)


class TRCDCS1051C(object):
    @pytest.mark.parametrize('fix_draft_device_type',
                             [{'data_list': dataC.post_device_type_list}],
                             indirect=True)
    def test_23813_post_device_type(self,
                                   fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_device_type_properties',
                             [{'data_list': dataC.post_device_type_properties_list}],
                             indirect=True)
    def test_23813_post_device_type_properties(self,
                                              fix_draft_device_type_properties):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_same)
