import pytest
from iot.hub.data.tasks import rcdcs752_data as data
from iot.verify import verifyData
from iot import requestsData
from iot.clients.mqtt.help import post_data
from iot.util import my_assert


class TRCDCS752(object):
    def test_set_value(self):
        data.query_data_from_historian_list[0]['query_string'] = f"?properties={requestsData.historian_properties}" \
            f"&startTime={verifyData.e2e_start_time}&endTime={verifyData.e2e_end_time}"
        data.query_data_from_historian_list2[0]['query_string'] = f"?startTime={verifyData.e2e_start_time}" \
            f"&endTime={verifyData.e2e_end_time}&devices=[\"{data.device_id}\"]"
        data.query_data_with_li_agg_list[0]['query_string'] = f"?startTime={verifyData.e2e_start_time}" \
            f"&endTime={verifyData.e2e_end_time}&devices=[\"{data.device_id}\"]&timeInterval=10000m" \
            f"&aggProperties=[\"MAX(li_temperature)\"]"
        data.query_data_with_li_device_id_agg_list[0]['query_string'] = f"?startTime={verifyData.e2e_start_time}" \
            f"&endTime={verifyData.e2e_end_time}&properties={requestsData.historian_properties}&timeInterval=10000m" \
            f"&aggFunc=LAST"
        post_data(verifyData.mqtt_e2e_client, data.post_data)

    @pytest.mark.parametrize('fix_historian_logical', [
                             {'data_list': data.query_data_from_historian_list, 'num': 6}], indirect=True)
    def test_query_data_from_historian(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_res_4)
        _time = verifyData.res_text['payload'][0]['rows'][-1][0]
        data.patch_historian_data_list[0]['data'][0]['time'] = _time
        data.patch_historian_data_list2[0]['data'][0]['time'] = _time

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.patch_historian_data_list}],
                             indirect=True)
    def test_patch_data_from_historian(self,
                                       fix_historian_logical):
        pass

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 6}], indirect=True)
    def test_query_patch_data_from_historian(self,
                                             fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_data_5)
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][0], \
               data.patch_historian_data_list[0]['data'][0]['time'])

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.query_data_from_historian_list2,
                                                        'num': 6}],
                             indirect=True)
    def test_query_data_with_deviceset(self,
                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], data.e2e_res_1)
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_data_5)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.patch_historian_data_list2}],
                             indirect=True)
    def test_patch_data_from_historian2(self,
                                       fix_historian_logical):
        pass

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.query_data_from_historian_list2, 'num': 6}],
                             indirect=True)
    def test_query_data_with_deviceset2(self,
                                        fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], data.e2e_res_1)
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_data_6)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.query_data_with_li_agg_list, 'num': 1}],
                             indirect=True)
    def test_query_data_with_aggregation(self,
                                         fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['columns'][1], "max_li_temperature")
        my_assert(verifyData.res_text['payload'][0]['rows'][0][1], data.e2e_res_4)

    @pytest.mark.parametrize('fix_historian_logical', [{'data_list': data.query_data_with_li_device_id_agg_list, 'num': 1}],
                             indirect=True)
    def test_query_data_with_device_id_and_aggregation(self,
                                                       fix_historian_logical):
        my_assert(verifyData.res_text['payload'][0]['rows'][-1][1], data.e2e_data_6)
