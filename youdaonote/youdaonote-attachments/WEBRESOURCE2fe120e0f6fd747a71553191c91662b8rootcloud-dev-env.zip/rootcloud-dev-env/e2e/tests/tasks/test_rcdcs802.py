import time
from iot import util
from iot.util import my_assert
import pytest
from iot.hub.data.tasks import rcdcs802_data as data
from iot import requestsData
from iot.verify import verifyData, verifyPayload
from iot.clients.mqtt.help import post_data, get_connection


class TRCDCS802(object):
    # RCDCS701: predefined-property
    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.post_and_get_schema_list}], indirect=True)
    def test_802_post_and_get_schema(self,
                                     fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        data.post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [{'data_list': data.post_event_type_list}], indirect=True)
    def test_802_post_event_type(self,
                                 fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        data.post_pi_list[0]['data']['eventTypeIds'] = [verifyData.event_type_id]

    @pytest.mark.parametrize('fix_draft_schema', [{'data_list': data.post_schema_for_pi_list}], indirect=True)
    def test_802_post_get_schema_for_pi(self,
                                        fix_draft_schema):
        verifyData.schema_pi_id = verifyData.res_text['payload'][requestsData.schemaId]
        data.post_pi_list[0]['data']['schemaId'] = verifyData.schema_pi_id

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.post_expression_1_for_pi_list}],
                             indirect=True)
    def test_802_post_expression_1_for_pi(self,
                                          fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id

    @pytest.mark.parametrize('fix_draft_expression', [{'data_list': data.post_expression_2_for_pi_list}],
                             indirect=True)
    def test_802_post_expression_2_for_pi(self,
                                          fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        data.post_pi_list[0]['data']['propertyMappings'][-1]['expressionId'] = _expression_id
        _create_time = verifyData.res_text['payload']['created']
        verifyData.create_time = _create_time
        verifyData.start_time, verifyData.end_time = util.get_time_stamp(_create_time, 1000)

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.post_pi_list}], indirect=True)
    def test_802_post_pi(self,
                         fix_draft_physical_interface):
        verifyData.physical_interface_id = verifyData.res_text['payload'][requestsData.interfaceId]
        data.post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        data.active_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type', [{'data_list': data.post_device_type_list}],
                             indirect=True)
    def test_802_post_device_type(self,
                                  fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [{'data_list': data.active_pi_list}],
                             indirect=True)
    def test_802_patch_pi(self,
                          fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_1_list}], indirect=True)
    def test_802_post_device1(self,
                             fix_device):
        verifyData.res_payload = verifyData.res_text['payload']
        verifyData.mqtt_client = get_connection(verifyData.res_payload)
        data.query_data_from_historian_list[0]['query_string'] = util.get_query_string(data.ts)
        data.query_data_from_historian_list[0]['logicaltype_id'] = verifyData.physical_interface_id
        time.sleep(1)
        post_data(verifyData.mqtt_client, data.post_data)

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_2_list}], indirect=True)
    def test_802_post_device2(self,
                             fix_device):
        pass

    @pytest.mark.parametrize('fix_device', [{'data_list': data.post_device_3_list}], indirect=True)
    def test_802_post_device3(self,
                             fix_device):
        pass

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 1}], indirect=True)
    def test_802_query_data_from_historian(self,
                                           fix_historian_logical):
        _res_column = verifyData.res_text['payload'][0]['columns'][1:]
        _res_row = verifyData.res_text['payload'][0]['rows'][-1][1:]
        my_assert(len(_res_column), len(data.ver_data))
        _dict = dict(zip(_res_column, _res_row))
        my_assert(verifyPayload.verify_res_payload(data.ver_data, _dict), 0)

    # RCDCS802: device online status
    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.query_device_status_by_id_list}],
                             indirect=True)
    def test_802_query_device_status_by_id(self,
                                             fix_device_status):
        assert verifyData.res_text['payload']['online']
        my_assert(verifyData.res_text['payload']['country'], '中国')
        my_assert(verifyData.res_text['payload']['district'], '长宁区')

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.post_device_status_by_id_list}],
                             indirect=True)
    def test_802_post_device_status_by_id(self,
                                           fix_device_status):
        pass

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.query_device_1_status_by_id_list}],
                             indirect=True)
    def test_802_query_device_1_status_by_id(self,
                                             fix_device_status):
        assert not verifyData.res_text['payload']['online']
        my_assert(verifyData.res_text['payload']['city'], 'beijing')

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.query_device_2_status_by_id_list}],
                             indirect=True)
    def test_802_query_device_2_status_by_id(self,
                                             fix_device_status):
        assert not verifyData.res_text['payload']['online']
        my_assert(verifyData.res_text['payload']['city'], 'suzhou')

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.put_device_1_status_by_id_list}],
                             indirect=True)
    def test_802_put_device_1_status_by_id(self,
                                           fix_device_status):
        my_assert(verifyData.res_text['payload']['city'], 'nanjing')
        my_assert(verifyData.res_text['payload']['street'], 'xinjiekou')

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.put_device_2_status_by_id_list}],
                             indirect=True)
    def test_802_put_device_2_status_by_id(self,
                                           fix_device_status):
        my_assert(verifyData.res_text['payload']['city'], 'shanghai')
        my_assert(verifyData.res_text['payload']['street'], 'nanjingxilu')

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.query_multi_device_by_device_type_list}],
                             indirect=True)
    def test_802_query_multi_device_status(self,
                                           fix_device_status):
        my_assert(len(verifyData.res_text['payload']), 3)
        assert verifyData.res_text['payload'][0]['online']
        assert not verifyData.res_text['payload'][1]['online']
        assert not verifyData.res_text['payload'][2]['online']

    @pytest.mark.parametrize('fix_device_bulk', [{'data_list': data.post_bulk_device_query_list}],
                             indirect=True)
    def test_post_bulk_device_query(self,
                                    fix_device_bulk):
        assert verifyData.res_text['payload'][0]['online']
        assert not verifyData.res_text['payload'][1]['online']

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.query_device_status_count_list}],
                             indirect=True)
    def test_query_device_status_count(self,
                                       fix_device_status):
        my_assert(verifyData.res_text['payload'][0]['count'], 1)
        post_data(verifyData.mqtt_client, data.post_data1)

    @pytest.mark.parametrize('fix_historian_logical', [
        {'data_list': data.query_data_from_historian_list, 'num': 2}], indirect=True)
    def test_802_query_data_from_historian_2(self,
                                           fix_historian_logical):
        _res_column = verifyData.res_text['payload'][0]['columns'][1:]
        _res_row = verifyData.res_text['payload'][0]['rows'][-1][1:]
        my_assert(len(_res_column), len(data.ver_data))
        _dict = dict(zip(_res_column, _res_row))
        my_assert(verifyPayload.verify_res_payload(data.ver_1_data, _dict), 0)

    @pytest.mark.parametrize('fix_device_status', [{'data_list': data.query_device_status_1_by_id_list}],
                             indirect=True)
    def test_802_query_device_status_by_id(self,
                                           fix_device_status):
        assert verifyData.res_text['payload']['online']
        my_assert(verifyData.res_text['payload']['country'], '中国')
        my_assert(verifyData.res_text['payload']['district'], '淅川县')
