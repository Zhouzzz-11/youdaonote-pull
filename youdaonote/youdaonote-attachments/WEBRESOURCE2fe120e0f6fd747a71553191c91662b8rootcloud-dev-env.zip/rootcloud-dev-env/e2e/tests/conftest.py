import pytest


from iot.hub.fixture.alarmType import *
from iot.hub.fixture.callback import *
from iot.hub.fixture.deployer import *
from iot.hub.fixture.device import *
from iot.hub.fixture.deviceType import *
from iot.hub.fixture.deviceStatus import *
from iot.hub.fixture.eventType import *
from iot.hub.fixture.expression import *
from iot.hub.fixture.file import *
from iot.hub.fixture.instruction import *
from iot.hub.fixture.logicalInterface import *
from iot.hub.fixture.mapping import *
from iot.hub.fixture.manufacturer import *
from iot.hub.fixture.physicalInterface import *
from iot.hub.fixture.richQuery import *
from iot.hub.fixture.rule import *
from iot.hub.fixture.schema import *
from iot.hub.fixture.thing import *
from iot.hub.fixture.thingMapping import *
from iot.hub.fixture.udf import *


from iot.historian.fixture.historian import *
from iot.historian.fixture.realtime import *
from iot.historian.fixture.alarm import *


from iot.deployer.fixture.job import *


from iot.metrics.fixture.metrics import *


from iot.identity.fixture.identity import *