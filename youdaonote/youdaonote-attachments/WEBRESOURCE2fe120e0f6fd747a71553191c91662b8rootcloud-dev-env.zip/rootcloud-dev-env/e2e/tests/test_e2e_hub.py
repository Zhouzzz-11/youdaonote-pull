import pytest
from iot import requestsData
from iot.verify import verifyData
from iot.util import my_assert, my_assert_mes
from iot.hub.data import device_type_data, schema_data, event_type_data, physical_interface_data, device_data
from iot.hub.data.tasks2 import gypt12124_data as rich_query_data


class TRCDCS162(object):
    """
        e2e test case for draft schema
    """
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': schema_data.t162_get_schema_list}],
                             indirect=True)
    def test_162_get_schema(self,
                            fix_draft_schema):
        verifyData.res_payload = verifyData.res_text['payload']

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': schema_data.t162_post_and_get_schema_list}], indirect=True)
    def test_162_post_and_get_schema(self,
                                     fix_draft_schema):
        verifyData.res_payload2 = verifyData.res_text['payload']
        verifyData.schema_id = verifyData.res_payload2[-1][requestsData.schemaId]
        schema_data.t162_put_and_get_schema_list[0]['id'] = verifyData.schema_id
        schema_data.t162_put_and_get_schema_list[1]['id'] = verifyData.schema_id
        schema_data.t162_delete_and_get_schema_list[0]['id'] = verifyData.schema_id
        schema_data.t162_delete_and_get_schema_list[1]['id'] = verifyData.schema_id
        schema_data.t162_put_invalid_body_schema_list[0]['id'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_schema', [
        {'data_list': schema_data.t162_post_with_invalid_properties_format_list}], indirect=True)
    def test_162_post_with_invalid_properties_format(self,
                                                     fix_draft_schema):
       # my_assert_mes(verifyData.res_text['message'], requestsData.mes_invalid_body)
       pass
    @pytest.mark.parametrize('fix_draft_schema', [
        {'data_list': schema_data.t162_post_with_same_name_list}], indirect=True)
    def test_162_post_with_same_name(self,
                                     fix_draft_schema):
        my_assert(verifyData.res_text['payload']['name'], schema_data.post_schema_data[1])

    @pytest.mark.parametrize('fix_draft_schema', [
        {'data_list': schema_data.t162_post_with_null_name_list}], indirect=True)
    def test_162_post_with_null_name(self,
                                     fix_draft_schema):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_null_value)

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': schema_data.t162_put_and_get_schema_list}], indirect=True)
    def test_162_put_and_get_schema(self,
                                    fix_draft_schema):
        my_assert(verifyData.res_text['payload']['properties'][0]['type'], 'String')

    @pytest.mark.parametrize('fix_draft_schema', [
        {'data_list': schema_data.t162_get_invalid_id_schema_list}], indirect=True)
    def test_162_get_invalid_id_schema(self,
                                       fix_draft_schema):
        my_assert_mes(verifyData.res_text['message'], requestsData.invalid_id)
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_schema', [
        {'data_list': schema_data.t162_delete_not_exist_schema_list}], indirect=True)
    def test_162_delete_not_exist_schema(self,
                                         fix_draft_schema):
        my_assert_mes(verifyData.res_text['message'], requestsData.invalid_id)
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)


class TRCDCS173(object):
    """
        e2e test case for draft event type
    """
    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': event_type_data.t173_post_and_get_schema_list}], indirect=True)
    def test_173_post_and_get_schema(self,
                                     fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        event_type_data.t173_post_and_get_event_type_list[0]['data']['schemaId'] = verifyData.schema_id
        event_type_data.t173_delete_schema_list[0]['id'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': event_type_data.t173_get_event_type_list}], indirect=True)
    def test_173_get_event_type(self,
                                fix_draft_event_type):
        verifyData.res_payload = verifyData.res_text['payload']

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': event_type_data.t173_post_and_get_event_type_list}], indirect=True)
    def test_173_post_and_get_event_type(self,
                                         fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        event_type_data.t173_put_and_get_event_type_list[0]['id'] = verifyData.event_type_id
        event_type_data.t173_put_and_get_event_type_list[1]['id'] = verifyData.event_type_id
        event_type_data.t173_delete_and_get_event_type_list[0]['id'] = verifyData.event_type_id
        event_type_data.t173_delete_and_get_event_type_list[1]['id'] = verifyData.event_type_id

        event_type_data.t173_put_with_invalid_event_type_name_type_list[0]['id'] = verifyData.event_type_id
        event_type_data.t173_put_with_null_name_list[0]['id'] = verifyData.event_type_id
        event_type_data.t173_delete_event_type_been_deleted_list[0]['id'] = verifyData.event_type_id

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_post_and_get_event_type_list}], indirect=True)
    def test_173_post_with_same_body(self, fix_draft_event_type):
        my_assert(verifyData.res_text['payload']['eventTypeName'], event_type_data.post_event_type_data[1])

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_post_with_null_name_list}], indirect=True)
    def test_173_post_with_null_name(self, fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_null_value)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_post_with_null_event_type_name_list}], indirect=True)
    def test_173_post_with_null_event_type_name(self, fix_draft_event_type):
        my_assert(verifyData.res_text['payload']['eventTypeName'], requestsData.default_event)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_post_with_null_schema_id_list}], indirect=True)
    def test_173_post_with_null_schema_id(self, fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_null_value)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_post_with_invalid_type_list}], indirect=True)
    def test_173_post_with_invalid_type(self, fix_draft_event_type):
        #my_assert_mes(verifyData.res_text['message'], requestsData.mes_invalid_body)
        pass
    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': event_type_data.t173_put_and_get_event_type_list}], indirect=True)
    def test_173_put_and_get_event_type(self,
                                        fix_draft_event_type):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_put_not_exist_event_type_list}], indirect=True)
    def test_173_put_with_not_exist_id(self,
                                       fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_put_not_exist_event_type_list}], indirect=True)
    def test_173_put_with_invalid_type(self,
                                       fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_put_with_null_name_list}], indirect=True)
    def test_173_put_with_null_name(self,
                                    fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_null_value)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_get_not_exist_list}], indirect=True)
    def test_173_get_not_exist_event_type(self,
                                          fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': event_type_data.t173_delete_and_get_event_type_list}], indirect=True)
    def test_173_delete_and_get_event_type(self,
                                           fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_delete_not_exist_list}], indirect=True)
    def test_173_delete_not_exist_event_type(self,
                                             fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_event_type', [
        {'data_list': event_type_data.t173_delete_event_type_been_deleted_list}], indirect=True)
    def test_173_delete_exist_event_type_had_been_deleted(self,
                                                          fix_draft_event_type):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': event_type_data.t173_delete_schema_list}], indirect=True)
    def test_173_delete_schema(self,
                               fix_draft_schema):
        pass


class TRCDCS208(object):
    """
        e2e test case for draft physical interface
    """
    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': physical_interface_data.t208_post_and_get_schema_list}], indirect=True)
    def test_208_post_and_get_schema_list(self,
                                          fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][-1][requestsData.schemaId]
        physical_interface_data.t208_post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id
        physical_interface_data.t208_delete_schema_list[0]['id'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': physical_interface_data.t208_post_event_type_list}], indirect=True)
    def test_208_post_event_type_list(self,
                                      fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        physical_interface_data.t208_post_and_get_pi_list[0]['data']['eventTypeIds'] = [
            verifyData.event_type_id]
        physical_interface_data.t208_put_and_get_pi_list[0]['data']['eventTypeIds'] = [
            verifyData.event_type_id]
        physical_interface_data.t208_delete_event_type_list[0]['id'] = verifyData.event_type_id

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': physical_interface_data.t208_post_schema_for_pi_list}], indirect=True)
    def test_208_post_schema_for_pi(self,
                                    fix_draft_schema):
        verifyData.schema_pi_id = verifyData.res_text['payload'][requestsData.schemaId]
        physical_interface_data.t208_post_and_get_pi_list[
            0]['data']['schemaId'] = verifyData.schema_pi_id
        physical_interface_data.t208_put_and_get_pi_list[0]['data']['schemaId'] = verifyData.schema_pi_id
        physical_interface_data.t208_delete_schema_for_pi_list[0]['id'] = verifyData.schema_pi_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': physical_interface_data.t208_post_expression_for_pi_list}], indirect=True)
    def test_208_post_expression_for_pi(self,
                                        fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        physical_interface_data.t208_post_and_get_pi_list[0]['data'][
            'propertyMappings'][0]['expressionId'] = _expression_id
        physical_interface_data.t208_delete_expression_for_pi_list[0]['id'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': physical_interface_data.t208_post_and_get_pi_list}], indirect=True)
    def test_208_post_and_get_pi(self,
                                 fix_draft_physical_interface):
        verifyData.res_payload2 = verifyData.res_text['payload']
        verifyData.physical_interface_id = verifyData.res_payload2[-1][requestsData.interfaceId]
        physical_interface_data.t208_put_and_get_pi_list[0]['id'] = verifyData.physical_interface_id
        physical_interface_data.t208_put_and_get_pi_list[1]['id'] = verifyData.physical_interface_id
        physical_interface_data.t208_delete_and_get_pi_list[0]['id'] = verifyData.physical_interface_id
        physical_interface_data.t208_delete_and_get_pi_list[1]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': physical_interface_data.t208_put_and_get_pi_list}], indirect=True)
    def test_208_put_and_get_pi(self,
                                fix_draft_physical_interface):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': physical_interface_data.t208_delete_and_get_pi_list}], indirect=True)
    def test_208_delete_and_get_pi(self,
                                   fix_draft_physical_interface):
        my_assert_mes(verifyData.res_text['message'], requestsData.mes_not_exist)

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': physical_interface_data.t208_delete_schema_for_pi_list}], indirect=True)
    def test_208_delete_schema_for_pi(self,
                                      fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': physical_interface_data.t208_delete_expression_for_pi_list}], indirect=True)
    def test_208_delete_expression_for_pi(self,
                                          fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': physical_interface_data.t208_delete_event_type_list}], indirect=True)
    def test_208_delete_event_type(self,
                                   fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': physical_interface_data.t208_delete_schema_list}], indirect=True)
    def test_208_delete_schema(self,
                               fix_draft_schema):
        pass


class TRCDCS220(object):
    """
        e2e test case for draft device type
    """
    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': device_type_data.t220_post_schema_list}], indirect=True)
    def test_220_post_schema(self,
                             fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][requestsData.schemaId]
        device_type_data.t220_post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id
        device_type_data.t220_delete_schema_list[0]['id'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': device_type_data.t220_post_event_type_list}], indirect=True)
    def test_220_post_event_type(self,
                                 fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        device_type_data.t220_post_pi_list[0]['data']['eventTypeIds'] = [
            verifyData.event_type_id]
        device_type_data.t220_delete_event_type_list[0]['id'] = verifyData.event_type_id

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': device_type_data.t220_post_schema_for_pi_list}], indirect=True)
    def test_220_post_schema_for_pi(self,
                                    fix_draft_schema):
        verifyData.schema_pi_id = verifyData.res_text['payload'][requestsData.schemaId]
        device_type_data.t220_post_pi_list[0]['data']['schemaId'] = verifyData.schema_pi_id
        device_type_data.t220_delete_schema_for_pi_list[0]['id'] = verifyData.schema_pi_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': device_type_data.t220_post_expression_for_pi_list}], indirect=True)
    def test_220_post_expression_for_pi(self,
                                        fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        device_type_data.t220_post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id
        device_type_data.t220_delete_expression_for_pi_list[0]['id'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': device_type_data.t220_post_pi_list}], indirect=True)
    def test_220_post_pi(self,
                         fix_draft_physical_interface):
        verifyData.physical_interface_id = verifyData.res_text['payload'][requestsData.interfaceId]
        device_type_data.t220_post_and_get_device_type_list[0]['data'][
            'physicalInterfaceId'] = verifyData.physical_interface_id
        device_type_data.t220_delete_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': device_type_data.t220_get_device_type_list}], indirect=True)
    def test_220_get_device_type(self,
                                 fix_draft_device_type):
        verifyData.res_payload = verifyData.res_text['payload']

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': device_type_data.t220_post_and_get_device_type_list}], indirect=True)
    def test_220_post_and_get_device_type(self,
                                          fix_draft_device_type):
        my_assert(verifyData.res_text['payload']['deviceTypeId'], device_type_data.post_device_type_data[1])

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': device_type_data.t220_put_and_get_deivce_type_list}], indirect=True)
    def test_220_put_and_get_device_type(self,
                                         fix_draft_device_type):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': device_type_data.t220_delete_and_get_device_type_list}], indirect=True)
    def test_220_delete_and_get_device_type(self,
                                            fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': device_type_data.t220_delete_pi_list}], indirect=True)
    def test_220_delete_pi(self,
                           fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': device_type_data.t220_delete_schema_for_pi_list}], indirect=True)
    def test_220_delete_schema_for_pi(self,
                                      fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': device_type_data.t220_delete_expression_for_pi_list}], indirect=True)
    def test_220_delete_expression_for_pi(self,
                                          fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': device_type_data.t220_delete_event_type_list}], indirect=True)
    def test_220_delete_event_type(self,
                                   fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': device_type_data.t220_delete_schema_list}], indirect=True)
    def test_220_delete_schema(self,
                               fix_draft_schema):
        pass


class TRCDCS221(object):
    """
        e2e test case for device
    """
    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': device_data.t221_post_schema_list}],
                             indirect=True)
    def test_221_post_schema(self,
                             fix_draft_schema):
        verifyData.schema_id = verifyData.res_text['payload'][requestsData.schemaId]
        device_data.t221_post_event_type_list[0]['data']['schemaId'] = verifyData.schema_id
        device_data.t221_delete_schema_list[0]['id'] = verifyData.schema_id

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': device_data.t221_post_event_type_list}], indirect=True)
    def test_221_post_event_type(self,
                                 fix_draft_event_type):
        verifyData.event_type_id = verifyData.res_text['payload'][requestsData.eventTypeId]
        device_data.t221_post_pi_list[0]['data']['eventTypeIds'] = [
            verifyData.event_type_id]
        device_data.t221_delete_event_type_list[0]['id'] = verifyData.event_type_id

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': device_data.t221_post_schema_for_pi_list}], indirect=True)
    def test_221_post_schema_for_pi(self,
                                    fix_draft_schema):
        verifyData.schema_pi_id = verifyData.res_text['payload'][requestsData.schemaId]
        device_data.t221_post_pi_list[0]['data']['schemaId'] = verifyData.schema_pi_id
        device_data.t221_delete_schema_for_pi_list[0]['id'] = verifyData.schema_pi_id

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': device_data.t221_post_expression_for_pi_list}], indirect=True)
    def test_221_post_expression_for_ci(self,
                                        fix_draft_expression):
        _expression_id = verifyData.res_text['payload']['expressionId']
        device_data.t221_post_pi_list[0]['data']['propertyMappings'][0]['expressionId'] = _expression_id
        device_data.t221_delete_expression_for_pi_list[0]['id'] = _expression_id

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': device_data.t221_post_pi_list}], indirect=True)
    def test_221_post_pi(self,
                         fix_draft_physical_interface):
        verifyData.physical_interface_id = verifyData.res_text['payload'][requestsData.interfaceId]
        device_data.t221_post_device_type_list[0]['data']['physicalInterfaceId'] = verifyData.physical_interface_id
        device_data.t221_delete_pi_list[0]['id'] = verifyData.physical_interface_id

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': device_data.t221_post_device_type_list}], indirect=True)
    def test_221_post_device_type(self,
                                  fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_device',
                             [{'data_list': device_data.t221_get_device_list}],
                             indirect=True)
    def test_221_get_device(self,
                            fix_device):
        verifyData.res_payload = verifyData.res_text['payload']

    @pytest.mark.parametrize('fix_device', [
                             {'data_list': device_data.t221_post_and_get_device_list}], indirect=True)
    def test_221_post_and_get_device(self,
                                     fix_device):
        verifyData.res_payload2 = verifyData.res_text['payload']
        my_assert(len(verifyData.res_payload2) - len(verifyData.res_payload), 1)

    @pytest.mark.parametrize('fix_device', [
                             {'data_list': device_data.t221_put_and_get_device_list}], indirect=True)
    def test_221_put_and_get_device(self,
                                    fix_device):
        my_assert(verifyData.res_text['payload']['description'], requestsData.des_str_put)

    """
        GYPT-12124: rich query test cases
    """
    @pytest.mark.parametrize('fix_rich_query', [{'data_list': rich_query_data.get_by_find_list}],
                             indirect=True)
    def test_12124_get_by_find(self,
                               fix_rich_query):
        assert type(verifyData.res_text['payload']) == list
        my_assert(verifyData.res_text['payload'][0]['deviceId'], rich_query_data.post_device_data[1])

    @pytest.mark.parametrize('fix_rich_query', [{'data_list': rich_query_data.get_by_wrong_class_list}],
                             indirect=True)
    def test_12124_get_by_find_wrong_class(self,
                               fix_rich_query):
        pass

    @pytest.mark.parametrize('fix_rich_query', [{'data_list': rich_query_data.post_by_find_list}],
                             indirect=True)
    def test_12124_post_by_find(self,
                                fix_rich_query):
        assert type(verifyData.res_text['payload']) == list
        my_assert(len(verifyData.res_text['payload']), 1)
        my_assert(verifyData.res_text['payload'][0]['deviceId'], rich_query_data.post_device_data[1])
        my_assert(verifyData.res_text['payload'][0]['name'], rich_query_data.post_device_data[2])

    @pytest.mark.parametrize('fix_rich_query', [{'data_list': rich_query_data.post_by_find_wrong_list}],
                             indirect=True)
    def test_12124_post_by_find_wrong_body(self,
                                fix_rich_query):
        my_assert_mes(verifyData.res_text['message'], rich_query_data.mes_null_value)

    @pytest.mark.parametrize('fix_device', [
                             {'data_list': device_data.t221_delete_and_get_device_list}], indirect=True)
    def test_221_delete_and_get_device(self,
                                       fix_device):
        pass

    @pytest.mark.parametrize('fix_draft_device_type', [
                             {'data_list': device_data.t221_delete_device_type_list}], indirect=True)
    def test_221_delete_device_type(self,
                                    fix_draft_device_type):
        pass

    @pytest.mark.parametrize('fix_draft_physical_interface', [
                             {'data_list': device_data.t221_delete_pi_list}], indirect=True)
    def test_221_delete_pi(self,
                           fix_draft_physical_interface):
        pass

    @pytest.mark.parametrize('fix_draft_schema', [
                             {'data_list': device_data.t221_delete_schema_for_pi_list}], indirect=True)
    def test_221_delete_schema_for_pi(self,
                                      fix_draft_schema):
        pass

    @pytest.mark.parametrize('fix_draft_expression', [
                             {'data_list': device_data.t221_delete_expression_for_pi_list}], indirect=True)
    def test_221_delete_expression_for_pi(self,
                                          fix_draft_expression):
        pass

    @pytest.mark.parametrize('fix_draft_event_type', [
                             {'data_list': device_data.t221_delete_event_type_list}], indirect=True)
    def test_221_delete_event_type(self,
                                   fix_draft_event_type):
        pass

    @pytest.mark.parametrize('fix_draft_schema',
                             [{'data_list': device_data.t221_delete_schema_list}],
                             indirect=True)
    def test_221_delete_schema(self,
                               fix_draft_schema):
        pass
