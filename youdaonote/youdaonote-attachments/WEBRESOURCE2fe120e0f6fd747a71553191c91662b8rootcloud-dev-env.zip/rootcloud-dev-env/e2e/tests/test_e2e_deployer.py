import time
import pytest
from iot import requestsData
from iot.deployer.data import jobData as data


class TRCDCS274(object):
    """
        e2e tests for deployer job
            get job
            delete and get job
            post and get job
    """
    @pytest.mark.parametrize('fix_deployer', [{'data_list': data.jd_t1_3_data_list}], indirect=True)
    def test_274_post_job(self,
                           fix_deployer):
        time.sleep(3*requestsData.sleep_time)

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.post_manufacturer_list}], indirect=True)
    def test_274_post_manufacturer(self,
                                    fix_manufacturer):
        pass


class TRCDCS274ClearJob(object):
    @pytest.mark.parametrize('fix_callback', [{'data_list': data.jd_t1_4_data_list}], indirect=True)
    def test_274_delete_tenant(self,
                               fix_callback):
        pass

    @pytest.mark.parametrize('fix_manufacturer', [{'data_list': data.delete_manufacturer_list}], indirect=True)
    def test_274_delete_manufacturer(self,
                                     fix_manufacturer):
        pass
