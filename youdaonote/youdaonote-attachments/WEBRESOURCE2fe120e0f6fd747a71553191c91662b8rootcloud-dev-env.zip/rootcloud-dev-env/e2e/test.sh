#!/bin/bash

set -e

CWD="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "Preparing for UDF e2e test jars"

export ORG_GRADLE_PROJECT_ecaVersion=$(node -p "require('$CWD/../package.json').dependencies['@rootcloud/rootcloud-eca']")

cd ${CWD}/fixtures/udf-projects/test-udf-v1 && ./gradlew assemble &> /dev/null
cd ${CWD}/fixtures/udf-projects/test-udf-v2 && ./gradlew assemble &> /dev/null

jarV1=$(base64 ${CWD}/fixtures/udf-projects/test-udf-v1/build/libs/test-udf-0.0.1.jar | tr -d \\n)
jarV2=$(base64 ${CWD}/fixtures/udf-projects/test-udf-v2/build/libs/test-udf-0.0.2.jar | tr -d \\n)

echo "ud_jar_base64_dict = {
  'v1': \"${jarV1}\",
  'v2': \"${jarV2}\"
}" > ${CWD}/iot/hub/data/udfJarData.py

HOST_ADDRESS=$(node -p "Object.values(require('os').networkInterfaces()).reduce((a, c) => c.forEach((x) => a.push(x)) || a, []).filter(ni => ni.family === 'IPv4' && ni.internal === false).map(ni => ni.address)[0]") || exit 1

if [[ $1 == '' ]]; then
  echo "Running E2E test on local dev-env..."
  docker build -t e2e-test --build-arg BASE_ADDRESS="${HOST_ADDRESS}" "${CWD}"
else
  echo "Running E2E test on remote ${1} environment..."

  HUB_URL="http://hub.iot-${1}.rootcloudapp.com"
  HISTORIAN_URL="http://historian.iot-${1}.rootcloudapp.com"
  SIMULATOR_URL="http://device.iot-${1}.rootcloudapp.com/v1"
  DEPLOYER_URL="http://eca-deployer.iot-${1}.rootcloudapp.com"
  METRICS_URL="http://platform-metrics.iot-${1}.rootcloudapp.com"
  IDENTITY_URL="http://rootcloud-identity.iot-${1}.rootcloudapp.com"

  HUB_SUPER_USER="aHViLXN1cGVyLXVzZXI"
  if [ ${1} == 'dev' ]; then
    KAFKA_BOOTSTRAP_SERVER_ADDRESS="10.70.25.125:9092,10.70.25.70:9092,10.70.25.116:9092"
    EMQX_HOST="10.70.22.72"
    RUN_ENV='dev'
    IAM_USERNAME='rc_admin'
    IAM_PASSWORD='admin'
  elif [ ${1} == 'qa' ]; then
    KAFKA_BOOTSTRAP_SERVER_ADDRESS="10.70.40.140:9092"
    EMQX_HOST="10.70.40.124"
    RUN_ENV='qa'
    IAM_USERNAME='rc_admin'
    IAM_PASSWORD='admin'
  elif [ ${1} == 'i18n-dev' ]; then
    KAFKA_BOOTSTRAP_SERVER_ADDRESS="10.70.31.76:9092,10.70.31.58:9092,10.70.31.117:9092"
    EMQX_HOST="10.70.31.95"
  elif [ ${1} == 'pre' ]; then
    KAFKA_BOOTSTRAP_SERVER_ADDRESS="10.70.43.47:9092"
    EMQX_HOST="10.70.43.30"
    RUN_ENV='pre'
    IAM_USERNAME='rc_admin'
    IAM_PASSWORD='123qweasd'
  else
    KAFKA_BOOTSTRAP_SERVER_ADDRESS=""
    EMQX_HOST=""
    HUB_SUPER_USER="hub-super-user"
    RUN_ENV='local'
  fi

  docker build -q -t e2e-test \
    --build-arg HUB_URL="${HUB_URL}" \
    --build-arg HISTORIAN_URL="${HISTORIAN_URL}" \
    --build-arg SIMULATOR_URL="${SIMULATOR_URL}" \
    --build-arg DEPLOYER_URL="${DEPLOYER_URL}" \
    --build-arg METRICS_URL="${METRICS_URL}" \
    --build-arg KAFKA_BOOTSTRAP_SERVER_ADDRESS="${KAFKA_BOOTSTRAP_SERVER_ADDRESS}" \
    --build-arg HUB_SUPER_USER="${HUB_SUPER_USER}" \
    --build-arg EMQX_HOST="${EMQX_HOST}" \
    --build-arg RUN_ENV="${RUN_ENV}" \
    --build-arg IDENTITY_URL="${IDENTITY_URL}" \
    --build-arg IAM_USERNAME="${IAM_USERNAME}" \
    --build-arg IAM_PASSWORD="${IAM_PASSWORD}" \
    "${CWD}" &> /dev/null
fi

docker run --add-host=kafka:"${HOST_ADDRESS}" --rm --net=host -v "${CWD}/../report":/report e2e-test
