def return_local_body(_tenant_id, _project_code='project-code', _job_mode='recoup'):
    return {
        "tenantId": _tenant_id,
        "projectCode": _project_code,
        "influxUrl": "influxproxy:8086",
        "mongoUrl": "mongodb:27017,mongodb:27018,mongodb:27019",
        "redisUrl": "redis:6379",
        "redisMode": "single",
        "hbaseUrl":"hbase-phoenix:8765",
        "flinkJobManagerUrl": "jobmanager:8081",
        "emqUrl": "emq:1883",
        "kafkaBroadcastAddress": "kafka:9092",
        "jobMode": _job_mode,
        "enableSandBox": True,
        "groovyTimeout": 10
    }


def return_qa_body(_tenant_id, _project_code='project-code', _job_mode='recoup'):

    return {
        "tenantId": _tenant_id,
        "projectCode": _project_code,
        "influxUrl": "influxproxy.iot-qa.rootcloudapp.com:80",
        "mongoUrl": "Testuser:Testuser4@10.70.40.10:27017,10.70.40.42:27017,10.70.40.12:27017",
        "redisKey": "pP~W,[eC-/qj7n8",
        "redisUrl": "10.70.40.116:6379",
        "redisMode": "cluster",
        "flinkJobManagerUrl": "10.70.40.24:8081",
        "emqUrl": "10.70.40.124:1883,10.70.40.81:1883",
        "kafkaBroadcastAddress": "10.70.40.140:9092",
        "jobMode": _job_mode,
        "enableSandBox": True,
        "groovyTimeout": 10
    }


def return_dev_body(_tenant_id, _project_code='project-code', _job_mode='recoup'):
    return {
        "tenantId": _tenant_id,
        "projectCode": _project_code,
        "influxUrl": "influxproxy.iot-dev.rootcloudapp.com:80",
        "mongoUrl": "Devuser:DevuserV4@10.70.42.4:27017",
        "redisKey": "pP~W,[eC-/qj7n8",
        "redisUrl": "10.70.40.84:6379",
        "redisMode": "cluster",
        "flinkJobManagerUrl": "10.70.25.125:8081",
        "emqUrl": "10.70.22.72:1883,10.70.22.152:1883",
        # "hiveUrl": "10.70.31.91:10000",
        # "hdfsUrl": "10.70.31.91:8020",
        "kafkaBroadcastAddress": "10.70.25.125:9092,10.70.25.70:9092,10.70.25.116:9092",
        "jobMode": _job_mode,
        "enableSandBox": True,
        "groovyTimeout": 10
    }


def return_pre_body(_tenant_id, _project_code='project-code', _job_mode='recoup'):
    return {
        "tenantId": _tenant_id,
        "projectCode": _project_code,
        "influxUrl": "influxproxy.iot-pre.rootcloudapp.com:80",
        "mongoUrl": "irootech:s(R27)XM5rLEkn@10.70.43.24:27017,10.70.43.27:27017,10.70.43.31:27017",
        "redisKey": "appq*Cm5glP^",
        "redisUrl": "10.70.43.75:6379",
        "redisMode": "cluster",
        "flinkJobManagerUrl": "10.70.43.19:8081",
        "emqUrl": "10.70.43.30:1883,10.70.43.32:1883",
        "kafkaBroadcastAddress": "10.70.43.47:9092",
        "hiveUrl": "10.70.43.19:10000",
        "hdfsUrl": "10.70.43.19:8020",
        "parallelism": 1,
        "enableSandBox": True,
        "groovyTimeout": 10,
        "jobMode": _job_mode
    }
