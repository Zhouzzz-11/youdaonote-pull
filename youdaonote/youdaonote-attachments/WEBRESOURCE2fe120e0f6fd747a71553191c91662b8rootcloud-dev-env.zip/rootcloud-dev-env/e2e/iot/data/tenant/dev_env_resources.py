def hub_payload(_uuid, _tenant_id, _project_code='shared-project-code'):
  return {
  "id": _uuid,
  "tenantId": _tenant_id,
  "type": "hub",
  "tier": "shared",
  "projectCode": _project_code,
  "projectName": "name",
  "createdAt": "2020-02-28T12:00:00Z",
  "status": 0,
  "statusDesc": "",
  "statusTime": "2020-02-28T13:00:00Z",
  "resources": [
    {
      "type": "mongo",
      "resourceLevel": "shared",
      "accessUrl": "mongodb:27017,mongodb:27018,mongodb:27019",
      "version": "1.0",
      "mode": "replica",
      "nodeNum": 3,
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "initScriptUri": ""
    },
    {
      "type": "emq",
      "resourceLevel": "shared",
      "version": "1.0",
      "emqServerUrl": "emq:1883"
    },
    {
      "type": "kafka",
      "resourceLevel": "shared",
      "version": "1.0",
      "kafkaBroadcastAddress": "kafka:9092"
    },
    {
      "type": "influx",
      "resourceLevel": "shared",
      "version": "1.0",
      "nodeNum": 6,
      "accessUrl": "influxproxy:8086",
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "eachNodeDisk": 100,
      "init_script_uri": ""
    },
    {
      "type": "redis",
      "mode": "single",
      "resourceLevel": "shared",
      "version": "1.0",
      "nodeNum": 6,
      "accessUrl": "redis:6379",
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "eachNodeDisk": 100
    }
  ]
}


def eca_payload(_uuid, _tenant_id, _project_code='shared-project-code'):
  return {
  "id": _uuid,
  "tenantId": _tenant_id,
  "type": "stream",
  "tier": "shared",
  "projectCode": _project_code,
  "projectName": "name",
  "createdAt": "2020-02-28T12:00:00Z",
  "status": 0,
  "statusDesc": "",
  "statusTime": "2020-02-28T13:00:00Z",
  "resources": [
    {
      "type": "mongo",
      "resourceLevel": "shared",
      "accessUrl": "mongodb:27017,mongodb:27018,mongodb:27019",
      "version": "1.0",
      "mode": "replica",
      "nodeNum": 3,
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "initScriptUri": ""
    },
    {
      "type": "kafka",
      "resourceLevel": "shared",
      "version": "1.0",
      "kafkaBroadcastAddress": "kafka:9092"
    },
    {
      "type": "flink",
      "resourceLevel": "shared",
      "version": "1.0",
      "flinkJobManagerAddress": "jobmanager:8081"
    },
    {
      "type": "influx",
      "resourceLevel": "shared",
      "version": "1.0",
      "nodeNum": 6,
      "accessUrl": "influxproxy:8086",
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "eachNodeDisk": 100,
      "init_script_uri": ""
    },
    {
      "type": "redis",
      "mode": "single",
      "resourceLevel": "shared",
      "version": "1.0",
      "nodeNum": 6,
      "accessUrl": "redis:6379",
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "eachNodeDisk": 100
    },
    {
      "type": "hbase",
      "resourceLevel": "shared",
      "version": "1.0",
      "phoenixAddress": "hbase-phoenix:8765"
    }
  ]
}


def historian_payload(_uuid, _tenant_id, _project_code='shared-project-code'):
  return {
  "id": _uuid,
  "tenantId": _tenant_id,
  "type": "historian",
  "tier": "shared",
  "projectCode": _project_code,
  "projectName": "name",
  "createdAt": "2020-02-28T12:00:00Z",
  "status": 0,
  "statusDesc": "",
  "statusTime": "2020-02-28T13:00:00Z",
  "resources": [
    {
      "type": "mongo",
      "resourceLevel": "shared",
      "accessUrl": "mongodb:27017,mongodb:27018,mongodb:27019",
      "version": "1.0",
      "mode": "replica",
      "nodeNum": 3,
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "initScriptUri": ""
    },
    {
      "type": "influx",
      "resourceLevel": "shared",
      "version": "1.0",
      "nodeNum": 6,
      "accessUrl": "influxproxy:8086",
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "eachNodeDisk": 100,
      "init_script_uri": ""
    },
    {
      "type": "redis",
      "mode": "single",
      "resourceLevel": "shared",
      "version": "1.0",
      "nodeNum": 6,
      "accessUrl": "redis:6379",
      "eachNodeCores": 2,
      "eachNodeMemory": 4,
      "eachNodeDisk": 100
    },
    {
      "type": "hbase",
      "resourceLevel": "shared",
      "version": "1.0",
      "phoenixAddress": "hbase-phoenix:8765"
    }
  ]
}
