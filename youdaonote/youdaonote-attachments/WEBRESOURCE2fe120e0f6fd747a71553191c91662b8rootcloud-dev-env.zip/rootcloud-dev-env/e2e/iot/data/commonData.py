from iot.requestsData import *
from iot.data.tenant import dev_env_resources, dev_resources, qa_resources
from iot.data.tenant.deployer_body import *


def return_name(_prefix, _str):
    return f"{_prefix}_{_str}_{r_num_suffix}"


def return_draft_schema_data(_prefix, _schema_properties, **kw):
    schema_name = return_name(_prefix, 'schema_name')
    return return_body_data(kw, name=schema_name, description=des_str, properties=_schema_properties), schema_name


def return_draft_device_type(_prefix, _physical_interface_id, _description=des_str, _offlineCheckPeriod=1000000, **kw):
    device_type_id = return_name(_prefix, 'device_type_id')
    device_type_name = return_name(_prefix, 'device_type_name')
    _manufacturer_id = manufacturer_id if kw.get('directlyLinked') else None
    return return_body_data(kw, deviceTypeId=device_type_id, name=device_type_name, description=_description,
                            classId=deviceClass, physicalInterfaceId=_physical_interface_id,
                            offlineCheckPeriod=_offlineCheckPeriod, manufacturerId=_manufacturer_id),\
           device_type_id, device_type_name


def return_draft_device(_prefix, _description=des_str, **kw):
    _device_id = return_name(_prefix, 'device_id')
    _device_name = return_name(_prefix, 'device_name')
    _gateway_id = return_name(_prefix, 'gateway_id') if kw.get('gatewayId') else None
    return return_body_data(kw, deviceId=_device_id, name=_device_name, description=_description,
                            authType=deviceAuthType, gatewayId=_gateway_id, protocol=protocolV4),\
           _device_id, _device_name


def return_draft_schema_properties(_name, _type, **kw):
    return return_body_data(kw, name=_name, type=_type, displayName="温度", unit="摄氏度",
                            persistStrategy=persis_strategy_always)


def return_schema_property_interface(_name, _type, _stategy=persis_strategy_always, _period=0, _privilege=read_write, **kw):
    return return_body_data(kw, name=_name, type=_type, persistStrategy=_stategy, privilege=_privilege, period=_period)


def return_draft_event_type(_prefix, _schema_id, _description=des_str, **kw):
    event_type_name = return_name(_prefix, 'event_type_name')
    _name = return_name(_prefix, 'name')
    return return_body_data(kw, eventTypeName=event_type_name, name=_name, description=_description, schemaId=_schema_id),\
           event_type_name


def return_draft_physical_interface(_prefix, _event_type_ids, _schema_id, _property_mapping, _description=des_str, **kw):
    name = return_name(_prefix, 'physical_interface_name')
    return return_body_data(kw, name=name, description=_description, eventTypeIds=_event_type_ids, schemaId=_schema_id,
                            propertyMappings=_property_mapping), name


def return_draft_logical_interface(_prefix, _schema_id, **kw):
    name = return_name(_prefix, 'logical_interface_name')
    li_id = return_name(_prefix, 'li_id')
    return return_body_data(kw, name=name, description=des_str, schemaId=_schema_id, interfaceId=li_id,
                            requiredByWindow=False), name, li_id


def return_draft_expression(_prefix, _expression, _type='groovy', **kw):
    name = return_name(_prefix, 'expression')
    return return_body_data(kw, name=name, description=des_str, expression=_expression, type=_type), name


def return_mapping_property(_property_name, _expression_id, **kw):
    return return_body_data(kw, propertyName=_property_name, expressionId=_expression_id)


def return_draft_mapping(_prefix, _physical_interface_id, _logical_interface_id, _property_mappings, **kw):
    name = return_name(_prefix, 'mapping')
    return return_body_data(kw, name=name, description=des_str, physicalInterfaceId=_physical_interface_id,
                            logicalInterfaceId=_logical_interface_id, propertyMappings=_property_mappings), name


def return_draft_rules(_prefix, _logical_interface_id, _condition_id, _rule_notification_strategy,
                       _description=des_str, **kw):
    name = return_name(_prefix, 'rules')
    return return_body_data(kw, name=name, description=_description, logicalInterfaceId=_logical_interface_id,
                            expressionId=_condition_id, ruleNotificationStrategy=_rule_notification_strategy), name


def return_udf(_prefix, _classes, _jar_base64, **kw):
    _name = return_name(_prefix, 'udf')
    return return_body_data(kw, name=_name, description=des_str, classes=[_classes], jarBase64=_jar_base64)


def return_job(_tenant_id, _topic_prefix, **kw):
    return return_body_data(kw, tenantId=_tenant_id, topicPrefix=_topic_prefix)


def return_alarm_category(_prefix, _description=des_str, **kw):
    cid = return_name(_prefix, 'cid')
    term = return_name(_prefix, 'category_term')
    return return_body_data(kw, cid=cid, term=term, description=_description), cid


def return_alarm_severity(_prefix, _level, _description=des_str, **kw):
    term = return_name(_prefix, 'severity_term')
    return return_body_data(kw, level=_level, term=term, description=_description), term


def return_draft_alarm_type(_prefix, _source, _level, _description=des_str, **kw):
    name = return_name(_prefix, 'draft_alarm_type_name')
    _subject = return_name(_prefix, 'draft_alarm_type_subject')
    return return_body_data(kw, name=name, source=_source, subject=_subject, severityLevel=_level,
                            description=_description), name


def return_draft_alarm_type_2(_prefix, _source, _category_id, _level, _condition, _var, _li, _when,
                              _delay_period, _description=des_str, _required_ack=False, **kw):
    name = return_name(_prefix, 'draft_alarm_type_name')
    _subject = return_name(_prefix, 'draft_alarm_type_subject')
    return return_body_data(kw, name=name, source=_source, subject=_subject, categoryId=_category_id,
                            severityLevel=_level, description=_description, variables=[_var], logicalInterfaceId=_li,
                            condition=_condition, when=_when, delayPeriod=_delay_period,
                            requiredAck=_required_ack), name, _subject


def return_instruction(_prefix, _properties, _description=des_str, **kw):
    instruction_id = return_name(_prefix, 'instruction_id')
    instruction_name = 'set'
    return return_body_data(kw, instructionId=instruction_id, name=instruction_name, description=_description,
                            properties=_properties), instruction_id


def return_device_type_properties(**kw):
    return return_body_data(kw)


def return_li_properties(**kw):
    return return_body_data(kw)


def return_manufacturer(_id, _name, **kw):
    return return_body_data(kw, manufacturerId=_id, name=_name)


def return_child_thing_model(_prefix, _thing_type_id, _node_type='SingleDeviceNode', **kw):
    _node_id = return_name(_prefix, 'node_id')
    _node_name = return_name(_prefix, 'node_name')
    return return_body_data(kw, childInterfaceId=_thing_type_id, nodeId=_node_id, nodeName=_node_name, nodeType=_node_type),\
           _node_id


def return_thing_mapping(_prefix, _li_id, _child_thing_models, _property_mappings, _description=des_str, **kw):
    _name = return_name(_prefix, 'thing_mapping_name')
    return return_body_data(kw, name=_name, logicalInterfaceId=_li_id, childThingModels=_child_thing_models,
                            description=_description, propertyMappings=_property_mappings), _name


def return_thing(_prefix, _description=des_str, **kw):
    _id = return_name(_prefix, 'thing_id')
    _name = return_name(_prefix, 'thing_name')
    return return_body_data(kw, thingId=_id, name=_name, description=_description), _id, _name


def return_login_user(username, password, grant_type='password', client_id='web_app', client_secret='changeit', **kw):
    return return_body_data(kw, username=username, password=password, grant_type=grant_type,
                            client_id=client_id, client_secret=client_secret)


def return_super_admin(id, username, password, **kw):
    return return_body_data(kw, id=id, username=username, password=password)


def return_post_company(id, name, superAdmin, isOperator=True, **kw):
    return return_body_data(kw, id=id, name=name, isOperator=isOperator, superAdmin=superAdmin)


def return_service_license(service, grantTo, startAt, **kw):
    return return_body_data(kw, service=service, grantTo=grantTo, startAt=startAt)


def return_items(_properties, **kw):
    if kw.get('ts'):
        return {
            "qBad": ["level"],
            "ts": kw.get('ts'),
            "properties": _properties
        }
    else:
        return {
            "qBad": ["level"],
            "properties": _properties
        }


def return_post_data(_items, _thing_type='Device', **kw):
    return {
        "header": {},
        "body":
            {
                "things": [
                    {
                        "eventType": kw.get('eventType', default_event),
                        "thingType": _thing_type,
                        "items": _items
                    }
                ]

            }
    }


def return_post_no_direct_data(_items, _id, _thing_type='Device', **kw):
    return {
        "header": {},
        "body":
            {
                "things": [
                    {
                        "id": _id,
                        "eventType": kw.get('eventType', default_event),
                        "thingType": _thing_type,
                        "items": _items
                    }
                ]

            }
    }


def return_post_data_list(data_list):
    post_data_list = []
    for item in data_list:
        item = [return_items(item)]
        post_data = return_post_data(item)
        post_data_list.append(post_data)
    return post_data_list


def get_deploy_body(tenant_id, **kw):
    if test_server in ['local', 'localhost']:
        resource = dev_env_resources
        deployer_body = return_local_body(tenant_id, kw.get('projectCode', 'project-code'))
    elif test_server == 'qa':
        resource = qa_resources
        deployer_body = return_qa_body(tenant_id, kw.get('projectCode', 'project-code'))
    elif test_server == 'dev':
        resource = dev_resources
        deployer_body = return_dev_body(tenant_id, kw.get('projectCode', 'project-code'))
    elif test_server == 'pre':
        resource = dev_resources
        deployer_body = return_pre_body(tenant_id, kw.get('projectCode', 'project-code'))
    else:
        assert False, f"Test server {test_server} is not supported"
    return deployer_body, resource


def return_callback(_func, _uuid, _tenant_id, _project_code='shared-project-code'):
    return _func(_uuid, _tenant_id, _project_code)


schema_properties_number_temp = [return_draft_schema_properties('temp', 'Number')]
schema_properties_number_temperature = [return_draft_schema_properties('temperature', 'Number')]
schema_properties_number_li_temperature = [return_draft_schema_properties('li_temperature', 'Number')]
schema_properties_number_t = [return_draft_schema_properties('t', 'Number')]
schema_properties_string_temp = [return_draft_schema_properties('temp', 'String')]
schema_properties_boolean_temp = [return_draft_schema_properties('temp', 'Boolean')]
schema_properties_multi_numbers = [return_draft_schema_properties('temperature1', 'Number'),
                                   return_draft_schema_properties('temperature2', 'Number')]
schema_properties_number_temperature_pi = [return_draft_schema_properties('temperature', 'Number')]
schema_properties_string_temperature_pi = [return_draft_schema_properties('temperature', 'String')]
schema_properties_boolean_temperature_pi = [return_draft_schema_properties('temperature', 'Boolean')]
schema_properties_boolean_li_temperature_li = [return_draft_schema_properties('li_temperature', 'Boolean')]


mapping_property_pi = [return_mapping_property('temperature', '')]
mapping_property_li = [return_mapping_property('li_temperature', '')]
mapping_property_thing = [return_mapping_property('thing_temperature', '')]

rules_notification_strategy = {'when': 'everyTime', 'count': 0, 'timePeriod': 0}
