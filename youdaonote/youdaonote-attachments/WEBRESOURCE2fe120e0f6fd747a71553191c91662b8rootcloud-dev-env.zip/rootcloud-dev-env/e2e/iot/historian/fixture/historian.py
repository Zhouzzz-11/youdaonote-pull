import pytest
from iot import help
from iot.requestsData import headers, get_historian_url, api_logger


@pytest.fixture()
def fix_historian_logical(request):
    _url = get_historian_url('historian_logical_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        
        if _action == 'POST':
            pass
        elif _action == 'GET':
            _num = request.param['num']
            if i.get('aggregation') and i.get('device_id'):
                _res = help.get_historian(_url + '/' + i.get('logicaltype_id') + '/devices/' + i.get('device_id') +
                                       '/aggregation' + i.get('query_string'), headers1, expect=i.get('expect'),
                                       retry=True, expect_num=_num)
            elif i.get('aggregation'):
                _res = help.get_historian(_url + '/' + i.get('logicaltype_id') + '/aggregation' + i.get('query_string'),
                                       headers1, expect=i.get('expect'), retry=True, expect_num=_num)
            elif i.get('logicaltype_id') and i.get('device_id'):
                _res = help.get_historian(_url + '/' + i.get('logicaltype_id') + '/devices/' + i.get('device_id')
                                       + i.get('query_string'), headers1, expect=i.get('expect'), retry=True, expect_num=_num)
            elif i.get('logicaltype_id') and not i.get('device_id'):
                _res = help.get_historian(_url + '/' + i.get('logicaltype_id') + '/deviceset' + i.get('query_string'),
                                       headers1, expect=i.get('expect'), expect_num=_num)
        elif _action == 'PATCH':
            if i.get('device_id'):
                _res = help.patch_action(_url + '/' + i.get('logicaltype_id') + '/devices/' + i.get('device_id'),
                                         headers1, i.get('data'), expect=i.get('expect'))
            else:
                _res = help.patch_action(_url + '/' + i.get('logicaltype_id') + '/deviceset', headers1, i.get('data'),
                                         expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_historian_actionable(request):
    _url = get_historian_url('historian_actionable_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            pass
        elif _action == 'GET':
            _num = request.param['num']
            _res = help.get_historian(_url + '/' + i.get('logicaltype_id') + '/actionables/' + i.get('actionable_id') +
                                   i.get('query_string'), headers1, expect=i.get('expect'), retry=True,
                                   expect_num=_num)
        elif _action == 'PATCH':
            _res = help.patch_action(_url + '/' + i.get('logicaltype_id') + '/actionables/'+ i.get('actionable_id'),
                                     headers1, i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_historian_device_type(request):
    _url = get_historian_url('historian_devicetype_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            pass
        elif _action == 'GET':
            _num = request.param['num']
            if i.get('aggregation'):
                _res = help.get_historian(_url + '/' + i.get('devicetype_id') + '/aggregation' +
                                   i.get('query_string'), headers1, expect=i.get('expect'), retry=True,
                                       expect_num=_num)
            elif i.get('device_id'):
                _res = help.get_historian(_url + '/' + i.get('devicetype_id') + '/devices/' + i.get('device_id') +
                                       i.get('query_string'), headers1, expect=i.get('expect'),
                                       expect_num=_num)
            elif i.get('devicetype_id'):
                _res = help.get_historian(_url + '/' + i.get('devicetype_id') + '/deviceset' + i.get('query_string'),
                                   headers1, expect=i.get('expect'), retry=True, expect_num=_num)
            else:
                api_logger.error(f"Have the wrong request para")
        else:
            api_logger.error(f"Have the wrong request method {_action}")
