import pytest
from iot import help
from iot.requestsData import headers, get_historian_url, api_logger


@pytest.fixture()
def fix_alarm(request):
    _url = get_historian_url('alarm_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers

        if _action == 'POST':
            pass
        elif _action == 'GET':
            _num = request.param.get('num')
            _count = request.param.get('count')
            if i.get('all'):
                _res = help.get_alarm(_url + '/multi-query/all' + (i.get('query_string') or ''), headers1,
                                          expect=i.get('expect'), retry=True, expect_num=_num)
            elif i.get('count'):
                _res = help.get_alarm(_url + '/multi-query/count' + (i.get('query_string') or ''), headers1,
                                         expect=i.get('expect'), retry=True, expect_count=_count)
            elif i.get('device'):
                _res = help.get_alarm(_url + '/count/' + i.get('device_id') + '/' + i.get('type_id'), headers1,
                                        expect=i.get('expect'), retry=True, expect_count=_count)
            elif i.get('alarm_id'):
                _res = help.get_alarm(_url + '/' + i.get('alarm_id'), headers1, expect=i.get('expect'),
                                          retry=True, expect_num=_num)
        elif _action == 'PUT':
            _res = help.put_action(_url + '/close/' + i.get('alarm_id'), headers1, i.get('data') or {}, expect=i.get('expect'))
        elif _action == 'DELETE':
            if i.get('tenant_id'):
                _res = help.delete_action(_url + '/batch-delete/' + i.get('tenant_id'), headers1, expect=i.get('expect'))
            else:
                _res = help.delete_action(_url + '/delete/' + i.get('alarm_id'), headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
