import pytest
from iot import help
from iot.requestsData import headers, get_historian_url, api_logger


@pytest.fixture()
def fix_realtime(request):
    _url = get_historian_url('realtime_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url + '/devices/query', headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('actionable_id'):
                _res = help.get_action(_url + '/logicaltypes/' + i.get('logicaltype_id') + '/actionables/'
                                       + i.get('actionable_id') + i.get('query_string'), headers1,
                                       expect=i.get('expect'), retry=True)
            elif i.get('device_id'):
                _res = help.get_action(_url + '/logicaltypes/' + i.get('logicaltype_id') + '/devices/' + i.get('device_id'),
                                       headers1, expect=i.get('expect'), retry=True)
            else:
                _res = help.get_action(_url + '/logicaltypes/' + i.get('logicaltype_id') + '/deviceset?devices='
                                       + i.get('devices'), headers1, expect=i.get('expect'), retry=True)
        else:
            api_logger.error(f"Have the wrong request method {_action}")
