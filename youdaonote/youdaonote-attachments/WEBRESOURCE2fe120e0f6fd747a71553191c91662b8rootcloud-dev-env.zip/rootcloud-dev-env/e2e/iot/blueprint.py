"""
    the common data
"""
import os
import dotenv
from iot.logger import getLogger


class Blueprint:
    def __init__(self):
        # log
        self.api_logger = getLogger('api-test')
        self.per_logger = getLogger('performance')

        self.default_tenant_id = "t2_a"

        # url
        self.dotenv_path = os.path.join(os.path.curdir, 'iot/.env')
        if os.path.exists(self.dotenv_path):
            dotenv.load_dotenv(self.dotenv_path)
        self.hub_url = os.getenv('HUB_URL')
        self.historian_url = os.getenv('HISTORIAN_URL')
        self.simulator_url = os.getenv('SIMULATOR_URL')
        self.deployer_url = os.getenv('DEPLOYER_URL')
        self.metrics_url = os.getenv('METRICS_URL')
        self.kafka_server = os.getenv('KAFKA_BOOTSTRAP_SERVER_ADDRESS', '')
        self.hub_super_token = os.getenv('HUB_SUPER_USER')
        self.mqtt_host = os.getenv('EMQX_HOST', 'localhost')
        self.run_env = os.getenv('RUN_ENV', 'localhost')
        self.identity_url = os.getenv('IDENTITY_URL', '')
        self.iam_username = os.getenv('IAM_USERNAME', '')
        self.iam_password = os.getenv('IAM_PASSWORD', '')


        self.hub_url_dict = {
            "alarm_url": f"{self.hub_url}/alarm",
            "callback_url": f"{self.hub_url}/resource/tenant/callback",
            "deployer_url": f"{self.hub_url}/deployer",
            "device_url": f"{self.hub_url}/device/types",
            "device_bulk_url": f"{self.hub_url}/bulk/devices/",
            "device_types_url": f"{self.hub_url}/device/types",
            "device_status_url": f"{self.hub_url}/devices/status",
            "downstream_url": f"{self.hub_url}/downstream/request",
            "draft_alarm_types_url": f"{self.hub_url}/draft/alarm/types",
            "draft_device_types_url": f"{self.hub_url}/draft/device/types",
            "draft_event_types_url": f"{self.hub_url}/draft/event/types",
            "draft_expressions_url": f"{self.hub_url}/draft/expressions",
            "draft_mappings_url": f"{self.hub_url}/draft/mappings",
            "draft_physical_interfaces_url": f"{self.hub_url}/draft/physicalInterfaces",
            "draft_logical_interfaces_url": f"{self.hub_url}/draft/logicalInterfaces",
            "draft_rules_url": f"{self.hub_url}/draft/rules",
            "draft_schemas_sample_data_url": f"{self.hub_url}/draft/sampleData",
            "draft_schemas_sample_url": f"{self.hub_url}/draft/sampleSchemas",
            "draft_schemas_url": f"{self.hub_url}/draft/schemas",
            "draft_thing_mappings_url": f"{self.hub_url}/draft/thingMappings",
            "event_types_url": f"{self.hub_url}/event/types",
            "expressions_url": f"{self.hub_url}/expressions",
            "file_url": f"{self.hub_url}/file",
            "instructions_url": f"{self.hub_url}/device/types/",
            "instructions_cmd_url": f"{self.hub_url}/device/cmd/types/",
            "instructions_config_url": f"{self.hub_url}/device/config/types/",
            "logical_interfaces_url": f"{self.hub_url}/logicalInterfaces",
            "mappings_url": f"{self.hub_url}/mappings",
            "manufacturer_url": f"{self.hub_url}/manufacturers",
            "physical_interfaces_url": f"{self.hub_url}/physicalInterfaces",
            "rich_query_url": f"{self.hub_url}",
            "rules_url": f"{self.hub_url}/rules",
            "schemas_url": f"{self.hub_url}/schemas",
            "thing_url": f"{self.hub_url}/thing",
            "thing_mappings_url": f"{self.hub_url}/thingMappings",
            "udf_url": f"{self.hub_url}/udfs"
        }

        self.historian_url_dict = {
            "alarm_url": f"{self.historian_url}/alarms",
            "historian_logical_url": f"{self.historian_url}/historian/logicaltypes",
            "historian_actionable_url": f"{self.historian_url}/historian/logicaltypes",
            "realtime_url": f"{self.historian_url}/realtime"
        }

        self.deployer_url_dict = {
            "job_url": f"{self.deployer_url}/job"
        }

        self.metrics_url_dict = {
            "metrics_url": f"{self.metrics_url}/platformMetrics"
        }

        self.identity_url_dict = {
            "login_user_url": f"{self.identity_url}/api/v1/auth/login",
            "company_url": f"{self.identity_url}/api/v1/company",
            "service_license_url": f"{self.identity_url}/api/v1/service/license"
        }

        self.retry_code = [404]


blueprint = Blueprint()
