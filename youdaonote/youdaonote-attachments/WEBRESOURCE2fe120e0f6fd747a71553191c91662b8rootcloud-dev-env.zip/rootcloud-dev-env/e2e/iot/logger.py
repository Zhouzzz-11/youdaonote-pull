import logging

logging.basicConfig(level=logging.INFO,
                    filename='output.log',
                    format='[%(asctime)s] %(levelname)s [%(filename)s, %(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filemode='a')


def getLogger(name=None):
    logging.getLogger("kafka").setLevel(logging.ERROR)
    logging.getLogger("pika").setLevel(logging.CRITICAL)
    return logging.getLogger(name) if name else logging.getLogger()


logger = getLogger()