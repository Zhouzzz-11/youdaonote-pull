import pytest
import json
from iot import help
from iot.requestsData import get_identity_url, api_logger, headers_dict


@pytest.fixture()
def fix_login_user(request):
    _url = get_identity_url('login_user_url')

    for i in request.param['data_list']:
        _action = i['action']
        if _action == 'POST':
            _res = help.post_action(_url, {}, i.get('data'), expect=i.get('expect'))
            _token = json.loads(_res.text)['access_token']
            headers_dict[i.get('id')] = "Bearer " + _token
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_company(request):
    _url = get_identity_url('company_url')
    for i in request.param['data_list']:
        _action = i['action']
        header = {"accept": "application/json", "Authorization": headers_dict['superAdmin']}
        if _action == 'POST':
            _res = help.post_action(_url, header, i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_service(request):
    _url = get_identity_url('service_license_url')
    for i in request.param['data_list']:
        _action = i['action']
        header = {"accept": "application/json", "Authorization": headers_dict['superAdmin']}
        if _action == 'POST':
            _res = help.post_action(_url, header, i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
