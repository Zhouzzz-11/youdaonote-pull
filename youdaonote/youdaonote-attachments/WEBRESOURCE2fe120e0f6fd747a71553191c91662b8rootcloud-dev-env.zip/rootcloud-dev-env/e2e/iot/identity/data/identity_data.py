from iot.data.commonData import *


login_with_super_admin_body = return_login_user(bp.iam_username, bp.iam_password)

post_company_body_dict = {}
login_super_user_dict = {}
service_license_dict = {}
tenant_list = [tenant_id, tenant_a, tenant_b, tenant_shared_a, tenant_shared_b, tenant_shared_c]

for tenant in tenant_list:
    super_admin_body = return_super_admin(tenant + '_super_username', tenant + '_super_username', '123abcABC')
    post_company_body_dict[tenant] = return_post_company(tenant, tenant, super_admin_body)
    login_super_user_dict[tenant] = return_login_user(tenant + '_super_username', '123abcABC')
    service_license_dict[tenant] = return_service_license('RC_SERVICE_001', tenant, 1577836800000)


post_login_super_admin_list = [
    {'action': 'POST', 'data': login_with_super_admin_body, 'id': 'superAdmin', 'expect': res_code_200}
]

post_company_list = [
    {'action': 'POST', 'data': body} for body in post_company_body_dict.values()
]

post_login_super_user_list = [
    {'action': 'POST', 'data': body, 'id': key, 'expect': res_code_200} for key, body in login_super_user_dict.items()
]

post_service_license_list = [
    {'action': 'POST', 'data': body} for body in service_license_dict.values()
]
