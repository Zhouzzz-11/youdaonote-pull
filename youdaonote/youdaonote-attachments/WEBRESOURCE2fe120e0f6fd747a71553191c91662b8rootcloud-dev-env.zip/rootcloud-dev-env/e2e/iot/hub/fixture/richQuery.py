import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_rich_query(request):
    _url1 = get_hub_url('rich_query_url') + '/find'
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if i.get('find'):
            if _action == 'POST':
                _res = help.post_action(_url1, headers1, i.get('data'), expect=i.get('expect'))
            elif _action == 'GET':
                if i.get('query_string'):
                    _res = help.get_action(_url1 + i.get('query_string'), headers1, expect=i.get('expect'))
            else:
                api_logger.error(f"Have the wrong request method {_action}")
        else:
            api_logger.error(f"Have the wrong request method {_action}")
