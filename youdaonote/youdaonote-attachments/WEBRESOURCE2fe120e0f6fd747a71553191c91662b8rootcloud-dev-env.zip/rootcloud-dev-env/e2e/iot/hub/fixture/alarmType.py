import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_alarm_severity(request):
    _url1 = get_hub_url('alarm_url') + '/severities'
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url1, headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url1 + '/' + str(i.get('id')), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url1, headers1, expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url1 + '/' + str(i.get('id')), headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url1 + '/' + str(i.get('id')), headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_alarm_category(request):
    _url1 = get_hub_url('alarm_url') + '/categories'
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url1, headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url1 + '/' + i.get('id'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url1 + i.get('query_string'), headers1, expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url1 + '/' + i.get('id'), headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url1 + '/' + i.get('id'), headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_draft_alarm_type(request):
    _url = get_hub_url('draft_alarm_types_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url, headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url + i.get('query_string'), headers1, expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url + '/' + i.get('id'), headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'PATCH':
            _res = help.patch_action(_url + '/' + i.get('id'), headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_alarm_type(request):
    _url = get_hub_url('alarm_url') + '/types'
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url + i.get('query_string'), headers1, expect=i.get('expect'))
        elif _action == 'PATCH':
            _res = help.patch_action(_url + '/' + i.get('id'), headers1, i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
