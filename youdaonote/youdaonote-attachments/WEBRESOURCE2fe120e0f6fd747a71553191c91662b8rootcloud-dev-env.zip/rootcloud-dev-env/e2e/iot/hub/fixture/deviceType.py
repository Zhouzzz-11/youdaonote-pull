import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_draft_device_type(request):
    _url = get_hub_url('draft_device_types_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url, headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
            elif i.get('query_string'):
                _res = help.get_action(_url + i.get('query_string'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url, headers1, expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url + '/' + i.get('id'), headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_device_type(request):
    _url = get_hub_url('device_types_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url, headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_draft_device_type_properties(request):
    _url = get_hub_url('draft_device_types_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url + '/' + i.get('id') + '/properties', headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url + '/' + i.get('id') + '/properties', headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url + '/' + i.get('id') + '/properties', headers1, data=i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
