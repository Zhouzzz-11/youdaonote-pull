import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_deployer(request):
    _url = get_hub_url('deployer_url')

    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url, headers1, i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
