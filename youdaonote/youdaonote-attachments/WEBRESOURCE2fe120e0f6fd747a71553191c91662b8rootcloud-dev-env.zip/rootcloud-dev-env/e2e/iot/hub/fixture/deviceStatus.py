import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_device_status(request):
    _url1 = get_hub_url('device_types_url')
    _url2 = get_hub_url('device_status_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url1+ '/' + i.get('device_type_id') + '/devices/' + i.get('device_id')
                                       + '/location', headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('count'):
                _res = help.get_action(_url2 + '/count' + i.get('query_string'), headers1, expect=i.get('expect'))
            elif i.get('device_id'):
                _res = help.get_action(_url1 + '/' + i.get('device_type_id') + '/devices/' + i.get('device_id')
                                       + '/status', headers1, expect=i.get('expect'))
            elif i.get('query_string'):
                _res = help.get_action(_url2 + i.get('query_string'), headers1, expect=i.get('expect'))
            else:
                pass
        elif _action == 'PUT':
            _res = help.put_action(_url1+ '/' + i.get('device_type_id') + '/devices/' + i.get('device_id')
                                       + '/locations', headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url2 + '/' + str(i.get('id')), headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_device_bulk(request):
    _url = get_hub_url('device_bulk_url') + 'query'
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url, headers1, i.get('data'), expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_device_status_agg(request):
    _url1 = get_hub_url('device_status_url') + '/count'
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'GET':
            if i.get('count'):
                _res = help.get_action(_url1 + i.get('query_string'), headers1, expect=i.get('expect'))
            elif i.get('today'):
                _res = help.get_action(_url1 + '/todayActivity' + i.get('query_string'), headers1, expect=i.get('expect'))
            elif i.get('month'):
                _res = help.get_action(_url1 + '/thisMonthActivity' + i.get('query_string'), headers1,
                                       expect=i.get('expect'))
            else:
                pass
        else:
            api_logger.error(f"Have the wrong request method {_action}")
