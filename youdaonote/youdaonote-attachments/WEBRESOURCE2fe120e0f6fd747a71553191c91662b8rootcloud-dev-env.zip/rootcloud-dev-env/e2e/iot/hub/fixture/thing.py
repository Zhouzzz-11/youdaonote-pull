import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_thing(request):
        _url = get_hub_url('thing_url')
        _url1 = _url + 's'
        _url2 = _url + '/types/'
        for i in request.param['data_list']:
            _action = i['action']
            headers1 = i.get('header') or headers
            if _action == 'POST':
                _res = help.post_action(_url2 + i.get('thingTypeId') + '/things', headers1, i.get('data'),
                                        expect=i.get('expect'))
            elif _action == 'GET':
                if i.get('id'):
                    _res = help.get_action(_url2 + i.get('thingTypeId') + '/things/' + i.get('id'), headers1,
                                           expect=i.get('expect'))
                elif i.get('query_string'):
                    _res = help.get_action(_url1 + i.get('query_string'), headers1, expect=i.get('expect'))
                else:
                    _res = help.get_action(_url1, headers1, expect=i.get('expect'))
            elif _action == 'PUT':
                _res = help.put_action(_url2 + i.get('thingTypeId') + '/things/' + i.get('id'), headers1, i.get('data'),
                                       expect=i.get('expect'))
            elif _action == 'DELETE':
                _res = help.delete_action(_url2 + i.get('thingTypeId') + '/things/' + i.get('id'), headers1,
                                          expect=i.get('expect'))
            else:
                api_logger.error(f"Have the wrong request method {_action}")
