import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_instruction(request):
    _url = get_hub_url('instructions_url')
    _url_cmd = get_hub_url('instructions_cmd_url')
    _url_config = get_hub_url('instructions_config_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        _device_type_id = i.get('devicetype_id')
        _url1 = _url + _device_type_id + '/instructions'
        _url2 = _url_cmd + _device_type_id + '/devices/'
        _url3 = _url_config + _device_type_id + '/devices/'
        if _action == 'POST':
            _res = help.post_action(_url1, headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url1 + '/' + i.get('id'), headers1, expect=i.get('expect'))
            elif i.get('query_string'):
                _res = help.get_action(_url1 + i.get('query_string'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url1, headers1, expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url1 + '/' + i.get('id'), headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url1 + '/' + i.get('id'), headers1, expect=i.get('expect'))
        elif _action == 'PATCH':
            if i.get('cmd'):
                _res = help.patch_action(_url2 + i.get('device_id'), headers1, i.get('data'), expect=i.get('expect'))
            elif i.get('config'):
                _res = help.patch_action(_url3 + i.get('device_id'), headers1, i.get('data'), expect=i.get('expect'))
            else:
                _res = help.patch_action(_url1 + '/' + i.get('id') + '/devices/' + i.get('device_id'), headers1, i.get('data'),
                                         expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")


@pytest.fixture()
def fix_downstream(request):
    _url = get_hub_url('downstream_url')
    for i in request.param['data_list']:
        _action = i['action']
        headers1 = i.get('header') or headers
        if _action == 'POST':
            _res = help.post_action(_url, headers1, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('cmd'):
                _res = help.get_action(_url + '/cmd/' + i.get('id') + '/deviceStatus/' + i.get('devicetype_id') + '/' +
                                       i.get('device_id'), headers1, expect=i.get('expect'))
            elif i.get('config'):
                _res = help.get_action(_url + '/config/' + i.get('id') + '/deviceStatus/' + i.get('devicetype_id') + '/' +
                                       i.get('device_id'), headers1, expect=i.get('expect'))
            elif i.get('live'):
                _res = help.get_action(_url + '/live/' + i.get('id') + '/deviceStatus/' + i.get('devicetype_id') + '/' +
                                       i.get('device_id'), headers1, expect=i.get('expect'))
            elif i.get('device_id'):
                _res = help.get_action(_url + '/' + i.get('id') + '/deviceStatus/' + i.get('devicetype_id') + '/' +
                                       i.get('device_id'), headers1, expect=i.get('expect'))
            elif i.get('query_string'):
                _res = help.get_action(_url + i.get('query_string'), headers1, expect=i.get('expect'))
            elif i.get('id'):
                _res = help.get_action(_url + '/' + i.get('id'), headers1, expect=i.get('expect'))
            else:
                _res = help.get_action(_url, headers1, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
