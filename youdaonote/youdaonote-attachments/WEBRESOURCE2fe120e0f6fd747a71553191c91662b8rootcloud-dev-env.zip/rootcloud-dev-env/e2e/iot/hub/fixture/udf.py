import pytest
from iot import help
from iot.requestsData import headers, get_hub_url, api_logger


@pytest.fixture()
def fix_udf(request):
    _url = get_hub_url('udf_url')
    for i in request.param['data_list']:
        _action = i['action']
        if _action == 'POST':
            _res = help.post_action(_url, headers, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            if i.get('id'):
                _res = help.get_action(_url + '/' + i.get('id'), headers, expect=i.get('expect'))
            elif i.get('query_string'):
                _res = help.get_action(_url + i.get('query_string'), headers, expect=i.get('expect'))
            else:
                _res = help.get_action(_url, headers, expect=i.get('expect'))
        elif _action == 'PUT':
            _res = help.put_action(_url + '/' + i.get('id'), headers, i.get('data'), expect=i.get('expect'))
        elif _action == 'DELETE':
            _res = help.delete_action(_url + '/' + i.get('id'), headers, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
