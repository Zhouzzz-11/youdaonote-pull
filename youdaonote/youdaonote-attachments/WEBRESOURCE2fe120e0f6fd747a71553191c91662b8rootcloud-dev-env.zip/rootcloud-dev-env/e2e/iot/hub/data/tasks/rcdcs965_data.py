import time
from iot.data.commonData import *
from iot.verify.verifyData import *


_prefix = 'RCDCS965'
_prefix_pi = 'RCDCS965_pi'
_prefix_li = 'RCDCS965_li'
_prefix1 = 'RCDCS965_1'
_prefix_bin = 'RCDCS965_bin'
_prefix_array = 'RCDCS965_array'
_prefix_json = 'RCDCS965_json'
_prefix1_bin = 'RCDCS965_1_bin'
_prefix1_array = 'RCDCS965_1_array'
_prefix1_json = 'RCDCS965_1_json'

_schema_properties = [return_draft_schema_properties('t_bin', 'Binary'),
                      return_draft_schema_properties('t_array', 'Array'),
                      return_draft_schema_properties('t_json', 'Json')]
_schema_properties_pi = [return_draft_schema_properties('t_pi_bin', 'Binary'),
                         return_draft_schema_properties('t_pi_array', 'Array'),
                         return_draft_schema_properties('t_pi_json', 'Json')]
_schema_properties_li = [return_draft_schema_properties('t_li_bin', 'Binary'),
                         return_draft_schema_properties('t_li_array', 'Array'),
                         return_draft_schema_properties('t_li_json', 'Json')]
post_schema_data_for_event_type = return_draft_schema_data(_prefix, _schema_properties)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

expression_for_pi_bin = "t_bin"
expression_for_pi_array = "t_array"
expression_for_pi_json = "t_json"
expression_for_mapping_bin = "t_pi_bin"
expression_for_mapping_array = "t_pi_array"
expression_for_mapping_json = "t_pi_json"

mapping_property_pi = [
    {'propertyName': 't_pi_bin', 'expressionId': ''},
    {'propertyName': 't_pi_array', 'expressionId': ''},
    {'propertyName': 't_pi_json', 'expressionId': ''}
]

mapping_property_li = [
    {'propertyName': 't_li_bin', 'expressionId': ''},
    {'propertyName': 't_li_array', 'expressionId': ''},
    {'propertyName': 't_li_json', 'expressionId': ''}
]

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, _schema_properties_pi)
post_expression_for_pi_bin = return_draft_expression(_prefix_bin, expression_for_pi_bin)
post_expression_for_pi_array = return_draft_expression(_prefix_array, expression_for_pi_array)
post_expression_for_pi_json = return_draft_expression(_prefix_json, expression_for_pi_json)


post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, _schema_properties_li)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')

post_expression_for_mapping_bin = return_draft_expression(_prefix1_bin, expression_for_mapping_bin)
post_expression_for_mapping_array = return_draft_expression(_prefix1_array, expression_for_mapping_array)
post_expression_for_mapping_json = return_draft_expression(_prefix1_json, expression_for_mapping_json)
post_mapping_data = return_draft_mapping(_prefix, '', post_logical_interface_data[2], mapping_property_li)


# post schema for event type
post_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200}
]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# post schema for physical interface
post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [
    {'action': 'GET', 'query_string': query_schema_for_pi_str, 'expect': res_code_200}
]

# post expression for pi
post_expression_for_pi_bin_list = [
    {'action': 'POST', 'data': post_expression_for_pi_bin[0], 'expect': res_code_200}
]

# post expression for pi
post_expression_for_pi_array_list = [
    {'action': 'POST', 'data': post_expression_for_pi_array[0], 'expect': res_code_200}
]

# post expression for pi
post_expression_for_pi_json_list = [
    {'action': 'POST', 'data': post_expression_for_pi_json[0], 'expect': res_code_200}
]

# post physical interface
post_pi_list = [
    {'action': 'POST', 'data': post_physical_interface_data[0], 'expect': res_code_200}
]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST',
                          'data': post_device_type_data[0],
                          'expect': res_code_200}]

# active physical interface
active_pi_list = [{'action': 'PATCH',
                   'id': physical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# post device
post_device_list = [{'action': 'POST',
                     'data': post_device_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_200}]

# get device
query_device_list = [{'action': 'GET',
                      'id': post_device_data[1],
                      'type_id': post_device_type_data[1],
                      'expect': res_code_200}]

# post schema for logical interface
post_schema_for_li_list = [{'action': 'POST',
                            'data': post_schema_data_for_li[0],
                            'expect': res_code_200}]

# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [{'action': 'GET',
                             'query_string': query_schema_for_li_str,
                             'expect': res_code_200}]

# post the logical interface
post_li_list = [{'action': 'POST',
                 'data': post_logical_interface_data[0],
                 'expect': res_code_200}]

# get the logical interface
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'query_string': query_li_str, 'expect': res_code_200}
]

# post expression
post_expression_for_mapping_bin_list = [
    {'action': 'POST', 'data': post_expression_for_mapping_bin[0], 'expect': res_code_200}
]

# post expression
post_expression_for_mapping_array_list = [
    {'action': 'POST', 'data': post_expression_for_mapping_array[0], 'expect': res_code_200}
]

# post expression
post_expression_for_mapping_json_list = [
    {'action': 'POST', 'data': post_expression_for_mapping_json[0], 'expect': res_code_200}
]

# post the mapping
post_mapping_list = [
    {'action': 'POST', 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_mapping_data[1]}"
query_mapping_list = [{'action': 'GET',
                       'query_string': query_mapping_str,
                       'expect': res_code_200}]

# activate logical interface
active_li_list = [{'action': 'PATCH',
                   'id': post_logical_interface_data[2],
                   'data': activateData,
                   'expect': res_code_200}]

t = int(time.time()*1000)
items = [
    return_items({"t_bin": 'dGVzdAo='}, ts=t+100),
    return_items({"t_array": ['test', 100]}, ts=t+200),
    return_items({"t_json": {"json_test": {"name": "test_json", "age": "18"}}}, ts=t+300)
]

post_data = return_post_data(items)

# get the data from historian
query_data_from_historian_str = ''

query_data_from_historian_list = [{'action': 'GET',
                                   'logicaltype_id': post_logical_interface_data[2],
                                   'device_id': post_device_data[1],
                                   'query_string': query_data_from_historian_str,
                                   'expect': res_code_200}]


ver_data = [[None, None, 'dGVzdAo='], [["test", 100], None, 'dGVzdAo='],
            [["test", 100], {'json_test': {'name': 'test_json', 'age': '18'}}, 'dGVzdAo=']]
