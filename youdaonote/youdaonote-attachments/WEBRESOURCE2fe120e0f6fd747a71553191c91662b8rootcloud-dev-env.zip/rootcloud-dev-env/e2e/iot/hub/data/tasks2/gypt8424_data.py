from iot.data.commonData import *
from iot.requestsData import *


# GYPT-8424: li properties
_prefix = 'GYPT8424'


post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='groovy',
    expression='temp+1.2222',
    mappingName='temp',
    fixed=2
)]

post_li_data = return_draft_logical_interface(_prefix,'')

post_li_properties_data = [return_li_properties(
    name='li_temperature',
    displayName='li_温度',
    propertyType="Number",
    persistStrategy="always",
    privilege="ReadOnly",
    minValue="30",
    maxValue="80",
    expressionType="groovy",
    expression="temperature+9.1119",
    fromInterfaceId=post_device_type_data[1],
    fixed=3
)]

put_device_type_properties_data = {
    'change': {
        'name': 'temperature',
        'mappingName': 'temp'
    },
    'to': return_device_type_properties(
        name='temperature',
        displayName='温度',
        propertyType='Number',
        persistStrategy='always',
        privilege=read_write,
        minValue='20',
        maxValue='80',
        expressionType='groovy',
        expression='temp+2.2223',
        mappingName='temp',
        fixed=3
    )
}


put_li_properties_data = {
    'change': {
        'name': 'li_temperature',
        'fromInterfaceId': post_device_type_data[1]
    },
    'to': return_li_properties(
        name='li_temperature',
        displayName='li_温度',
        propertyType="Number",
        persistStrategy="always",
        privilege="ReadOnly",
        minValue="30",
        maxValue="80",
        expressionType="groovy",
        expression="temperature+20",
        fromInterfaceId=post_device_type_data[1],
        fixed=2
    )
}

put_device_type_properties_data2 = {
    'change': {
        'name': 'temperature',
        'mappingName': 'temp'
    },
    'to': return_device_type_properties(
        name='temperature',
        displayName='温度',
        propertyType='Number',
        persistStrategy='always',
        privilege=read_write,
        minValue='20',
        maxValue='80',
        expressionType='groovy',
        # expression="False",
        expression="while(true) {}",
        mappingName='temp',
        fixed=3
    )
}


delete_pi_properties_data = [{'name': 'temperature', 'mappingName': 'temp'}]
delete_li_properties_data = [{'name': 'li_temperature', 'fromInterfaceId': post_device_type_data[1]}]

post_device_data = return_draft_device(_prefix)


# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

# post li properties
post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

# active li interface
active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

# post the data
items = [
    return_items({"temp": 40.7588})
]
post_data = return_post_data(items)

items1 = [
    return_items({"temp": 60.7588})
]
post_data1 = return_post_data(items1)

items2 = [
    return_items({"temp": 100.7588})
]
post_data2 = return_post_data(items2)

# get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = ''

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_device_data[1],
     'query_string': query_data_from_historian_str, 'expect': res_code_200}
]

# put pi properties
put_pi_properties_list = [
    {'action': 'PUT', 'id': post_device_type_data[1], 'data': put_device_type_properties_data, 'expect': res_code_200}
]

# put li properties
put_li_properties_list = [
    {'action': 'PUT', 'id': post_li_data[2], 'data': put_li_properties_data, 'expect': res_code_200}
]

# delete li properties
delete_li_properties_list = [
    {'action': 'DELETE', 'id': post_li_data[2], 'data': delete_li_properties_data, 'expect': res_code_200}
]

# delete pi properties
delete_pi_properties_list = [
    {'action': 'DELETE', 'id': post_device_type_data[1], 'data': delete_pi_properties_data, 'expect': res_code_200}
]

# GYPT-17948： Groovy 安全测试
put_pi_properties_2_list = [
    {'action': 'PUT', 'id': post_device_type_data[1], 'data': put_device_type_properties_data2, 'expect': res_code_200}
]

#
schema_id_1 = _prefix + '_li_id_' + r_num_suffix + '_schema'
schema_id_2 = _prefix + '_device_type_id_' + r_num_suffix + '_schema'
schema_id_3 = _prefix + '_device_type_id_' + r_num_suffix + '_DEFAULT_EVENT_schema'
expression_id_1 = _prefix + '_device_type_id_' + r_num_suffix + '_temperature_expression'
expression_id_2 = _prefix + '_li_id_' + r_num_suffix + '_li_temperature_expression'

# query the draft schema and expression after delete
get_schema_1_list = [
    {'action': 'GET', 'id': schema_id_1, 'expect': res_code_404}
]

get_schema_2_list = [
    {'action': 'GET', 'id': schema_id_2, 'expect': res_code_404}
]

get_schema_3_list = [
    {'action': 'GET', 'id': schema_id_3, 'expect': res_code_404}
]

get_expression_1_list = [
    {'action': 'GET', 'id': expression_id_1, 'expect': res_code_404}
]

get_expression_2_list = [
    {'action': 'GET', 'id': expression_id_2, 'expect': res_code_404}
]
