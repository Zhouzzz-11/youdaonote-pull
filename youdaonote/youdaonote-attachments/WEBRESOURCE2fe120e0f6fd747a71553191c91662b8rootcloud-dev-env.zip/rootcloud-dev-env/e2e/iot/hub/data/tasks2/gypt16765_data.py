from iot.verify.verifyData import *
from iot.data.commonData import *

# GYPT-16765: rule
_prefix = 'GYPT16765'
_prefix_li = 'GYPT16765_li'
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_properties_number_li_temperature)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')
dd_expression_for_rule = "li_temperature > 50"
post_expression_for_rule_1 = return_draft_expression(_prefix, dd_expression_for_rule)
post_rule_data = return_draft_rules(_prefix, '', '', rules_notification_strategy)
put_rule_data = return_draft_rules(_prefix, '', '', rules_notification_strategy, des_str_put)

# post schema for logical interface
post_schema_for_li_list = [
    {'action': 'POST', 'data': post_schema_data_for_li[0], 'expect': res_code_200}
]
# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [
    {'action': 'GET', 'query_string': query_schema_for_li_str, 'expect': res_code_200}
]
# post the expression > 50
post_expression_list = [
    {'action': 'POST', 'data': post_expression_for_rule_1[0], 'expect': res_code_200}
]
# query the expression
query_expression_for_li_str = f"?name={post_expression_for_rule_1[1]}"
query_expression_for_li_list = [
    {'action': 'GET', 'query_string': query_expression_for_li_str, 'expect': res_code_200}
]
# post the logical interface
post_li_list = [
    {'action': 'POST', 'data': post_logical_interface_data[0], 'expect': res_code_200}
]
# query the li
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'query_string': query_li_str, 'expect': res_code_200}
]
# post the rule
post_rule_list = [
    {'action': 'POST', 'data': post_rule_data[0], 'expect': res_code_200}
]

# get the rule
query_rule_str = f"?name={post_rule_data[1]}"
query_rule_list = [
    {'action': 'GET', 'query_string': query_rule_str, 'expect': res_code_200}
]

# put the rule
put_rule_list = [
    {'action': 'PUT', 'id': rule_id, 'data': put_rule_data[0], 'expect': res_code_200}
]

# delete the rule
delete_rule_list = [
    {'action': 'DELETE', 'id': rule_id, 'expect': res_code_200}
]
