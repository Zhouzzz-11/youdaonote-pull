from iot.data.commonData import *
from iot.requestsData import *


# GYPT-8585: thing li property
_prefix = 'GYPT8585_node2'


post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Integer',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='groovy',
    expression='temp+1',
    mappingName='temp'
)]

post_li_data = return_draft_logical_interface(_prefix, '')
post_li_properties_data = [return_li_properties(
    name='li_temperature',
    displayName='li_温度',
    propertyType="Integer",
    persistStrategy="always",
    privilege="ReadOnly",
    minValue="30",
    maxValue="80",
    expressionType="groovy",
    expression="temperature+10",
    fromInterfaceId=post_device_type_data[1],
    fromPropertyName="temperature"
)]

post_device_data = return_draft_device(_prefix)

# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

# post li properties
post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

# active li interface
active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]
