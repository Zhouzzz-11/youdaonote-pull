from iot.data.commonData import *

# RCDCS-15984: li输出$state信息 - 设备管理员希望Thing与Rule支持$recent()函数
_prefix = 'GYPT15984'
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy=persis_strategy_on_report,
    privilege=read_write,
    expressionType=ex_groovy,
    expression="$recent('temp')",
    mappingName='temp',
), return_device_type_properties(
    name='temperatureB',
    displayName='温度',
    propertyType='Number',
    persistStrategy=persis_strategy_on_report,
    privilege=read_write,
    expressionType=ex_groovy,
    expression="$lastState('tempB')",
    mappingName="tempB",
), return_device_type_properties(
    name='temperatureC',
    displayName='温度',
    propertyType='Number',
    persistStrategy=persis_strategy_on_report,
    privilege=read_write,
    expressionType=ex_groovy,
    expression="$lastState('temperatureB')",
    fromProperty="temperatureB"
)]

post_device_data = return_draft_device(_prefix)

post_li_data = return_draft_logical_interface(_prefix, '')

post_li_properties_data = [return_li_properties(
    name='li_temperatureA',
    displayName='li_温度',
    propertyType="Number",
    persistStrategy=persis_strategy_on_report,
    privilege="ReadOnly",
    expressionType=ex_groovy,
    expression="$lastState('temperatureC')",
    fromInterfaceId=post_device_type_data[1],
    fromProperty="temperatureC",
), return_li_properties(
    name='li_temperatureB',
    displayName='li_温度',
    propertyType="Number",
    persistStrategy=persis_strategy_on_report,
    privilege="ReadOnly",
    expressionType=ex_groovy,
    expression="$recent('li_temperatureA')",
    fromInterfaceId=post_device_type_data[1],
), return_li_properties(
    name='li_temperatureC',
    displayName='li_温度',
    propertyType="Number",
    persistStrategy=persis_strategy_on_report,
    privilege="ReadOnly",
    expressionType=ex_groovy,
    expression="$recent('temperature')",
    fromInterfaceId=post_device_type_data[1],
    fromProperty="temperature",
)]


post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]


# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1],
     'expect': res_code_200}]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

# post li properties
post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

# active li interface
active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

# post the data
items = [
    return_items({"temp": 5.0, "tempB": 7.0})
]
post_data = return_post_data(items)

res_dict = {'li_temperatureC': 5.0}

# get the data from historian
query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_device_data[1],
     'query_string': '', 'expect': res_code_200}
]


# post the data 1
items1 = [
    return_items({"tempB": 8.0})
]
post_data1 = return_post_data(items1)

res_dict1 = {'li_temperatureC': 5.0}

# post the data 2
items2 = [
    return_items({"tempB": 9.0})
]
post_data2 = return_post_data(items2)

res_dict2 = {'li_temperatureC': 5.0}

# post the data 3
items3 = [
    return_items({"tempB": 10.0})
]
post_data3 = return_post_data(items3)

res_dict3 = {'li_temperatureC': 5.0, 'li_temperatureB': 7.0, 'li_temperatureA': 7.0}

# post the data 4
items4 = [
    return_items({"tempB": 11.0})
]
post_data4 = return_post_data(items4)

res_dict4 = {'li_temperatureC': 5.0, 'li_temperatureB': 8.0, 'li_temperatureA': 8.0}

# post the data 5
items5 = [
    return_items({"temp": 20.0, "tempB": 12.0})
]
post_data5 = return_post_data(items5)

res_dict5 = {'li_temperatureC': 20.0, 'li_temperatureB': 9.0, 'li_temperatureA': 9.0}
