from iot.hub.data.demo_data import *


_prefix = 'GYPT8594'
post_device_data_2 = return_draft_device(_prefix)

post_device_2_list = [
    {'action': 'POST', 'data': post_device_data_2[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

get_device_by_li_id_list = [
    {'action': 'GET', 'li_id': post_logical_interface_data[2], 'expect': res_code_200}
]
