from iot.data.commonData import *
from iot.verify.verifyData import *


"""
    RCDCS-411: property store strategy e2e
"""
_prefix = 'RCDCS411'
_prefix_pi = 'RCDCS411_pi'
_prefix_li = 'RCDCS411_li'
_prefix1 = 'RCDCS411_1'
_prefix_a = 'RCDCS411_a'
_prefix_b = 'RCDCS411_b'
_prefix_c = 'RCDCS411_c'
_prefix_d = 'RCDCS411_d'
_prefix_e = 'RCDCS411_e'
_prefix_f = 'RCDCS411_f'
_prefix_g = 'RCDCS411_g'
_prefix_h = 'RCDCS411_h'
_prefix_i = 'RCDCS411_i'
_prefix_1a = 'RCDCS411_1a'
_prefix_1b = 'RCDCS411_1b'
_prefix_1c = 'RCDCS411_1c'
_prefix_1d = 'RCDCS411_1d'
_prefix_1e = 'RCDCS411_1e'
_prefix_1f = 'RCDCS411_1f'
_prefix_1g = 'RCDCS411_1g'
_prefix_1h = 'RCDCS411_1h'
_prefix_1i = 'RCDCS411_1i'

test_properties_a = "[\"li_temp_a\"]"
test_properties_b = "[\"li_temp_b\"]"
test_properties_c = "[\"li_temp_c\"]"
test_properties_d = "[\"li_temp_d\"]"
test_properties_e = "[\"li_temp_e\"]"
test_properties_f = "[\"li_temp_f\"]"
test_properties_g = "[\"li_temp_g\"]"
test_properties_h = "[\"li_temp_h\"]"
test_properties_i = "[\"li_temp_i\"]"


schema_property_event_type = [
    return_schema_property_interface('a', 'Number', persis_strategy_always),
    return_schema_property_interface('b', 'Number', persis_strategy_always),
    return_schema_property_interface('c', 'Number', persis_strategy_always),
    return_schema_property_interface('d', 'Number', persis_strategy_always),
    return_schema_property_interface('e', 'Number', persis_strategy_on_report),
    return_schema_property_interface('f', 'Number', persis_strategy_on_report),
    return_schema_property_interface('g', 'Number', persis_strategy_on_report),
    return_schema_property_interface('h', 'Number', persis_strategy_on_report),
    return_schema_property_interface('i', 'Number', persis_strategy_on_report),
]

schema_property_pi = [
    return_schema_property_interface('temp_a', 'Number', persis_strategy_always),
    return_schema_property_interface('temp_b', 'Number', persis_strategy_always),
    return_schema_property_interface('temp_c', 'Number', persis_strategy_always),
    return_schema_property_interface('temp_d', 'Number', persis_strategy_always),
    return_schema_property_interface('temp_e', 'Number', persis_strategy_on_report),
    return_schema_property_interface('temp_f', 'Number', persis_strategy_on_report),
    return_schema_property_interface('temp_g', 'Number', persis_strategy_on_report),
    return_schema_property_interface('temp_h', 'Number', persis_strategy_on_report),
    return_schema_property_interface('temp_i', 'Number', persis_strategy_on_report)
]

schema_property_li = [
    return_schema_property_interface('li_temp_a', 'Number', persis_strategy_always),
    return_schema_property_interface('li_temp_b', 'Number', persis_strategy_on_report),
    return_schema_property_interface('li_temp_c', 'Number', persis_strategy_on_change),
    return_schema_property_interface('li_temp_d', 'Number', persis_strategy_on_period, 1200000),
    return_schema_property_interface('li_temp_e', 'Number', persis_strategy_always),
    return_schema_property_interface('li_temp_f', 'Number', persis_strategy_on_report),
    return_schema_property_interface('li_temp_g', 'Number', persis_strategy_on_change),
    return_schema_property_interface('li_temp_h', 'Number', persis_strategy_on_period, 1200000),
    return_schema_property_interface('li_temp_i', 'Number', persis_strategy_never)
]

post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_property_event_type)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

expression_for_a = f"{default_event}.a"
expression_for_b = f"{default_event}.b"
expression_for_c = f"{default_event}.c"
expression_for_d = f"{default_event}.d"
expression_for_e = f"{default_event}.e"
expression_for_f = f"{default_event}.f"
expression_for_g = f"{default_event}.g"
expression_for_h = f"{default_event}.h"
expression_for_i = f"{default_event}.i"
expression_for_mapping_a = "temp_a"
expression_for_mapping_b = "temp_b"
expression_for_mapping_c = "temp_c"
expression_for_mapping_d = "temp_d"
expression_for_mapping_e = "temp_e"
expression_for_mapping_f = "temp_f"
expression_for_mapping_g = "temp_g"
expression_for_mapping_h = "temp_h"
expression_for_mapping_i = "temp_i"
mapping_property_pi = [{'propertyName': 'temp_a', 'expressionId': ''},
                       {'propertyName': 'temp_b', 'expressionId': ''},
                       {'propertyName': 'temp_c', 'expressionId': ''},
                       {'propertyName': 'temp_d', 'expressionId': ''},
                       {'propertyName': 'temp_e', 'expressionId': ''},
                       {'propertyName': 'temp_f', 'expressionId': ''},
                       {'propertyName': 'temp_g', 'expressionId': ''},
                       {'propertyName': 'temp_h', 'expressionId': ''},
                       {'propertyName': 'temp_i', 'expressionId': ''},
                       ]

mapping_property_li = [{'propertyName': 'li_temp_a', 'expressionId': ''},
                       {'propertyName': 'li_temp_b', 'expressionId': ''},
                       {'propertyName': 'li_temp_c', 'expressionId': ''},
                       {'propertyName': 'li_temp_d', 'expressionId': ''},
                       {'propertyName': 'li_temp_e', 'expressionId': ''},
                       {'propertyName': 'li_temp_f', 'expressionId': ''},
                       {'propertyName': 'li_temp_g', 'expressionId': ''},
                       {'propertyName': 'li_temp_h', 'expressionId': ''},
                       {'propertyName': 'li_temp_i', 'expressionId': ''},
                       ]

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_property_pi)
post_expression_for_pi_a = return_draft_expression(_prefix_a, expression_for_a)
post_expression_for_pi_b = return_draft_expression(_prefix_b, expression_for_b)
post_expression_for_pi_c = return_draft_expression(_prefix_c, expression_for_c)
post_expression_for_pi_d = return_draft_expression(_prefix_d, expression_for_d)
post_expression_for_pi_e = return_draft_expression(_prefix_e, expression_for_e)
post_expression_for_pi_f = return_draft_expression(_prefix_f, expression_for_f)
post_expression_for_pi_g = return_draft_expression(_prefix_g, expression_for_g)
post_expression_for_pi_h = return_draft_expression(_prefix_h, expression_for_h)
post_expression_for_pi_i = return_draft_expression(_prefix_i, expression_for_i)

post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_property_li)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')

post_expression_for_mapping_a = return_draft_expression(_prefix_1a, expression_for_mapping_a)
post_expression_for_mapping_b = return_draft_expression(_prefix_1b, expression_for_mapping_b)
post_expression_for_mapping_c = return_draft_expression(_prefix_1c, expression_for_mapping_c)
post_expression_for_mapping_d = return_draft_expression(_prefix_1d, expression_for_mapping_d)
post_expression_for_mapping_e = return_draft_expression(_prefix_1e, expression_for_mapping_e)
post_expression_for_mapping_f = return_draft_expression(_prefix_1f, expression_for_mapping_f)
post_expression_for_mapping_g = return_draft_expression(_prefix_1g, expression_for_mapping_g)
post_expression_for_mapping_h = return_draft_expression(_prefix_1h, expression_for_mapping_h)
post_expression_for_mapping_i = return_draft_expression(_prefix_1i, expression_for_mapping_i)
post_mapping_data = return_draft_mapping(_prefix, '', '', mapping_property_li)

# RCDCS-571: test data for activating
# post schema for event type
post_schema_list = [{'action': 'POST',
                     'data': post_schema_data_for_event_type[0],
                     'expect': res_code_200}]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={default_event}"
query_event_type_list = [{'action': 'GET',
                          'query_string': query_event_type_str,
                          'expect': res_code_200}]

# post schema for physical interface
post_schema_for_pi_list = [{'action': 'POST',
                            'data': post_schema_data_for_pi[0],
                            'expect': res_code_200}]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [{'action': 'GET',
                             'query_string': query_schema_for_pi_str,
                             'expect': res_code_200}]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi_a[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_b[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_c[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_d[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_e[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_f[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_g[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_h[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_pi_i[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str_a = f"?name={post_expression_for_pi_a[1]}"
query_expression_for_pi_a_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_a,
                                 'expect': res_code_200}]
query_expression_for_pi_str_b = f"?name={post_expression_for_pi_b[1]}"
query_expression_for_pi_b_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_b,
                                 'expect': res_code_200}]
query_expression_for_pi_str_c = f"?name={post_expression_for_pi_c[1]}"
query_expression_for_pi_c_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_c,
                                 'expect': res_code_200}]
query_expression_for_pi_str_d = f"?name={post_expression_for_pi_d[1]}"
query_expression_for_pi_d_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_d,
                                 'expect': res_code_200}]
query_expression_for_pi_str_e = f"?name={post_expression_for_pi_e[1]}"
query_expression_for_pi_e_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_e,
                                 'expect': res_code_200}]
query_expression_for_pi_str_f = f"?name={post_expression_for_pi_f[1]}"
query_expression_for_pi_f_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_f,
                                 'expect': res_code_200}]
query_expression_for_pi_str_g = f"?name={post_expression_for_pi_g[1]}"
query_expression_for_pi_g_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_g,
                                 'expect': res_code_200}]
query_expression_for_pi_str_h = f"?name={post_expression_for_pi_h[1]}"
query_expression_for_pi_h_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_h,
                                 'expect': res_code_200}]
query_expression_for_pi_str_i = f"?name={post_expression_for_pi_i[1]}"
query_expression_for_pi_i_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str_i,
                                 'expect': res_code_200}]

# post physical interface
post_pi_list = [{'action': 'POST',
                 'data': post_physical_interface_data[0],
                 'expect': res_code_200}]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST',
                          'data': post_device_type_data[0],
                          'expect': res_code_200}]

# active physical interface
active_pi_list = [{'action': 'PATCH',
                   'id': physical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# post device
post_device_list = [{'action': 'POST',
                     'data': post_device_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_200}]

# get device
query_device_list = [{'action': 'GET',
                      'id': post_device_data[1],
                      'type_id': post_device_type_data[1],
                      'expect': res_code_200}]

# post schema for logical interface
post_schema_for_li_list = [{'action': 'POST',
                            'data': post_schema_data_for_li[0],
                            'expect': res_code_200}]

# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [{'action': 'GET',
                             'query_string': query_schema_for_li_str,
                             'expect': res_code_200}]

# post the logical interface
post_li_list = [{'action': 'POST',
                 'data': post_logical_interface_data[0],
                 'expect': res_code_200}]

# get the logical interface
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'query_string': query_li_str, 'expect': res_code_200}
]

# post expression for property mapping
post_expression_list = [
    {'action': 'POST', 'data': post_expression_for_mapping_a[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_b[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_c[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_d[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_e[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_f[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_g[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_h[0], 'expect': res_code_200},
    {'action': 'POST', 'data': post_expression_for_mapping_i[0], 'expect': res_code_200}
]

# query the expression
query_expression_tr_a = f"?name={post_expression_for_mapping_a[1]}"
query_expression_a_list = [{'action': 'GET',
                            'query_string': query_expression_tr_a,
                            'expect': res_code_200}]
query_expression_tr_b = f"?name={post_expression_for_mapping_b[1]}"
query_expression_b_list = [{'action': 'GET',
                            'query_string': query_expression_tr_b,
                            'expect': res_code_200}]
query_expression_tr_c = f"?name={post_expression_for_mapping_c[1]}"
query_expression_c_list = [{'action': 'GET',
                            'query_string': query_expression_tr_c,
                            'expect': res_code_200}]
query_expression_tr_d = f"?name={post_expression_for_mapping_d[1]}"
query_expression_d_list = [{'action': 'GET',
                            'query_string': query_expression_tr_d,
                            'expect': res_code_200}]
query_expression_tr_e = f"?name={post_expression_for_mapping_e[1]}"
query_expression_e_list = [{'action': 'GET',
                            'query_string': query_expression_tr_e,
                            'expect': res_code_200}]
query_expression_tr_f = f"?name={post_expression_for_mapping_f[1]}"
query_expression_f_list = [{'action': 'GET',
                            'query_string': query_expression_tr_f,
                            'expect': res_code_200}]
query_expression_tr_g = f"?name={post_expression_for_mapping_g[1]}"
query_expression_g_list = [{'action': 'GET',
                            'query_string': query_expression_tr_g,
                            'expect': res_code_200}]
query_expression_tr_h = f"?name={post_expression_for_mapping_h[1]}"
query_expression_h_list = [{'action': 'GET',
                            'query_string': query_expression_tr_h,
                            'expect': res_code_200}]
query_expression_tr_i = f"?name={post_expression_for_mapping_i[1]}"
query_expression_i_list = [{'action': 'GET',
                            'query_string': query_expression_tr_i,
                            'expect': res_code_200}]

# post the mapping
post_mapping_list = [
    {'action': 'POST', 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_mapping_data[1]}"
query_mapping_list = [{'action': 'GET',
                       'query_string': query_mapping_str,
                       'expect': res_code_200}]

# activate logical interface
active_li_list = [{'action': 'PATCH',
                   'id': logical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# step 28: get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = f"?startTime={query_start_time}&endTime={query_end_time}"

query_data_from_historian_list = [{'action': 'GET',
                                   'logicaltype_id': logical_interface_id,
                                   'device_id': post_device_data[1],
                                   'query_string': query_data_from_historian_str,
                                   'expect': res_code_200}]


items = [
    return_items({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8, "i": 9})
]
post_data = return_post_data(items)
ver_data_1 = {'li_temp_a': 1, 'li_temp_b': 2, 'li_temp_c': 3, 'li_temp_d': 4, 'li_temp_e': 5, 'li_temp_f': 6,
              'li_temp_g': 7, 'li_temp_h': 8}

# post the data
items1 = [
    return_items({"b": 2, "c": 3, "d": 4, "e": 5, "g": 7, "h": 8, "i": 9})
]

post_data1 = return_post_data(items1)

ver_data_2 = {'li_temp_a': 1, 'li_temp_b': 2, 'li_temp_c': None, 'li_temp_d': None, 'li_temp_e': 5, 'li_temp_f': None,
              'li_temp_g': None, 'li_temp_h': None}

# post the data
items2 = [
    return_items({"c": 4, "e": 5,  "g": 8, "h": 8, "i": 9})
]
post_data2 = return_post_data(items2)

ver_data_3 = {'li_temp_a': 1, 'li_temp_b': 2, 'li_temp_c': 4, 'li_temp_d': None, 'li_temp_e': 5, 'li_temp_f': None,
              'li_temp_g': 8, 'li_temp_h': None}

# post the data
items3 = [
    return_items({"a": 2, "b": 2, "c": 4, "f": 6, "g": 8})
]
post_data3 = return_post_data(items3)
ver_data_4 = {'li_temp_a': 2, 'li_temp_b': 2, 'li_temp_c': None, 'li_temp_d': None, 'li_temp_e': 5, 'li_temp_f': 6,
              'li_temp_g': None, 'li_temp_h': None}

# post the data
items4 = [
    return_items({"a": 2, "b": 2, "c": 4, "f": 6, "g": 8})
]
post_data4 = return_post_data(items4)

ver_data_5 = {'li_temp_a': 2, 'li_temp_b': 2, 'li_temp_c': None, 'li_temp_d': 4, 'li_temp_e': 5, 'li_temp_f': None,
              'li_temp_g': 7, 'li_temp_h': 8}