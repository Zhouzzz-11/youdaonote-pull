from iot.data.commonData import *
from iot.requestsData import *


# 修改预制属性的位置信息的历史数据保存方式
_prefix = 'GYPT20113'

post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='GPSLocation',
    displayName='位置信息',
    propertyType='Json',
    persistStrategy=persis_strategy_on_change,
    privilege=read_write,
    expressionType='groovy',
    expression="$location(GPS_LONGITUDE,GPS_LATITUDE)",
    mappingName='GPS_LONGITUDE,GPS_LATITUDE',
    mappingPropertyType='Number',
    alignStrategy=persis_strategy_on_report
)]

put_device_type_properties_data = {
    'change': {
        'name': 'GPSLocation',
        'mappingName': 'GPS_LONGITUDE,GPS_LATITUDE'
    },
    'to': return_device_type_properties(
        name='GPSLocation',
        displayName='位置信息',
        propertyType='Json',
        persistStrategy=persis_strategy_on_report,
        privilege=read_write,
        expressionType='groovy',
        expression="$location(GPS_LONGITUDE,GPS_LATITUDE)",
        mappingName='GPS_LONGITUDE,GPS_LATITUDE',
        mappingPropertyType='Number',
        alignStrategy=persis_strategy_on_report
    )
}


post_device_data = return_draft_device(_prefix)

items = [
    return_items({"GPS_LONGITUDE": 121.41257, "GPS_LATITUDE": 31.191118})
]
post_data = return_post_data(items)

items1 = [
    return_items({"GPS_LONGITUDE": 111.41257, "GPS_LATITUDE": 33.191118})
]
post_data1 = return_post_data(items1)

# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'query_string': '', 'expect': res_code_200}
]

# put pi properties
put_pi_properties_list = [
    {'action': 'PUT', 'id': post_device_type_data[1], 'data': put_device_type_properties_data, 'expect': res_code_200}
]
