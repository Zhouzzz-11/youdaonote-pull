from iot.data.commonData import *
from iot.verify import verifyData

_prefix = 'RCDCS790'
post_alarm_category_data = return_alarm_category(_prefix)
put_alarm_category_data = return_alarm_category(_prefix, des_str_put)

severity_level = 790
post_alarm_severity_data = return_alarm_severity(_prefix, severity_level)
put_alarm_severity_data = return_alarm_severity(_prefix, severity_level, des_str_put)

post_draft_alarm_type_data = return_draft_alarm_type(_prefix, deviceClass, severity_level)
put_draft_alarm_type_data = return_draft_alarm_type(_prefix, deviceClass, severity_level, des_str_put)

# category crud
post_alarm_category_list = [
    {'action': 'POST', 'data': post_alarm_category_data[0], 'expect': res_code_200}
]

query_alarm_category_str = f"?cid={post_alarm_category_data[1]}"
query_alarm_category_list = [
    {'action': 'GET', 'query_string': query_alarm_category_str, 'expect': res_code_200}
]

put_alarm_category_list = [
    {'action': 'PUT', 'id': post_alarm_category_data[1], 'data': put_alarm_category_data[0], 'expect': res_code_200}
]

query_alarm_category_by_id_list = [
    {'action': 'GET', 'id': post_alarm_category_data[1], 'expect': res_code_200}
]

delete_and_query_alarm_category_list = [
    {'action': 'DELETE', 'id': post_alarm_category_data[1], 'expect': res_code_200},
    {'action': 'GET', 'id': post_alarm_category_data[1], 'expect': res_code_404}
]


# severity crud
post_alarm_severity_list = [
    {'action': 'POST', 'data': post_alarm_severity_data[0], 'expect': res_code_200}
]

query_alarm_severity_str = f"?level={severity_level}"
query_alarm_severity_list = [
    {'action': 'GET', 'query_string': query_alarm_severity_str, 'expect': res_code_200}
]

put_alarm_severity_list = [
    {'action': 'PUT', 'id': severity_level, 'data': put_alarm_severity_data[0], 'expect': res_code_200}
]

query_alarm_severity_by_id_list = [
    {'action': 'GET', 'id': severity_level, 'expect': res_code_200}
]

delete_and_query_alarm_severity_list = [
    {'action': 'DELETE', 'id': severity_level, 'expect': res_code_200},
    {'action': 'GET', 'id': severity_level, 'expect': res_code_404}
]

# alarm types crud
post_draft_alarm_type_list = [
    {'action': 'POST', 'data': post_draft_alarm_type_data[0], 'expect': res_code_200}
]

query_draft_alarm_type_str = f"?name={post_draft_alarm_type_data[1]}"
query_draft_alarm_type_list = [
    {'action': 'GET', 'query_string': query_draft_alarm_type_str, 'expect': res_code_200}
]

put_draft_alarm_type_list = [
    {'action': 'PUT', 'id': verifyData.alarm_type_id, 'data': put_draft_alarm_type_data[0],
     'expect': res_code_200}
]

query_draft_alarm_type_by_id_list = [
    {'action': 'GET', 'id': verifyData.alarm_type_id, 'expect': res_code_200}
]

patch_draft_alarm_type_list = [
    {'action': 'PATCH', 'id': verifyData.alarm_type_id, 'data': activateData, 'expect': res_code_200}
]

query_alarm_type_list = [
    {'action': 'GET', 'query_string': query_draft_alarm_type_str, 'expect': res_code_200}
]

query_alarm_type_by_id_list = [
    {'action': 'GET', 'id': verifyData.alarm_type_id, 'expect': res_code_200}
]

patch_alarm_type_list = [
    {'action': 'PATCH', 'id': verifyData.alarm_type_id, 'data': deactivateData, 'expect': res_code_200}
]

query_alarm_type_after_deactivate_list = [
    {'action': 'GET', 'query_string': query_draft_alarm_type_str, 'expect': res_code_404}
]

delete_and_query_drafte_alarm_type_list = [
    {'action': 'DELETE', 'id': verifyData.alarm_type_id, 'expect': res_code_200},
    {'action': 'GET', 'id': verifyData.alarm_type_id, 'expect': res_code_404}
]