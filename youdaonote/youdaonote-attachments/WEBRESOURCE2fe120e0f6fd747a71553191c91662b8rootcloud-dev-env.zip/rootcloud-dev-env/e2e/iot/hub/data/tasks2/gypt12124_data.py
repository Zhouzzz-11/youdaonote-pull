import json
from iot.hub.data.device_data import *

# rich query with get and find
# case 1
find_json = {deviceId: post_device_data[1]}
query_string_with_find_str = f"?className={deviceClass2}&find={json.dumps(find_json)}"
get_by_find_list = [
    {'action': 'GET', 'find': True, 'query_string': query_string_with_find_str, 'expect': res_code_200}
]

# case 2
query_with_wrong_cls_find_str = f"?className=wrongClass&find={json.dumps(find_json)}"
get_by_wrong_class_list = [
    {'action': 'GET', 'find': True, 'query_string': query_with_wrong_cls_find_str, 'expect': res_code_500}
]

# case 3
find_data = {
    'className': deviceClass2,
    'find': json.dumps({deviceId: post_device_data[1], 'name': post_device_data[2]})
}
post_by_find_list = [
    {'action': 'POST', 'find': True, 'data': find_data, 'expect': res_code_200}
]

# case 4
find_wrong_data = {
    'className': deviceClass2
}
post_by_find_wrong_list = [
    {'action': 'POST', 'find': True, 'data': find_wrong_data, 'expect': res_code_400}
]
