from iot.hub.data import udfJarData
from iot.data.commonData import *
from iot.verify.verifyData import *


_prefix = 'RCDCS32'
_prefix1 = 'RCDCS32_1'
_prefix_pi = 'RCDCS32_pi'
_prefix_li = 'RCDCS32_li'

post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_multi_numbers)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

udf_classes = "com.rootcloud.udf.test.TestUdf"
udf_expression_for_pi = f"$udf('{udf_classes}').diffTemp($input.{default_event})"
udf_expression_for_mapping = "temperature"
udf_jar_base = udfJarData.ud_jar_base64_dict['v1']
udf_jar_base2 = udfJarData.ud_jar_base64_dict['v2']

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_boolean_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, udf_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_properties_boolean_li_temperature_li)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')
post_expression_for_mapping = return_draft_expression(_prefix1, udf_expression_for_mapping)
post_mapping_data = return_draft_mapping(_prefix, '', '', mapping_property_li)

post_udf_data = return_udf(_prefix, udf_classes, udf_jar_base)
put_udf_data = return_udf(_prefix, udf_classes, udf_jar_base2)

# post schema
ud_t1_1_data_list = [
  {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200}
]

# query the schema
ud_t1_2_query_string = f"?name={post_schema_data_for_event_type[1]}"
ud_t1_2_data_list = [
  {'action': 'GET', 'query_string': ud_t1_2_query_string,
   'expect': res_code_200}
]

# post event type
ud_t1_3_data_list = [
  {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
ud_t1_4_query_string = f"?eventTypeId={default_event}"
ud_t1_4_data_list = [
  {'action': 'GET', 'query_string': ud_t1_4_query_string,
   'expect': res_code_200}
]

# post schema for physical interface
ud_t1_5_data_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# query the schema
ud_t1_6_query_string = f"?name={post_schema_data_for_pi[1]}"
ud_t1_6_data_list = [
    {'action': 'GET', 'query_string': ud_t1_6_query_string, 'expect': res_code_200}
]

# post expression for property mapping
ud_t1_7_data_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
ud_t1_8_query_string = f"?name={post_expression_for_pi[1]}"
ud_t1_8_data_list = [
    {'action': 'GET', 'query_string': ud_t1_8_query_string, 'expect': res_code_200}
]

# step 5: post physical interface
ud_t1_9_data_list = [
  {'action': 'POST', 'data': post_physical_interface_data[0], 'expect': res_code_200}
]

# step 6: query the physical interface
ud_t1_10_query_string = f"?name={post_physical_interface_data[1]}"
ud_t1_10_data_list = [
  {'action': 'GET', 'query_string': ud_t1_10_query_string,
   'expect': res_code_200}
]

# step 7: post device type
ud_t1_11_data_list = [
  {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# step 8: get device type
ud_t1_12_data_list = [
  {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# active physical interface
ud_t1_13_data_list = [
    {'action': 'PATCH', 'id': physical_interface_id, 'data': activateData, 'expect': res_code_200}
]


# step 9: post device
ud_t1_14_data_list = [
  {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1],
   'expect': res_code_200}
]

# step 10: get device
ud_t1_15_data_list = [
  {'action': 'GET', 'id': post_device_data[1], 'type_id': post_device_type_data[1],
   'expect': res_code_200}
]

# step 11: post schema for logical interface
ud_t1_16_data_list = [
  {'action': 'POST', 'data': post_schema_data_for_li[0], 'expect': res_code_200}
]

# step 12: get the schema
ud_t1_17_query_string = f"?name={post_schema_data_for_li[1]}"
ud_t1_17_data_list = [
  {'action': 'GET', 'query_string': ud_t1_17_query_string,
   'expect': res_code_200}
]

# step 13: post the logical interface
ud_t1_18_data_list = [
  {'action': 'POST', 'data': post_logical_interface_data[0], 'expect': res_code_200}
]

# step 14: get the logical interface
ud_t1_19_query_string = f"?name={post_logical_interface_data[1]}"
ud_t1_19_data_list = [
  {'action': 'GET', 'query_string': ud_t1_19_query_string,
   'expect': res_code_200}
]

# step 15: post udf
ud_t1_20_data_list = [
  {'action': 'POST', 'data': post_udf_data, 'expect': res_code_200}
]

# step 16: get udf by id
ud_t1_21_data_list = [
  {'action': 'GET', 'id': udf_id, 'expect': res_code_200}
]

# step 17: post expression
ud_t1_22_data_list = [
  {'action': 'POST', 'data': post_expression_for_mapping[0], 'expect': res_code_200}
]

# step 18: get the expression
ud_t1_23_query_string = f"?name={post_expression_for_mapping[1]}"
ud_t1_23_data_list = [
  {'action': 'GET', 'query_string': ud_t1_23_query_string,
   'expect': res_code_200}
]

# step 19: post the mapping
ud_t1_24_data_list = [
  {'action': 'POST', 'data': post_mapping_data[0], 'expect': res_code_200}
]

# step 20: get the mapping
ud_t1_25_query_string = f"?name={post_mapping_data[1]}"
ud_t1_25_data_list = [
  {'action': 'GET', 'query_string': ud_t1_25_query_string,
   'expect': res_code_200}
]

# step 21: activate
ud_t1_26_data_list = [
  {'action': 'PATCH', 'id': logical_interface_id, 'data': activateData,
   'expect': res_code_200}
]


# post the data
items = [
    return_items({"temperature1": 30, "temperature2": 100})
]
post_data = return_post_data(items)

# step 25: get the data from historian
ud_t1_30_query_string = f"?properties={historian_properties}&startTime={start_time}" \
                        f"&endTime={end_time}"

ud_t1_30_data_list = [
  {'action': 'GET', 'logicaltype_id': logical_interface_id,
   'device_id': post_device_data[1],
   'query_string': ud_t1_30_query_string, 'expect': res_code_200}
]

# step 26: post the data
items1 = [
    return_items({"temperature1": 30, "temperature2": 70})
]
post_data1 = return_post_data(items1)

# step 27: get the data from historian

# step 28: deactivate the logical interface
ud_t1_33_data_list = [
  {'action': 'PATCH', 'id': logical_interface_id, 'data': deactivateData,
   'expect': res_code_200}
]

# step 29: put the udf
ud_t1_34_data_list = [
  {'action': 'PUT', 'id': udf_id, 'data': put_udf_data,
   'expect': res_code_200}
]

# step 30: active

# step 31: post the data

# step 32: get the data from historian

# step 33: post the data
items2 = [
    return_items({"temperature1": 30, "temperature2": 140})
]
post_data2 = return_post_data(items2)

# step 34: get the data from historian

# step 35: deactive

# step 36: delete udf
ud_t1_41_data_list = [
    {'action': 'DELETE', 'id': udf_id, 'expect': res_code_200}
]
