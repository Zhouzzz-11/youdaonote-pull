from iot.data.commonData import *
from iot.requestsData import *


# RCDCS-1051: device type properties
# RCDCS-1052: windows regression
_prefix = 'RCDCS1051b'


post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='onReport',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='window',
    mappingName='temp',
    operator='min',
    windowStepMills=1000,
    windowSizeMills=5000,
    windowAllowedLatenessMills=0,
)]

post_device_data = return_draft_device(_prefix)


# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]


# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

# post the data
items = [
    return_items({"temp": 40})
]
post_data = return_post_data(items)

items1 = [
    return_items({"temp": 41})
]
post_data1 = return_post_data(items1)

# get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = ''

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'query_string': query_data_from_historian_str, 'expect': res_code_200}
]

# post the data1
items2 = [
    return_items({"temp": 42})
]
post_data2 = return_post_data(items2)
items3 = [
    return_items({"temp": 43})
]
post_data3 = return_post_data(items3)

# verify Data
window_output_list = [40.0, 40.0, 40.0, 40.0, 40.0]

# post the data2
items4 = [
    return_items({"temp": 44})
]
post_data4 = return_post_data(items4)
items5 = [
    return_items({"temp": 45})
]
post_data5 = return_post_data(items5)

# verify Data
window_output2_list = [40.0, 40.0, 40.0, 40.0, 40.0, 42.0]

# post the data3
items6 = [
    return_items({"temp": 46})
]
post_data6 = return_post_data(items6)
items7 = [
    return_items({"temp": 47})
]
post_data7 = return_post_data(items7)