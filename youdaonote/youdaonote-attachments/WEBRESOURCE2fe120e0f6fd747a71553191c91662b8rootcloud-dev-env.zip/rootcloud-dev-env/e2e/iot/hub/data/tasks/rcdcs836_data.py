from iot.data.commonData import *
from iot.data.commonData import schema_properties_number_temp, schema_properties_number_temperature_pi, \
    mapping_property_pi
from iot.verify.verifyData import *

# RCDCS-836: test alarm e2e
_prefix = 'RCDCS836'
_prefix_pi = 'RCDCS836_pi'

post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

dd_expression_for_pi = "temp"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix)

# post schema for event type
post_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200}
]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={post_event_type_data[0]['eventTypeName']}"
query_event_type_list = [
    {'action': 'GET', 'query_string': query_event_type_str, 'expect': res_code_200}
]

# post schema for physical interface
post_schema_for_pi_list = [{'action': 'POST',
                            'data': post_schema_data_for_pi[0],
                            'expect': res_code_200}]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [{'action': 'GET',
                             'query_string': query_schema_for_pi_str,
                             'expect': res_code_200}]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
query_expression_for_pi_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str,
                                 'expect': res_code_200}]

# post physical interface
post_pi_list = [{'action': 'POST',
                 'data': post_physical_interface_data[0],
                 'expect': res_code_200}]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST',
                          'data': post_device_type_data[0],
                          'expect': res_code_200}]

# active physical interface
active_pi_list = [{'action': 'PATCH',
                   'id': physical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# post device
post_device_list = [{'action': 'POST',
                     'data': post_device_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_200}]

# get device
query_device_list = [{'action': 'GET',
                      'id': post_device_data[1],
                      'type_id': post_device_type_data[1],
                      'expect': res_code_200}]

import time
t = int(time.time())
t = t*1000

items = [
    return_items({"temp": 30}, ts=t+1000)
]
post_data = return_post_data(items)

# get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = f"?properties={historian_properties1}&startTime={query_start_time}" \
    f"&endTime={query_end_time}"

query_data_from_historian_list = [{'action': 'GET',
                                   'logicaltype_id': post_physical_interface_data[1],
                                   'device_id': post_device_data[1],
                                   'query_string': query_data_from_historian_str,
                                   'expect': res_code_200}]


# test alarm
_condition = "temperature > 50"
_when = 'everyTime'
post_alarm_category_data = return_alarm_category(_prefix)
post_draft_alarm_type_data = return_draft_alarm_type_2(_prefix, platform, post_alarm_category_data[1], sl_2,
                                                       _condition, 'temperature', physical_interface_id, _when, 0)

query_alarm_severity_list = [
    {'action': 'GET', 'expect': res_code_200}
]


# add category
post_alarm_category_list = [
    {'action': 'POST', 'data': post_alarm_category_data[0], 'expect': res_code_200}
]

# create alarm
post_draft_alarm_type_list = [
     {'action': 'POST', 'data': post_draft_alarm_type_data[0], 'expect': res_code_200}
]

# active alarm
patch_draft_alarm_type_list = [
    {'action': 'PATCH', 'id': alarm_type_id, 'data': activateData, 'expect': res_code_200}
]

items1 = [
    return_items({"temp": 60}, ts=t+10000)
]
post_data1 = return_post_data(items1)

items1_disorder = [
    return_items({"temp": 61}, ts=t+11000)
]
post_data1_disorder = return_post_data(items1_disorder)

items1_disorder1 = [
    return_items({"temp": 70}, ts=t+12000)
]
post_data1_disorder1 = return_post_data(items1_disorder1)

items1_disorder2 = [
    return_items({"temp": 80}, ts=t+9100)
]
post_data1_disorder2 = return_post_data(items1_disorder2)

items1_history = [
    return_items({"temp": 59}, ts=t+9000)
]
post_data1_history = return_post_data(items1_history)

query_realtime_data_with_li_di = [
    {'action': 'GET', 'logicaltype_id': post_physical_interface_data[1], 'device_id': post_device_data[1],
     'expect': res_code_200}
]

# query all alarms
query_all_alarm_str = f"?deviceIds=[\"{post_device_data[1]}\"]"
query_all_alarm_list = [
    {'action': 'GET', 'all': True, 'query_string': query_all_alarm_str, 'expect': res_code_200}
]

query_all_alarm_with_subject_str = f"?subject={post_draft_alarm_type_data[2]}"
query_all_alarm_with_subject_list = [
    {'action': 'GET', 'all': True, 'query_string': query_all_alarm_with_subject_str, 'expect': res_code_200}
]

query_alarm_count_with_type_str = ''
query_alarm_count_with_type_list = [
    {'action': 'GET', 'count': True, 'query_string': query_alarm_count_with_type_str, 'expect': res_code_200}
]

query_alarm_count_with_device_and_type_list = [
    {'action': 'GET', 'device': True, 'device_id': post_device_data[1], 'type_id': physical_interface_id,
     'expect': res_code_200}
]

query_alarm_with_id_list = [
    {'action': 'GET', 'alarm_id': '', 'expect': res_code_404}
]

put_alarm_with_id_list = [
    {'action': 'PUT', 'alarm_id': '', 'expect': res_code_200}
]

delete_alarm_with_id_list = [
    {'action': 'DELETE', 'alarm_id': '', 'expect': res_code_200}
]

query_alarm_after_delete_list = [
    {'action': 'GET', 'alarm_id': '', 'expect': res_code_404}
]

delete_multi_alarm_list = [
    {'action': 'DELETE', 'tenant_id': tenant_id, 'expect': res_code_200}
]


# update alarm type
_condition1 = "temperature > 80"
_when1 = 'becomesTrue'
put_draft_alarm_type_data = return_draft_alarm_type_2(_prefix, platform, post_alarm_category_data[1], sl_2,
                                                       _condition1, 'temperature', physical_interface_id, _when1, 0,
                                                      _required_ack=True)
# create alarm
put_draft_alarm_type_2_list = [
     {'action': 'PUT', 'id': alarm_type_id, 'data': put_draft_alarm_type_data[0], 'expect': res_code_200}
]

items21 = [
    return_items({"temp": 30}, ts=t+19000)
]
post_data21 = return_post_data(items21)

items22 = [
    return_items({"temp": 90}, ts=t+20000)
]
post_data22 = return_post_data(items22)

items23 = [
    return_items({"temp": 90}, ts=t+21000)
]
post_data23 = return_post_data(items23)

put_alarm_with_id_2_list = [
    {'action': 'PUT', 'alarm_id': '', 'expect': res_code_200}
]

put_alarm_with_id_3_list = [
    {'action': 'PUT', 'alarm_id': '', 'expect': res_code_200}
]


# put alarm type with period
# update alarm type
_when1 = 'everyTime'
_delayPeriod = 3000
put_draft_alarm_type_data2 = return_draft_alarm_type_2(_prefix, platform, post_alarm_category_data[1], sl_2,
                                                       _condition1, 'temperature', physical_interface_id, _when1,
                                                      _delayPeriod, _required_ack=True)
# create alarm
put_draft_alarm_type_3_list = [
     {'action': 'PUT', 'id': alarm_type_id, 'data': put_draft_alarm_type_data2[0], 'expect': res_code_200}
]

items31 = [
    return_items({"temp": 90}, ts=t+23000)
]
post_data31 = return_post_data(items31)

items32 = [
    return_items({"temp": 90}, ts=t+24000)
]
post_data32 = return_post_data(items32)

items33 = [
    return_items({"temp": 90}, ts=t+26003)
]
post_data33 = return_post_data(items33)

items34 = [
    return_items({"temp": 90}, ts=t+27004)
]
post_data34 = return_post_data(items34)

items35 = [
    return_items({"temp": 90}, ts=t+27005)
]
post_data35 = return_post_data(items35)

items36 = [
    return_items({"temp": 60}, ts=t+27006)
]
post_data36 = return_post_data(items36)

# put alarm type with period
# update alarm type
_when1 = 'becomesTrue'
_condition1 = "temperature > 15"
_recoverCondition = "temperature < 15"
_delayPeriod = 6000
put_draft_alarm_type_data3 = return_draft_alarm_type_2(_prefix, platform, post_alarm_category_data[1], sl_2,
                                                       _condition1, 'temperature', physical_interface_id, _when1,
                                                      _delayPeriod, recoverCondition=_recoverCondition,  _required_ack=False)
# create alarm
put_draft_alarm_type_4_list = [
     {'action': 'PUT', 'id': alarm_type_id, 'data': put_draft_alarm_type_data3[0], 'expect': res_code_200}
]

items3 = [
    return_items({"temp": 20})
]
post_data3 = return_post_data(items3)

items4 = [
    return_items({"temp": 10})
]
post_data4 = return_post_data(items4)
