from iot.data.commonData import *
from iot.requestsData import *
import time


# GYPT-8586: thing e2e
_prefix = 'GYPT8586'
_prefix_1 = 'GYPT8586_1'
_prefix_2 = 'GYPT8586_2'
_prefix_thing_property = 'GYPT8586_thing_property'

post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='Ia',
    displayName='A相电流',
    propertyType='Number',
    privilege=read_only,
    expressionType='linear',
    scale=1,
    base=0,
    mappingName='Ia'
), return_device_type_properties(
    name='Ib',
    displayName='B相电流',
    propertyType='Number',
    privilege=read_only,
    expressionType='linear',
    scale=1,
    base=0,
    mappingName='Ib'
), return_device_type_properties(
    name='Ic',
    displayName='C相电流',
    propertyType='Number',
    privilege=read_only,
    expressionType='linear',
    scale=1,
    base=0,
    mappingName='Ic'
), return_device_type_properties(
    name='Ua',
    displayName='A相电压',
    propertyType='Number',
    privilege=read_only,
    expressionType='linear',
    scale=1,
    base=0,
    mappingName='Ua'
), return_device_type_properties(
    name='Ub',
    displayName='B相电压',
    propertyType='Number',
    privilege=read_only,
    expressionType='linear',
    scale=1,
    base=0,
    mappingName='Ub'
), return_device_type_properties(
    name='Uc',
    displayName='C相电压',
    propertyType='Number',
    privilege=read_only,
    expressionType='linear',
    scale=1,
    base=0,
    mappingName='Uc'
), return_device_type_properties(
    name='onwork',
    displayName='工作阈值',
    propertyType='Number',
    privilege=read_only,
    expressionType='constant',
    expression='30'
), return_device_type_properties(
    name='offwork',
    displayName='待机工作阈值',
    propertyType='Number',
    privilege=read_only,
    expressionType='constant',
    expression='10'
), return_device_type_properties(
    name='workingStatus',
    displayName='电表状态',
    propertyType='String',
    privilege=read_only,
    expressionType='groovy',
    expression="def maxL = $max(Ia, Ib, Ic); if (maxL >= onwork) \"工作\"; else if (maxL >= offwork && maxL <= onwork) \"待机\"; else \"停机\";"
), return_device_type_properties(
    name='workingStatus30s',
    displayName='电表状态',
    propertyType='String',
    privilege=read_only,
    expressionType='window',
    expression="def maxL = $max(Ia, Ib, Ic); if (maxL >= onwork) \"工作\"; else if (maxL >= offwork && maxL <= onwork) \"待机\"; else \"停机\";",
    operator='majority',
    windowSizeMills=30000,
    windowStepMills=30000,
    windowAllowedLatenessMills=30000,
    windowDefaultValueJson="\"离线\""
)]

post_li_data = return_draft_logical_interface(_prefix_thing_property, '', type=li_thing_type)

child_thing_model1 = return_child_thing_model(_prefix, post_device_type_data[1], nodeId='node1')
child_thing_model2 = return_child_thing_model(_prefix, post_device_type_data[1], nodeId='node2')
child_thing_model3 = return_child_thing_model(_prefix, post_device_type_data[1], nodeId='node3')
post_thing_mapping_data = return_thing_mapping(_prefix, post_li_data[2],
                                               [child_thing_model1[0], child_thing_model2[0], child_thing_model3[0]], [])

post_li_properties_data = [return_li_properties(
    name='node1_Ia',
    displayName='A相电流',
    propertyType="Number",
    expressionType="groovy",
    expression="node1.Ia"
), return_li_properties(
    name='state',
    displayName='设备状态',
    propertyType="String",
    expressionType="window",
    expression="def rs = [\"工作\": 0, \"待机\": 0, \"停机\": 0, \"离线\": 0]; if ($input.containsKey(\"node1\") && rs[node1.workingStatus] != null) rs[node1.workingStatus] += 1; if ($input.containsKey(\"node2\") && rs[node2.workingStatus] != null) rs[node2.workingStatus] += 1; if ($input.containsKey(\"node3\") && rs[node3.workingStatus] != null) rs[node3.workingStatus] += 1; println(node1.workingStatus);println(rs[node1.workingStatus]); if (rs[\"工作\"] > 0) \"工作\" else if (rs[\"待机\"] > 0) \"待机\" else if (rs[\"停机\"] > 0) \"停机\" else \"离线\"",
    operator="majority",
    windowStepMills=30000,
    windowSizeMills=30000,
    windowAllowedLatenessMills=30000,
    windowDefaultValueJson="\"离线\""
)]

post_device_data1 = return_draft_device(_prefix, name='电表1')
post_device_data2 = return_draft_device(_prefix_1, name='电表2')
post_device_data3 = return_draft_device(_prefix_2, name='电表3')

device_data = [
    {
        'nodeId': 'node1',
        'instances': [
            {
                'deviceId': post_device_data1[1],
                'deviceTypeId': post_device_type_data[1]
            }
        ]
    },
    {
        'nodeId': 'node2',
        'instances': [
            {
                'deviceId': post_device_data2[1],
                'deviceTypeId': post_device_type_data[1]
            }
        ]
    },
    {
        'nodeId': 'node3',
        'instances': [
            {
                'deviceId': post_device_data3[1],
                'deviceTypeId': post_device_type_data[1]
            }
        ]
    }
]

post_thing_data = return_thing(_prefix, devices=device_data)


post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data, 'expect': res_code_200}
]

active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

post_device_1_list = [
    {'action': 'POST', 'data': post_device_data1[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

post_device_2_list = [
    {'action': 'POST', 'data': post_device_data2[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

post_device_3_list = [
    {'action': 'POST', 'data': post_device_data3[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

post_thing_mapping_list = [
    {'action': 'POST', 'data': post_thing_mapping_data[0], 'expect': res_code_200}
]

post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

post_thing_list = [
    {'action': 'POST', 'thingTypeId': post_li_data[2], 'data': post_thing_data[0], 'expect': res_code_200}
]


t = int(time.time())
t1 = int(t/60)*60000 + 25000
t2 = int(t/60)*60000 + 95000
t = t*1000

items1 = [
    return_items({"Ia": 10, "Ib": 15, "Ic": 32, "Ua": 220, "Ub": 180, "Uc": 120}, ts=t1)
]
post_data1 = return_post_data(items1)


items2 = [
    return_items({"Ia": 9, "Ib": 15, "Ic": 22, "Ua": 220, "Ub": 180, "Uc": 120}, ts=t1+10)
]
post_data2 = return_post_data(items2)


items3 = [
    return_items({"Ia": 8, "Ib": 8, "Ic": 9, "Ua": 220, "Ub": 180, "Uc": 120}, ts=t1+20)
]
post_data3 = return_post_data(items3)

items1_1 = [
    return_items({"Ia": 10, "Ib": 15, "Ic": 32, "Ua": 220, "Ub": 180, "Uc": 120}, ts=t2)
]
post_data4 = return_post_data(items1_1)


items2_1 = [
    return_items({"Ia": 10, "Ib": 15, "Ic": 22, "Ua": 220, "Ub": 180, "Uc": 120}, ts=t2+10)
]
post_data5 = return_post_data(items2_1)


items3_1 = [
    return_items({"Ia": 2, "Ib": 8, "Ic": 9, "Ua": 220, "Ub": 180, "Uc": 120}, ts=t2+20)
]
post_data6 = return_post_data(items3_1)


query_data_from_pi_historian_1_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data1[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_pi_historian_2_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data2[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_pi_historian_3_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data3[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_thing_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_thing_data[1],
     'query_string': '', 'expect': res_code_200}
]

ver_res_1 = [10.0, 10.0, 15.0, 32.0, 220.0, '工作', 180.0, 120.0, 30.0]
ver_res_2 = [10.0, 9.0, 15.0, 22.0, 220.0, '待机', 180.0, 120.0, 30.0]
ver_res_3 = [10.0, 8.0, 8.0, 9.0, 220.0, '停机', 180.0, 120.0, 30.0]
