from iot.verify.verifyData import *
from iot.data.commonData import *

# test case 1: e2e case for draft schema
_prefix = 'RCDCS162'
post_schema_data = return_draft_schema_data(_prefix, schema_properties_number_temp)
put_schema_data = return_draft_schema_data(_prefix, schema_properties_string_temp)

# neg:
_prefix_neg = 'RCDCS162_neg'
post_schema_with_invalid_properties_format_data = return_draft_schema_data(_prefix_neg, "test")
post_schema_with_null_name_data = return_draft_schema_data(_prefix, schema_properties_number_temp, name='')

# get schema
t162_get_schema_list = [
    {'action': 'GET', 'expect': res_code_200}
]

# post schema and get the schema
query_schema_str = f"?name={post_schema_data[1]}"
t162_post_and_get_schema_list = [
    {'action': 'POST', 'data': post_schema_data[0], 'expect': res_code_200},
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post schema with invalid properties format
t162_post_with_invalid_properties_format_list = [
    {'action': 'POST', 'data': post_schema_with_invalid_properties_format_data[0], 'expect': res_code_400}
]

# post schema with same name
t162_post_with_same_name_list = [
    {'action': 'POST', 'data': post_schema_data[0], 'expect': res_code_200}
]

# post schema with '' name
t162_post_with_null_name_list = [
    {'action': 'POST', 'data': post_schema_with_null_name_data[0], 'expect': res_code_400}
]

# put schema and get the schema by id
t162_put_and_get_schema_list = [
    {'action': 'PUT', 'id': schema_id, 'data': put_schema_data[0], 'expect': res_code_200},
    {'action': 'GET', 'id': schema_id, 'expect': res_code_200}
]

# get schema with not exist id
t162_get_invalid_id_schema_list = [
    {'action': 'GET', 'id': invalid_id, 'expect': res_code_404}
]

# put schema with not exist id
t162_put_invalid_id_schema_list = [
    {'action': 'PUT', 'id': invalid_id, 'data': put_schema_data[0], 'expect': res_code_404}
]

# put schema with invalid body
t162_put_invalid_body_schema_list = [
    {'action': 'PUT', 'id': schema_id, 'data': post_schema_with_null_name_data[0], 'expect': res_code_400}
]

# delete schema and get schema by id
t162_delete_and_get_schema_list = [
    {'action': 'DELETE', 'id': schema_id, 'expect': res_code_200},
    {'action': 'GET', 'id': schema_id, 'expect': res_code_404}
]

# delete with not exist schema id
t162_delete_not_exist_schema_list = [
    {'action': 'DELETE', 'id': invalid_id, 'expect': res_code_404}
]