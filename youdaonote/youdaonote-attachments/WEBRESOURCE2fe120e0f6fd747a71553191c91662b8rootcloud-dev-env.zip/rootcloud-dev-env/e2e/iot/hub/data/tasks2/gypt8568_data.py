from iot.data.commonData import *
from iot.requestsData import *


# GYPT-8568: device type directlyLinked field
_prefix = 'GYPT8568'
_prefix_1 = 'AGYPT8568'
_prefix_2 = 'AGYPT8568_2'

post_device_type_data = return_draft_device_type(_prefix, '')
post_device_type_data2 = return_draft_device_type(_prefix_1, '', directlyLinked=True)
post_device_type_data3 = return_draft_device_type(_prefix_2, '', directlyLinked=True, classId=gatewayClass)
put_device_type_data = return_draft_device_type(_prefix, '', _description=des_str_put)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
post_device_data2 = return_draft_device(_prefix_1, manufacturerId=manufacturer_id)
post_device_data3 = return_draft_device(_prefix_2, gatewayId=post_device_data2[1], manufacturerId=manufacturer_id)


# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post draft device type
post_gateway_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data3[0], 'expect': res_code_200}
]

put_device_type_list = [
    {'action': 'PUT', 'id': post_device_type_data[1], 'data': put_device_type_data[0], 'expect': res_code_200}
]

# post draft device type
post_device_type_2_list = [
    {'action': 'POST', 'data': post_device_type_data2[0], 'expect': res_code_200}
]

query_device_type_without_direct_link_str = f"?name={post_device_type_data[2]}"
get_device_type_without_direct_link_list = [
    {'action': 'GET', 'query_string': query_device_type_without_direct_link_str, 'expect': res_code_200}
]

query_device_type_with_direct_link_true_str = f"?name={post_device_type_data[2]}&directlyLinked=true"
get_device_type_with_direct_link_true_list = [
    {'action': 'GET', 'query_string': query_device_type_with_direct_link_true_str, 'expect': res_code_200}
]

query_device_type_with_direct_link_false_str = f"?name={post_device_type_data[2]}&directlyLinked=false"
get_device_type_with_direct_link_false_list = [
    {'action': 'GET', 'query_string': query_device_type_with_direct_link_false_str, 'expect': res_code_200}
]

# post device
post_device_without_gateway_id_and_direct_link_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_500}
]

# post gateway
post_device_list = [
    {'action': 'POST', 'data': post_device_data2[0], 'type_id': post_device_type_data3[1], 'expect': res_code_200}
]

# post not direct device
post_device_with_gateway_list = [
    {'action': 'POST', 'data': post_device_data3[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]
