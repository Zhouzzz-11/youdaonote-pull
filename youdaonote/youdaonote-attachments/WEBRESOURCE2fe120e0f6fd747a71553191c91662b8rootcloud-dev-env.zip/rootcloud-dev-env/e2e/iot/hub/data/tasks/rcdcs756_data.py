from iot.hub.data.demo_data import *


_prefix = 'RCDCS756'

logical_interface_id = post_logical_interface_data[2]
device_id = post_device_data[1]

# query the realtime data with li and device id
query_realtime_data_with_li_di = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'device_id': device_id,
     'expect': res_code_200}
]

# query the realtime data with li
query_realtime_data_with_li = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'devices': f"[\"{device_id}\"]", 'expect': res_code_200}
]

# post query with device
query_data = [
    {'deviceIds': [device_id], 'logicalTypeId': logical_interface_id, 'properties': ['li_temperature']}
]

post_query_realtime_with_device_list = [
    {'action': 'POST', 'data': query_data, 'expect': res_code_200}
]

# query with actionable id
query_realtime_data_with_actionable_list = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'actionable_id': e2e_actionable_id,
     'query_string': '', 'expect': res_code_200}
]