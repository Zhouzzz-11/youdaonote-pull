from iot.data.commonData import *
from iot.requestsData import *
import time

# GYPT-8578: 4.0协议上数
_prefix = 'GYPT8578'
_prefix_1 = 'GYPT8578_1'
_prefix_2 = 'GYPT8578_2'

post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Integer',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='groovy',
    expression='temp+1',
    mappingName='temp'
)]

post_device_type_data2 = return_draft_device_type(_prefix_1, '', directlyLinked=True, classId=gatewayClass)
post_device_type_properties_data2 = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='groovy',
    expression='temp+2',
    mappingName='temp'
)]

post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id, protocol=protocolV4)
post_device_data2 = return_draft_device(_prefix_1, manufacturerId=manufacturer_id, protocol=protocolV4)


ts = int(time.time()*1000)
items_neg = [
    return_items({"temp": 2222222222222222400000000000000000000000000000000000000000000000}, ts=ts+10)
]
post_neg_data = return_post_data(items_neg)

items = [
    return_items({"temp": 40}, ts=ts+100)
]
post_data = return_post_data(items)

items2 = [
    return_items({"temp": 41}, ts=ts+100)
]
post_data2 = return_post_data(items2)

# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'query_string': '', 'expect': res_code_200}
]


"""
    gateway
"""
# post device
post_device_type_2_list = [
    {'action': 'POST', 'data': post_device_type_data2[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_2_list = [
    {'action': 'POST', 'id': post_device_type_data2[1], 'data': post_device_type_properties_data2,
     'expect': res_code_200}
]

# active physical interface
active_pi_2_list = [
    {'action': 'PATCH', 'id': post_device_type_data2[1], 'data': activateData, 'expect': res_code_200}
]


post_device_2_list = [
    {'action': 'POST', 'data': post_device_data2[0], 'type_id': post_device_type_data2[1], 'expect': res_code_200}
]

query_data_from_historian_2_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data2[1], 'device_id': post_device_data2[1],
     'query_string': '', 'expect': res_code_200}
]

"""
    not directly
"""
post_device_type_data3 = return_draft_device_type(_prefix_2, '')
post_device_type_properties_data3 = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='groovy',
    expression='temp+3',
    mappingName='temp'
)]

post_device_data3 = return_draft_device(_prefix_2, manufacturerId=manufacturer_id, protocol=protocolV4,
                                        gatewayId=post_device_data2[1])

items3 = [
    return_items({"temp": 42}, ts=ts+200)
]
post_data3 = return_post_no_direct_data(items3, post_device_data3[1])
# post device
post_device_type_3_list = [
    {'action': 'POST', 'data': post_device_type_data3[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_3_list = [
    {'action': 'POST', 'id': post_device_type_data3[1], 'data': post_device_type_properties_data3,
     'expect': res_code_200}
]

# active physical interface
active_pi_3_list = [
    {'action': 'PATCH', 'id': post_device_type_data3[1], 'data': activateData, 'expect': res_code_200}
]


post_device_3_list = [
    {'action': 'POST', 'data': post_device_data3[0], 'type_id': post_device_type_data3[1], 'expect': res_code_200}
]

query_data_from_historian_3_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data3[1], 'device_id': post_device_data3[1],
     'query_string': '', 'expect': res_code_200}
]