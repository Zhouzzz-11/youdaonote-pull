from iot.hub.data.tasks2.mqtt4.gypt8578_data import *


_prefix = 'GYPT8357'
put_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id,
                                      protocol=protocolV4, assetId=_prefix+'_asset_id_'+r_num_suffix2)

items3 = [
    return_items({"temp": 42}, ts=ts+300)
]
post_data3 = return_post_data(items3)

put_device_list = [
    {'action': 'PUT', 'type_id': post_device_type_data[1], 'id': post_device_data[1],
     'data': put_device_data[0], 'expect': res_code_200}
]