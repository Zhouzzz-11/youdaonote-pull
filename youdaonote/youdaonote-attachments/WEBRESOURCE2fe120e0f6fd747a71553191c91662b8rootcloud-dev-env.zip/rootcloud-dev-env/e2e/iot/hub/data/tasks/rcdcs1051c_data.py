from iot.data.commonData import *
from iot.requestsData import *


# GYPT-23813: groovy window default value optimize
_prefix = 'RCDCS1051c'


post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='onReport',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType='window',
    mappingName='temp',
    operator='min',
    windowStepMills=1000,
    windowSizeMills=5000,
    windowAllowedLatenessMills=0,
    windowDefaultValueJson='test'
)]

post_device_data = return_draft_device(_prefix)


# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_400}
]
