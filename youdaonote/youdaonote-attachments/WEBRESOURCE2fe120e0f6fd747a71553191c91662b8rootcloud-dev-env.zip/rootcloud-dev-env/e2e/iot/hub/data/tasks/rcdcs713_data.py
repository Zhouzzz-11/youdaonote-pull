from iot.data.commonData import *
from iot.data.commonData import schema_properties_number_li_temperature, mapping_property_pi, mapping_property_li
from iot.verify.verifyData import *


_prefix = 'RCDCS713'
_prefix_pi = 'RCDCS713_pi'
_prefix_li = 'RCDCS713_li'
_prefix1 = 'RCDCS713_1'

_schema_properties = [return_draft_schema_properties('temp', 'Integer')]
_schema_properties_2 = [return_draft_schema_properties('temperature', 'Integer', privilege='WriteOnly', minValue='20',
                                                       maxValue='100')]
post_schema_data_for_event_type = return_draft_schema_data(_prefix, _schema_properties)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

dd_expression_for_pi = "temp"
dd_expression_for_mapping = "temperature + 10"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, _schema_properties_2)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi, ex_linear, scale=2, base=1,
                                                 fromProperty='temp')

post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_properties_number_li_temperature)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')
post_expression_for_mapping = return_draft_expression(_prefix1, dd_expression_for_mapping)
post_mapping_data = return_draft_mapping(_prefix, '', '', mapping_property_li)


# RCDCS-571: test data for activating
# post schema for event type
post_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200}
]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={post_event_type_data[0]['eventTypeName']}"
query_event_type_list = [
    {'action': 'GET', 'query_string': query_event_type_str, 'expect': res_code_200}
]

# post schema for physical interface
post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [
    {'action': 'GET', 'query_string': query_schema_for_pi_str, 'expect': res_code_200}
]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
query_expression_for_pi_list = [
    {'action': 'GET', 'query_string': query_expression_for_pi_str, 'expect': res_code_200}
]

# post physical interface
post_pi_list = [
    {'action': 'POST', 'data': post_physical_interface_data[0], 'expect': res_code_200}
]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': physical_interface_id, 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

# get device
query_device_list = [
    {'action': 'GET', 'id': post_device_data[1], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

# post schema for logical interface
post_schema_for_li_list = [
    {'action': 'POST', 'data': post_schema_data_for_li[0], 'expect': res_code_200}
]

# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [
    {'action': 'GET', 'query_string': query_schema_for_li_str, 'expect': res_code_200}
]

# post the logical interface
post_li_list = [
    {'action': 'POST', 'data': post_logical_interface_data[0], 'expect': res_code_200}
]

# get the logical interface
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'query_string': query_li_str, 'expect': res_code_200}
]

# post expression
post_expression_list = [
    {'action': 'POST', 'data': post_expression_for_mapping[0], 'expect': res_code_200}
]

# get the expression
query_expression_str = f"?name={post_expression_for_mapping[1]}"
query_expression_list = [
    {'action': 'GET', 'query_string': query_expression_str, 'expect': res_code_200}
]

# post the mapping
post_mapping_list = [
    {'action': 'POST', 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_mapping_data[1]}"
query_mapping_list = [
    {'action': 'GET', 'query_string': query_mapping_str, 'expect': res_code_200}
]

# activate logical interface
active_li_list = [
    {'action': 'PATCH', 'id': logical_interface_id, 'data': activateData, 'expect': res_code_200}
]

items = [
    return_items({"temp": 30})
]

post_data = return_post_data(items)


# get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = f"?properties={historian_properties}&startTime={query_start_time}" \
    f"&endTime={query_end_time}"

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'device_id': post_device_data[1],
     'query_string': query_data_from_historian_str, 'expect': res_code_200}
]


# instruction
post_instruction_data = return_instruction(_prefix, _schema_properties_2)
patch_instruction_data = {'properties': [{'name': 'temperature', 'value': '99', 'valueType': 'String'}]}
post_instruction_list = [
    {'action': 'POST', 'data': post_instruction_data[0], 'devicetype_id': post_device_type_data[1],
     'expect': res_code_200}
]

patch_instruction_list = [
    {'action': 'PATCH', 'devicetype_id': post_device_type_data[1], 'id': post_instruction_data[1],
     'device_id': post_device_data[1], 'data':patch_instruction_data, 'expect': res_code_200}
]