from iot.data.commonData import *
from iot.requestsData import *
from iot.hub.data.tasks2.gypt8585.gypt8585_e2e_2 import gypt8585_node2_property_data as node2_data


# GYPT-8585: thing li property
_prefix = 'GYPT8585_thing_property'

post_li_data = return_draft_logical_interface(_prefix, '', type=li_thing_type)
child_thing_model = return_child_thing_model(_prefix, node2_data.post_li_data[2])
post_thing_mapping_data = return_thing_mapping(_prefix, post_li_data[2],
                                               [child_thing_model[0]], [])

post_li_properties_data = [return_li_properties(
    name='thing_temperature',
    displayName='thing_温度',
    propertyType="Integer",
    persistStrategy="always",
    privilege="ReadOnly",
    minValue="30",
    maxValue="80",
    expressionType="groovy",
    expression="li_temperature+8",
    fromInterfaceId=node2_data.post_li_data[2],
    fromPropertyName="li_temperature",
    nodeId=child_thing_model[1]
)]

put_li_properties_data = {
    'change': {
        'name': 'thing_temperature',
        'fromInterfaceId': node2_data.post_li_data[2],
        'nodeId': child_thing_model[1]
    },
    'to': return_li_properties(
        name='thing_temperature',
        displayName='thing_温度',
        propertyType="Integer",
        persistStrategy="always",
        privilege="ReadOnly",
        minValue="30",
        maxValue="80",
        expressionType="groovy",
        expression="li_temperature+9",
        fromInterfaceId=node2_data.post_li_data[2],
        fromPropertyName="li_temperature",
        nodeId=child_thing_model[1]
    )
}

delete_li_properties_data = [
    {
        'name': 'thing_temperature',
        'fromInterfaceId': node2_data.post_li_data[2],
        'nodeId': child_thing_model[1]
    }
]


# post the mapping
post_thing_mapping_list = [
    {'action': 'POST', 'data': post_thing_mapping_data[0], 'expect': res_code_200}
]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

# active li interface
active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

put_li_properties_list = [
    {'action': 'PUT', 'id': post_li_data[2], 'data': put_li_properties_data, 'expect': res_code_200}
]

# get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = ''

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': node2_data.post_device_data[1],
     'query_string': query_data_from_historian_str, 'expect': res_code_200}
]

# delete li properties
delete_li_properties_list = [
    {'action': 'DELETE', 'id': post_li_data[2], 'data': delete_li_properties_data, 'expect': res_code_200}
]
