from iot.data.commonData import *
from iot.hub.data.tasks2.gypt8585.gypt8585_e2e_1 import gypt8585_data, gypt8585_node1_data

# data for the thing mapping
_prefix = 'GYPT8585_thing_mapping'
_prefix1 = 'GYPT8585_thing'

child_thing_model = gypt8585_data.child_thing_model
post_thing_mapping_data = gypt8585_data.post_thing_mapping_data
put_thing_mapping_data = return_thing_mapping(_prefix, gypt8585_data.post_logical_interface_data[2],
                                              [child_thing_model[0]], mapping_property_thing, _description=des_str_put)

device_data = {
    "nodeId": child_thing_model[1],
    "instances": [
        {
          "deviceId": gypt8585_node1_data.post_device_data[1],
          "deviceTypeId": gypt8585_node1_data.post_device_type_data[1]
        }
      ]
    }

post_thing_data = return_thing(_prefix1, devices=[device_data])
put_thing_data = return_thing(_prefix1, devices=[device_data], _description=des_str_put)


query_thing_mapping_str = f"?mappingId={gypt8585_data.post_logical_interface_data[2]}"
get_thing_mappings_by_name_list = [
    {'action': 'GET', 'query_string': query_thing_mapping_str, 'expect': res_code_200}
]

query_thing_mapping_str2 = f"?logicalInterface.interfaceId={gypt8585_data.post_logical_interface_data[2]}"
get_thing_mappings_by_li_id_list = [
    {'action': 'GET', 'query_string': query_thing_mapping_str2, 'expect': res_code_200}
]

post_thing_list = [
    {'action': 'POST', 'thingTypeId': gypt8585_data.post_logical_interface_data[2], 'data': post_thing_data[0],
     'expect': res_code_200}
]

get_thing_by_id_list = [
    {'action': 'GET', 'thingTypeId': gypt8585_data.post_logical_interface_data[2], 'id': post_thing_data[1],
     'expect': res_code_200}
]

put_thing_list = [
    {'action': 'PUT', 'thingTypeId': gypt8585_data.post_logical_interface_data[2], 'id': post_thing_data[1],
     'data': put_thing_data[0], 'expect': res_code_200}
]

delete_thing_list = [
    {'action': 'DELETE', 'thingTypeId': gypt8585_data.post_logical_interface_data[2], 'id': post_thing_data[1],
     'expect': res_code_200}
]

query_thing_str = f"?name={post_thing_data[2]}"
get_thing_by_name_list = [
    {'action': 'GET',  'query_string': query_thing_str, 'expect': res_code_200}
]

put_thing_mappings_list = [
    {'action': 'PUT', 'id': gypt8585_data.post_logical_interface_data[2], 'data': put_thing_mapping_data[0], 'expect': res_code_200}
]

delete_thing_mapping_list = [
    {'action': 'DELETE', 'id': gypt8585_data.post_logical_interface_data[2], 'expect': res_code_200}
]

get_thing_mapping_by_id_list = [
    {'action': 'GET', 'id': gypt8585_data.post_logical_interface_data[2], 'expect': res_code_404}
]