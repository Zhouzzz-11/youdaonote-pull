from iot.data.commonData import *
from iot.requestsData import *


_prefix = 'GYPT11108'

post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    expressionType='constant',
    expression='10',
    mappingName='temp'
)]

post_device_data = return_draft_device(_prefix)

items = [
    return_items({})
]
post_data = return_post_data(items)

# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'query_string': '', 'expect': res_code_200}
]
