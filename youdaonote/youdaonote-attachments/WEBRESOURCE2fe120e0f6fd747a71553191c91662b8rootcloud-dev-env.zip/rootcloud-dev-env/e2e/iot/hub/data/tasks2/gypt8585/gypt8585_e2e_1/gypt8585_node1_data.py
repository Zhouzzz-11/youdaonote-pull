from iot.data.commonData import *
from iot.verify.verifyData import *


# GYPT8585 thing E2E
# data for the node 1 li
_prefix = 'GYPT8585_node1'
_prefix_pi = 'GYPT8585_node1_pi'
_prefix_li = 'GYPT8585_node1_li'
_prefix1 = 'GYPT8585_node1_1'

_schema_properties = [return_draft_schema_properties('temp', 'Number')]
_schema_properties_pi = [return_draft_schema_properties('temperature', 'Number')]
_schema_properties_li = [return_draft_schema_properties('li_temperature', 'Number')]
post_schema_data_for_event_type = return_draft_schema_data(_prefix, _schema_properties)
post_event_type_data = return_draft_event_type(_prefix, '')

dd_expression_for_pi = f"{post_event_type_data[1]}.temp"
dd_expression_for_mapping = "temperature + 1"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, _schema_properties_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, _schema_properties_li)
post_logical_interface_data = return_draft_logical_interface(_prefix, '', type=li_type)
post_expression_for_mapping = return_draft_expression(_prefix1, dd_expression_for_mapping)
post_mapping_data = return_draft_mapping(_prefix, '', post_logical_interface_data[2], mapping_property_li)

# GYPT-8585: test data for Thing/ThingType
# post schema for event type
post_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200}
]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={post_event_type_data[1]}"
query_event_type_list = [
    {'action': 'GET', 'query_string': query_event_type_str, 'expect': res_code_200}
]

# post schema for physical interface
post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [
    {'action': 'GET', 'query_string': query_schema_for_pi_str, 'expect': res_code_200}
]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
query_expression_for_pi_list = [
    {'action': 'GET', 'query_string': query_expression_for_pi_str, 'expect': res_code_200}
]

# post physical interface
post_pi_list = [
    {'action': 'POST', 'data': post_physical_interface_data[0], 'expect': res_code_200}
]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': physical_interface_id, 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

# get device
query_device_list = [
    {'action': 'GET', 'id': post_device_data[1], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

# post schema for logical interface
post_schema_for_li_list = [{'action': 'POST',
                            'data': post_schema_data_for_li[0],
                            'expect': res_code_200}]

# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [{'action': 'GET',
                             'query_string': query_schema_for_li_str,
                             'expect': res_code_200}]

# post the logical interface
post_li_list = [{'action': 'POST',
                 'data': post_logical_interface_data[0],
                 'expect': res_code_200}]

# get the logical interface
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'query_string': query_li_str, 'expect': res_code_200}
]

# post expression
post_expression_list = [
    {'action': 'POST', 'data': post_expression_for_mapping[0], 'expect': res_code_200}
]

# get the expression
query_expression_str = f"?name={post_expression_for_mapping[1]}"
query_expression_list = [
    {'action': 'GET', 'query_string': query_expression_str, 'expect': res_code_200}
]

# post the mapping
post_mapping_list = [
    {'action': 'POST', 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_mapping_data[1]}"
query_mapping_list = [
    {'action': 'GET', 'query_string': query_mapping_str, 'expect': res_code_200}
]

# activate logical interface
active_li_list = [
    {'action': 'PATCH', 'id': post_logical_interface_data[2], 'data': activateData, 'expect': res_code_200}
]

