from iot.data.commonData import *

# RCDCS-6931: expression priority
_prefix = 'GYPT6931'
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperature',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType=ex_groovy,
    expression='temp+1',
    mappingName='temp',
),return_device_type_properties(
    name='temperatureA',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType=ex_const,
    expression='22'
), return_device_type_properties(
    name='temperatureB',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType=ex_linear,
    scale=2,
    base=1,
    fromProperty="temperatureA",
), return_device_type_properties(
    name='temperatureC',
    displayName='温度',
    propertyType='Number',
    persistStrategy='always',
    privilege=read_write,
    minValue='20',
    maxValue='80',
    expressionType=ex_groovy,
    expression='temperatureB+1',
    fromProperty="temperatureB"
)]

post_device_data = return_draft_device(_prefix)

post_li_data = return_draft_logical_interface(_prefix, '')

post_li_properties_data = [return_li_properties(
    name='li_temperatureA',
    displayName='li_温度',
    propertyType="Number",
    persistStrategy="always",
    privilege="ReadOnly",
    minValue="30",
    maxValue="80",
    expressionType=ex_linear,
    scale=1,
    base=2,
    fromInterfaceId=post_device_type_data[1],
    fromProperty="temperatureC",
), return_li_properties(
    name='li_temperatureB',
    displayName='li_温度',
    propertyType="Number",
    persistStrategy="always",
    privilege="ReadOnly",
    minValue="30",
    maxValue="80",
    expressionType=ex_groovy,
    expression='li_temperatureA+1',
    fromInterfaceId=post_device_type_data[1],
)]


post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]


# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1],
     'expect': res_code_200}]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

# post li properties
post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

# 查询设备接入时长
get_device_by_id = [
    {'action': 'GET', 'id': post_device_data[1], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

get_device_status_by_id = [
    {'action': 'GET', 'device_id': post_device_data[1], 'device_type_id': post_device_type_data[1], 'expect': res_code_200}
]

# active li interface
active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

# post the data
items = [
    return_items({"temp": 37})
]
post_data = return_post_data(items)

# get the data from historian
query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_device_data[1],
     'query_string': '', 'expect': res_code_200}
]
