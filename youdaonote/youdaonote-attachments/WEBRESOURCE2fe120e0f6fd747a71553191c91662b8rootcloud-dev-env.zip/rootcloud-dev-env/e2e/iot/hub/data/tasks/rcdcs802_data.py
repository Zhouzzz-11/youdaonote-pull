import time
from iot.data.commonData import *
from iot.verify import verifyData


_prefix = 'RCDCS802'
_prefix_pi = 'RCDCS802_pi'
_prefix_1 = 'RCDCS802_1'
_prefix_2 = 'RCDCS802_2'

_location = '__location__'
_online = '__online__'

schema_property = [
    return_schema_property_interface('longitude', 'Number', persis_strategy_on_report, _privilege=read_only),
    return_schema_property_interface('latitude', 'Number', persis_strategy_on_report, _privilege=read_only),
    return_schema_property_interface('connected', 'Boolean', persis_strategy_on_report, _privilege=read_only)
]

schema_property_pi = [
    return_schema_property_interface(_location, 'Json', persis_strategy_on_report, _privilege=read_only),
    return_schema_property_interface(_online, 'Json', persis_strategy_on_report, _privilege=read_only)
]

expression_for_pi_1 = "$location(longitude, latitude)"
expression_for_pi_2 = "$online(connected)"

mapping_property_pi = [
    {'propertyName': _location, 'expressionId': ''},
    {'propertyName': _online, 'expressionId': ''}
]


post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_property)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_property_pi)
post_expression_for_pi_1 = return_draft_expression(_prefix, expression_for_pi_1)
post_expression_for_pi_2 = return_draft_expression(_prefix, expression_for_pi_2)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
post_device_data_1 = return_draft_device(_prefix_1, manufacturerId=manufacturer_id)
post_device_data_2 = return_draft_device(_prefix_2, manufacturerId=manufacturer_id)

# step 1: post schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
post_and_get_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200},
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# step 2: post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# post schema for physical interface
post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# post expression for property mapping
post_expression_1_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi_1[0], 'expect': res_code_200}
]

post_expression_2_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi_2[0], 'expect': res_code_200}
]

# post physical interface and get physical interface
post_pi_list = [
    {'action': 'POST', 'data': post_physical_interface_data[0], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}]

# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': verifyData.physical_interface_id, 'data': activateData,
    'expect': res_code_200}
]

# post device
post_device_1_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200},
]

post_device_2_list = [
    {'action': 'POST', 'data': post_device_data_1[0], 'type_id': post_device_type_data[1], 'expect': res_code_200},
]

post_device_3_list = [
    {'action': 'POST', 'data': post_device_data_2[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

ts = int(time.time()*1000)
items = [
    return_items({"longitude": 121.41257, "latitude": 31.191118, "connected": True}, ts=ts+100)
]
post_data = return_post_data(items)

# get the data from historian
query_start_time = ""
query_end_time = ""

query_data_from_historian_list = [{'action': 'GET',
                                   'logicaltype_id': verifyData.physical_interface_id,
                                   'device_id': post_device_data[1],
                                   'query_string': '',
                                   'expect': res_code_200}]

ver_data = {f'{_location}.latitude': 31.191118, f'{_location}.city': '上海城区', f'{_online}.connected': True,
            f'{_location}.district': '长宁区', f'{_location}.country': '中国', f'{_location}.locationSource': 'GPS',
            f'{_location}.state': '上海市', f'{_location}.longitude': 121.41257}

# device status
query_device_status_by_id_list = [
    {'action': 'GET', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'expect': res_code_200}
]

device_1_status_data = {'country': 'china', 'city': 'beijing'}
device_2_status_data = {'country': 'china', 'city': 'suzhou'}
post_device_status_by_id_list = [
    {'action': 'PUT', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data_1[1],
     'data': device_1_status_data, 'expect': res_code_200},
    {'action': 'PUT', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data_2[1],
     'data': device_2_status_data, 'expect': res_code_200},
]

query_device_1_status_by_id_list = [
    {'action': 'GET', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data_1[1],
     'expect': res_code_200}
]
query_device_2_status_by_id_list = [
    {'action': 'GET', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data_2[1],
     'expect': res_code_200}
]

device_1_status_put_data = {'city': 'nanjing', 'street': 'xinjiekou'}
device_2_status_put_data = {'city': 'shanghai', 'street': 'nanjingxilu'}
put_device_1_status_by_id_list = [
    {'action': 'PUT', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data_1[1],
     'data': device_1_status_put_data, 'expect': res_code_200}
]
put_device_2_status_by_id_list = [
    {'action': 'PUT', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data_2[1],
     'data': device_2_status_put_data, 'expect': res_code_200}
]

query_multi_device_str = f"?deviceTypeId={post_device_type_data[1]}"
query_multi_device_by_device_type_list = [
    {'action': 'GET', 'query_string': query_multi_device_str, 'expect': res_code_200}
]

device_status_query_data = [
    {'deviceId': post_device_data[1], 'deviceTypeId': post_device_type_data[1]},
    {'deviceId': post_device_data_2[1], 'deviceTypeId': post_device_type_data[1]}
]
post_bulk_device_query_list = [
    {'action': 'POST', 'data': device_status_query_data, 'expect': res_code_200}
]

query_device_status_count_str = f"?deviceTypeId={post_device_type_data[1]}&online=true"
query_device_status_count_list = [
    {'action': 'GET', 'query_string': query_device_status_count_str, 'count': True, 'expect': res_code_200}
]

# post the data, update the device online and location
items1 = [
    return_items({"longitude": 111.41257, "latitude": 33.191118, "connected": False})
]
post_data1 = return_post_data(items1)

ver_1_data = {f'{_location}.latitude': 33.191118, f'{_location}.city': '南阳市', f'{_online}.connected': False,
            f'{_location}.district': '淅川县', f'{_location}.country': '中国', f'{_location}.locationSource': 'GPS',
            f'{_location}.state': '河南省', f'{_location}.longitude': 111.41257}

# device status
query_device_status_1_by_id_list = [
    {'action': 'GET', 'device_type_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'expect': res_code_200}
]
