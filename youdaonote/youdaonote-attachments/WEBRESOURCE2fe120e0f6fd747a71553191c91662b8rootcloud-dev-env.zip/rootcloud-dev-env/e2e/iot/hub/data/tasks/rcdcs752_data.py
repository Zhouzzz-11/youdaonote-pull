from iot.hub.data.demo_data import *


_prefix = 'RCDCS752'

logical_interface_id = post_logical_interface_data[2]
device_id = post_device_data[1]
event_type_name = post_event_type_data[1]

query_start_time = ""
query_end_time = ""

items = [
    return_items({"temp": e2e_data_4})
]
post_data = return_post_data(items)

query_data_with_device_id = f"?properties={historian_properties}&startTime={query_start_time}" \
    f"&endTime={query_end_time}"

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'device_id': device_id,
     'query_string': query_data_with_device_id, 'expect': res_code_200}
]

# patch historian data with li and device id
patch_data = [{"time": "", "li_temperature": e2e_data_5}]
patch_historian_data_list = [
    {'action': 'PATCH', 'logicaltype_id': logical_interface_id, 'device_id': device_id, 'data': patch_data,
     'expect': res_code_200}
]

# query with li and deviceset
query_data_with_device_set = f"?startTime={query_start_time}&endTime={query_end_time}&devices=[{device_id}]"
query_data_from_historian_list2 = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'query_string': query_data_with_device_set,
     'expect': res_code_200}
]

# patch historian data with li and device set
patch_device_set_data = [{"time": "", "deviceId": device_id, "li_temperature": e2e_data_6}]
patch_historian_data_list2 = [
    {'action': 'PATCH', 'logicaltype_id': logical_interface_id, 'data': patch_device_set_data,
     'expect': res_code_200}
]

# query with li and aggregation
query_data_with_li_agg = f"?startTime={query_start_time}&endTime={query_end_time}&devices=[{device_id}]" \
    f"&aggProperties=[\"MAX(li_temperature)\"]"
query_data_with_li_agg_list = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'aggregation': True, 'query_string': query_data_with_li_agg,
     'expect': res_code_200}
]

# query with li, device id and aggregation
query_data_with_li_device_id_agg = ""
query_data_with_li_device_id_agg_list = [
    {'action': 'GET', 'logicaltype_id': logical_interface_id, 'device_id': device_id, 'aggregation': True,
     'query_string': query_data_with_li_agg, 'expect': res_code_200}
]