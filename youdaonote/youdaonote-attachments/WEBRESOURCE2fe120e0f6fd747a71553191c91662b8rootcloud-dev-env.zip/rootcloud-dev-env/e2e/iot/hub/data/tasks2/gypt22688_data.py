from iot.data.commonData import *
from iot.requestsData import *

# GYPT-22688: thing e2e
_prefix = 'GYPT22688'
_prefix_1 = 'GYPT22688_1'
_prefix_2 = 'GYPT22688_2'
_prefix_3 = 'GYPT22688_3'
_prefix_thing_property = 'GYPT22688_thing_property'
_prefix_li_property = 'GYPT22688_li_property'

# ammeter model 1
post_device_type_data1 = return_draft_device_type(_prefix_1, '', directlyLinked=True)

# ammeter model 1
post_device_type_properties_data = [return_device_type_properties(
    name='EPP',
    displayName='10s总有功电能',
    propertyType='Number',
    privilege=read_only,
    expressionType='groovy',
    expression='EPP',
    mappingName='EPP'
)]

post_li_data = return_draft_logical_interface(_prefix_thing_property, '', type=li_thing_type)

child_thing_model1 = return_child_thing_model(_prefix_1, post_device_type_data1[1], nodeId='node1',
                                              _node_type='MultipleDeviceNode')

post_thing_mapping_data = return_thing_mapping(_prefix, post_li_data[2], [child_thing_model1[0]], [])

post_li_properties_data = [return_li_properties(
    name='EPP10s',
    displayName='总有功电能10s',
    privilege=read_only,
    propertyType="Number",
    expressionType="groovy",
    expression="$child(\"sum\",\"node1\",\"EPP\")"
)]

post_device_data1 = return_draft_device(_prefix_1, name='电表1')
post_device_data2 = return_draft_device(_prefix_2, name='电表2')
post_device_data3 = return_draft_device(_prefix_3, name='电表3')

device_data1 = [
    {
        'nodeId': 'node1',
        'instances': [
            {
                'deviceId': post_device_data1[1],
                'deviceTypeId': post_device_type_data1[1]
            },
            {
                'deviceId': post_device_data2[1],
                'deviceTypeId': post_device_type_data1[1]
            },
            {
                'deviceId': post_device_data3[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    }
]

device_data2 = [
    {
        'nodeId': 'node1',
        'instances': [
            {
                'deviceId': post_device_data1[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    }
]

post_thing_data1 = return_thing(_prefix_1, devices=device_data1)
post_thing_data2 = return_thing(_prefix_1, devices=device_data2)

post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data1[0], 'expect': res_code_200}
]

post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data1[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]

active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data1[1], 'data': activateData, 'expect': res_code_200}
]

post_device1_list = [
    {'action': 'POST', 'data': post_device_data1[0], 'type_id': post_device_type_data1[1], 'expect': res_code_200}
]

post_device2_list = [
    {'action': 'POST', 'data': post_device_data2[0], 'type_id': post_device_type_data1[1], 'expect': res_code_200}
]

post_device3_list = [
    {'action': 'POST', 'data': post_device_data3[0], 'type_id': post_device_type_data1[1], 'expect': res_code_200}
]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

post_thing_mapping_list = [
    {'action': 'POST', 'data': post_thing_mapping_data[0], 'expect': res_code_200}
]

post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

post_thing_list = [
    {'action': 'POST', 'thingTypeId': post_li_data[2], 'data': post_thing_data1[0], 'expect': res_code_200},
]

put_thing_list = [
    {'action': 'PUT', 'thingTypeId': post_li_data[2], 'id': post_thing_data1[1], 'data': post_thing_data2[0], 'expect': res_code_200},
]

items = [
    return_items({"EPP": 100})
]
post_data_list1 = return_post_data(items)

items1 = [
    return_items({"EPP": 10})
]
post_data_list2 = return_post_data(items1)

query_data_from_pi1_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data1[1], 'device_id': post_device_data1[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_thing1_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_thing_data1[1],
     'query_string': '', 'expect': res_code_200}
]
