from iot.verify.verifyData import *
from iot.data.commonData import *


_prefix = 'RCDCS571'
_prefix_pi = 'RCDCS571_pi'
_prefix_li = 'RCDCS571_li'
_prefix1 = 'RCDCS571_1'
_prefix2 = 'RCDCS571_2'
_prefix3 = 'RCDCS571_3'

# e2e post data
e2e_data_1 = 30
e2e_data_2 = 66
e2e_data_3 = 56
e2e_data_4 = 35
e2e_data_5 = 55
e2e_data_6 = 65
e2e_data_7 = 99

# e2e expression data
e2e_ex_1 = 10
e2e_ex_2 = 20

# e2e result data
e2e_res_1 = e2e_data_1 + e2e_ex_1   #40
e2e_res_2 = e2e_data_2 + e2e_ex_1   #76
e2e_res_3 = e2e_data_2 + e2e_ex_2   #86
e2e_res_4 = 2*e2e_data_2 - e2e_ex_2 + e2e_ex_1  #122
e2e_res_5 = e2e_data_3 + e2e_ex_1   #66
e2e_res_6 = e2e_data_4 + e2e_ex_1   #45


post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event


dd_expression_for_pi = f"{default_event}.temp"
dd_expression_for_mapping = "temperature + 10"
dd_expression_for_rule_1 = "li_temperature > 50"
dd_expression_for_rule_2 = "li_temperature < 40"
dd_expression_for_rule_3 = f"{default_event}.temp + 10"
dd_expression_for_rule_4 = f"2*{default_event}.temp - 20"
dd_expression_for_rule_5 = f"{default_event}.t"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_properties_number_li_temperature)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')
post_expression_for_mapping = return_draft_expression(_prefix1, dd_expression_for_mapping)
post_mapping_data = return_draft_mapping(_prefix, '', '', mapping_property_li)

post_expression_for_rule_1 = return_draft_expression(_prefix3, dd_expression_for_rule_1)
post_rule_data = return_draft_rules(_prefix, '', '', rules_notification_strategy)
post_expression_for_rule_2 = return_draft_expression(_prefix2, dd_expression_for_rule_2)
post_rule_data1 = return_draft_rules(_prefix1, '', '', rules_notification_strategy)

put_expression_for_rule_3 = return_draft_expression(_prefix1, dd_expression_for_rule_3)
put_expression_for_rule_4 = return_draft_expression(_prefix1, dd_expression_for_rule_4)
put_schema_data = return_draft_schema_data(_prefix, schema_properties_number_t)
put_expression_for_rule_5 = return_draft_expression(_prefix1, dd_expression_for_rule_5)


# Test case 1: Demo Data

# post schema for event type
t571_post_schema_list = [{'action': 'POST',
                          'data': post_schema_data_for_event_type[0],
                          'expect': res_code_200}]

# query the schema
t571_quey_schema_str = f"?name={post_schema_data_for_event_type[1]}"
t571_query_schema_list = [{'action': 'GET',
                           'query_string': t571_quey_schema_str,
                           'expect': res_code_200}]

# post event type
t571_post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
t571_query_event_type_str = f"?eventTypeId={default_event}"
t571_query_event_type_list = [{'action': 'GET',
                               'query_string': t571_query_event_type_str,
                               'expect': res_code_200}]

# post schema for physical interface
t571_post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# query the schema
t571_query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
t571_query_schema_for_pi_list = [{'action': 'GET',
                                  'query_string': t571_query_schema_for_pi_str,
                                  'expect': res_code_200}]

# post expression for property mapping
t571_post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
t571_query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
t571_query_expression_for_pi_list = [
    {'action': 'GET', 'query_string': t571_query_expression_for_pi_str, 'expect': res_code_200}
]

# post physical interface
t571_post_pi_list = [{'action': 'POST',
                      'data': post_physical_interface_data[0],
                      'expect': res_code_200}]

# query the physical interface
t571_query_pi_str = f"?name={post_physical_interface_data[1]}"
t571_query_pi_list = [{'action': 'GET',
                       'query_string': t571_query_pi_str,
                       'expect': res_code_200}]

# query device type
t571_query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
t571_post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# active physical interface
t571_active_pi_list = [{'action': 'PATCH',
                        'id': physical_interface_id,
                        'data': activateData,
                        'expect': res_code_200}]

# post device
t571_post_device_list = [{'action': 'POST',
                          'data': post_device_data[0],
                          'type_id': post_device_type_data[1],
                          'expect': res_code_200}]

# get device
t571_query_device_list = [{'action': 'GET',
                           'id': post_device_data[1],
                           'type_id': post_device_type_data[1],
                           'expect': res_code_200}]

# post schema for logical interface
t571_post_schema_for_li_list = [
    {'action': 'POST', 'data': post_schema_data_for_li[0], 'expect': res_code_200}
]

# get the schema
t571_query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
t571_query_schema_for_li_list = [{'action': 'GET',
                                  'query_string': t571_query_schema_for_li_str,
                                  'expect': res_code_200}]

# post the logical interface
t571_post_li_list = [{'action': 'POST',
                      'data': post_logical_interface_data[0],
                      'expect': res_code_200}]

# get the logical interface
t571_query_li_str = f"?name={post_logical_interface_data[1]}"
t571_query_li_list = [{'action': 'GET',
                       'query_string': t571_query_li_str,
                       'expect': res_code_200}]

# post expression
t571_post_expression_list = [{'action': 'POST',
                              'data': post_expression_for_mapping[0],
                              'expect': res_code_200}]

# get the expression
t571_query_expression_str = f"?name={post_expression_for_mapping[1]}"
t571_query_expression_list = [{'action': 'GET',
                               'query_string': t571_query_expression_str,
                               'expect': res_code_200}]

# post the mapping
t571_post_mapping_list = [
    {'action': 'POST', 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
t571_query_mapping_str = f"?name={post_mapping_data[1]}"
t571_query_mapping_list = [{'action': 'GET',
                            'query_string': t571_query_mapping_str,
                            'expect': res_code_200}]

# activate logical interface
t571_active_li_list = [{'action': 'PATCH',
                        'id': logical_interface_id,
                        'data': activateData,
                        'expect': res_code_200}]

# post the expression > 50
t571_post_expression_with_temp_bigger_50_list = [
    {'action': 'POST', 'data': post_expression_for_rule_1[0], 'expect': res_code_200}
]

# get the expression
t571_query_expression_with_temp_bigger_50_str = f"?name={post_expression_for_rule_1[1]}"
t571_query_expression_with_temp_bigger_50_list = [
    {
        'action': 'GET',
        'query_string': t571_query_expression_with_temp_bigger_50_str,
        'expect': res_code_200}]

# post the rule
t571_post_rule_with_temp_bigger_50_list = [
    {'action': 'POST', 'data': post_rule_data[0], 'expect': res_code_200}
]

# get the rule
t571_query_rule_with_temp_bigger_50_str = f"?name={post_rule_data[1]}"
t571_query_rule_with_temp_bigger_50_list = [
    {
        'action': 'GET',
        'query_string': t571_query_rule_with_temp_bigger_50_str,
        'expect': res_code_200}]

# post the expression
t571_post_expression_with_temp_less_40_list = [
    {'action': 'POST', 'data': post_expression_for_rule_2[0], 'expect': res_code_200}
]

# query the expression
t571_query_expression_with_temp_less_40_str = f"?name={post_expression_for_rule_2[1]}"
t571_query_expression_with_temp_less_40_list = [
    {
        'action': 'GET',
        'query_string': t571_query_expression_with_temp_less_40_str,
        'expect': res_code_200}]

# post the rule
t571_post_rule_with_temp_less_40_list = [
    {'action': 'POST', 'data': post_rule_data1[0], 'expect': res_code_200}
]

# get the rule
t571_query_rule_with_temp_less_40_str = f"?name={post_rule_data1[1]}"
t571_query_rule_with_temp_less_40_list = [
    {'action': 'GET', 'query_string': t571_query_rule_with_temp_less_40_str, 'expect': res_code_200}
]

# post the data
items = [
    return_items({"temp": e2e_data_1})
]
post_data = return_post_data(items)

# get the data from historian
t571_query_start_time = ""
t571_query_end_time = ""
t571_query_data_from_historian_str = f"?properties={historian_properties}&startTime={t571_query_start_time}" \
    f"&endTime={t571_query_end_time}"

t571_query_data_from_historian_list = [
    {
        'action': 'GET',
        'logicaltype_id': logical_interface_id,
        'device_id': post_device_data[1],
        'query_string': t571_query_data_from_historian_str,
        'expect': res_code_200
    }]

# deactivate the logical interface
t571_deactive_li_list = [{'action': 'PATCH',
                          'id': logical_interface_id,
                          'data': deactivateData,
                          'expect': res_code_200}]

# get the logical interface
t571_query_li_after_deactive = [
    {'action': 'GET', 'id': logical_interface_id, 'expect': res_code_404}
]

# activate the logical interface

# post the data
items1 = [
    return_items({"temp": e2e_data_2})
]
post_data1 = return_post_data(items1)

# get the data from historian

# put the expression from event_type_id.temp to event_type_id.temp + 10
t571_put_expression_with_temp_add_10_list = [
    {
        'action': 'PUT',
        'id': expression_id,
        'data': put_expression_for_rule_3[0],
        'expect': res_code_200}]

# activate the logical interface

# post the data

# query the data from historian

# put the expression from event_type_id.temp to 2*event_type_id.temp - 20
t571_put_expression_with_temp_multiply_2_subtract_20_list = [
    {'action': 'PUT', 'id': expression_id, 'data': put_expression_for_rule_4[0], 'expect': res_code_200}
]

# activate the logical interface

# post the data

# query the data from historian

# Put the schema properties from "temp" to "t"
t571_put_schema_list = [{'action': 'PUT',
                         'id': schema_id,
                         'data': put_schema_data[0],
                         'expect': res_code_200}]

# Put the expression from event_type_id.temp to event_type_id.t
t571_put_expression_from_temp_to_t = [
    {
        'action': 'PUT',
        'id': expression_id,
        'data': put_expression_for_rule_5[0],
        'expect': res_code_200}]

# Activate with logical interface

# post the data
items2 = [
    return_items({"temp": e2e_data_3})
]
post_data2 = return_post_data(items2)

# Query the data with historian

# Get the rule id
t571_query_rule_2_str = f"?name={post_rule_data[1]}"
t571_query_rule_2_list = [{'action': 'GET',
                           'query_string': t571_query_rule_2_str,
                           'expect': res_code_200}]

# Query the data with historian actionable id
t571_query_data_from_actionable_str = f"?properties={actionable_properties}&startTime={t571_query_start_time}" \
    f"&endTime={t571_query_end_time}"
t571_query_data_from_actionable_list = [
    {
        'action': 'GET',
        'actionable_id': actionable_id,
        'logicaltype_id': logical_interface_id,
        'query_string': t571_query_data_from_actionable_str,
        'expect': res_code_200}]
