from iot.data.commonData import *
from iot.verify.verifyData import *


_prefix = 'GYPT8579b'
_prefix_pi = 'GYPT8579b_pi'
_prefix_li = 'GYPT8579b_li'
_prefix1 = 'GYPT8579b_1'

headers_b = {"accept": "application/json", "X-RCD-Tenant-Id": tenant_shared_b, "Authorization": hub_super_token} if\
    test_server in ['local', 'localhost'] else {"accept": "application/json", 'Authorization': ""}

post_call_back_eca = return_callback(get_deploy_body(tenant_shared_b)[1].eca_payload, suid_list[12], tenant_shared_b)
post_call_back_hub = return_callback(get_deploy_body(tenant_shared_b)[1].hub_payload, suid_list[13], tenant_shared_b)
post_call_back_historian = return_callback(get_deploy_body(tenant_shared_b)[1].historian_payload, suid_list[14], tenant_shared_b)

# delete and get job
jd_t1_delete_tenant_list = [
    {'action': 'DELETE', 'id': tenant_shared_b, 'force': 'true', 'expect': res_code_401}
]

jd_t1_get_tenant_list = [
    {'action': 'GET', 'id': tenant_shared_b, 'expect': res_code_401}
]


jd_t1_b_data_list = [
    {'action': 'POST', 'data': post_call_back_eca, 'expect': res_code_200},
    {'action': 'POST', 'data': post_call_back_hub, 'expect': res_code_200},
    {'action': 'POST', 'data': post_call_back_historian, 'expect': res_code_200}
]

post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

dd_expression_for_pi = f"{default_event}.temp"
dd_expression_for_mapping_tenant_shared_b = "temperature + 20"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_properties_number_li_temperature)
post_logical_interface_data = return_draft_logical_interface(_prefix, '')
post_expression_for_mapping_tenant_shared_b = return_draft_expression(_prefix1, dd_expression_for_mapping_tenant_shared_b)
post_mapping_data = return_draft_mapping(_prefix, '', post_logical_interface_data[2], mapping_property_li)

# RCDCS-8579: multi share tenant
post_manufacturer_data = return_manufacturer(manufacturer_id, manufacturer_name)

# post manufacturer
post_manufacturer_list = [
    {'action': 'POST', 'data': post_manufacturer_data, 'header': headers_b}
]

# post schema for event type
post_schema_list = [{'action': 'POST', 'header': headers_b,
                     'data': post_schema_data_for_event_type[0],
                     'expect': res_code_200}]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'header': headers_b, 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={default_event}"
query_event_type_list = [{'action': 'GET', 'header': headers_b,
                          'query_string': query_event_type_str,
                          'expect': res_code_200}]

# post schema for physical interface
post_schema_for_pi_list = [{'action': 'POST', 'header': headers_b,
                            'data': post_schema_data_for_pi[0],
                            'expect': res_code_200}]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [{'action': 'GET', 'header': headers_b,
                             'query_string': query_schema_for_pi_str,
                             'expect': res_code_200}]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
query_expression_for_pi_list = [{'action': 'GET', 'header': headers_b,
                                 'query_string': query_expression_for_pi_str,
                                 'expect': res_code_200}]

# post physical interface
post_pi_list = [{'action': 'POST', 'header': headers_b,
                 'data': post_physical_interface_data[0],
                 'expect': res_code_200}]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'header': headers_b, 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'header': headers_b, 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST', 'header': headers_b,
                          'data': post_device_type_data[0],
                          'expect': res_code_200}]

# active physical interface
active_pi_list = [{'action': 'PATCH', 'header': headers_b,
                   'id': physical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# post device
post_device_list = [{'action': 'POST', 'header': headers_b,
                     'data': post_device_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_200}]

# get device
query_device_list = [{'action': 'GET', 'header': headers_b,
                      'id': post_device_data[1],
                      'type_id': post_device_type_data[1],
                      'expect': res_code_200}]

# post schema for logical interface
post_schema_for_li_list = [{'action': 'POST', 'header': headers_b,
                            'data': post_schema_data_for_li[0],
                            'expect': res_code_200}]

# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [{'action': 'GET', 'header': headers_b,
                             'query_string': query_schema_for_li_str,
                             'expect': res_code_200}]

# post the logical interface
post_li_list = [{'action': 'POST', 'header': headers_b,
                 'data': post_logical_interface_data[0],
                 'expect': res_code_200}]

# get the logical interface
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'header': headers_b, 'query_string': query_li_str, 'expect': res_code_200}
]

# post expression
post_expression_list = [{'action': 'POST', 'header': headers_b,
                         'data': post_expression_for_mapping_tenant_shared_b[0],
                         'expect': res_code_200}]

# get the expression
query_expression_str = f"?name={post_expression_for_mapping_tenant_shared_b[1]}"
query_expression_list = [{'action': 'GET', 'header': headers_b,
                          'query_string': query_expression_str,
                          'expect': res_code_200}]

# post the mapping
post_mapping_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_mapping_data[1]}"
query_mapping_list = [{'action': 'GET', 'header': headers_b,
                       'query_string': query_mapping_str,
                       'expect': res_code_200}]

# activate logical interface
active_li_list = [{'action': 'PATCH', 'header': headers_b,
                   'id': post_logical_interface_data[2],
                   'data': activateData,
                   'expect': res_code_200}]

items = [
    return_items({"temp": 30})
]
post_data = return_post_data(items)

# step 28: get the data from historian
query_data_from_historian_str = ''

query_data_from_historian_list = [{'action': 'GET', 'header': headers_b,
                                   'logicaltype_id': post_logical_interface_data[2],
                                   'device_id': post_device_data[1],
                                   'query_string': query_data_from_historian_str,
                                   'expect': res_code_200}]

# delete tenant and job
delete_call_back = {'tenantId': tenant_shared_b}
jd_b_data_list = [
    {'action': 'DELETE', 'id': tenant_shared_b, 'data': delete_call_back, 'expect': res_code_200}
]

delete_manufacturer_list = [
    {'action': 'DELETE', 'id': manufacturer_id, 'expect': res_code_200}
]

# test alarm
_condition = "li_temperature > 60"
_when = 'everyTime'
post_alarm_category_data = return_alarm_category(_prefix)
post_draft_alarm_type_data = return_draft_alarm_type_2(_prefix, platform, post_alarm_category_data[1], sl_2,
                                                       _condition, 'li_temperature', post_logical_interface_data[2], _when, 0)

query_alarm_severity_list = [
    {'action': 'GET', 'header': headers_b, 'expect': res_code_200}
]

# add category
post_alarm_category_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_alarm_category_data[0], 'expect': res_code_200}
]

# create alarm
post_draft_alarm_type_list = [
     {'action': 'POST', 'header': headers_b, 'data': post_draft_alarm_type_data[0], 'expect': res_code_200}
]

# active alarm
patch_draft_alarm_type_list = [
    {'action': 'PATCH', 'header': headers_b, 'id': alarm_type_id, 'data': activateData, 'expect': res_code_200}
]

delete_multi_alarm_list = [
    {'action': 'DELETE', 'header': headers_b, 'tenant_id': tenant_shared_b, 'expect': res_code_200}
]

# post data after setting alarm
# post the data
items1 = [
    return_items({"temp": 70})
]
post_data1 = return_post_data(items1)

# query all alarms
query_all_alarm_str = f"?deviceIds=[\"{post_device_data[1]}\"]"
query_all_alarm_list = [
    {'action': 'GET', 'header': headers_b, 'all': True, 'query_string': query_all_alarm_str, 'expect': res_code_200}
]