from iot.data.commonData import *
from iot.data.commonData import schema_properties_number_temp
from iot.verify.verifyData import *

# test case 1: e2e case for draft event type
_prefix = 'RCDCS173'
post_schema_data = return_draft_schema_data(_prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')
put_event_type_data = return_draft_event_type(_prefix, '', des_str_put)

# neg:
post_null_event_type_name_data = return_draft_event_type('', 'name', 'string', eventTypeName='')
post_null_name_data = return_draft_event_type('name', '', '', name='')
post_null_schema_id_data = return_draft_event_type('name', 'event_type_name', '', schemaId='')
post_invalid_event_type_name_type_data = return_draft_event_type('', 'name', 'string', eventTypeName=123)

# post schema and get schema
t173_post_and_get_schema_list = [
    {'action': 'POST', 'data': post_schema_data[0], 'expect': res_code_200},
    {'action': 'GET', 'expect': res_code_200}
]

# get event type
t173_get_event_type_list = [
    {'action': 'GET', 'expect': res_code_200}
]

# post event type
t173_post_and_get_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# post with null name
t173_post_with_null_name_list = [
    {'action': 'POST', 'data': post_null_name_data[0], 'expect': res_code_400}
]

# post with null event type name
t173_post_with_null_event_type_name_list = [
    {'action': 'POST', 'data': post_null_event_type_name_data[0], 'expect': res_code_200}
]

# post with null schema id
t173_post_with_null_schema_id_list = [
    {'action': 'POST', 'data': post_null_schema_id_data[0], 'expect': res_code_400}
]

# post with number type event type name
t173_post_with_invalid_type_list = [
    {'action': 'POST', 'data': post_invalid_event_type_name_type_data[0], 'expect': res_code_400}
]

# put event type and get event type
etd_t1_event_type_put_data = {'description': des_str_put}
t173_put_and_get_event_type_list = [
    {'action': 'PUT', 'id': event_type_id, 'data': put_event_type_data[0], 'expect': res_code_200},
    {'action': 'GET', 'id': event_type_id, 'expect': res_code_200}
]

# put not exist event type
t173_put_not_exist_event_type_list = [
    {'action': 'PUT', 'id': invalid_id, 'data': put_event_type_data[0], 'expect': res_code_404}
]

# put event type with invalid event type name type
t173_put_with_invalid_event_type_name_type_list = [
    {'action': 'PUT', 'id': event_type_id, 'data': post_invalid_event_type_name_type_data[0], 'expect': res_code_500}
]

# put event type with null name
t173_put_with_null_name_list = [
    {'action': 'POST', 'id': event_type_id, 'data': post_null_name_data[0], 'expect': res_code_400}
]

# get not exist event type
t173_get_not_exist_list = [
    {'action': 'GET', 'id': invalid_id, 'expect':res_code_404}
]

# delete event type and get event type
t173_delete_and_get_event_type_list = [
    {'action': 'DELETE', 'id': event_type_id, 'expect': res_code_200},
    {'action': 'GET', 'id': event_type_id, 'expect': res_code_404}
]

# delete not exist event type
t173_delete_not_exist_list = [
    {'action': 'DELETE', 'id': invalid_id, 'expect': res_code_404}
]

# delete event type which had been deleted
t173_delete_event_type_been_deleted_list = [
    {'action': 'DELETE', 'id': event_type_id, 'expect': res_code_404}
]

# delete schema
t173_delete_schema_list = [
    {'action': 'DELETE', 'id': schema_id, 'expect': res_code_200}
]
