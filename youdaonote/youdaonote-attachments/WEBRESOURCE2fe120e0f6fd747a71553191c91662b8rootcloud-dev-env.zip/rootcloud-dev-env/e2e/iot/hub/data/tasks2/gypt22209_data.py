from iot.data.commonData import *
from iot.requestsData import *

# GYPT-22209: thing e2e
_prefix = 'GYPT22209'
_prefix_1 = 'GYPT22209_ammeter_mode_1'
_prefix_2 = 'GYPT22209_ammeter_mode_2'
_prefix_thing_property = 'GYPT22209_thing_property'
_prefix_li_property = 'GYPT22209_li_property'

# ammeter model 1
post_device_type_data1 = return_draft_device_type(_prefix_1, '', directlyLinked=True)
# ammeter model 2
# post_device_type_data2 = return_draft_device_type(_prefix_2, '', directlyLinked=True)

# ammeter model 1
post_device_type_properties_data = [return_device_type_properties(
    name='EPP10s',
    displayName='10s总有功电能',
    propertyType='Number',
    privilege=read_only,
    expressionType='window',
    expression='EPP',
    mappingName='EPP',
    operator='last',
    windowSizeMills=10000,
    windowStepMills=10000,
    windowAllowedLatenessMills=10000,
    windowDefaultValueJson='0'
), return_device_type_properties(
    name='EPP30s',
    displayName='30s总有功电能',
    propertyType='Number',
    privilege=read_only,
    expressionType='window',
    expression='EPP',
    operator='last',
    windowSizeMills=30000,
    windowStepMills=30000,
    windowAllowedLatenessMills=30000,
    windowDefaultValueJson='0'
)]

post_li_data = return_draft_logical_interface(_prefix_thing_property, '', type=li_thing_type)
post_li_data1 = return_draft_logical_interface(_prefix_li_property, '')

post_li_properties_data1 = [return_li_properties(
    name='EPP10s',
    displayName='总有功电能10s',
    privilege=read_only,
    propertyType="Number",
    expressionType="groovy",
    expression="def last = $lastState('EPP10s'); last == null ? 0 : EPP10s - last;",
    fromInterfaceId=post_device_type_data1[1]
), return_li_properties(
    name='EPP30s',
    displayName='总有功电能30s',
    privilege=read_only,
    propertyType="Number",
    expressionType="groovy",
    expression="def last = $lastState('EPP30s'); last == null ? 0 : EPP30s - last;",
    fromInterfaceId=post_device_type_data1[1]
)]

child_thing_model1 = return_child_thing_model(_prefix_1, post_li_data1[2], nodeId='ammeter_model_1_normal',
                                              _node_type='MultipleDeviceNode')
child_thing_model2 = return_child_thing_model(_prefix_1, post_li_data1[2], nodeId='ammeter_model_1_auxiliary',
                                              _node_type='MultipleDeviceNode')
child_thing_model3 = return_child_thing_model(_prefix_2, post_li_data1[2], nodeId='ammeter_model_2_normal',
                                              _node_type='MultipleDeviceNode')
child_thing_model4 = return_child_thing_model(_prefix_2, post_li_data1[2], nodeId='ammeter_model_2_auxiliary',
                                              _node_type='MultipleDeviceNode')

post_thing_mapping_data = return_thing_mapping(_prefix, post_li_data[2],
                                               [child_thing_model1[0], child_thing_model2[0], child_thing_model3[0],
                                                child_thing_model4[0]], [])

post_li_properties_data = [return_li_properties(
    name='EPP10s',
    displayName='总有功电能10s',
    privilege=read_only,
    propertyType="Number",
    expressionType="groovy",
    expression="$child(\"sum\",\"ammeter_model_1_normal\",\"EPP10s\") + $child(\"sum\",\"ammeter_model_1_auxiliary\",\"EPP10s\") + $child(\"sum\",\"ammeter_model_2_normal\",\"EPP10s\") + $child(\"sum\",\"ammeter_model_2_auxiliary\",\"EPP10s\")"
), return_li_properties(
    name='EPP30s',
    displayName='总有功电能30s',
    privilege=read_only,
    propertyType="Number",
    expressionType="groovy",
    expression="$child(\"sum\",\"ammeter_model_1_normal\",\"EPP30s\") + $child(\"sum\",\"ammeter_model_1_auxiliary\",\"EPP30s\") + $child(\"sum\",\"ammeter_model_2_normal\",\"EPP30s\") + $child(\"sum\",\"ammeter_model_2_auxiliary\",\"EPP30s\")"
)]

post_device_data1 = return_draft_device(_prefix_1, name='电表1')
post_device_data2 = return_draft_device(_prefix_2, name='电表2')

device_data1 = [
    {
        'nodeId': 'ammeter_model_1_normal',
        'instances': [
            {
                'deviceId': post_device_data1[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    },
]

device_data2 = [
    {
        'nodeId': 'ammeter_model_1_normal',
        'instances': [
            {
                'deviceId': post_device_data1[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    },
    {
        'nodeId': 'ammeter_model_1_auxiliary',
        'instances': [
            {
                'deviceId': post_device_data1[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    },
    {
        'nodeId': 'ammeter_model_2_normal',
        'instances': [
            {
                'deviceId': post_device_data2[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    },
    {
        'nodeId': 'ammeter_model_2_auxiliary',
        'instances': [
            {
                'deviceId': post_device_data2[1],
                'deviceTypeId': post_device_type_data1[1]
            }
        ]
    }
]

post_thing_data1 = return_thing(_prefix_1, devices=device_data1)
post_thing_data2 = return_thing(_prefix_2, devices=device_data2)

post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data1[0], 'expect': res_code_200}
    # {'action': 'POST', 'data': post_device_type_data2[0], 'expect': res_code_200}
]

post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data1[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
    # {'action': 'POST', 'id': post_device_type_data2[1], 'data': post_device_type_properties_data,
    #  'expect': res_code_200}
]

active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data1[1], 'data': activateData, 'expect': res_code_200}
    # {'action': 'PATCH', 'id': post_device_type_data2[1], 'data': activateData, 'expect': res_code_200}
]

post_device1_list = [
    {'action': 'POST', 'data': post_device_data1[0], 'type_id': post_device_type_data1[1], 'expect': res_code_200}
]

post_device2_list = [
    {'action': 'POST', 'data': post_device_data2[0], 'type_id': post_device_type_data1[1], 'expect': res_code_200}
]

post_li1_list = [
    {'action': 'POST', 'data': post_li_data1[0], 'expect': res_code_200}
]

# post li properties
post_li1_properties_list = [
    {'action': 'POST', 'id': post_li_data1[2], 'data': post_li_properties_data1, 'expect': res_code_200}
]

# active li interface
active_li1_list = [
    {'action': 'PATCH', 'id': post_li_data1[2], 'data': activateData, 'expect': res_code_200}
]

post_li_list = [
    {'action': 'POST', 'data': post_li_data[0], 'expect': res_code_200}
]

post_thing_mapping_list = [
    {'action': 'POST', 'data': post_thing_mapping_data[0], 'expect': res_code_200}
]

post_li_properties_list = [
    {'action': 'POST', 'id': post_li_data[2], 'data': post_li_properties_data, 'expect': res_code_200}
]

active_li_list = [
    {'action': 'PATCH', 'id': post_li_data[2], 'data': activateData, 'expect': res_code_200}
]

post_thing_list = [
    {'action': 'POST', 'thingTypeId': post_li_data[2], 'data': post_thing_data1[0], 'expect': res_code_200},
    {'action': 'POST', 'thingTypeId': post_li_data[2], 'data': post_thing_data2[0], 'expect': res_code_200}
]

data_list1 = [
    {"EPP": 1},
    {"EPP": 2},
    {"EPP": 3},
    {"EPP": 4},
    {"EPP": 5},
    {"EPP": 6},
    {"EPP": 7},
    {"EPP": 8},
    {"EPP": 9},
    {"EPP": 10},
    {"EPP": 11},
    {"EPP": 12},
    {"EPP": 13},
    {"EPP": 14},
    {"EPP": 15},
    {"EPP": 16},
    {"EPP": 17},
    {"EPP": 18},
    {"EPP": 19},
    {"EPP": 20}
]

data_list2 = [
    {"EPP": 2},
    {"EPP": 4},
    {"EPP": 6},
    {"EPP": 8},
    {"EPP": 10},
    {"EPP": 12},
    {"EPP": 14},
    {"EPP": 16},
    {"EPP": 18},
    {"EPP": 20},
    {"EPP": 22},
    {"EPP": 24},
    {"EPP": 26},
    {"EPP": 28},
    {"EPP": 30},
    {"EPP": 32},
    {"EPP": 34},
    {"EPP": 36},
    {"EPP": 38},
    {"EPP": 40}
]

post_data_list1 = return_post_data_list(data_list1)
post_data_list2 = return_post_data_list(data_list2)

query_data_from_pi1_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data1[1], 'device_id': post_device_data1[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_li_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data1[2], 'device_id': post_device_data1[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_thing1_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_thing_data1[1],
     'query_string': '', 'expect': res_code_200}
]

query_data_from_thing2_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_li_data[2], 'device_id': post_thing_data2[1],
     'query_string': '', 'expect': res_code_200}
]

ver_data1 = [[20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 1.0], [20.0, None, 50.0, 100.0],
             [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 10000.0], [20.0, "100", 50.0, 1.0],
             [20.0, None, 50.0, 100.0],
             [20.0, None, 50.0, 1.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0],
             [20.0, None, 50.0, 1.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0]]

ver_data2 = [[20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 1.0], [20.0, None, 50.0, 1.0],
             [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0], [20.0, '100', 50.0, 1.0], [20.0, None, 50.0, 100.0],
             [20.0, None, 50.0, 1.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0],
             [20.0, None, 50.0, 1.0], [20.0, None, 50.0, 100.0], [20.0, None, 50.0, 100.0]]
