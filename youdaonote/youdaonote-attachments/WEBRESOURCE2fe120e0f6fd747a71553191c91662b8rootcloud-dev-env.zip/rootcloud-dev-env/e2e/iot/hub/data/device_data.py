from iot.data.commonData import *
from iot.data.commonData import schema_properties_number_temp, schema_properties_number_temperature_pi, \
    mapping_property_pi
from iot.verify.verifyData import *

# test case 1: e2e case for device
_prefix = 'RCDCS221'
_prefix_pi = 'RCDCS221_pi'
post_schema_data_for_event_type = return_draft_schema_data(
    _prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')

dd_expression_for_pi = f"{post_event_type_data[1]}.temp"

post_schema_data_for_pi = return_draft_schema_data(
    _prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(
    _prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix, manufacturerId=manufacturer_id)
put_device_data = return_draft_device(_prefix, des_str_put, manufacturerId=manufacturer_id)

# post schema for event type
t221_post_schema_list = [{'action': 'POST',
                          'data': post_schema_data_for_event_type[0],
                          'expect': res_code_200}]

# post event type
t221_post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# post schema for physical interface
t221_post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# post expression for property mapping
t221_post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# post physical interface
t221_post_pi_list = [{'action': 'POST',
                      'data': post_physical_interface_data[0],
                      'expect': res_code_200}]

# post draft device type
t221_post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

t221_get_device_list = [{'action': 'GET',
                         'type_id': post_device_type_data[1],
                         'expect': res_code_200}]

# post device and get device
t221_post_and_get_device_list = [{'action': 'POST',
                                  'type_id': post_device_type_data[1],
                                  'data': post_device_data[0],
                                  'expect': res_code_200},
                                 {'action': 'GET',
                                  'type_id': post_device_type_data[1],
                                  'expect': res_code_200}]

# put device and get device
t221_put_and_get_device_list = [{'action': 'PUT',
                                 'type_id': post_device_type_data[1],
                                 'id': post_device_data[1],
                                 'data': put_device_data[0],
                                 'expect': res_code_200},
                                {'action': 'GET',
                                 'type_id': post_device_type_data[1],
                                 'id': post_device_data[1],
                                 'expect': res_code_200}]

# delete device and get device
t221_delete_and_get_device_list = [{'action': 'DELETE',
                                    'type_id': post_device_type_data[1],
                                    'id': post_device_data[1],
                                    'expect': res_code_200},
                                   {'action': 'GET',
                                    'type_id': post_device_type_data[1],
                                    'id': post_device_data[1],
                                    'expect': res_code_404}]

# delete device type
t221_delete_device_type_list = [
    {'action': 'DELETE', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# delete physical interface
t221_delete_pi_list = [
    {'action': 'DELETE', 'id': physicalInterfaceId, 'expect': res_code_404}
]

t221_delete_schema_for_pi_list = [
    {'action': 'DELETE', 'id': schema_pi_id, 'expect': res_code_404}
]

t221_delete_expression_for_pi_list = [
    {'action': 'DELETE', 'id': expression_pi_id, 'expect': res_code_404}
]

t221_delete_event_type_list = [
    {'action': 'DELETE', 'id': event_type_id, 'expect': res_code_404}
]

t221_delete_schema_list = [
    {'action': 'DELETE', 'id': schema_id, 'expect': res_code_404}
]
