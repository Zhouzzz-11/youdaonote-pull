from iot.data.commonData import *
from iot.verify.verifyData import *


_prefix = 'RCDCS815'
_prefix_pi = 'RCDCS815_pi'
_prefix_li = 'RCDCS815_li'
_prefix1 = 'RCDCS815_1'
_prefix_a = 'RCDCS815a'
_prefix_b = 'RCDCS815b'

headers_b = {"accept": "application/json", "X-RCD-Tenant-Id": tenant_b, "Authorization": hub_super_token} if\
    test_server in ['local', 'localhost'] else {"accept": "application/json", 'Authorization': ""}

post_job_data = return_job(tenant_b, tenant_b)

jd_t1_b_1_data_list = [
    {'action': 'POST', 'data': get_deploy_body(tenant_b)[0], 'expect': res_code_200}
]

jd_t1_b_2_data_list = [
    {'action': 'GET', 'id': tenant_b, 'expect': res_code_200}
]

post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')
post_event_type_data[0]['eventTypeName'] = default_event

dd_expression_for_pi = f"{default_event}.temp"
dd_expression_for_mapping_tenant_b = "temperature + 20"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix_b, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix_b)
post_schema_data_for_li = return_draft_schema_data(_prefix_li, schema_properties_number_li_temperature)
post_logical_interface_data = return_draft_logical_interface(_prefix_b, '')
post_expression_for_mapping_tenant_b = return_draft_expression(_prefix1, dd_expression_for_mapping_tenant_b)
post_mapping_data = return_draft_mapping(_prefix, '', post_logical_interface_data[2], mapping_property_li)


post_device_type_neg_data = return_draft_device_type(_prefix_a, '', directlyLinked=True)
post_device_neg_data = return_draft_device(_prefix_a)
post_logical_interface_neg_data = return_draft_logical_interface(_prefix_a, '')

# RCDCS-815: multi tenant
# post manufacturer id
post_manufacturer_data = return_manufacturer(manufacturer_id, manufacturer_name)

# post manufacturer
post_manufacturer_list = [
    {'action': 'POST', 'data': post_manufacturer_data, 'header': headers_b, 'expect': res_code_200}
]

# post schema for event type
post_schema_list = [{'action': 'POST', 'header': headers_b,
                     'data': post_schema_data_for_event_type[0],
                     'expect': res_code_200}]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'header': headers_b, 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={default_event}"
query_event_type_list = [{'action': 'GET', 'header': headers_b,
                          'query_string': query_event_type_str,
                          'expect': res_code_200}]

# post schema for physical interface
post_schema_for_pi_list = [{'action': 'POST', 'header': headers_b,
                            'data': post_schema_data_for_pi[0],
                            'expect': res_code_200}]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [{'action': 'GET', 'header': headers_b,
                             'query_string': query_schema_for_pi_str,
                             'expect': res_code_200}]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
query_expression_for_pi_list = [{'action': 'GET', 'header': headers_b,
                                 'query_string': query_expression_for_pi_str,
                                 'expect': res_code_200}]

# post physical interface
post_pi_list = [{'action': 'POST', 'header': headers_b,
                 'data': post_physical_interface_data[0],
                 'expect': res_code_200}]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'header': headers_b, 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'header': headers_b, 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST', 'header': headers_b,
                          'data': post_device_type_data[0],
                          'expect': res_code_200}]

post_device_type_neg_list = [{'action': 'POST', 'header': headers_b,
                          'data': post_device_type_neg_data[0],
                          'expect': res_code_400}]

# active physical interface
active_pi_list = [{'action': 'PATCH', 'header': headers_b,
                   'id': physical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# post device
post_device_list = [{'action': 'POST', 'header': headers_b,
                     'data': post_device_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_200}]

post_device_neg_list = [{'action': 'POST', 'header': headers_b,
                     'data': post_device_neg_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_400}]

# get device
query_device_list = [{'action': 'GET', 'header': headers_b,
                      'id': post_device_data[1],
                      'type_id': post_device_type_data[1],
                      'expect': res_code_200}]

# post schema for logical interface
post_schema_for_li_list = [{'action': 'POST', 'header': headers_b,
                            'data': post_schema_data_for_li[0],
                            'expect': res_code_200}]

# get the schema
query_schema_for_li_str = f"?name={post_schema_data_for_li[1]}"
query_schema_for_li_list = [{'action': 'GET', 'header': headers_b,
                             'query_string': query_schema_for_li_str,
                             'expect': res_code_200}]

# post the logical interface
post_li_list = [{'action': 'POST', 'header': headers_b,
                 'data': post_logical_interface_data[0],
                 'expect': res_code_200}]

post_li_neg_list = [{'action': 'POST', 'header': headers_b,
                 'data': post_logical_interface_neg_data[0],
                 'expect': res_code_400}]

# get the logical interface
query_li_str = f"?name={post_logical_interface_data[1]}"
query_li_list = [
    {'action': 'GET', 'header': headers_b, 'query_string': query_li_str, 'expect': res_code_200}
]

# post expression
post_expression_list = [{'action': 'POST', 'header': headers_b,
                         'data': post_expression_for_mapping_tenant_b[0],
                         'expect': res_code_200}]

# get the expression
query_expression_str = f"?name={post_expression_for_mapping_tenant_b[1]}"
query_expression_list = [{'action': 'GET', 'header': headers_b,
                          'query_string': query_expression_str,
                          'expect': res_code_200}]

# post the mapping
post_mapping_list = [
    {'action': 'POST', 'header': headers_b, 'data': post_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_mapping_data[1]}"
query_mapping_list = [{'action': 'GET', 'header': headers_b,
                       'query_string': query_mapping_str,
                       'expect': res_code_200}]

# activate logical interface
active_li_list = [{'action': 'PATCH', 'header': headers_b,
                   'id': post_logical_interface_data[2],
                   'data': activateData,
                   'expect': res_code_200}]

items = [
    return_items({"temp": 30})
]
post_data = return_post_data(items)

# step 28: get the data from historian
query_data_from_historian_str = ''

query_data_from_historian_list = [{'action': 'GET', 'header': headers_b,
                                   'logicaltype_id': post_logical_interface_data[2],
                                   'device_id': post_device_data[1],
                                   'query_string': query_data_from_historian_str,
                                   'expect': res_code_200}]

# delete tenant and job
delete_call_back = {'tenantId': tenant_b}
jd_b_data_list = [
    {'action': 'DELETE', 'id': tenant_b, 'data': delete_call_back, 'expect': res_code_200}
]

delete_manufacturer_list = [
    {'action': 'DELETE', 'id': manufacturer_id, 'header': headers_b, 'expect': res_code_200}
]
