from iot.verify.verifyData import *
from iot.data.commonData import *

# test case 1: e2e case for draft physical interface
"""
    steps:
        post schema
        post event type with schema id
        get physical interface
        post physical interface and get physical interface
        put physical interface and get physical interface
        delete physical interface and get physical interface
        delete event type
        delete schema
"""
_prefix = 'RCDCS208'
_prefix_pi = 'RCDCS208_pi'
post_schema_data_for_event_type = return_draft_schema_data(
    _prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')

dtd_expression_for_pi = f"{post_event_type_data[1]}.temp"

post_schema_data_for_pi = return_draft_schema_data(
    _prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(
    _prefix, dtd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(
    _prefix, [], '', mapping_property_pi)
put_physical_interface_data = return_draft_physical_interface(
    _prefix, [], '', mapping_property_pi, des_str_put)

# step 1: post schema
t208_post_and_get_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200},
    {'action': 'GET', 'expect': res_code_200}
]

# step 2: post event type
t208_post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# post schema for physical interface
t208_post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# post expression for property mapping
t208_post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# get physical interface
t208_get_pi_list = [
    {'action': 'GET', 'expect': res_code_200}
]

query_pi_str = f"?name={post_physical_interface_data[1]}"
# step 4: post physical interface and get physical interface
t208_post_and_get_pi_list = [{'action': 'POST',
                              'data': post_physical_interface_data[0],
                              'expect': res_code_200},
                             {'action': 'GET', 'query_string': query_pi_str,
                              'expect': res_code_200}]

# step 5: put physical interface and get physical interface
t208_put_and_get_pi_list = [{'action': 'PUT',
                             'id': physical_interface_id,
                             'data': put_physical_interface_data[0],
                             'expect': res_code_200},
                            {'action': 'GET',
                             'id': physical_interface_id,
                             'expect': res_code_200}]

# step 6: delete physical interface and get physical interface
t208_delete_and_get_pi_list = [
    {'action': 'DELETE', 'id': physical_interface_id, 'expect': res_code_200},
    {'action': 'GET', 'id': physical_interface_id, 'expect': res_code_404}
]

t208_delete_schema_for_pi_list = [
    {'action': 'DELETE', 'id': schema_pi_id, 'expect': res_code_404}
]

t208_delete_expression_for_pi_list = [
    {'action': 'DELETE', 'id': expression_pi_id, 'expect': res_code_404}
]

# step 7: delete event type
t208_delete_event_type_list = [
    {'action': 'DELETE', 'id': event_type_id, 'expect': res_code_404}
]

# step 8: delete schema
t208_delete_schema_list = [
    {'action': 'DELETE', 'id': schema_id, 'expect': res_code_404}
]
