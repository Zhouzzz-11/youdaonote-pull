from iot.data.commonData import *
from iot.hub.data.tasks2.gypt8585.gypt8585_e2e_1 import gypt8585_node1_data

# GYPT8585 thing E2E

# data for the thing type li
_prefix = 'GYPT8585'
_prefix_thing = 'GYPT8585_thing'
_prefix1 = 'GYPT8585_1'

_schema_properties_thing = [return_draft_schema_properties('thing_temperature', 'Number')]
dd_expression_for_mapping = "li_temperature + 10"

post_schema_data_for_thing = return_draft_schema_data(_prefix_thing, _schema_properties_thing)
post_logical_interface_data = return_draft_logical_interface(_prefix, '', type=li_thing_type)
post_expression_for_mapping = return_draft_expression(_prefix1, dd_expression_for_mapping)
child_thing_model = return_child_thing_model(_prefix, gypt8585_node1_data.post_logical_interface_data[2])
post_thing_mapping_data = return_thing_mapping(_prefix, post_logical_interface_data[2],
                                               [child_thing_model[0]], mapping_property_thing)

# GYPT-8585: test data for Thing/ThingType
# post schema for logical interface
post_schema_for_thing_list = [{'action': 'POST',
                            'data': post_schema_data_for_thing[0],
                            'expect': res_code_200}]

# post the logical interface
post_thing_list = [{'action': 'POST',
                 'data': post_logical_interface_data[0],
                 'expect': res_code_200}]

# post expression
post_expression_list = [{'action': 'POST',
                         'data': post_expression_for_mapping[0],
                         'expect': res_code_200}]

# post the mapping
post_thing_mapping_list = [
    {'action': 'POST', 'data': post_thing_mapping_data[0], 'expect': res_code_200}
]

# get the mapping
query_mapping_str = f"?name={post_thing_mapping_data[1]}"
query_mapping_list = [{'action': 'GET',
                       'query_string': query_mapping_str,
                       'expect': res_code_200}]

# activate logical interface
active_li_list = [{'action': 'PATCH',
                   'id': post_logical_interface_data[2],
                   'data': activateData,
                   'expect': res_code_200}]

# get the data from historian
query_data_from_historian_str = ''
query_data_from_historian_list = [{'action': 'GET',
                                   'logicaltype_id': post_logical_interface_data[2],
                                   'device_id': gypt8585_node1_data.post_device_data[1],
                                   'query_string': query_data_from_historian_str,
                                   'expect': res_code_200}]
