from iot.hub.data.demo_data import *


_prefix = 'RCDCS754'

logical_interface_id = post_logical_interface_data[2]
device_id = post_device_data[1]
device_type_id = post_device_type_data[1]


# Query the data with historian actionable id
query_data_from_actionable_list = [
    {'action': 'GET', 'actionable_id': e2e_actionable_id, 'logicaltype_id': logical_interface_id,
     'query_string': '', 'expect': res_code_200}
]

# patch the data with acitonable id
patch_actionable_data = [{"time": "", "state.li_temperature": e2e_data_7}]
patch_actionable_data_list = [
    {'action': 'PATCH', 'actionable_id': e2e_actionable_id, 'logicaltype_id': logical_interface_id,
     'data': patch_actionable_data, 'expect': res_code_200}
]

# Query the data with device type aggregation
query_data_with_agg_from_device_type_list = [
    {'action': 'GET', 'devicetype_id': device_type_id, 'query_string': '',  'aggregation': True,
     'expect': res_code_200}
]

# Query the data with deviceset
query_data_device_set_with_device_type_list = [
    {'action': 'GET', 'devicetype_id': device_type_id, 'query_string': '', 'expect': res_code_200}
]

# Query the data with device type and id
query_data_with_device_id_type_list = [
    {'action': 'GET', 'devicetype_id': device_type_id, 'device_id': device_id, 'query_string': '',
     'expect': res_code_200}
]