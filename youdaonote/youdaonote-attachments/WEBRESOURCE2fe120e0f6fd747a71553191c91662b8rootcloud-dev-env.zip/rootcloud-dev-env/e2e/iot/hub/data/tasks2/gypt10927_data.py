from iot.data.commonData import *
from iot.verify.verifyData import *

# GYPT10927: test property change from number to string
_prefix = 'GYPT10927'
_prefix_pi = 'GYPT10927_pi'

post_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')

# GYPT-12702: test post data with no default event type name
dd_expression_for_pi = f"{post_event_type_data[1]}.temp"

post_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(_prefix, dd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(_prefix, [], '', mapping_property_pi)
# post_device_type_data = return_draft_device_type(_prefix, '', classId=gatewayClass)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_data = return_draft_device(_prefix)
put_schema_data_for_event_type = return_draft_schema_data(_prefix, schema_properties_string_temp)
put_schema_data_for_pi = return_draft_schema_data(_prefix_pi, schema_properties_string_temperature_pi)

put_schema_data_for_event_type_to_boolean = return_draft_schema_data(_prefix, schema_properties_boolean_temp)
put_schema_data_for_pi_to_boolean = return_draft_schema_data(_prefix_pi, schema_properties_boolean_temperature_pi)

# post schema for event type
post_schema_list = [
    {'action': 'POST', 'data': post_schema_data_for_event_type[0], 'expect': res_code_200}
]

# query the schema
query_schema_str = f"?name={post_schema_data_for_event_type[1]}"
query_schema_list = [
    {'action': 'GET', 'query_string': query_schema_str, 'expect': res_code_200}
]

# post event type
post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# query the event type
query_event_type_str = f"?eventTypeId={post_event_type_data[0]['eventTypeName']}"
query_event_type_list = [
    {'action': 'GET', 'query_string': query_event_type_str, 'expect': res_code_200}
]

# post schema for physical interface
post_schema_for_pi_list = [{'action': 'POST',
                            'data': post_schema_data_for_pi[0],
                            'expect': res_code_200}]

# query the schema
query_schema_for_pi_str = f"?name={post_schema_data_for_pi[1]}"
query_schema_for_pi_list = [{'action': 'GET',
                             'query_string': query_schema_for_pi_str,
                             'expect': res_code_200}]

# post expression for property mapping
post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# query the expression
query_expression_for_pi_str = f"?name={post_expression_for_pi[1]}"
query_expression_for_pi_list = [{'action': 'GET',
                                 'query_string': query_expression_for_pi_str,
                                 'expect': res_code_200}]

# post physical interface
post_pi_list = [{'action': 'POST',
                 'data': post_physical_interface_data[0],
                 'expect': res_code_200}]

# query the physical interface
query_pi_str = f"?name={post_physical_interface_data[1]}"
query_pi_list = [
    {'action': 'GET', 'query_string': query_pi_str, 'expect': res_code_200}
]

# query device type
query_device_type_list = [
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# post draft device type
post_device_type_list = [{'action': 'POST',
                          'data': post_device_type_data[0],
                          'expect': res_code_200}]

# active physical interface
active_pi_list = [{'action': 'PATCH',
                   'id': physical_interface_id,
                   'data': activateData,
                   'expect': res_code_200}]

# post device
post_device_list = [{'action': 'POST',
                     'data': post_device_data[0],
                     'type_id': post_device_type_data[1],
                     'expect': res_code_200}]

# get device
query_device_list = [{'action': 'GET',
                      'id': post_device_data[1],
                      'type_id': post_device_type_data[1],
                      'expect': res_code_200}]

# post the data
items = [
    return_items({"temp": 31})
]
post_data = return_post_data(items, eventType=post_event_type_data[1])


# get the data from historian
query_data_from_historian_list = [{'action': 'GET',
                                   'logicaltype_id': physical_interface_id,
                                   'device_id': post_device_data[1],
                                   'query_string': '',
                                   'expect': res_code_200}]

# put schema for event type
put_schema_list = [
    {'action': 'PUT', 'id': '', 'data': put_schema_data_for_event_type[0], 'expect': res_code_200},
    {'action': 'PUT', 'id': '', 'data': put_schema_data_for_pi[0], 'expect': res_code_200}
]

# post the string data
# post the data
items1 = [
    return_items({"temp": 'abc'})
]
post_data1 = return_post_data(items1, eventType=post_event_type_data[1])

# put schema to boolean for event type
put_schema_to_boolean_list = [
    {'action': 'PUT', 'id': '', 'data': put_schema_data_for_event_type_to_boolean[0], 'expect': res_code_200},
    {'action': 'PUT', 'id': '', 'data': put_schema_data_for_pi_to_boolean[0], 'expect': res_code_200}
]

# post the data
items2 = [
    return_items({"temp": 0})
]
post_data2 = return_post_data(items2, eventType=post_event_type_data[1])

items3 = [
    return_items({"temp": 1})
]
post_data3 = return_post_data(items3, eventType=post_event_type_data[1])

items4 = [
    return_items({"temp": 10})
]
post_data4 = return_post_data(items4, eventType=post_event_type_data[1])
