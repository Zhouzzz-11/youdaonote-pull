from iot.data.commonData import *
from iot.data.commonData import schema_properties_number_temp, schema_properties_number_temperature_pi, \
    mapping_property_pi
from iot.verify.verifyData import *


# test case 1: e2e case for draft device type
_prefix = 'RCDCS220'
_prefix_pi = 'RCDCS220_pi'
post_schema_data_for_event_type = return_draft_schema_data(
    _prefix, schema_properties_number_temp)
post_event_type_data = return_draft_event_type(_prefix, '')

dtd_expression_for_pi = f"{post_event_type_data[1]}.temp"

post_schema_data_for_pi = return_draft_schema_data(
    _prefix_pi, schema_properties_number_temperature_pi)
post_expression_for_pi = return_draft_expression(
    _prefix, dtd_expression_for_pi)
post_physical_interface_data = return_draft_physical_interface(
    _prefix, [], '', mapping_property_pi)
post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
put_device_type_data = return_draft_device_type(_prefix, '', des_str_put, directlyLinked=True)

# post schema for event type
t220_post_schema_list = [{'action': 'POST',
                          'data': post_schema_data_for_event_type[0],
                          'expect': res_code_200}]

# post event type
t220_post_event_type_list = [
    {'action': 'POST', 'data': post_event_type_data[0], 'expect': res_code_200}
]

# post schema for physical interface
t220_post_schema_for_pi_list = [
    {'action': 'POST', 'data': post_schema_data_for_pi[0], 'expect': res_code_200}
]

# post expression for property mapping
t220_post_expression_for_pi_list = [
    {'action': 'POST', 'data': post_expression_for_pi[0], 'expect': res_code_200}
]

# post physical interface
t220_post_pi_list = [{'action': 'POST',
                      'data': post_physical_interface_data[0],
                      'expect': res_code_200}]

# get draft device type
t220_get_device_type_list = [
    {'action': 'GET', 'expect': res_code_200}
]

# post draft device type and get device type
t220_post_and_get_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200},
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# put device type and get device type
t220_put_and_get_deivce_type_list = [
    {'action': 'PUT', 'id': post_device_type_data[1], 'data': put_device_type_data[0],
     'expect': res_code_200},
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_200}
]

# delete device type and get device type
t220_delete_and_get_device_type_list = [
    {'action': 'DELETE', 'id': post_device_type_data[1], 'expect': res_code_200},
    {'action': 'GET', 'id': post_device_type_data[1], 'expect': res_code_404}
]

# delete physical interface
t220_delete_pi_list = [
    {'action': 'DELETE', 'id': physicalInterfaceId, 'expect': res_code_404}
]

t220_delete_schema_for_pi_list = [
    {'action': 'DELETE', 'id': schema_pi_id, 'expect': res_code_404}
]

t220_delete_expression_for_pi_list = [
    {'action': 'DELETE', 'id': expression_pi_id, 'expect': res_code_404}
]

t220_delete_event_type_list = [
    {'action': 'DELETE', 'id': event_type_id, 'expect': res_code_404}
]

t220_delete_schema_list = [
    {'action': 'DELETE', 'id': schema_id, 'expect': res_code_404}
]
