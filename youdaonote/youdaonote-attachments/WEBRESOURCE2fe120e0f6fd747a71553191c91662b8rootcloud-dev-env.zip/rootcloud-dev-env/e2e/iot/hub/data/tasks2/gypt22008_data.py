from iot.data.commonData import *
from iot.requestsData import *

# GYPT22008: windows 10s and 30s
_prefix = 'GYPT22008'


post_device_type_data = return_draft_device_type(_prefix, '', directlyLinked=True)
post_device_type_properties_data = [return_device_type_properties(
    name='temperatureA',
    displayName='温度',
    propertyType='Number',
    persistStrategy='onReport',
    privilege=read_write,
    expressionType='window',
    expression='temp',
    mappingName='temp',
    operator='sum',
    windowStepMills=10000,
    windowSizeMills=10000,
    windowAllowedLatenessMills=10000,
    windowDefaultValueJson='3333'
), return_device_type_properties(
    name='temperatureB',
    displayName='温度',
    propertyType='Number',
    persistStrategy='onReport',
    privilege=read_write,
    expressionType='window',
    expression='temp',
    operator='sum',
    windowStepMills=30000,
    windowSizeMills=30000,
    windowAllowedLatenessMills=30000,
    windowDefaultValueJson='3333'
)]

post_device_data = return_draft_device(_prefix)


# post draft device type
post_device_type_list = [
    {'action': 'POST', 'data': post_device_type_data[0], 'expect': res_code_200}
]

# post device type properties
post_device_type_properties_list = [
    {'action': 'POST', 'id': post_device_type_data[1], 'data': post_device_type_properties_data,
     'expect': res_code_200}
]


# active physical interface
active_pi_list = [
    {'action': 'PATCH', 'id': post_device_type_data[1], 'data': activateData, 'expect': res_code_200}
]

# post device
post_device_list = [
    {'action': 'POST', 'data': post_device_data[0], 'type_id': post_device_type_data[1], 'expect': res_code_200}
]

# post the data
items0 = [
    return_items({"temp": 0})
]
items1 = [
    return_items({"temp": 1})
]
items2 = [
    return_items({"temp": 2})
]
items3 = [
    return_items({"temp": 3})
]
items4 = [
    return_items({"temp": 4})
]
items5 = [
    return_items({"temp": 5})
]
items6 = [
    return_items({"temp": 6})
]
items7 = [
    return_items({"temp": 7})
]
items8 = [
    return_items({"temp": 8})
]
items9 = [
    return_items({"temp": 9})
]
items10 = [
    return_items({"temp": 10})
]
items11 = [
    return_items({"temp": 11})
]
items12 = [
    return_items({"temp": 12})
]
items13 = [
    return_items({"temp": 13})
]
post_data0 = return_post_data(items0)
post_data1 = return_post_data(items1)
post_data2 = return_post_data(items2)
post_data3 = return_post_data(items3)
post_data4 = return_post_data(items4)
post_data5 = return_post_data(items5)
post_data6 = return_post_data(items6)
post_data7 = return_post_data(items7)
post_data8 = return_post_data(items8)
post_data9 = return_post_data(items9)
post_data10 = return_post_data(items10)
post_data11 = return_post_data(items11)
post_data12 = return_post_data(items12)
post_data13 = return_post_data(items13)


# get the data from historian
query_start_time = ""
query_end_time = ""
query_data_from_historian_str = ''

query_data_from_historian_list = [
    {'action': 'GET', 'logicaltype_id': post_device_type_data[1], 'device_id': post_device_data[1],
     'query_string': query_data_from_historian_str, 'expect': res_code_200}
]
