from iot.data.commonData import *
from iot.requestsData import *


# GYPT-8512: manufacturer crud
_prefix = 'GYPT8512'
manufacturer_id = 'T' + str(num_suffix2)
manufacturer_id1 = 'T00001'
manufacturer_id2 = 't0001'
manufacturer_name = 'N' + str(num_suffix2)

post_manufacturer_data = return_manufacturer(manufacturer_id, manufacturer_name)
post_manufacturer_data1 = return_manufacturer(manufacturer_id1, manufacturer_name)
post_manufacturer_data2 = return_manufacturer(manufacturer_id2, manufacturer_name)

# post manufacturer
post_manufacturer_list = [
    {'action': 'POST', 'data': post_manufacturer_data, 'expect': res_code_200}
]

# neg: post manufacturer
post_manufacturer_1_list = [
    {'action': 'POST', 'data': post_manufacturer_data1, 'expect': res_code_400}
]

# neg: post manufacturer
post_manufacturer_2_list = [
    {'action': 'POST', 'data': post_manufacturer_data1, 'expect': res_code_400}
]


# get manufacturer by name
query_name_str = f"?name={num_suffix2}"
query_manufacturer_by_name_list = [
    {'action': 'GET', 'query_string': query_name_str, 'expect': res_code_200}
]

# put manufacturer
put_manufacturer_data = {'name': 'U' + str(num_suffix2)}
put_manufacturer_list = [
    {'action': 'PUT', 'id': manufacturer_id, 'data': put_manufacturer_data, 'expect': res_code_200}
]

# delete manufacturer
delete_manufacturer_list = [
    {'action': 'DELETE', 'id': manufacturer_id, 'expect': res_code_200}
]

# get manufacturer by id
query_manufacturer_by_id_list = [
    {'action': 'GET', 'id': manufacturer_id, 'expect': res_code_404}
]
