import pytest
from iot import help
from iot.requestsData import headers, get_metrics_url, api_logger


@pytest.fixture()
def fix_metrics(request):
    _url = get_metrics_url('metrics_url')
    for i in request.param['data_list']:
        _action = i['action']
        if _action == 'POST':
            if i.get('query_string'):
                _res = help.post_action(_url + i.get('query_string'), headers, None, expect=i.get('expect'))
            else:
                _res = help.post_action(_url, headers, None, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
