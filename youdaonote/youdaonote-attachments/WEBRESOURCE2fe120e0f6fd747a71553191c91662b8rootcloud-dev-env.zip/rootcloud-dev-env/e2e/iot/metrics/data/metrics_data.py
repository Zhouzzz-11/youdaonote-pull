from iot.data.commonData import *
import time

post_metrics_list = [
    {'action': 'POST', 'expect': res_code_200}
]

current_time = int(time.time()) * 1000
query_str = f'?currentMillis={current_time}'
post_metrics_with_currentMillis_list = [
    {'action': 'POST', 'query_string': query_str, 'expect': res_code_200}
]
