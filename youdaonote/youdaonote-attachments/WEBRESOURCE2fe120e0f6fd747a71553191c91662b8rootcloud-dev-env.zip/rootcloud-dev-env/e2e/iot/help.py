import os
import json
import time
import requests
from iot.blueprint import blueprint as bp
from iot.verify import verifyData

api_logger = bp.api_logger


def post_action(_url, _headers, _data, **kw):
    res = _send_request('POST', _url, _headers, json=_data, expect=kw.get('expect'), retry=kw.get('retry'))
    _verify_res(res, kw)
    return res


def post_file_action(_url, _headers, _data, _file, **kw):
    res = _send_request('POST_FILE', _url, _headers, data=_data, file=_file, expect=kw.get('expect'), retry=kw.get('retry'))
    _verify_res(res, kw)
    return res


def get_action(_url, _headers, **kw):
    res = _send_request("GET", _url, _headers, expect=kw.get('expect'), retry=kw.get('retry'))
    _verify_res(res, kw)
    return res


def get_historian(_url, _headers, **kw):
    res = _send_request("GET", _url, _headers, expect=kw.get('expect'), retry=kw.get('retry'),
                        expect_num=kw.get('expect_num'), expect_count=kw.get('expect_count'))
    _verify_res(res, kw)
    return res


def get_alarm(_url, _headers, **kw):
    res = _send_request("GET", _url, _headers, expect=kw.get('expect'), retry=kw.get('retry'),
                        expect_alarm_num=kw.get('expect_num'), expect_alarm_count=kw.get('expect_count'))
    _verify_res(res, kw)
    return res


def put_action(_url, _headers, _data, **kw):
    res = _send_request('PUT', _url, _headers, json=_data, expect=kw.get('expect'), retry=kw.get('retry'))
    _verify_res(res, kw)
    return res


def patch_action(_url, _headers, _data, **kw):
    res = _send_request('PATCH', _url, _headers, json=_data, expect=kw.get('expect'), retry=kw.get('retry'))
    _verify_res(res, kw)
    return res


def delete_action(_url, _headers, **kw):
    res = _send_request('DELETE', _url, _headers, json=(kw.get('data') or None), expect=kw.get('expect'),
                        retry_job=kw.get('retry_job'))
    _verify_res(res, kw)
    return res


def _send_request(_method, _url, _headers, **kw):
    _retry = False
    now_test = os.environ.get('PYTEST_CURRENT_TEST').split(':')[-1].split(' ')[0]
    api_logger.info(f'------------------------{now_test} ---------------------------------------')
    api_logger.info(now_test)


    for i in range(0, 9):
        next_sleep = 3 + i * 3
        api_logger.info(f"{_method} {_url}")
        if i == 8:
            api_logger.error(f"After retry 8 times, assert False")
            assert False
        if _method == 'POST':
            res = requests.post(_url, headers=_headers, json=kw['json'])
        elif _method == 'POST_FILE':
            res = requests.post(_url, headers=_headers, files=kw['file'], data=kw['data'])
        elif _method == 'GET':
            res = requests.get(_url, headers=_headers)
        elif _method == 'PUT':
            res = requests.put(_url, headers=_headers, json=kw['json'])
        elif _method == 'PATCH':
            res = requests.patch(_url, headers=_headers, json=kw['json'])
        elif _method == 'DELETE':
            res = requests.delete(_url, headers=_headers, json=kw['json'])
        else:
            api_logger.error(f"Have the wrong request method {_method}")


        if _method in ['POST','POST_FILE','PUT','PATCH']:
            pass
            #api_logger.info(f"BODY:{kw['json']}")
        #api_logger.info(f"RES CODE:{res.status_code}")
        #api_logger.info(f"RES CONTENT:{res.text}")

        if res.status_code == 504:
            api_logger.warning(f"{_method} {_url} get 504 timeout, retry after: {next_sleep}s")
            time.sleep(next_sleep)
            continue

        verifyData.res_text = json.loads(res.text)
        if kw.get('retry') and res.status_code == 200 and verifyData.res_text['payload'] == [] and\
                (kw.get('expect_num') != 0 and kw.get('expect_alarm_num') != 0 and kw.get('expect_alarm_count') != 0):
            _retry = True
            api_logger.warning(f"{_method} {_url} got the null payload, retry after: {next_sleep}s")
            time.sleep(next_sleep)
        elif kw.get('retry') and kw.get('expect_num') and res.status_code == 200 and \
                len(verifyData.res_text['payload'][0]['rows']) != kw.get('expect_num'):
            _retry = True
            api_logger.warning(f"{_method} {_url} doesn't got the expect number {kw.get('expect_num')} payload,"
                                  f" retry after: {next_sleep}s")
            time.sleep(next_sleep)
        elif kw.get('retry') and kw.get('expect_alarm_num') and res.status_code == 200 and \
                len(verifyData.res_text['payload']) != kw.get('expect_alarm_num'):
            _retry = True
            api_logger.warning(
                f"{_method} {_url} doesn't got the expect number {kw.get('expect_alarm_num')} of alarm,"
                f" retry after: {next_sleep}s")
            time.sleep(next_sleep)
        elif kw.get('retry') and kw.get('expect_alarm_count') and res.status_code == 200 and \
                verifyData.res_text['payload']['totalNum'] != kw.get('expect_alarm_count'):
            _retry = True
            api_logger.warning(
                f"{_method} {_url} doesn't got the expect number {kw.get('expect_alarm_count')} of alarm,"
                f" retry after: {next_sleep}s")
            time.sleep(next_sleep)
        elif kw.get('expect') == str(res.status_code) or not kw.get('expect'):
            return res
        else:
            _retry = _verify_retry(res, kw)

        if kw.get('retry_job'):
            _retry, _url = _verify_job_retry(_retry, _url, i, res)

        if not _retry:
            api_logger.error(f"{_method} {_url} got the unexpected res: {res.status_code} with message: {res.text}")
            assert False

        api_logger.warning(f"{_method} {_url} got the unexpected res: {res.status_code} with message: {res.text},"
                              f" retry after: {next_sleep}s")
        time.sleep(next_sleep)
    api_logger.error(f"After retry: get the unexpected res: {res.status_code} with message: {res.text}")
    assert False


def _verify_job_retry(_retry, _url, i, res):
    if res.status_code == 404:
        _url = _url + '?force=true'
        if i == 0:
            _retry = True
        else:
            _retry = False
    else:
        _url = _url + '?force=true'
        _retry = True
    return _retry, _url


def _verify_res(_res, _kw):
    pass


def _verify_retry(_res, _kw):
    if _kw.get('retry') and _res.status_code in bp.retry_code:
        return True
    return False
