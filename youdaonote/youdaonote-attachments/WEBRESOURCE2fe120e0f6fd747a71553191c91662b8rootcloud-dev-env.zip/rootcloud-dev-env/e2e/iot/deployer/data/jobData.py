from iot.data.commonData import *
from iot.requestsData import manufacturer_id, manufacturer_name

# Test case 1: RCDCS-295 job e2e cases
"""
    get job
    delete and get job
    post and get job
"""

# delete and get job
delete_call_back = {'tenantId': tenant_id}
jd_t1_2_data_list = [
    {'action': 'DELETE', 'id': tenant_id, 'data': delete_call_back}
]

jd_t1_3_data_list = [
    {'action': 'POST', 'data': get_deploy_body(tenant_id)[0], 'expect': res_code_200},
    {'action': 'POST', 'data': get_deploy_body(share, projectCode='shared-project-code')[0], 'expect': res_code_200}
]

job_data = {'tenantId': tenant_id, 'jobMode': 'recoup', 'parallelism': 1, 'topicprefix': tenant_id}
jd_t1_3_1_data_list = [
    {'action': 'POST', 'data': job_data, 'expect': res_code_200}
]


jd_t1_3_2_data_list = [
    {'action': 'GET', 'id': tenant_id, 'expect': res_code_200}
]


delete_call_back = {'tenantId': tenant_id}
jd_t1_4_data_list = [
    {'action': 'DELETE', 'id': tenant_id, 'data': delete_call_back, 'expect': res_code_200}
]

# post manufacturer id
post_manufacturer_data = return_manufacturer(manufacturer_id, manufacturer_name)

# post manufacturer
post_manufacturer_list = [
    {'action': 'POST', 'data': post_manufacturer_data}
]

# delete manufacturer
delete_manufacturer_list = [
    {'action': 'DELETE', 'id': manufacturer_id, 'expect': res_code_200}
]
