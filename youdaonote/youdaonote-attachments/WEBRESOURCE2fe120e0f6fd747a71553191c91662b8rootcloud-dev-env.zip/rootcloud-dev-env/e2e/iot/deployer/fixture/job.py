import pytest
from iot import help
from iot.requestsData import headers, get_deployer_url, api_logger


@pytest.fixture()
def fix_job(request):
    _url = get_deployer_url('job_url')
    for i in request.param['data_list']:
        _action = i['action']
        if _action == 'POST':
            _res = help.post_action(_url, headers, i.get('data'), expect=i.get('expect'))
        elif _action == 'GET':
            _res = help.get_action(_url + '/' + i.get('id'), headers, expect=i.get('expect'), retry=True)
        elif _action == 'DELETE':
            if i.get('force'):
                _res = help.delete_action(_url + '/' + i.get('id'), headers,
                                          expect=i.get('expect'), retry_job=True)
            else:
                _res = help.delete_action(_url + '/' + i.get('id'), headers, expect=i.get('expect'))
        else:
            api_logger.error(f"Have the wrong request method {_action}")
