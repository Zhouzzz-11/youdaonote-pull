import random
import datetime
import uuid
from iot.blueprint import blueprint as bp


tenant_id = bp.default_tenant_id
kafka_server = bp.kafka_server
hub_super_token = bp.hub_super_token
test_server = bp.run_env
share = 'share'

headers = {"accept": "application/json", "X-RCD-Tenant-Id": tenant_id, "Authorization": hub_super_token} if\
    test_server in ['local', 'localhost'] else {"accept": "application/json", 'Authorization': ""}
headers2 = {"accept": "application/json", "X-RCD-Tenant-Id": tenant_id, "Authorization": hub_super_token,
            "Content-Type": "multipart/form-data"}
# save bearer token
headers_dict = {}


def get_header(_tenant_id):
    if test_server in ['local', 'localhost']:
        return {"accept": "application/json", "X-RCD-Tenant-Id": _tenant_id, "Authorization": hub_super_token}
    else:
        return headers_dict.get(_tenant_id)


api_logger = bp.api_logger
per_logger = bp.per_logger

# multi tenant test
tenant_a = 't1_a'
tenant_b = 't1_b'

# shared tenant test
tenant_shared_a = 's_t1_a'
tenant_shared_b = 's_t1_b'
tenant_shared_c = 's_t1_c'

# for metric test
tenant_list = [tenant_id, tenant_a, tenant_b, tenant_shared_a, tenant_shared_b, tenant_shared_c]


topic_dict = {
    'ntp_sub': 'v4/s/get/cloud/time/json/1.0',
    'cmd_sub': 'v4/s/post/device/cmd/json/1.0',
    'cmd_pub': 'v4/p/resp/post/device/cmd/json/1.0',
    'config_req_sub': 'v4/s/set/device/config/json/1.0',
    'config_req_pub': 'v4/p/resp/set/device/config/json/1.0',
    'config_update_sub': 'v4/s/get/device/config/json/1.0',
    'config_update_pub': 'v4/p/resp/get/device/config/json/1.0',
    'live_sub': 'v4/s/set/thing/live/json/1.0',
    'live_pub': 'v4/p/resp/set/thing/live/json/1.0',
    'pub_1.0': 'v4/p/post/thing/live/json/1.0',
    'pub_1.1': 'v4/p/post/thing/live/json/1.1',
    'sub_1.0': 'v4/s/get/cloud/time/json/1.0',
    'sub_1.1': 'v4/s/get/cloud/time/json/1.1',
    'history_1.0': 'v4/p/post/thing/history/json/1.0',
    'history_1.1': 'v4/p/post/thing/history/json/1.1',
    'jsongz_1.0': 'v4/p/post/thing/history/jsongz/1.0',
    'jsongz_1.1': 'v4/p/post/thing/history/jsongz/1.1'
}

rabbitMq_dict = {
    'thing_sync': {
        'queue': "base-thing.queue.saas.4.0",
        'exchange': "base-thing-publish-model-4.0"
    },
    'thing_del': {
        'queue': "base-thing.queue.saas.del",
        'exchange': "base-thing-publish-model"
    },
    'device': {
        'queue': "device-create-update",
        'exchange': "base-thing-publish-model"
    },
    'device_status': {
        'queue': "device-status-change-saas",
        'exchange': "fanout-device-status"
    },
    'alarm_open': {
        'queue': "base-event.queue.notification.saas",
        'exchange': "base-event.direct",
        'routing':"base-event.queue.notification.saas"
    },
    'alarm_close': {
        'queue': "base-event.queue.notification.saas.event.status",
        'exchange': "base-event.direct",
        'routing': "base-event.queue.notification.saas.event.status"
    },
}


def get_hub_url(_url):
    return bp.hub_url_dict[_url]


def get_simulator_url(_url):
    return bp.simulator_url_dict[_url]


def get_historian_url(_url):
    return bp.historian_url_dict[_url]


def get_deployer_url(_url):
    return bp.deployer_url_dict[_url]


def get_metrics_url(_url):
    return bp.metrics_url_dict[_url]


def get_identity_url(_url):
    return bp.identity_url_dict[_url]


# random value
time_prefix = datetime.datetime.now().strftime('%y%m%d')
num_suffix = random.randint(0, 100000000)
num_suffix1 = random.randint(1000, 9998)
num_suffix2 = num_suffix1 + 1
r_num = num_suffix
r_num_suffix = time_prefix + '_' + str(num_suffix)
r_num_suffix2 = time_prefix + '_' + str(num_suffix1)

# get uuid
suid_list = []
for i in range(15):
    uid = str(uuid.uuid4())
    suid = ''.join(uid.split('-'))
    suid_list.append(suid)

manufacturer_id = 'T' + str(num_suffix1)
manufacturer_name = 'N' + str(num_suffix1)

sleep_time = 2
sleep_time_3 = 3
# device/device type
platform = 'PLATFORM'
deviceClass = 'DEVICE'
deviceClass2 = 'Device'
gatewayClass = 'GATEWAY'
deviceAuthType = 'PERSON'
protocolV4 = 'ROOTCLOUD_V4'

# event type
default_event = "DEFAULT_EVENT"

# ids
deviceTypeId = 'deviceTypeId'
deviceId = 'deviceId'
eventTypeId = 'eventTypeId'
expressionId = 'expressionId'
interfaceId = 'interfaceId'
logicalInterfaceId = 'logicalInterfaceId'
physicalInterfaceId = 'physicalInterfaceId'
propertyMappings = 'propertyMappings'
schemaId = 'schemaId'
ruleId = 'ruleId'

# active/deactive
activateData = {'operation': 'activate'}
deactivateData = {'operation': 'deactivate'}


# description string
des_str = "description string"
des_str_put = "put description string"

# schema property
persis_strategy_always = "always"
persis_strategy_on_report = "onReport"
persis_strategy_on_change = "onChange"
persis_strategy_on_period = "onPeriod"
persis_strategy_never = "never"
read_write = 'ReadWrite'
read_only = 'ReadOnly'
write_only = 'WriteOnly'

# expression type
ex_linear = 'linear'
ex_groovy = 'groovy'
ex_const = 'constant'

# logical interface
li_thing_type = 'THINGTYPE'
li_type = 'LOGICALINTERFACE'

# thing mapping
node_single_type = 'SingleDeviceNode'

# alarm
sl_2 = 2

# historian
historian_properties = "[\"li_temperature\"]"
historian_properties1 = "[\"temperature\"]"
historian_properties2 = "[\"li_temperatureB\"]"
actionable_properties = "[\"state.li_temperature\"]"

# metrics
metric_detail = 'IOT4_DEVICE_DETAIL_METRIC'
metric_overview = 'IOT4_DEVICE_OVERVIEW_METRIC'

# invalid test input
invalid_id = 'invalid_id'

# res code
res_code_200 = '200'
res_code_201 = '201'
res_code_204 = '204'
res_code_400 = '400'
res_code_401 = '401'
res_code_403 = '403'
res_code_404 = '404'
res_code_500 = '500'

# res message:
mes_put_alarm = "此报警为自动关闭，无法手动关闭"

mes_invalid_body = "Couldn't deserialize body to"
mes_param_no_null = "Parameter specified as non-null is null"
mes_invalid_type = "不符合格式要求"
mes_not_exist = "不存在"
mes_exist = "已存在"
mes_not_same = "不一致"
mes_null_value = "不能为空"
mes_shared_tenant = "是共享租户"
mes_mis_gateway_id = "缺少gatewayId"
mes_invalid_manufacturer = "manufacturerId必须是A-Z0-9组成的5位长度字符串"


# data body
def return_body_data(kw, **kwargs):
    d = {}
    for k,v in kwargs.items():
        d[k] = v
    for k,v in kw.items():
        d[k] = v
    return d
