import time


def get_time_stamp(_input_time, _time_duration):
    _create_time = _input_time.split('.')[0]
    _start_time = _create_time + 'Z'
    _struct_time = time.strptime(_create_time.replace('T', ' '), "%Y-%m-%d %H:%M:%S")
    _time_array = time.localtime(time.mktime(_struct_time) + _time_duration * 100)
    _time_array2 = time.localtime(time.mktime(_struct_time) - _time_duration * 100)
    _end_time = time.strftime("%Y-%m-%dT%H:%M:%SZ", _time_array)
    _start_time = time.strftime("%Y-%m-%dT%H:%M:%SZ", _time_array2)
    return _start_time, _end_time


def get_query_string(_timestamp, _property='No'):
    _local_time = time.localtime(int(_timestamp/1000)-50000)
    _create_time = time.strftime("%Y-%m-%dT%H:%M:%S", _local_time)
    _start_time, _end_time = get_time_stamp(_create_time, 100000)
    if _property == 'No':
        query_str = f"?startTime={_start_time}&endTime={_end_time}"
    else:
        query_str = f"?properties={_property}&startTime={_start_time}&endTime={_end_time}"
    return query_str


def my_assert(actual, expect):
    assert actual == expect, f"\nExpect result:\n  {expect},\nActual result:\n  {actual}"


def my_assert_mes(mes, expect):
    assert expect in mes, f"\nExpect message:\n  {expect},\nActual message:\n  {mes}"
