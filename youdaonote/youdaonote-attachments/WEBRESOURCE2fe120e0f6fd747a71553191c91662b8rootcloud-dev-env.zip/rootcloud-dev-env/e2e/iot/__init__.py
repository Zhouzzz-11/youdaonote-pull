import os
import yaml
import logging
import logging.config


DEFAULT_LOG_CONFIG = {
    'version': 1,
    'formatters': {
        'void': {
            'format': ''
        },
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        },
        'performance': {
            'format': '%(message)s'
        }
    },
    'handlers': {
        'default': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'standard',
            'stream': 'ext://sys.stdout'
        },
        'api-test': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'formatter': 'standard',
            'filename': 'api-test.log'
        },
        'performance': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'formatter': 'performance',
            'filename': 'performance.log'
        },
    },
    'loggers': {
        '': {
            'handlers': ['default'],
            'level': 'INFO'
        },
        'api-test': {
            'handlers': ['api-test', 'default'],
            'level': 'DEBUG',
            'propagate': False
        },
        'performance': {
            'handlers': ['performance', 'default'],
            'level': 'DEBUG',
            'propagate': False
        },
    },
}


def setup_logging(config_path='logging.yaml', env_key='LOG_CFG'):
    """Set up logging configuration
    """
    value = os.getenv(env_key)
    if value:
        config_path = value
    if os.path.exists(config_path):
        with open(config_path, 'rt') as f:
            config = yaml.safe_load(f.read())
            logging.config.dictConfig(config)
    else:
        logging.config.dictConfig(DEFAULT_LOG_CONFIG)


setup_logging()
