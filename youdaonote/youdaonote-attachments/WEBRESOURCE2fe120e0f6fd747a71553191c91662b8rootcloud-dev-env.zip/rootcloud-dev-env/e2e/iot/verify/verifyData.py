# res
res_text = ""  # record the res message
res_payload = []  # record the res payload
res_payload2 = []  # record the second res payload
res_payload3 = []  # record the third res payload
res_e2e_payload = []
mqtt_client = ""  # record mqtt client
mqtt_client_1 = ""
mqtt_client_2 = ""
mqtt_e2e_client = ""  # record mqtt client


# record the activation data
physical_interface_id = ""
logical_interface_id = ""
expression_id = ""
expression_pi_id = ""
schema_id = ""
schema_pi_id = ""
actionable_id = ""
event_type_id = ""
udf_id = ""
device_type_id = ""
start_time = ""
end_time = ""
create_time = ""
instruction_id = ""
hub_req_id = ""
thing_mapping_id = ""
thing_id = ""
rule_id = ""

# alarm type
alarm_id = ""
alarm_type_id = ""

# record the e2e data
e2e_actionable_id = ""
e2e_end_time = ""
e2e_start_time = ""

# current time stamp
current_time = 0

# metrics
metric_tenant_dict = {'tenant_before_num': 0, 'tenant_after_num': 0,
                      'tenant_before_list': [], 'tenant_after_list': []}
metric_device_dict = {'device_before_num': 0, 'device_after_num': 0,
                      'device_before_list': [], 'device_after_list': []}

# mqtt response
msg_id = ""
