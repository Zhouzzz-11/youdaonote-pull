import operator
from deepdiff import DeepDiff
from iot.requestsData import api_logger


def verify_res_payload(_get_payload, _post_data):
    if isinstance(_get_payload, dict) and operator.ge(_post_data.items(), _get_payload.items()):
        return 0
    elif isinstance(_get_payload, list) and operator.eq(_get_payload, _post_data):
        return 0
    else:
        dataDiff = get_data_diff(_post_data, _get_payload)
        api_logger.warning(dataDiff)
        return -1


def get_data_diff(data1, data2, ignore_order=True):
    dataDiff = DeepDiff(data1, data2, ignore_order)
    return dataDiff


def verify_res(_payload, res_dict):
    _key_list = _payload[0]['columns'][1:]
    _val_list = _payload[0]['rows'][-1][1:]
    _res_dict = dict(zip(_key_list, _val_list))
    assert operator.eq(_res_dict.items(), res_dict.items()), \
        f"\nExpect result:\n  {res_dict.items()},\nActual result:\n  {_res_dict.items()}"
