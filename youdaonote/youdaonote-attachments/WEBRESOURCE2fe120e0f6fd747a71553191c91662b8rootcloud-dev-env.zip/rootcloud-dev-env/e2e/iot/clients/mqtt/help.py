from iot.clients.mqtt.mqtts import MqttClients
from iot import requestsData
import time
import json
import uuid
from multiprocessing import Process
from multiprocessing import Manager

manager = Manager()
return_dict = manager.dict()
topics = requestsData.topic_dict


def post_data2(data, payload, sleep_time=2, topic=topics['pub_1.1']):
    res = insert_data(data, payload, topic)
    if not res:
        print("Insert data failed")
        assert False
    time.sleep(sleep_time)


def insert_data(data, device_payload, topic=topics['pub_1.1']):
    _mqtt = MqttClients(pub_topic=topic)
    return _mqtt.insert_data(data, device_payload)


def get_connection(device_payload):
    mqttClient = MqttClients()
    mqttClient.init_connection(device_payload)
    return mqttClient


def post_data(mqttClient, data, topic=topics['pub_1.1'], sleep_time=2):
    mqttClient.insert_data2(topic, data)
    time.sleep(sleep_time)


def ntp_instruction(device_payload, sub_topic, sleep_time=2):
    data = generate_read_time_data()
    _mqtt = MqttClients(sub_topic=sub_topic)
    return json.loads(_mqtt.ntp_instruction(device_payload, data)), data


def cmd_instruction(device_payload, sub_topic):
    print("主进程执行中A")
    p = Process(target=cmd_subscribe, args=(device_payload, return_dict, sub_topic))
    p.start()
    time.sleep(1)
    print("主进程执行中B")


def cmd_subscribe(device_payload, return_dict, sub_topic):
    print("子进程执行中")
    _mqtt = MqttClients(sub_topic=sub_topic)
    return _mqtt.cmd_instruction(device_payload, return_dict)


def cmd_publish(device_payload, data, pub_topic, sleep_time=0.5):
    _mqtt = MqttClients(pub_topic=pub_topic)
    _mqtt.cmd_publish(device_payload, data)
    time.sleep(sleep_time)


def generate_read_time_data():
    uid = str(uuid.uuid4())
    suid = ''.join(uid.split('-'))
    ts = int(time.time()*1000)
    data = {
        'header': {
            'msgId': suid,
            'ts': ts
        }
    }
    return data
