import os
import time
import json
import paho.mqtt.client as paho
import paho.mqtt.publish as publish
from iot.blueprint import blueprint as bp

api_logger = bp.api_logger


class MqttClients(object):
    def __init__(self, **kw):
        super().__init__()
        self.pub_topic = kw.get('pub_topic', '')
        self.sub_topic = kw.get('sub_topic', '')
        global instruction_history, autoResponse, device_payload
        instruction_history = []
        autoResponse = False
        self.client = ''
        api_logger.info(f"-----------begin connect to mqtt-----------")

    def insert_data(self, data, device_payload):
        conf = self.get_config(device_payload)
        hostname = conf['host']
        port = conf['port']
        auth = {'username': conf['userName'], 'password': conf['password']}
        clientId = conf['clientId']
        qos = conf['qos']
        try:
            msgs = map(
                lambda d: {
                    'topic': self.pub_topic,
                    'payload': json.dumps(d),
                    'qos': qos
                }, data
            )
            api_logger.info(f"publish.multiple Connecting to {hostname}:{port} with client id: {clientId}")
            publish.multiple(msgs, hostname=hostname, port=port, client_id=clientId,
                             keepalive=60, will=None, auth=auth, tls=None, protocol=paho.MQTTv31)
            count = len(data)
            api_logger.info(f"Successfully send {count} data")
            api_logger.info(f"insert  {msgs}:  {data} ")
            return True
        except Exception as e:
            errMes = f"Failed to publish message, {str(e)}"
            print(errMes)
            return False

    def init_connection(self, device_payload, qos=0):
        conf = self.get_config(device_payload)
        client_id = conf['clientId']
        self.client = paho.Client(client_id=client_id)
        self.client.username_pw_set(conf['userName'], conf['password'])
        api_logger.info(f"Connecting to {conf['host']}:{conf['port']} with client id: {client_id}")

        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.on_subscribe = self.on_subscribe
        self.client.on_log = self.on_log
        self.client.connect(conf['host'], conf['port'], 60)
        self.client.loop_start()
        time.sleep(0.2)
        self.client.loop_stop()
        conn_state = self.client.is_connected()
        if conn_state == False:
            assert False





    def insert_data2(self, topic, data):
        try:
            dataStr = json.dumps(data)
            self.client.publish(topic, dataStr)
            count = len(data)
            api_logger.info(f"Successfully send {count} data")
            api_logger.info(f"insert  {topic}:  {data} ")
        except Exception as e:
            errMes = f"Failed to publish message, {str(e)}"
            api_logger.error(errMes)




    def cmd_instruction(self, device_payload, return_dict):
        conf = self.get_config(device_payload)
        client_id = conf['clientId']
        client = paho.Client(client_id=client_id)
        client.username_pw_set(conf['userName'], conf['password'])
        print(f"Connecting to {conf['host']}:{conf['port']} with client id: {client_id}")
        client.on_connect = self.on_connect
        client.on_message = self.on_message
        client.on_subscribe = self.on_subscribe
        client.connect(conf['host'], conf['port'], 60)
        client.loop_start()
        time.sleep(3)
        client.loop_stop()
        client.disconnect()
        return_dict['cmd_res'] = self.res
        return client

    def cmd_publish(self, device_payload, data, qos=0):
        conf = self.get_config(device_payload)
        dataStr = json.dumps(data)
        client_id = conf['clientId']
        client = paho.Client(client_id=client_id)
        client.username_pw_set(conf['userName'], conf['password'])
        print(f"Connecting to {conf['host']}:{conf['port']} with client id: {client_id}")
        client.on_connect = self.on_connect
        client.on_message = self.on_message
        client.on_subscribe = self.on_subscribe
        client.connect(conf['host'], conf['port'], 60)
        client.publish(self.pub_topic, dataStr, qos)

    def ntp_instruction(self, device_payload, data, qos=0):
        conf = self.get_config(device_payload)
        dataStr = json.dumps(data)
        client_id = conf['clientId']
        client = paho.Client(client_id=client_id)
        client.username_pw_set(conf['userName'], conf['password'])
        print(f"Connecting to {conf['host']}:{conf['port']} with client id: {client_id}")
        client.on_connect = self.on_connect
        client.on_message = self.on_message
        client.on_subscribe = self.on_subscribe
        client.connect(conf['host'], conf['port'], 60)
        time.sleep(2)
        client.publish("v4/p/get/cloud/time/json/1.0", dataStr, qos)
        client.loop_start()
        time.sleep(2)
        client.loop_stop()
        client.disconnect()
        return self.res

    def get_config(self, device_payload):
        conf = {}
        conf['host'] = os.getenv('EMQX_HOST', 'localhost')
        conf['userName'] = device_payload.get('userName', 'token-auth')
        conf['password'] = device_payload.get('authToken', 'demoToken')
        conf['clientId'] = device_payload.get('userName', "token-auth")
        conf['devid'] = device_payload.get('deviceId', 'd1')
        conf['devtype'] = device_payload['type']['deviceTypeId']
        conf['category'] = device_payload.get('classId', 'd')
        conf['port'] = 1883
        conf['qos'] = 0
        conf['response'] = 'INSTRUCTION_ACK'
        return conf

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            api_logger.info(f"Connected to mqtt Broker,  with result code {str(rc)}")
        else:
            api_logger.info(f"Failed to connect mqtt, with result code {str(rc)}")
            self.client.loop.stop()

        client.subscribe(self.sub_topic)

    def on_subscribe(self, client, userdata, mid, granted_qos):
        api_logger.info(f"Subscribed to instruction topic")

    def on_message(self, client, userdata, msg):
        self.res = str(msg.payload.decode('utf-8'))
        api_logger.info(f"topic: {msg.topic}, message: {self.res}")

    def on_log(self, client, userdata, level, buff):
        api_logger.info(f"mqtt log, message: {buff}")