import pika
import json
from threading import Timer
from iot.requestsData import test_server


class RabbitMqClient:
    def __init__(self, queue, exchangeName, **kw):
        self.queue = queue
        self.exchangeName = exchangeName
        self.routing_key = kw.get('routing_key', '')
        self.user = kw.get('user', 'test')
        self.passwd = kw.get('passwd', 'test')
        self.host = 'rabbitmq' if test_server == 'local' else 'localhost'
        self.port = kw.get('port', 5672)
        self.channel = ''
        self.res_list = []

    def consumer_mes(self):
        credientials = pika.credentials.PlainCredentials(self.user, self.passwd)
        parameters = pika.ConnectionParameters(self.host, self.port, '/', credientials)
        connection = pika.BlockingConnection(parameters)
        channel = connection.channel()
        self.channel = channel
        if self.routing_key:
            channel.exchange_declare(exchange=self.exchangeName, exchange_type='direct', durable=True,
                                     auto_delete=False,
                                     internal=False, arguments=None)
            channel.queue_declare(queue=self.queue, durable=True, exclusive=False, auto_delete=False, arguments=None)
            channel.queue_bind(exchange=self.exchangeName, queue=self.queue, routing_key=self.routing_key)
        else:
            channel.exchange_declare(exchange=self.exchangeName, exchange_type='fanout', durable=True,
                                     auto_delete=False,
                                     internal=False, arguments=None)
            channel.queue_declare(queue=self.queue, durable=True, exclusive=False, auto_delete=False, arguments=None)

        channel.basic_consume(self.queue, self.print_mes, auto_ack=True)
        try:
            r = Timer(3, self.stop_consumer)
            r.start()
            channel.start_consuming()
        except Exception as ex:
            print(ex)

        return self.res_list

    def print_mes(self, ch, method, properties, body):
        res = json.loads(bytes.decode(body))
        self.res_list.append(res)

    def stop_consumer(self):
        try:
            self.channel.stop_consuming()
        except Exception as ex:
            print(ex)
