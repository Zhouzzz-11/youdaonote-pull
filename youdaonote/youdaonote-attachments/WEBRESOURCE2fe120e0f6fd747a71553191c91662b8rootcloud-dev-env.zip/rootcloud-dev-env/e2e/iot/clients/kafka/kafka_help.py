from kafka import KafkaConsumer
from iot.data.commonData import *
import json


def get_overview_metric():
    c = init_kafka_consumer(metric_overview, 'tenant_group')
    metric_list = []
    metric_tenant_list = []
    for msg in c:
        metric_list.append(json.loads(msg.value))
        metric_tenant_list.append(json.loads(msg.value)['tenantId'])
    c.close()
    metric_set = set(metric_tenant_list)
    metric_num = len(metric_set)
    return metric_num, list(metric_set)


def get_detail_metric():
    c = init_kafka_consumer2(metric_detail, 'detail_group')
    device_num = 0
    for msg in c:
        device_num = msg.offset
    c.close()
    return device_num


def get_detail_metric2():
    c = init_kafka_consumer(metric_detail, 'detail_group')
    metric_list = []
    metric_detail_list = []
    for msg in c:
        metric_list.append(json.loads(msg.value))
        metric_detail_list.append(json.loads(msg.value)['deviceId'])
    c.close()
    device_num = len(metric_detail_list)
    return device_num, metric_detail_list


def init_kafka_consumer(_metric_topic, _group_id):
    c = KafkaConsumer(_metric_topic, group_id=_group_id, bootstrap_servers=kafka_server, consumer_timeout_ms=1000)
    return c


def init_kafka_consumer2(_metric_topic, _group_id):
    c = KafkaConsumer(_metric_topic, group_id=_group_id, bootstrap_servers=kafka_server, consumer_timeout_ms=1000,
                      auto_offset_reset='latest', enable_auto_commit=False)
    return c
