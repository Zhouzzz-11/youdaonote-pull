package com.rootcloud.udf.test;


import cn.gezhitech.jsoniter.any.Any;
import com.rootcloud.platform.annotations.UdfContainer;
import com.rootcloud.platform.eca.UdfContext;
import java.util.Map;

@UdfContainer
public class TestUdf {

  static double c2F(UdfContext context) {
    Any input = context.getInput();
    return input.toDouble() * 1.8D + 32.0D;
  }

  double c2K(UdfContext context) {
    Any input = context.getInput();
    return input.toDouble() + 273.15D;
  }

  static boolean diffTemp(UdfContext context) {
    Map<String, Any> input = context.getInput().asMap();
    System.out.printf("## [new version] got input: %s%n", input);
    double temperature1 = input.get("temperature1").toDouble();
    double temperature2 = input.get("temperature2").toDouble();
    boolean res = Math.abs(temperature1 - temperature2) > 100.0D;
    System.out.printf("## [new version] diff temperature: %s, res: %s%n", input, res);
    return res;
  }
}

