#!/bin/bash

echo "Destroying Development Environment..."

CWD=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${CWD}"/env.sh

export IOT_DATA_DIR="${HOME}/.iot4-dev-env"

dockerComposeFiles=""
while IFS=  read -r -d $'\0'; do
    dockerComposeFiles+="-f $REPLY "
done < <(find . -name "docker-compose*" -print0)

sh -c "docker-compose ${dockerComposeFiles} down --remove-orphans"

rm -rf "${IOT_DATA_DIR}" || sudo rm -rf "${IOT_DATA_DIR}"

echo "Development Environment is destroyed!"
