'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, hubDict } = require('../test-data/requireData');

const httpClient = getHttpClient();

/*
	Post  /elecfence​/saas
 */
function postElecfenceByThingId(body, responsePutter = null, idPutter = null) {

	it('Post elecfence', async () => {
		const url = `${hubDict['elecfence']}`;
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
		if (Object.prototype.hasOwnProperty.call(JSON.parse(response.body), 'payload')) {
			const elecFenceRuleId = JSON.parse(response.body)['payload'];
			putData(idPutter, elecFenceRuleId);
		}
	});
}

/*
	Post  ​/draft​/elecfence​/types
 */
function postDraftElecfence(body, responsePutter = null) {

	it('Post draft elecfence', async () => {
		const url = `${hubDict['draftElecfence']}`;
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put  /elecfence​/saas​/{elecFenceRuleId}
 */
function putElecfenceByThingId(id, body, responsePutter = null) {

	it('put elecfence', async () => {
		const elecFenceRuleId = getData(id);
		const url = `${hubDict['elecfence']}/${elecFenceRuleId}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	delete  /elecfence​/saas​/{elecFenceRuleId}
 */
function deleteElecfenceByThingId(id, responsePutter = null) {

	it('delete elecfence', async () => {
		const elecFenceRuleId = getData(id);
		const url = `${hubDict['elecfence']}/${elecFenceRuleId}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	patch  /elecfence​/saas​/{elecFenceRuleId}
 */
function patchElecfenceByThingId(id, body, responsePutter = null) {

	it('patch elecfence', async () => {
		const elecFenceRuleId = getData(id);
		const url = `${hubDict['elecfence']}/${elecFenceRuleId}`;
		const response = await httpClient.patch(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	postDraftElecfence,
	postElecfenceByThingId,
	putElecfenceByThingId,
	deleteElecfenceByThingId,
	patchElecfenceByThingId
};