'use strict';

const { putData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, hubDict } = require('../test-data/requireData');
const { retryRequest } = require('../test-data/util');
const { Response } = require('@rootcloud/darjeeling-http');
const { log4js } = require('./logger');
const logger = log4js.getLogger('loggerApi');
const httpClient = getHttpClient();

/*
		get  /device​/types​/{deviceTypeId}​/devices​/{deviceId}​/status
 */

function getDeviceByDeviceOnlineStatusId(deviceTypeId, deviceId, responsePutter = null, options = {}) {
	it('get device online status by deviceTypeId and deviceId', async () => {
		const url = `${hubDict['deviceUrl']}/${deviceTypeId}/devices/${deviceId}/status`;
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			logger.info('checking shouldRetry');
			const body = Response.getJsonBody(response);
			if (Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime') !== options.flag) {
				logger.info(`retry: response status is: null`);
				return true;
			}
			return false;
		});
		logger.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

/*
	Post  /devices/status/aggregate
 */
function deviceAggregate(key, value,responsePutter = null) {

	it('aggregate Device and DeviceStatus', async () => {
		const url = `${hubDict['deviceAggregate']}`;
		var body = {};
		if(value == undefined){
			body= {
				'match':'{"'+key+'":null}',
				'group':'{"_id":"$'+key+'","count":{"$sum":1}}'
			};
		}else{
			body = {
				'match':'{"'+key+'":"'+value+'"}',
				'group':'{"_id":"$'+key+'","count":{"$sum":1}}'
			};
		}
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}


module.exports = {
	getDeviceByDeviceOnlineStatusId,
	deviceAggregate
};