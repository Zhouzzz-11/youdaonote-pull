'use strict';

const { putData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = getHttpClient();
const { header, hubDict } = require('../test-data/requireData');

function deployer(body, responsePutter = null) {

	it('deployer tenant and job', async () => {
		const response = await httpClient.post(hubDict['deployerUrl'], { json: body, headers: header });
		putData(responsePutter, response);
	});
}

// Delete  /resource/tenant/callback
function deleteDeployer(body,  responsePutter = null){
	it('delete tenant and jobs', async () => {
		const response = await httpClient.delete(hubDict['callbackUrl'], { json: body, headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	deployer,
	deleteDeployer
};
