'use strict';

const { putData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, openApiDict, hubDict } = require('../test-data/requireData');

const httpClient = getHttpClient();

/*
    GET  /device/device-instances/status
 */
function getDevicesStatus(responsePutter = null, options = {}){

	it('get devices status', async () => {
		let url = openApiDict['deviceStatus'];
		if (options != null){
			url = `${url}?${options.criteria}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
    GET  /find
 */
function getDevicesStatusByRichFind(responsePutter = null, options = {}){

	it('get devices status by rich find', async () => {
		let url = `${hubDict['richFindUrl']}?${options.criteria}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
    POST  /find
 */
function postDevicesStatusByRichFind(body, responsePutter = null, options = {}){

	it('post query devices status by rich find', async () => {
		let url = `${hubDict['richFindUrl']}?${options.criteria}`;
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	getDevicesStatus,
	getDevicesStatusByRichFind,
	postDevicesStatusByRichFind
};