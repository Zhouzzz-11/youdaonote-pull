'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = new getHttpClient();
const { iotDict } = require('../test-data/requireData');
const { getHeadersWithBearer } = require('../test-data/util');
const { saveToken } = require('../test-data/data/adeployer/getToken');
const { superUserToken } = require('../test-data/data/tasks/iotworks/source/GYPT24109');

/*
    POST  /external-data-sources
 */
function postExternalDataSource(body, responsePutter = null, idPutter = null) {

	it(`post create an external data source`, async () => {
		let url = iotDict['externalDataSource'];
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.post(url, { json: body, headers: headers });
		putData(responsePutter, response);
		if (JSON.parse(response.body)['code'] === 200){
			const id = JSON.parse(response.body)['body']['id'];
			putData(idPutter, id);
		}
	});
}

/*
    GET  /external-data-sources
 */
function getExternalDataSource(responsePutter = null, options = {}) {

	it(`get query an external data source by page`, async () => {
		let url = iotDict['externalDataSource'];
		if (options.criteria){
			url = `${url}?${options.criteria}`;
		}
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.get(url, { headers: headers });
		putData(responsePutter, response);
	});
}

/*
    GET  /external-data-sources/{id}
 */
function getExternalDataSourceById(id, responsePutter = null) {

	it(`get query an external data source by id`, async () => {
		let url = iotDict['externalDataSource'];
		url = `${url}/${getData(id)}`;
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.get(url, { headers: headers });
		putData(responsePutter, response);
	});
}

/*
    PUT  /external-data-sources/{id}
 */
function putExternalDataSourceById(id, body, responsePutter = null) {

	it(`put update external data source by id`, async () => {
		let url = iotDict['externalDataSource'];
		url = `${url}/${getData(id)}`;
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.put(url, { json: body, headers: headers });
		putData(responsePutter, response);
	});
}

/*
    DELETE  /external-data-sources/{id}
 */
function deleteExternalDataSourceById(id, responsePutter = null) {

	it(`put update external data source by id`, async () => {
		let url = iotDict['externalDataSource'];
		url = `${url}/${getData(id)}`;
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.delete(url, { headers: headers });
		putData(responsePutter, response);
	});
}

/*
    GET  /external-data-sources/{id}/tables
 */
function getTableExternalDataSourceById(id, responsePutter = null, tablePutter = null) {

	it(`get query an external data source by id`, async () => {
		let url = iotDict['externalDataSource'];
		url = `${url}/${getData(id)}/tables`;
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.get(url, { headers: headers });
		putData(responsePutter, response);
		if (JSON.parse(response.body)['code'] === 200){
			const tableNames = JSON.parse(response.body)['body'];
			putData(tablePutter, tableNames[0]);
		}
	});
}

/*
    GET  /external-data-sources/{id}/tables/{table}/schemas
 */
function getTableSchemaById(id, table, responsePutter = null) {

	it(`get query an external data source by id and tableName`, async () => {
		let url = iotDict['externalDataSource'];
		url = `${url}/${getData(id)}/tables/${getData(table)}/schemas`;
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.get(url, { headers: headers });
		putData(responsePutter, response);
	});
}

/*
    POST  /external-data-sources/connections/validations
 */
function postValidationConnections(body, responsePutter = null) {

	it(`post connectivity of data source instances`, async () => {
		let url = iotDict['externalDataSource'];
		url = `${url}/connections/validations`;
		const headers = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.post(url, { json: body, headers: headers });
		putData(responsePutter, response);
	});
}

module.exports = {
	postExternalDataSource,
	getExternalDataSource,
	getExternalDataSourceById,
	putExternalDataSourceById,
	deleteExternalDataSourceById,
	getTableExternalDataSourceById,
	getTableSchemaById,
	postValidationConnections
};