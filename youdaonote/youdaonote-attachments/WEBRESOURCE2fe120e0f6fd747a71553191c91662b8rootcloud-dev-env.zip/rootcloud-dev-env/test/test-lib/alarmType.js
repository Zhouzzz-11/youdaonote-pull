'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = new getHttpClient();
const { header, openApiDict, hubDict } = require('../test-data/requireData');

/*
	POST /alarm/categories
 */
function createAlarmCategories(body, responsePutter = null, idPutter = null) {

	it(`Create alarm categories`, async () => {
		let url = openApiDict['alarmCategories'];
		const response = await httpClient.post(url, { json: body, headers: header });

		putData(responsePutter, response);
		const cid = JSON.parse(response.body)['payload']['cid'];
		putData(idPutter, cid);
	});
}
/*
	post /alarm/severities
 */
function createAlarmSeverities(body, responsePutter = null, idPutter = null) {

	it(`Create alarm severities`, async () => {
		let url = openApiDict['alarmSeverities'];
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
		const level = Object.prototype.hasOwnProperty.call(response.body, 'payload') ? JSON.parse(response.body)['payload']['level'] : body.level;
		putData(idPutter, level);
	});
}
/*
	POST /draft/alarm/types
 */
function createAlarmType(body, responsePutter = null, idPutter = null) {

	it(`Create alarm type`, async () => {
		let url = hubDict['alarmTypeUrl'];
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
		if (JSON.parse(response.body)['message'] == null) {
			const id = JSON.parse(response.body)['payload']['alarmTypeId'];
			putData(idPutter, id);
		}
	});
}

/*
	PUT /draft/alarm/types/{alarmTypeId}
 */
function updateAlarmType(body, idGetter, responsePutter = null) {

	it(`Update alarm type`, async () => {
		let url = hubDict['alarmTypeUrl'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	GET /draft/alarm/alarm-types
 */
function getAlarmTypes(responsePutter = null, options = {}) {

	it(`Get alarm type`, async () => {
		let url = hubDict['alarmTypeUrl'];
		if (options.modelId) {
			url = url + `?logicalInterfaceId=${options.modelId}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	GET /alarm/alarm-types/{alarmTypeId}
 */
function getAlarmType(idGetter, responsePutter = null) {

	it(`Get alarm type`, async () => {
		let url = openApiDict['alarmTypes'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	POST /draft/alarm/models/{modelId} /按模型id批量增加报警定义
 */
function createBulkAlarmType(idGetter, body, responsePutter = null, options = {}) {

	it(`create Bulk Alarm Type`, async () => {
		const modelId = getData(idGetter);
		let url = `${hubDict['alarmModelUrl']}/${modelId}`;
		if (options != null) {
			url = `${url}?${options.criteria}`;
		}
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	DELETE /draft/alarm/models/{modelId} /按模型id批量删除报警定义
 */
function deleteBulkAlarmType(idGetter, responsePutter = null) {

	it(`Delete bulk alarm type`, async () => {
		let url = hubDict['alarmModelUrl'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	DELETE /draft/alarm/types/{alarmTypeId}
 */
function deleteAlarmType(idGetter, responsePutter = null) {

	it(`Delete alarm type`, async () => {
		let url = hubDict['alarmTypeUrl'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	DELETE /alarm/severities/{level}
 */
function deleteAlarmSeverities(idGetter, responsePutter = null) {

	it(`Delete alarm severities`, async () => {
		let url = openApiDict['alarmSeverities'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	DELETE /alarm/categories/{cid}
 */
function deleteAlarmCategories(idGetter, responsePutter = null) {

	it(`Delete alarm categories`, async () => {
		let url = openApiDict['alarmCategories'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	DELETE /draft/alarm/models/{modelId}
 */
function deleteAlarmTypeByModeId(modelId, responsePutter = null, options = {}) {

	it(`Delete alarm type`, async () => {
		let url = hubDict['alarmModelUrl'];
		url = `${url}/${modelId}`;
		if (options.alarmTypeIds) {
			url = url + `?alarmTypeIds=` + JSON.stringify(options.alarmTypeIds);
		}
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	POST /draft/rules
 */
function postRules(body, responsePutter = null, idPutter = null) {

	it(`Create alarm rules`, async () => {
		let url = hubDict['draftRule'];
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
		if (JSON.parse(response.body)['message'] == null) {
			const ruleId = JSON.parse(response.body)['payload']['ruleId'];
			putData(idPutter, ruleId);
		}
	});
}

/*
	PUT /draft/rules/{ruleId}
 */
function putAlarmRules(body, idGetter, responsePutter = null) {

	it(`Update alarm rules`, async () => {
		let url = hubDict['draftRule'];
		url = `${url}/${getData(idGetter)}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	createAlarmCategories,
	createAlarmSeverities,
	createAlarmType,
	createBulkAlarmType,
	deleteBulkAlarmType,
	deleteAlarmType,
	deleteAlarmSeverities,
	deleteAlarmCategories,
	deleteAlarmTypeByModeId,
	updateAlarmType,
	getAlarmType,
	getAlarmTypes,
	postRules,
	putAlarmRules
};