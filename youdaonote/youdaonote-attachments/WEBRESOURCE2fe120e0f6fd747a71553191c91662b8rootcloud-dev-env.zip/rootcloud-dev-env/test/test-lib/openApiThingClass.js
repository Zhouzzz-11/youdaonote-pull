'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, openApiDict } = require('../test-data/requireData');
const { saveToken } = require('../test-data/data/adeployer/getToken');
const { getHeadersWithBearer } = require('../test-data/util');

const httpClient = getHttpClient();

/*
	Get /thing/thing-classes
 */
function getThingClass(responsePutter = null, options = {}) {


	it('Get thing class and store response', async () => {
		let url = `${openApiDict['thingClasses']}`;
		if (options.queryString) {
			url = `${url}?${options.queryString}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/thing-classes/{modelId}
 */
function getThingClassByModelID(idGetter, responsePutter = null) {

	it('Get thing class by model id', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['thingClasses']}/${modelId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Patch /thing/thing-classes/{modelId}
 */
function patchThingClassByModelID(idGetter, responsePutter = null, options = {}) {

	it('patch thing class by model id', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(idGetter);
		const url = `${openApiDict['thingClasses']}/${modelId}`;
		const response = await httpClient.patch(url, { headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Get  /thing/draft/thing-classes
 */
function getDraftThingClass(responsePutter = null, options = {}) {

	it('get draft thing class', async () => {
		let url = `${openApiDict['draftThingClasses']}`;
		if (options.queryString) {
			url = `${url}?${options.queryString}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Post  /thing/draft/thing-classes
 */
function postDraftThingClass(body, responsePutter = null, options = {}) {

	it('post draft thing class', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		if (options.headers) {
			_header = options.headers;
		}
		const response = await httpClient.post(openApiDict['draftThingClasses'], { json: body, headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Get  /thing/draft/thing-classes/{modelId}
 */
function getDraftThingClassByModelID(idGetter, responsePutter = null) {

	it('get draft thing class by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put  /thing/draft/thing-classes/{modelId}
 */
function putDraftThingClassByModelID(idGetter, body, responsePutter = null) {

	it('put draft thing class by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Delete  /thing/draft/thing-classes/{modelId}
 */
function deleteDraftThingClassByModelID(idGetter, responsePutter = null, options = {}) {

	it('delete draft thing class by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}`;
		const response = await httpClient.delete(url, { headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Patch  /thing/draft/thing-classes/{modelId}
 */
function patchDraftThingClassByModelID(idGetter, responsePutter = null, options = {}) {

	it('patch draft thing class by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}`;
		const response = await httpClient.patch(url, { headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Get  /thing/draft/thing-classes/{modelId}/properties
 */
function getDraftThingClassPropertiesByModelID(idGetter, responsePutter = null) {

	it('get draft thing class properties by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}/properties`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get  /thing/thing-classes/{modelId}/properties
 */
function getThingClassPropertiesByModelID(idGetter, responsePutter = null) {

	it('get thing class properties by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['thingClasses']}/${modelId}/properties`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put  /thing/draft/thing-classes/{modelId}/properties
 */
function putDraftThingClassPropertiesByModelID(idGetter, body, responsePutter = null) {

	it('put draft thing class properties by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}/properties`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Post  /thing/draft/thing-classes/{modelId}/properties
 */
function postDraftThingClassPropertiesByModelID(modelId, body, responsePutter = null, options = {}) {

	it('post draft thing class properties by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		let url = `${openApiDict['draftThingClasses']}/${modelId}/properties`;
		if (options.partialAdd) {
			url = `${url}?partialAdd=${options.partialAdd}`;
			if (options.forceUpdate) {
				url = `${url}&forceUpdate=${options.forceUpdate}`;
			}
		}
		else if (options.forceUpdate) {
			url = `${url}?forceUpdate=${options.forceUpdate}`;
		}
		const response = await httpClient.post(url, { json: body, headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Delete  /thing/draft/thing-classes/{modelId}/properties
 */
function deleteDraftThingClassPropertiesByModelID(idGetter, body, responsePutter = null) {

	it('delete draft thing class properties by model ID', async () => {
		const modelId = getData(idGetter);
		body = [
			{
				'name': `${body}`
			}
		];
		const url = `${openApiDict['draftThingClasses']}/${modelId}/properties`;
		const response = await httpClient.delete(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Delete  /thing/draft/thing-classes/{modelId}/all-properties
 */
function deleteAllDraftThingClassPropertiesByModelID(idGetter, responsePutter = null) {

	it('delete all draft thing class properties by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingClasses']}/${modelId}/all-properties`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}


module.exports = {
	getThingClass,
	getThingClassByModelID,
	patchThingClassByModelID,
	getDraftThingClass,
	postDraftThingClass,
	getDraftThingClassByModelID,
	putDraftThingClassByModelID,
	deleteDraftThingClassByModelID,
	patchDraftThingClassByModelID,
	getDraftThingClassPropertiesByModelID,
	getThingClassPropertiesByModelID,
	putDraftThingClassPropertiesByModelID,
	postDraftThingClassPropertiesByModelID,
	deleteDraftThingClassPropertiesByModelID,
	deleteAllDraftThingClassPropertiesByModelID,
};
