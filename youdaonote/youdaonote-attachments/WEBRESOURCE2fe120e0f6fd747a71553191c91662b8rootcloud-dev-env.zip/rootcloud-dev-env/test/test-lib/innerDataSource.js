'use strict';

const { putData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = new getHttpClient();
const { iotDict } = require('../test-data/requireData');
const { saveToken } = require('../test-data/data/adeployer/getToken');
const { getHeadersWithBearer } = require('../test-data/util');
const { superUserToken } = require('../test-data/data/tasks/iotworks/source/GYPT24109');

/*
    GET  /inner-data-sources/list-inner-datasources
 */
function getInnerDataSource(responsePutter = null, options = {}) {

	it(`get list inner data sources`, async () => {
		let url = iotDict['innerDataSource'];
		if (options.criteria){
			url = `${url}?${options.criteria}`;
		}
		const header = getHeadersWithBearer(saveToken[superUserToken]);
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	getInnerDataSource,
};