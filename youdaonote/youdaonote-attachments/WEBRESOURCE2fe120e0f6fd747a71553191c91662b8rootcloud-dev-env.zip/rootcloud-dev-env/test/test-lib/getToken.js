'use strict';

const {putData, getData} = require('@rootcloud/darjeeling/dist/src/data-store');
const {getHttpClient} = require('@rootcloud/darjeeling-http');
const {header} = require('../test-data/data/adeployer/getToken');
const {identityDict, headerDict} = require('../test-data/requireData');
const {getHeadersWithBearer} = require('../test-data/util');
const {saveToken} = require('../test-data/data/adeployer/getToken');

const httpClient = getHttpClient();
const loginUrl = identityDict['login'];
const companyUrl = identityDict['company'];
const userUrl = identityDict['user'];
const serviceLicenseUrl = identityDict['servcieLicense'];

function loginUser(body, responsePutter = null, tokenPutter = null) {

	it('login user', async () => {
		const response = await httpClient.post(loginUrl, {json: body});
		putData(responsePutter, response);
		const token = JSON.parse(response.body)['access_token'];
		putData(tokenPutter, token);
	});
}

function loginTenantUser(userList, tenantKey) {

	it('login tenant user', async () => {
		for (let i in userList) {
			const response = await httpClient.post(loginUrl, {json: userList[i]})
			const token = JSON.parse(response.body)['access_token'];
			const id = tenantKey[i];
			headerDict[id].Authorization = `Bearer ${token}`;
		}
	});
}

function postCompany(companyList, tokenGetter, responsePutter = null) {

	it('post company', async () => {
		const token = getData(tokenGetter);
		header.Authorization = `Bearer ${token}`;
		for (let i in companyList) {
			const response = await httpClient.post(companyUrl, {json: companyList[i].companyBody, headers: header});
			putData(responsePutter, response);
		}
	});
}

function postServiceLicense(serviceList, tokenGetter, responsePutter = null) {

	it('post service license', async () => {
		const token = getData(tokenGetter);
		header.Authorization = `Bearer ${token}`;
		for (let i in serviceList) {
			const response = await httpClient.post(serviceLicenseUrl, {json: serviceList[i].serviceBody, headers: header});
			putData(responsePutter, response);
		}
	});
}

function getCompanyById(id, tokenGetter, responsePutter = null) {

	it('get company by id', async () => {
		const token = getData(tokenGetter);
		header.Authorization = `Bearer ${token}`;
		const url = `${companyUrl}/${id}`;
		const response = await httpClient.get(url, {headers: header});
		putData(responsePutter, response);
	});
}


function deleteCompany(id, tokenGetter, responsePutter = null) {

	it('delete company', async () => {
		const token = getData(tokenGetter);
		header.Authorization = `Bearer ${token}`;
		const url = `${companyUrl}/${id}`;
		const response = await httpClient.delete(url, {headers: header});
		putData(responsePutter, response);
	});
}

function postUser(body, tokenGetter, responsePutter = null) {

	it('post user', async () => {
		const token = getData(tokenGetter);
		header.Authorization = `Bearer ${token}`;
		const response = await httpClient.post(userUrl, {json: body, headers: header});
		putData(responsePutter, response);
	});
}

function putUserAclGroup(userId, aclGroupIdGetter, responsePutter = null, options = {}) {
	it('put user acl group', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const aclGroupId = getData(aclGroupIdGetter);
		const body = [aclGroupId];
		const url = `${userUrl}/${userId}/acl-groups`;
		const response = await httpClient.put(url, {json: body, headers: _header});
		putData(responsePutter, response);
	});
}

module.exports = {
	loginUser,
	loginTenantUser,
	postCompany,
	postServiceLicense,
	getCompanyById,
	deleteCompany,
	postUser,
	putUserAclGroup
};
