'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = getHttpClient();
const { header, hubDict } = require('../test-data/requireData');
const { retryRequest, itWait } = require('../test-data/util');
const { Response } = require('@rootcloud/darjeeling-http');
const { log4js } = require('./logger');
const logger = log4js.getLogger('loggerApi');

/*
	POST  /thing/instruction-requests
 */
function postInstructionRequests(body, responsePutter = null, requestId = null) {
	itWait(10);
	it('post give instructions', async () => {
		const response = await httpClient.post(hubDict['instructionRequests'], { json: body, headers: header });
		putData(responsePutter, response);
		logger.info(JSON.parse(response.body));
		if (Object.prototype.hasOwnProperty.call(JSON.parse(response.body), 'payload')) {
			const msgId = JSON.parse(response.body)['payload']['msgId'];
			putData(requestId, msgId);
		}
	});
}

/*
	GET  /thing/instruction-requests
 */
function getInstructionRequests(responsePutter = null, options = {}) {

	it('get historical equipment response results', async () => {
		let url = `${hubDict['instructionRequests']}`;
		if (options.queryString) {
			url = `${url}?${options.queryString}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			logger.info('checking shouldRetry');
			const body = Response.getJsonBody(response);
			if (body.payload.status !== options.status) {
				logger.info(`retry: response status is: ${body.payload.status}`);
				return true;
			}
			return false;
		});
		logger.info('if you reading this, it must be successfull');
		
		putData(responsePutter, response);
	});
}

/*
	GET   /thing/instruction-requests/{requestId}
 */
function getInstructionRequestsByRequestId1(requestId, responsePutter = null, options = {}) {

	it('get the execution of commands on a target device', async () => {
		const url = `${hubDict['instructionRequests']}/${getData(requestId)}`;
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			logger.info('checking shouldRetry');
			const body = Response.getJsonBody(response);
			if (body.payload.status !== options.status) {
				logger.info(`retry: response status is: ${body.payload.status}`);
				return true;
			}
			return false;
		});

		logger.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

function getInstructionRequestsByRequestId2(requestId, clientGetter, topic, message, responsePutter = null, options = {}) {

	it('get the execution of commands on a target device', async () => {
		const url = `${hubDict['instructionRequests']}/${getData(requestId)}`;
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			logger.info('checking shouldRetry');
			const body = Response.getJsonBody(response);
			if (body.payload.status !== options.status) {
				logger.info(`retry: response status is: ${body.payload.status}`);
				logger.info('Send device data to MQTT');
				const msgToPublish = JSON.stringify(message);
				const client = getData(clientGetter);
				client.publish(topic, msgToPublish, {}, (err) => {
					if (!err) {
						logger.info('MQTT message sent');
					}
					else {
						logger.info('err: ' + err);
					}
				});
				return true;
			}
			return false;
		});
		logger.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

module.exports = {
	postInstructionRequests,
	getInstructionRequests,
	getInstructionRequestsByRequestId1,
	getInstructionRequestsByRequestId2
};
