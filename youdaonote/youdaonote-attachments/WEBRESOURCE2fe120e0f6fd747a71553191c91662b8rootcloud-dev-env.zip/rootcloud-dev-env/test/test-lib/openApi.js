'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, openApiDict, hubDict } = require('../test-data/requireData');
const { saveToken } = require('../test-data/data/adeployer/getToken');
const { getHeadersWithBearer } = require('../test-data/util');
const { loggerApi } = require('./logger');
const httpClient = getHttpClient();

/*
        Post /device/device-instances/bulk-add
 */
function postBulkAddDeviceInstances(body, responsePutter = null, responsePutter1 = null) {

	it('Post bulk add device instances', async () => {
		let start = new Date().getTime();
		const response = await httpClient.post(openApiDict['deviceBulkAdd'], { json: body, headers: header });
		let end = new Date().getTime();
		const time = end - start;
		putData(responsePutter, response);
		putData(responsePutter1, time);
	});
}

/*
	Post /device/device-instances/bulk-remove
 */
function postBulkRemoveDeviceInstances(body, responsePutter = null) {

	it('Post bulk remove device instances', async () => {
		const response = await httpClient.post(openApiDict['deviceBulkRemove'], { json: body, headers: header });
		putData(responsePutter, response);
	});
}


/*
	Get /device/device-instances
 */
function getDeviceInstances(responsePutter = null, options = {}) {

	it('Get device instances', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		let _url = openApiDict['deviceInstances'];
		if (options.queryString) {
			_url = `${_url}/${options.queryString}`;
		}
		const response = await httpClient.get(_url, { headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Get /allarm/alarm-types
 */
function getAlarmTypes(url, responsePutter = null) {

	it('get alarm types', async () => {
		const response = await httpClient.get(openApiDict['alarmTypes'], { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /alarm/alarm-types/{alarmTypeId}
 */
function getAlarmTypesById(idGetter, responsePutter = null) {

	it('get alarm types by id', async () => {
		const alarmTypeId = getData(idGetter);
		const url = `${openApiDict['alarmTypes']}/${alarmTypeId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /alarm/severities
 */
function getAlarmSeverities(responsePutter = null) {

	it('get alarm severities', async () => {
		const response = await httpClient.get(openApiDict['alarmSeverities'], { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /alarm/severities/{level}
 */
function getAlarmSeveritiesByLevel(levelGetter, responsePutter = null) {

	it('get alarm severities by level', async () => {
		const level = getData(levelGetter);
		const url = `${openApiDict['alarmSeverities']}/${level}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /alarm/categories/{cid}
 */
function getAlarmCategoriesByCid(cidGetter, responsePutter = null) {

	it('get alarm categories by cid', async () => {
		const cid = getData(cidGetter);
		const url = `${openApiDict['alarmCategories']}/${cid}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /alarm/categories
 */
function getAlarmCategories(responsePutter = null) {

	it('get alarm categories', async () => {
		const response = await httpClient.get(openApiDict['alarmCategories'], { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put /device/device-types/{deviceTypeId}/devices/{deviceId}/locations
 */
function putLocationByDeviceTypeIdAndDeviceId(deviceTypeIdGetter, deviceIdGetter, body, responsePutter = null) {

	it('put location by device type id and device id', async () => {
		const deviceTypeId = getData(deviceTypeIdGetter);
		const deviceId = getData(deviceIdGetter);
		const url = `${openApiDict['deviceTypes']}/${deviceTypeId}/devices/${deviceId}/locations`;
		const response = await httpClient.put(url, { json: body, headers: header } );
		putData(responsePutter, response);
	});
}

/*
	Get /device/device-instances/status
 */
function getDeviceInstanceStatus(responsePutter = null) {

	it('get device instance status', async () => {
		const response = await httpClient.get(openApiDict['deviceStatus'], { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /device/device-instances/status/count
 */
function getDeviceInstanceStatusCount(responsePutter = null) {

	it('get device instance status count', async () => {
		const response = await httpClient.get(openApiDict['deviceStatusCount'], { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /acl-groups
 */
function getAclGroups(aclGroupIdGetter, responsePutter = null, options = {}) {

	it('get acl groups', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		let url = openApiDict['aclGroups'];
		const aclGroupId = getData(aclGroupIdGetter);
		const s = `["${aclGroupId}"]`;
		url = `${url}?groupIds=${s}`;
		const response = await httpClient.get(url, { headers: _header });
		putData(responsePutter, response);
	});
}

/*  
	Put /acl-groups
 */
function putAclGroups(body, aclGroupIdGetter, responsePutter = null, options = {}) {

	it('put acl groups', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const aclGroupId = getData(aclGroupIdGetter);
		body.groupId = aclGroupId;
		const response = await httpClient.put(openApiDict['aclGroups'], { json: body, headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Post /acl-groups
 */
function postAclGroups(body, responsePutter = null, idPutter = null, options = {}) {

	it('post acl groups', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const response = await httpClient.post(openApiDict['aclGroups'], { json: body, headers: _header });
		putData(responsePutter, response);
		const aclGroupId = JSON.parse(response.body)['payload'];
		putData(idPutter, aclGroupId);
	});
}
/*
        Post /acl-groups
 */
function postAclGroups1(body, _id, responsePutter = null, idPutter = null, options = {noDownStream:false, noTemplate:false, wrongTemplateId:false}) {
	it('post acl groups', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const id = getData(_id);
		body.modelAclDefinitions[1].modelAcl.modelFilter[0].expression = `{"_id":{"$in":["${id}"]}}`;
		body.modelAclDefinitions[0].modelAcl.accessDefinition.accessRight.DeviceDownstream[0].field = `${id}`;
		if(options.noDownStream){
			body.modelAclDefinitions[0].modelAcl.accessDefinition.accessRight.DeviceDownstream = [];
		}
		if(options.wrongTemplateId){
			body.modelAclDefinitions[0].modelAcl.accessDefinition.accessRight.DeviceDownstream[0].field = 'notExisted';
		}
		if(options.noTemplate) {
			body = {
				name: 'only-see-userName',
				modelAclDefinitions: [body.modelAclDefinitions[0]]
			};
		}
		const response = await httpClient.post(openApiDict['aclGroups'], { json: body, headers: _header });
		putData(responsePutter, response);
		const aclGroupId = JSON.parse(response.body)['payload'];
		putData(idPutter, aclGroupId);
	});
}

/*
	Delete /acl-groups
 */
function deleteAclGroups(groupIdGetter, responsePutter = null, options = {}) {

	it('delete acl groups', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		var aclGroupId = getData(groupIdGetter);
		const body = {
			'list': [
				`${aclGroupId}`
			]
		};
		const response = await httpClient.delete(openApiDict['aclGroups'], { json: body, headers: _header });
		putData(responsePutter, response);
	});
}


/*
	Get /acl-groups/{groupId}
 */
function getAclGroupsByGroupId(groupIdGetter, responsePutter = null, options = {}) {

	it('get acl groups by group id', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const groupId = getData(groupIdGetter);
		const url = `${openApiDict['aclGroups']}/${groupId}`;
		const response = await httpClient.get(url, { headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Delete /acl-groups/{groupId}
 */
function deleteAclGroupsByGroupId(groupIdGetter, responsePutter = null, options = {}) {

	it('delete acl groups by group id', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const groupId = getData(groupIdGetter);
		const url = `${openApiDict['aclGroups']}/${groupId}`;
		const response = await httpClient.delete(url, { headers: _header });
		putData(responsePutter, response);
	});
}


/*
	Get /files/{fileId}
 */
function getFilesByFileId(fileIdGetter, responsePutter = null) {

	it('get files by file id', async () => {
		const fileId = getData(fileIdGetter);
		const url = `${openApiDict['files']}/${fileId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Delete /files/{fileId}
 */
function deleteFilesByFileId(fileIdGetter, responsePutter = null) {

	it('delete files by file id', async () => {
		const fileId = getData(fileIdGetter);
		const url = `${openApiDict['files']}/${fileId}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /file/{fileId}/md5
 */
function getFileMd5ByFileId(fileIdGetter, responsePutter = null) {

	it('get file md5 by file id', async () => {
		const fileId = getData(fileIdGetter);
		const url = `${openApiDict['file']}/${fileId}/md5`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /files
 */
function getFiles(responsePutter = null) {
	it('get files', async () => {
		const response = await httpClient.get(openApiDict['files'], { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Post /devices/countByState
 */
function postCountDeviceByState(body, responsePutter = null){
	it(' post count device by state ', async () => {
		const url = `${openApiDict['devicesUrl']}/countByState`;
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}


/*
	Post /devices/{state}/countByCity
 */
function postCountDeviceByCity(state, body, responsePutter = null){
	it(' post count device by city ', async () => {
		const url = `${openApiDict['devicesUrl']}/${state}/countByCity`;
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Post /draft/device/types/{deviceTypeId}/properties
 */
function postBulkAddDeviceProperties(deviceTypeId, body, responsePutter = null, responsePutter1 = null, options={'partialAdd':null, 'forceUpdate':null }){
	it('bulk add properties optimization',  async () => {
		let url = `${hubDict['draftDeviceTypesUrl']}/${deviceTypeId}/properties`;
		if(options.partialAdd){
			url = `${url}?partialAdd=${options.partialAdd}`;
			if(options.forceUpdate){
				url = `${url}&forceUpdate=${options.forceUpdate}`;
			}
		}
		else if(options.forceUpdate){
			url = `${url}?forceUpdate=${options.forceUpdate}`;
		}
		let start = new Date().getTime();
		const response = await httpClient.post(url, { json: body, headers: header });
		let end = new Date().getTime();
		const time = end - start;
		putData(responsePutter, response);
		putData(responsePutter1, time);
	});
}

/*
	Delete /draft/device/types/{deviceTypeId}/properties
 */
function BulkDeleteDeviceProperties(deviceTypeId, body, responsePutter = null){
	it('bulk delete properties',  async () => {
		const url = `${hubDict['draftDeviceTypesUrl']}/${deviceTypeId}/properties`;
		loggerApi.log(url);
		const response = await httpClient.delete(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /device-type/tags
*/

function getDeviceTags(deviceTypeId, responsePutter = null){
	it('get active device type tags by deviceTypeId', async () => {
		const url = `${openApiDict['deviceTags']}/tags?deviceTypeId=${deviceTypeId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /device-type/tag-fields
*/

function getDeviceTagfields(deviceTypeId, responsePutter = null){
	it('get active device type tags by deviceTypeId', async () => {
		const url = `${openApiDict['deviceTags']}/tag-fields?deviceTypeId=${deviceTypeId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}









module.exports = {
	postBulkAddDeviceInstances,
	postBulkRemoveDeviceInstances,
	getDeviceInstances,
	getAlarmTypes,
	getAlarmTypesById,
	getAlarmSeverities,
	getAlarmSeveritiesByLevel,
	getAlarmCategoriesByCid,
	getAlarmCategories,
	putLocationByDeviceTypeIdAndDeviceId,
	getDeviceInstanceStatus,
	getDeviceInstanceStatusCount,
	getAclGroups,
	putAclGroups,
	postAclGroups,
	postAclGroups1,
	deleteAclGroups,
	getAclGroupsByGroupId,
	deleteAclGroupsByGroupId,
	getFilesByFileId,
	deleteFilesByFileId,
	getFileMd5ByFileId,
	getFiles,
	postCountDeviceByState,
	postCountDeviceByCity,
	postBulkAddDeviceProperties,
	BulkDeleteDeviceProperties,
	getDeviceTags,
	getDeviceTagfields
};
