'use strict';

const {putData, getData} = require('@rootcloud/darjeeling/dist/src/data-store');
const {getHttpClient} = require('@rootcloud/darjeeling-http');
const {header, openApiDict} = require('../test-data/requireData');
const {saveToken} = require('../test-data/data/adeployer/getToken');
const {getHeadersWithBearer} = require('../test-data/util');

const httpClient = getHttpClient();

/*
	Get /thing/thing-classes/{modelId}/instances
 */
function getThingInstancesByModelId(modelId, responsePutter = null, options = {}) {

	it('Get thing instances by model Id', async () => {
		let url = `${openApiDict['thingClasses']}/${modelId}/instances`;
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		if (options.queryString) {
			url = `${url}/${options.queryString}`;
		}
		const response = await httpClient.get(url, {headers: _header});
		putData(responsePutter, response);
	});
}

/*
	Post /thing/thing-classes/{modelId}/instances
 */
function postThingInstancesByModelId(idGetter, body, responsePutter = null, options = {}) {

	it('Post thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['thingClasses']}/${modelId}/instances`;
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const response = await httpClient.post(url, {json: body, headers: _header});
		putData(responsePutter, response);
	});
}

/*
	Post /thing/thing-instances/bulk-add
 */
function postThingInstancesBulk(body, responsePutter = null, options = {} ) {
	
	it('Post thing instances by model Id', async () => {
		const url = `${openApiDict['thingInstances']}/bulk-add`;
		let _header = header;
		if ( options.header ) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const response = await httpClient.post(url, { json: body, headers: _header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/thing-classes/{modelId}/instances/{thingId}
 */
function getThingInstancesByModelIdAndThingId(modelId, thingId, responsePutter = null, options = {}) {

	it('Get thing instances by model Id and thing Id', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		let url = `${openApiDict['thingClasses']}/${modelId}/instances/${thingId}`;
		const response = await httpClient.get(url, {headers: _header});
		putData(responsePutter, response);
	});
}


/*
	Put /thing/thing-classes/{modelId}/instances/{thingId}
 */
function putThingInstancesByModelIdAndThingId(modelIdGetter, thingIdGetter, body, responsePutter = null, options = {}) {

	it('Put thing instances by model Id and thing Id', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(modelIdGetter);
		const thingId = getData(thingIdGetter);
		const url = `${openApiDict['thingClasses']}/${modelId}/instances/${thingId}`;
		const response = await httpClient.put(url, {json: body, headers: _header});
		putData(responsePutter, response);
	});
}

/*
	Delete /thing/thing-classes/{modelId}/instances/{thingId}
 */
function deleteThingInstancesByModelIdAndThingId(modelIdGetter, thingIdGetter, responsePutter = null, options = {}) {

	it('Delete thing instances by model Id and thing Id', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(modelIdGetter);
		const thingId = getData(thingIdGetter);
		const url = `${openApiDict['thingClasses']}/${modelId}/instances/${thingId}`;
		const response = await httpClient.delete(url, {headers: _header});
		putData(responsePutter, response);
	});
}


/*
	Get /thing/thing-instances
 */
function getThingInstances(responsePutter = null, options = {}) {

	it('Post thing instances by model Id', async () => {
		let url = openApiDict['thingInstances'];
		if (options){
			url = `${url}?${options.criteria}`;
		}
		const response = await httpClient.get(url, {headers: header});
		putData(responsePutter, response);
	});
}


module.exports = {
	getThingInstancesByModelId,
	postThingInstancesByModelId,
	postThingInstancesBulk,
	getThingInstancesByModelIdAndThingId,
	putThingInstancesByModelIdAndThingId,
	deleteThingInstancesByModelIdAndThingId,
	getThingInstances
};
