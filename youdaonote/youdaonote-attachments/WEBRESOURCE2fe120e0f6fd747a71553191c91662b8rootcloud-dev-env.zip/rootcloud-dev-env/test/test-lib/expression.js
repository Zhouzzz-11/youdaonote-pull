'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = getHttpClient();
const { header, hubDict } = require('../test-data/requireData');

// POST  /draft/expressions
function postExpression(body, responsePutter = null, idPutter = null,) {

	it('Creates an expression for a property evaluation or rule', async () => {
		const response = await httpClient.post(hubDict['draftExpression'], { json: body, headers: header });
		putData(responsePutter, response);
		if (Object.prototype.hasOwnProperty.call(JSON.parse(response.body), 'payload')) {
			const expressionId = JSON.parse(response.body)['payload']['expressionId'];
			putData(idPutter, expressionId);
		}
	});
}

// Delete  /draft/expressions/{expressionId}
function deleteExpression(id, responsePutter = null) {
	it('delete expression', async () => {
		const expressionId = getData(id);
		const url = `${hubDict['draftExpression']}/${expressionId}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

// PUT  /draft/expressions/{expressionId}
function putExpression(id, body, responsePutter = null) {
	it('update expression', async () => {
		const expressionId = getData(id);
		const url = `${hubDict['draftExpression']}/${expressionId}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	postExpression,
	deleteExpression,
	putExpression
};
