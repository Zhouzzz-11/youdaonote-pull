'use strict';

const _ = require('lodash');
const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, openApiDict } = require('../test-data/requireData');
const { retryRequest } = require('../test-data/util');
const { loggerApi } = require('./logger');
const httpClient = getHttpClient();

/*
	Get /historian/alarms/query/count
 */
function getAlarmCount(responsePutter = null) {

	it('Get alarm count with query', async () => {
		const url = `${openApiDict['historianAlarm']}/query/count`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put /historian/alarms/close/{alarmId}
 */
function putCloseAlarmById(idGetter, responsePutter = null) {

	it('Put close alarm', async () => {
		const alarmId = getData(idGetter);
		const url = `${openApiDict['historianAlarm']}/close/${alarmId}`;
		const response = await httpClient.put(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /historian/alarms/{alarmId}
 */
function getAlarmById(idGetter, responsePutter = null) {

	it('Get alarm by alarm id', async () => {
		const alarmId = getData(idGetter);
		const url = `${openApiDict['historianAlarm']}/${alarmId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /historian/alarms/query/all
 */
function getAlarmAll(responsePutter = null, options = {}) {

	it('Get all alarm', async () => {
		let url = `${openApiDict['historianAlarm']}/query/all`;
		if (options.criteria){
			url = `${url}?${options.criteria}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header}),(response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if(_.get(JSON.parse(response.body), 'payload.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

/*
	Get /historian/alarms/count/{thingId}/{modelId}
 */
function getAlarmCountByThingId(idGetter, modelIdGetter, responsePutter = null,options = {}) {

	it('Get alarm count by thing id', async () => {
		const thingId = getData(idGetter);
		const modelId = getData(modelIdGetter);
		const url = `${openApiDict['historianAlarm']}/count/${thingId}/${modelId}`;
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload.totalNum', -1) === options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	});
}

/*
	Get /historian/models/{modelId}/things
 */
function getHistorianByModelId(things, idGetter, queryString, responsePutter = null, options = {}) {

	it('Get historian by model id', async () => {
		const modelId = getData(idGetter);
		const str = queryString.substr(1);
		let url = `${openApiDict['historian']}/models/${modelId}/things?things=${things}&${str}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

/*
	Get /historian/models/{modelId}/things/{thingId}/aggregation
 */
function getHistorianAggByModelAndThingId(idGetter, modelIdGetter, responsePutter = null) {

	it('Get historian aggregation by model id', async () => {
		const modelId = getData(modelIdGetter);
		const thingId = getData(idGetter);
		const url = `${openApiDict['historian']}/models/${modelId}/things/${thingId}/aggregation`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /historian/models/{modelId}/things/{thingId}/aggregation
 */
function getHistorianAggByModelAndThingId1(idGetter, modelIdGetter, queryString, properties, aggFunc, timeInterval, responsePutter = null, options = {}) {

	it('Get historian aggregation by model id', async () => {
		const modelId = getData(modelIdGetter);
		const thingId = getData(idGetter);
		let url = `${openApiDict['historian']}/models/${modelId}/things/${thingId}/aggregation${queryString}&properties=${properties}&aggFunc=${aggFunc}&timeInterval=${timeInterval}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}
/*
	Get /historian/models/{modelId}/things/{thingId}
 */
function getHistorianByModelAndThingId(idGetter, modelIdGetter, queryString, responsePutter = null, options = {}) {

	it('Get historian by model id and thing id', async () => {
		const modelId = getData(modelIdGetter);
		const thingId = getData(idGetter);
		let url = `${openApiDict['historian']}/models/${modelId}/things/${thingId}${queryString}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		if (options.coldstoreOnly) {
			url = url + `&bookmark=${options.bookmark}&coldStoreOnly=true`;
			loggerApi.info(`get the cold data url: ${url}`);
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}
/*
	Get /historian/models/{modelId}/things/{thingId}
 */
function getHistorianByModelAndThingId1(idGetter, modelIdGetter, queryString, responsePutter = null, responsePutter1 = null, options = {}) {

	it('Get historian by model id and thing id', async () => {
		const modelId = getData(modelIdGetter);
		const thingId = getData(idGetter);
		let url = `${openApiDict['historian']}/models/${modelId}/things/${thingId}${queryString}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		const bodys = JSON.parse(response.body)['payload'];
		const time=bodys[0].rows[0][0];
		putData(responsePutter1, time);
		putData(responsePutter, response);
	}).timeout(120000);
}
/*
	Get /historian/models/{modelId}/things/aggregation
 */
function getHistorianAggByModel(things, modelIdGetter, queryString, aggProperties, timeInterval, responsePutter = null, options = {}) {

	it('Get historian aggregation by model id', async () => {
		const modelId = getData(modelIdGetter);
		const str = queryString.substr(1);
		let url = `${openApiDict['historian']}/models/${modelId}/aggregation?things=${things}&${str}&aggProperties=${aggProperties}&timeInterval=${timeInterval}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

/*
	Get /realtime/models/{modelId}/things/{thingId}
 */
function getRealTimeByModelAndThingId(idGetter, modelIdGetter, responsePutter = null, options = {}) {

	it('Get realtime by model id and thing id', async () => {
		const thingId = getData(idGetter);
		const modelId = getData(modelIdGetter);
		const url = `${openApiDict['realtime']}/${modelId}/things/${thingId}`;
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header}),(response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			const body = JSON.parse(response.body);
			if((body.payload.length === 0) || (Object.keys(JSON.parse(response.body).payload[0].data).length !== options.expectNum)) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			if (options.name && body.payload[0].data.GYPT17465_realData.value !== options.value){
				loggerApi.info(`retry: response body value is: ${body.payload[0].data.GYPT17465_realData.value}`);
				return true;
			}
			
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}

/*
	Get /realtime/models/{modelId}/things
 */
function getRealTimeByModelId(idGetter, responsePutter = null) {

	it('Get realtime by model id', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['realtime']}/${modelId}/things`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

module.exports = {
	getAlarmCount,
	putCloseAlarmById,
	getAlarmById,
	getAlarmAll,
	getAlarmCountByThingId,
	getHistorianByModelId,
	getHistorianAggByModelAndThingId,
	getHistorianByModelAndThingId,
	getHistorianAggByModel,
	getRealTimeByModelAndThingId,
	getRealTimeByModelId,
	getHistorianAggByModelAndThingId1,
	getHistorianByModelAndThingId1
};