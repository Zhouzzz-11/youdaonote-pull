'use strict';

const _ = require('lodash');
const { putData ,getData} = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = getHttpClient();
const { header,openApiDict } = require('../test-data/requireData');
const { retryRequest } = require('../test-data/util');
const { loggerApi } = require('./logger');

/*
​patch  /historian​/logicaltypes​/{logicaltype-id}​/devices​/{device-id}
 */
function patchHistorianDate( modelId, deviceId,propertiesName,time ,responsePutter = null) {

	it('modify historian date', async () => {
		const body=[{"time": `${getData(time)}`, "deviceId": `${deviceId}`}];
		body[0][`${propertiesName}`]=7;
		let url = `${openApiDict['historian']}/logicaltypes/${modelId}/devices/${deviceId}`;
		const response = await httpClient.patch(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /historian/logicaltypes/{logicaltype-id}/deviceset
 */
function getHistorianDevicesetByModelId( modelIdGetter,devices, queryString, responsePutter = null,responsePutter1 = null, options = {}) {

	it('Get historian deviceset by model id', async () => {
		const modelId = getData(modelIdGetter);
		const str = queryString.substr(1);
		let url = `${openApiDict['historian']}/logicaltypes/${modelId}/deviceset?devices=${devices}&${str}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		const bodys = JSON.parse(response.body)['payload'];
		const time=bodys[0].rows[0][0];
		putData(responsePutter1, time);
		putData(responsePutter, response);
	}).timeout(120000);
}
/*
	patch /historian/logicaltypes/{logicaltype-id}/deviceset
 */
function patchHistorianDevicesetDate( modelId, deviceId, propertiesName, time ,responsePutter = null) {

	it('modify historian date', async () => {
		const body=[{"time": `${getData(time)}`, "deviceId": `${deviceId}`}];
		body[0][`${propertiesName}`]= 8 ;
		let url = `${openApiDict['historian']}/logicaltypes/${modelId}/deviceset`;
		const response = await httpClient.patch(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /historian​/logicaltypes​/{logicaltype-id}​/aggregation
 */
function getHistorianAggByModelId( modelIdGetter, queryString, devices, aggProperties, timeInterval, responsePutter = null, options = {}) {

	it('Get historian aggregation by model id', async () => {
		const modelId = getData(modelIdGetter);
		const str = queryString.substr(1);
		let url = `${openApiDict['historian']}/logicaltypes/${modelId}/aggregation?devices=${devices}&${str}&aggProperties=${aggProperties}&timeInterval=${timeInterval}`;
		if (options.queryString1) {
			url = `${url}&${options.queryString1}`;
		}
		const response = await retryRequest({ retries: 6 }, () => httpClient.get(url, { headers: header }), (response) => {
			loggerApi.info('checking shouldRetry');
			if (response.statusCode === options.retryCode) {
				loggerApi.info(`retry: response status code is: ${response.statusCode}`);
				return true;
			}
			if (_.get(JSON.parse(response.body), 'payload[0].rows.length', -1) !== options.expectNum) {
				loggerApi.info(`retry: response body is: ${response.body}`);
				return true;
			}
			return false;
		});
		loggerApi.info('if you reading this, it must be successfull');
		putData(responsePutter, response);
	}).timeout(120000);
}
module.exports = {
	patchHistorianDate,
	getHistorianDevicesetByModelId,
	patchHistorianDevicesetDate,
	getHistorianAggByModelId
};
