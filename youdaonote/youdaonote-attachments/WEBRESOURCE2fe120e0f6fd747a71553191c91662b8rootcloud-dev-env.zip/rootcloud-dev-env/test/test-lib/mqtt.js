'use strict';

// const Moment = require('moment');
const Mqtt = require('mqtt');
const zlib = require('zlib');
const { valDict } = require('../test-data/requireData');
const { getData, putData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { log4js } = require('./logger');
const logger = log4js.getLogger('util');
const { retryRequest } = require('../test-data/util');

// Get mqtt client before publish or subscribe
function getMqttClient(clientId, responseProcessor = () => { }, responseMessage = null, options = {}) {

	it('Get mqtt client', function (done) {
		const client = Mqtt.connect({
			host: valDict.mqttHost,
			port: 1883,
			username: clientId,
			password: options.password || 'demoToken',
			clientId: clientId,
			protocol: 'mqtt'
		});

		client.on('error', (err) => {
			logger.info(err);
			client.end(true, () => {
				return done(err);
			});
		});

		client.on('offline', () => {
			throw Error('MQTT is offline');
		});

		client.on('connect', async () => {
			logger.info('MQTT client connect');
			await responseProcessor(client);
			return done();
		});

		client.on('message', (topic, message) => {
			logger.info('message is: ' + message);
			logger.info('topic is: ' + topic);
			const message1 = message + '';
			putData(responseMessage, message1);
		});
	});
}

function getSubMessage(resMessage, responsePutter = null, options = {}) {

	it('get subscribe message', async () => {
		const message = await retryRequest({ retries: 6 }, () => getData(resMessage), (message) => {
			logger.info('checking shouldRetry');
			if (options.flag && message === null) {
				logger.info(`retry: message status  is: null`);
				return false;
			} else if(message === null) {
				logger.info(`retry: message status  is: null`);
				return true;
			}
			return false;
		});
		logger.info('if you reading this, it must be successfull');
		putData(responsePutter, message);
	}).timeout(120000);
}

function postDataWithClient(clientGetter, topic, message, gz = false) {
	
	it('Send device data to MQTT', function () {
		const msgToPublish = gz ? zlib.gzipSync(Buffer.from(JSON.stringify(message), 'utf8')) : JSON.stringify(message);
		const client = getData(clientGetter);
		client.publish(topic, msgToPublish, {}, (err) => {
			if (!err) {
				logger.info('MQTT message sent');
			}
			else {
				logger.info('err: ' + err);
			}
		});
	});
}

function subDataWithClient(clientGetter, topic) {

	it('Subscribe device data with MQTT client', function () {
		const client = getData(clientGetter);
		client.subscribe(topic, (err) => {
			if (!err) {
				logger.info('MQTT message subscribe');
			}
			else {
				logger.info('err: ' + err);
			}
		});
	});
}

function closeClient(clientGetter) {

	it('Close MQTT client', function (done) {
		const client = getData(clientGetter);
		client.end(done);
	});
}


module.exports = {
	getMqttClient,
	postDataWithClient,
	subDataWithClient,
	closeClient,
	getSubMessage
};
