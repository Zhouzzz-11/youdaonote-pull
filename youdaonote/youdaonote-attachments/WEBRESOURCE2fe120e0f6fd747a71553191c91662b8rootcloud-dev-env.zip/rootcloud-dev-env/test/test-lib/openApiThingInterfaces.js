'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const { header, openApiDict } = require('../test-data/requireData');

const httpClient = getHttpClient();

/*
	Get /thing/thing-interfaces
 */
function getThingInterfaces(responsePutter = null, options = {}) {
	
	it('Get thing interfaces', async () => {
		let url = openApiDict['thingInterfaces'];
		if (options.modelId != null){
			url = `${url}?modelId=${options.modelId}`;
		}
		else if (options.name){
			url = `${url}?name=${options.name}`;
		}
		else if (options.otherQuery){
			url = `${url}?${options.otherQuery}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/thing-interfaces/{modelId}
 */
function getThingInterfacesByModelId(idGetter, responsePutter = null) {
	
	it('Get thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['thingInterfaces']}/${modelId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Patch /thing/thing-interfaces/{modelId}
 */
function patchThingInterfacesByModelId(idGetter, responsePutter = null) {
	
	it('Patch thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		/*const body = {
			'operation': 'deactivate'
		};*/
		const url = `${openApiDict['thingInterfaces']}/${modelId}`;
		//const response = await httpClient.patch(url, { json: body, headers: header });
		const response = await httpClient.patch(url, {headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/draft/thing-interfaces
 */
function getDraftThingInterfaces(responsePutter = null, options) {

	it('Get draft thing interfaces', async () => {
		let url = openApiDict['draftThingInterfaces'];
		if(options.modelId != null){
			url = `${url}/?modelId=${options.modelId}`;
		}
		if (options.name){
			url = `${url}?name=${options.name}`;
		}
		if (options.otherQuery){
			url = `${url}?${options.otherQuery}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Post /thing/draft/thing-interfaces
 */
function postDraftThingInterfaces(body, responsePutter = null, options = {}) {
	
	it('Post draft thing interfaces', async () => {
		const response = await httpClient.post(openApiDict['draftThingInterfaces'], { json: body, headers: options.headers || header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/draft/thing-interfaces/{modelId}
 */
function getDraftThingInterfacesByModelId(idGetter, responsePutter = null) {
	
	it('Get draft thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		let url = `${openApiDict['draftThingInterfaces']}`;
		if (idGetter != null){
			url = `${url}/${modelId}`;
		}
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put /thing/draft/thing-interfaces/{modelId}
 */
function putDraftThingInterfacesByModelId(idGetter, body, responsePutter = null) {
	
	it('Put draft thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Delete /thing/draft/thing-interfaces/{modelId}
 */
function deleteDraftThingInterfacesByModelId(idGetter, responsePutter = null) {
	
	it('Delete draft thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Patch /thing/draft/thing-interfaces/{modelId}
 */
function patchDraftThingInterfacesByModelId(idGetter, responsePutter = null) {
	
	it('Patch draft thing instances by model Id', async () => {
		const modelId = getData(idGetter);
		/*const body = {
			'operation': 'activate'
		};*/
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}`;
		//const response = await httpClient.patch(url, { json: body, headers: header });
		const response = await httpClient.patch(url, {headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/thing-interfaces/{modelId}/implementations/{destModelId}/properties
 */
function getThingInterfacesPropertiesByDestId(modelIdGetter, destModelIdGetter, responsePutter = null) {
	
	it('Get thing instances by model and destModel Id', async () => {
		const modelId = getData(modelIdGetter);
		const destModelId = getData(destModelIdGetter);
		const url = `${openApiDict['thingInterfaces']}/${modelId}/implementations/${destModelId}/properties`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Get /thing/draft/thing-interfaces/{modelId}/implementations/{destModelId}/properties
 */
function getDraftThingInterfacesPropertiesByDestId(modelIdGetter, destModelIdGetter, responsePutter = null) {
	
	it('Get draft thing instances by model and destModel Id', async () => {
		const modelId = getData(modelIdGetter);
		const destModelId = getData(destModelIdGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}/implementations/${destModelId}/properties`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

/*
	Put /thing/draft/thing-interfaces/{modelId}/implementations/{destModelId}/properties
 */
function putDraftThingInterfacesPropertiesByDestId(modelIdGetter, destModelIdGetter, body, responsePutter = null) {
	
	it('Put draft thing instances by model and destModel Id', async () => {
		const modelId = getData(modelIdGetter);
		const destModelId = getData(destModelIdGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}/implementations/${destModelId}/properties`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

/*
	Post /thing/draft/thing-interfaces/{modelId}/implementations/{destModelId}/properties
 */
function postDraftThingInterfacesPropertiesByDestId(modelIdGetter, destModelIdGetter, body, responsePutter = null) {
	
	it('Post draft thing instances by model and destModel Id', async () => {
		const modelId = getData(modelIdGetter);
		const destModelId = getData(destModelIdGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}/implementations/${destModelId}/properties`;
		const response = await httpClient.post(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}


/*
	Delete /thing/draft/thing-interfaces/{modelId}/implementations/{destModelId}/properties
 */
function deleteDraftThingInterfacesPropertiesByDestId(modelIdGetter, destModelIdGetter, body, responsePutter = null) {
	
	it('Delete draft thing instances by model and destModel Id', async () => {
		const modelId = getData(modelIdGetter);
		const destModelId = getData(destModelIdGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}/implementations/${destModelId}/properties`;
		const response = await httpClient.delete(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}


/*
	Delete /thing/draft/thing-interfaces/{modelId}/all-properties
 */
function deleteAllDraftThingInterfacesPropertiesByModelId(modelIdGetter, responsePutter = null) {
	
	it('Delete draft thing instances by model and destModel Id', async () => {
		const modelId = getData(modelIdGetter);
		const url = `${openApiDict['draftThingInterfaces']}/${modelId}/all-properties`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}


module.exports = {
	getThingInterfaces,
	getThingInterfacesByModelId,
	patchThingInterfacesByModelId,
	getDraftThingInterfaces,
	postDraftThingInterfaces,
	getDraftThingInterfacesByModelId,
	putDraftThingInterfacesByModelId,
	deleteDraftThingInterfacesByModelId,
	patchDraftThingInterfacesByModelId,
	getThingInterfacesPropertiesByDestId,
	getDraftThingInterfacesPropertiesByDestId,
	putDraftThingInterfacesPropertiesByDestId,
	postDraftThingInterfacesPropertiesByDestId,
	deleteDraftThingInterfacesPropertiesByDestId,
	deleteAllDraftThingInterfacesPropertiesByModelId
};
