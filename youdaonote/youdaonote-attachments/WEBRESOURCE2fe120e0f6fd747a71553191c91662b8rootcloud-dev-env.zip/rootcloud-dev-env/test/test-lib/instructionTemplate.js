'use strict';

const { putData, getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { getHttpClient } = require('@rootcloud/darjeeling-http');
const httpClient = getHttpClient();
const { header, hubDict } = require('../test-data/requireData');
const { saveToken } = require('../test-data/data/adeployer/getToken');
const { getHeadersWithBearer } = require('../test-data/util');

//post ​/draft​/thing​/thing-models​/{modelId}​/instruction-templates
function postInstructionTemplate(idGetter, body, responsePutter = null, options={}) {

	it('post draft thing class by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(idGetter);
		const url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates`;
		const response = await httpClient.post(url, { json: body, headers: _header });
		putData(responsePutter, response);
	});
}

//get 	​/draft​/thing​/thing-models​/{modelId}​/instruction-templates
function getInstructionTemplate(idGetter, responsePutter = null, options = {}) {

	it('get draft thing class by model ID', async () => {
		const modelId = getData(idGetter);
		const url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates?instructionTemplateId=${options.instructionTemplateId}`;
		const response = await httpClient.get(url, { headers: header });
		putData(responsePutter, response);
	});
}

//get 	​/draft​/thing​/thing-models​/{modelId}​/instruction-templates
function getInstructionTemplate_1(modelId, responsePutter = null,idPutter = null, options = {}) {

	it('get draft thing class by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		let url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates`;
		if (options.instructionTemplateId) {
			url = `${url}?instructionTemplateId=${options.instructionTemplateId}`;
		}
		const response = await httpClient.get(url, { headers: _header });
		putData(responsePutter, response);
		const payload = JSON.parse(response.body)['payload'];
		const _id = payload[0].id;
		putData(idPutter, _id);
	});
}


//get  /thing/thing-models/{modelId}/instruction-templates
function getThingInstructionTemplate(modelId, responsePutter = null, options = {}) {

	it('get draft thing class by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const url = `${hubDict['instructionUrl']}/${modelId}/instruction-templates?instructionTemplateId=${options.instructionTemplateId}`;
		const response = await httpClient.get(url, { headers: _header });
		putData(responsePutter, response);
	});
}

//get  /thing/thing-models/{modelId}/instruction-templates
function getThingInstructionTemplate_1(modelId, responsePutter = null,idPutter = null, options = {}) {

	it('get draft thing class by model ID', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		let url = `${hubDict['instructionUrl']}/${modelId}/instruction-templates`;
		if (options.instructionTemplateId) {
			url = `${url}?instructionTemplateId=${options.instructionTemplateId}`;
		}
		const response = await httpClient.get(url, { headers: _header });
		putData(responsePutter, response);
		const payload = JSON.parse(response.body)['payload'];
		const _id = payload[0].id;
		putData(idPutter, _id);
	});
}


// put	​/draft​/thing​/thing-models​/{modelId}​/instruction-templates​/{instructionTemplateId}
function putInstructionTemplate(modelId, instructionTemplateId, body, responsePutter = null) {

	it('put draft thing class by model ID', async () => {
		const url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates/${instructionTemplateId}`;
		const response = await httpClient.put(url, { json: body, headers: header });
		putData(responsePutter, response);
	});
}

// delete	​/draft​/thing​/thing-models​/{modelId}​/instruction-templates​/{instructionTemplateId}
function deleteInstructionTemplate(modelId, idGetter, responsePutter = null) {

	it('delete draft thing class by model ID', async () => {
		const instructionTemplateId = getData(idGetter);
		const url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates/${instructionTemplateId}`;
		const response = await httpClient.delete(url, { headers: header });
		putData(responsePutter, response);
	});
}

// delete	​/draft​/thing​/thing-models​/{modelId}​/instruction-template-batch
function batchDeleteInstructionTemplate(modelId,responsePutter = null, idGetter) {
	const instructionTemplateId = getData(idGetter);
	it('batch delete draft thing class by model ID', async () => {
		const body = {
			'list': instructionTemplateId
		};
		const url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates-batch`;
		const response = await httpClient.delete(url, {json: body, headers: header });
		putData(responsePutter, response);
	});
}

// delete	​/draft​/thing​/thing-models​/{modelId}​/instruction-template-all
function deleteAllInstructionTemplate(modelId, responsePutter = null) {
	it('batch delete draft thing class by model ID', async () => {
		const url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates-all`;
		const response = await httpClient.delete(url, {headers: header });
		putData(responsePutter, response);
	});
}

// batch add	/draft/thing/thing-models/{modelId}/instruction-templates-batch
function batchAddInstructionTemplates(idGetter, body, responsePutter = null, options={}) {

	it('batch add instruction templates', async () => {
		let _header = header;
		if (options.header) {
			_header = getHeadersWithBearer(saveToken[options.userKey]);
		}
		const modelId = getData(idGetter);
		let url = `${hubDict['draftInstructionUrl']}/${modelId}/instruction-templates-batch`;
		if(options.query && options.query.checkDuplicate){
			url = url + '?' + 'checkDuplicate=true';
		}
		const response = await httpClient.post(url, { json: body, headers: _header });
		putData(responsePutter, response);
	});
}

module.exports = {
	postInstructionTemplate,
	getThingInstructionTemplate_1,
	getInstructionTemplate,
	getInstructionTemplate_1,
	deleteInstructionTemplate,
	getThingInstructionTemplate,
	putInstructionTemplate,
	deleteAllInstructionTemplate,
	batchDeleteInstructionTemplate,
	batchAddInstructionTemplates,
};
