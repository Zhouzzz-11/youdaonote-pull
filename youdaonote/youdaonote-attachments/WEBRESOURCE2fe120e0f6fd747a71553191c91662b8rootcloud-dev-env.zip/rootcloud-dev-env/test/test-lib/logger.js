'use strict';

const log4js = require('log4js');
log4js.configure({
	appenders: { console: { type: 'console' } },
	categories: { default: { appenders: ['console'], level: 'info' } }
});
 
const loggerApi = log4js.getLogger('openApi');
const loggerCase = log4js.getLogger('case');
const loggerCommon = log4js.getLogger('common');

module.exports = {
	log4js,
	loggerApi,
	loggerCase,
	loggerCommon
};