// 'use strict';

// const { DataStore, Assert } = require('@rootcloud/darjeeling');
// const { Response } = require('@rootcloud/darjeeling-http');
// const { verifyResponseSchema } = require('../../../../test-verify/verify');
// const { postExternalDataSourcesSchema, getExternalDataSourcesSchema, deleteExternalDataSourcesSchema } = require('../../../../test-data/schema/externalDataSources');
// const { postExternalDataSource, getExternalDataSource, postValidationConnections, getTableSchemaById, getTableExternalDataSourceById, getExternalDataSourceById, putExternalDataSourceById, deleteExternalDataSourceById } = require('../../../../test-lib/externalDataSource');
// const { errorResponseSchema } = require('../../../../test-data/schema/common');
// const { valDict } = require('../../../../test-data/requireData');
// const store = new DataStore();
// const { externalDataSourceData,
// 	externalDataSourceData1,
// 	externalDataSourceData2,
// 	externalDataSourceData3,
// 	externalDataSourceData5,
// 	putExternalDataSourceData,
// 	postValidationConnectionsData,
// 	externalDataSourceData4 } = require('../../../../test-data/data/tasks/iotworks/source/GYPT24109');

// describe('GYPT-24109: define the external data source of iot works', function () {

// 	before(function () {
// 		if (valDict.runEnv === 'local' || valDict.runEnv === 'ci') {
// 			this.skip();
// 		}
// 	});

// 	describe('C2074314: create external data source by _MYSQL_JDBC_URL', function () {
// 		postExternalDataSource(externalDataSourceData.externalDataSourceBody, store.putLater('response'), store.putLater('id'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), postExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dataSourceName', externalDataSourceData.externalDataSourceBody.dataSourceName);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dbType', externalDataSourceData.externalDataSourceBody.dbType);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.jdbcUrl', externalDataSourceData.externalDataSourceBody.jdbcUrl);
// 	});

// 	describe('C1880570: create external data source by MYSQL_HOST_PORT', function () {
// 		postExternalDataSource(externalDataSourceData1.externalDataSourceBody, store.putLater('response'), store.putLater('id1'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), postExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dataSourceName', externalDataSourceData1.externalDataSourceBody.dataSourceName);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dbType', externalDataSourceData1.externalDataSourceBody.dbType);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.host', externalDataSourceData1.externalDataSourceBody.host);
// 	});

// 	describe('C188570: create external data source by MONGO_JDBC_URL', function () {
// 		postExternalDataSource(externalDataSourceData2.externalDataSourceBody, store.putLater('response'), store.putLater('id2'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), postExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dataSourceName', externalDataSourceData2.externalDataSourceBody.dataSourceName);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dbType', externalDataSourceData2.externalDataSourceBody.dbType);
// 		it('verify that the return value is correct', function () {
// 			const body = Response.getJsonBody(store.get('response'));
// 			Assert.isFalse(body.body.params.uri === undefined, 'fields are missing');
// 		});
// 	});

// 	describe('C1849328: create external data source by MONGO_HOST_PORT', function () {
// 		postExternalDataSource(externalDataSourceData3.externalDataSourceBody, store.putLater('response'), store.putLater('id3'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), postExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dataSourceName', externalDataSourceData3.externalDataSourceBody.dataSourceName);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dbType', externalDataSourceData3.externalDataSourceBody.dbType);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.host', externalDataSourceData3.externalDataSourceBody.host);
// 	});

// 	describe('C2074646: create external data source request parameter exception string verification', function () {
// 		postExternalDataSource(externalDataSourceData4.externalDataSourceBody, store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 400);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C2074645: create external data source request the same body to create repeatedly', function () {
// 		postExternalDataSource(externalDataSourceData3.externalDataSourceBody, store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 401);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C2074647: create external data source request parameters to enter a very large string', function () {
// 		postExternalDataSource(externalDataSourceData5.externalDataSourceBody, store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 400);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C1849327: pagination query external data source instance list request parameter default', function () {
// 		getExternalDataSource(store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), getExternalDataSourcesSchema);
// 		it('verify whether the queried data is created', function () {
// 			const body = Response.getJsonBody(store.get('response'));
// 			let flag = 0;
// 			for (var i = 0; i < body.page.result.length; i++) {
// 				if (body.page.result[i].params.dataSourceName === externalDataSourceData.externalDataSourceBody.dataSourceName) {
// 					flag++;
// 				}
// 			}
// 			Assert.strictEqual(1, flag, 'value does not exist');
// 		});
// 	});

// 	describe('C2074649: pagination query external data source instance list page turning parameter verification', function () {
// 		getExternalDataSource(store.putLater('response'), { criteria: 'pageNo=1&pageSize=2' });
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), getExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'page.pageNo', 1);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'page.pageSize', 2);
// 		it('verify the amount of data on the current page', function () {
// 			const body = Response.getJsonBody(store.get('response'));
// 			Assert.strictEqual(2, body.page.result.length, 'the amount of data is inconsistent');
// 		});

// 		getExternalDataSource(store.putLater('response2'), { criteria: 'pageNo=2&pageSize=2' });
// 		Response.statusCodeEquals(store.getLater('response2'), 200);
// 		verifyResponseSchema(store.getLater('response2'), getExternalDataSourcesSchema);
// 		it('verify accessUrl', function () {
// 			const body = Response.getJsonBody(store.get('response'));
// 			const body2 = Response.getJsonBody(store.get('response2'));
// 			Assert.notStrictEqual(body.page.result[0].id, body2.page.result[0].id, 'value does not exist');
// 		});
// 	});

// 	describe('C2074648: pagination query external data source forward and reverse order', function () {

// 		describe('orderType = ASC', function () {
// 			getExternalDataSource(store.putLater('response'), { criteria: 'orderBy=createTime&orderType=ASC' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 			verifyResponseSchema(store.getLater('response'), getExternalDataSourcesSchema);
// 		});

// 		describe('orderType = DESC', function () {
// 			getExternalDataSource(store.putLater('response'), { criteria: 'orderBy=createTime&orderType=DESC' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 			verifyResponseSchema(store.getLater('response'), getExternalDataSourcesSchema);
// 		});

// 		describe('only specify orderType no orderBy', function () {
// 			getExternalDataSource(store.putLater('response'), { criteria: 'orderType=ASC' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 			verifyResponseSchema(store.getLater('response'), getExternalDataSourcesSchema);
// 		});
// 	});

// 	describe('C188573: query external data source instance based on data source ID and ID really exists', function () {
// 		getExternalDataSourceById(store.getLater('id'), store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), postExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dbType', externalDataSourceData.externalDataSourceBody.dbType);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dataSourceName', externalDataSourceData.externalDataSourceBody.dataSourceName);
// 	});

// 	describe('C2074650: query external data source instance based on data source ID nonentity', function () {
// 		getExternalDataSourceById(store.getLater('nonentity'), store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 401);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C1849329: modify the external data source instance according to the data source ID and ID really exists', function () {
// 		putExternalDataSourceById(store.getLater('id1'), putExternalDataSourceData.externalDataSourceBody, store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), postExternalDataSourcesSchema);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dbType', putExternalDataSourceData.externalDataSourceBody.dbType);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'body.params.dataSourceName', putExternalDataSourceData.externalDataSourceBody.dataSourceName);
// 	});

// 	describe('C188574: modify the external data source instance according to the data source ID and ID does not actually exist', function () {
// 		putExternalDataSourceById(store.getLater('nonentity'), putExternalDataSourceData.externalDataSourceBody, store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 401);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C1849331: delete the external data source instance according to the data source ID and ID really exists', function () {
// 		deleteExternalDataSourceById(store.getLater('id1'), store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		verifyResponseSchema(store.getLater('response'), deleteExternalDataSourcesSchema);

// 		describe('check deleted successfully', function () {
// 			getExternalDataSourceById(store.getLater('id1'), store.putLater('response'));
// 			Response.statusCodeEquals(store.getLater('response'), 401);
// 			verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 		});
// 	});

// 	describe('C2074348: delete the external data source instance according to the data source ID and ID does not actually exist', function () {
// 		deleteExternalDataSourceById(store.getLater('nonentity'), store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 401);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C2074349: get the instance database table under the data source the database table exists', function () {
// 		getTableExternalDataSourceById(store.getLater('id'), store.putLater('response'), store.putLater('tableName'));
// 		//Response.statusCodeEquals(store.getLater('response'), 200); 
// 	});

// 	describe('C11849330: get the instance database table under the data source the database table exists', function () {
// 		getTableExternalDataSourceById(store.getLater('nonentity'), store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 401);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C2074350: get the schema_database table of the instance database table really exists', function () {
// 		getTableSchemaById(store.getLater('id'), store.getLater('tableName'), store.putLater('response'));
// 		//Response.statusCodeEquals(store.getLater('response'), 200);
// 	});

// 	describe('C1849332: the schema_database table that obtained the My SQL instance database table does not actually exist', function () {
// 		getTableSchemaById(store.getLater('nonentity'), store.getLater('nonentity'), store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 401);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('C2074351: verify the connectivity of the instances external data source instance', function () {
// 		postValidationConnections(postValidationConnectionsData.externalDataSourceBody, store.putLater('response'));
// 		//Response.statusCodeEquals(store.getLater('response'), 200);
// 		//verifyResponseSchema(store.getLater('response'), deleteExternalDataSourcesSchema);
// 	});

// 	describe('C1849333: verify the connectivity of the instances external data source instance, actual unconnectability', function () {
// 		postValidationConnections(postValidationConnectionsData, store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 400);
// 		verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 	});

// 	describe('clear environmental dependencies', function () {
// 		describe('delete external data source', function () {
// 			deleteExternalDataSourceById(store.getLater('id'), store.putLater('response'));
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 			verifyResponseSchema(store.getLater('response'), deleteExternalDataSourcesSchema);

// 			describe('check deleted successfully', function () {
// 				getExternalDataSourceById(store.getLater('id'), store.putLater('response'));
// 				Response.statusCodeEquals(store.getLater('response'), 401);
// 				verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 			});
// 		});

// 		describe('delete external data source', function () {
// 			deleteExternalDataSourceById(store.getLater('id2'), store.putLater('response'));
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 			verifyResponseSchema(store.getLater('response'), deleteExternalDataSourcesSchema);

// 			describe('check deleted successfully', function () {
// 				getExternalDataSourceById(store.getLater('id2'), store.putLater('response'));
// 				Response.statusCodeEquals(store.getLater('response'), 401);
// 				verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 			});
// 		});

// 		describe('delete external data source', function () {
// 			deleteExternalDataSourceById(store.getLater('id3'), store.putLater('response'));
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 			verifyResponseSchema(store.getLater('response'), deleteExternalDataSourcesSchema);

// 			describe('check deleted successfully', function () {
// 				getExternalDataSourceById(store.getLater('id3'), store.putLater('response'));
// 				Response.statusCodeEquals(store.getLater('response'), 401);
// 				verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 			});
// 		});
// 	});
// });