// 'use strict';

// const { DataStore, Assert } = require('@rootcloud/darjeeling');
// const { Response } = require('@rootcloud/darjeeling-http');
// const { verifyResponseSchema } = require('../../../../test-verify/verify');
// const { getInnerDataSource } = require('../../../../test-lib/innerDataSource');
// const { errorResponseSchema } = require('../../../../test-data/schema/common');
// const { valDict } = require('../../../../test-data/requireData');
// const store = new DataStore();

// describe('GYPT-24102: find IoTWorks internal data source', function () {

// 	before(function () {
// 		if (valDict.runEnv === 'local' || valDict.runEnv === 'ci') {
// 			this.skip();
// 		}
// 	});

// 	describe('C2074313: query iotWorks internal data source', function () {
// 		getInnerDataSource(store.putLater('response'));
// 		Response.statusCodeEquals(store.getLater('response'), 200);
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'page.result[0].type', 'kafka');
// 		it('verify kafkaBroadcastAddress', function () {
// 			const body = Response.getJsonBody(store.get('response'));
// 			let flag = true;
// 			if (!body.page.result[0].kafkaBroadcastAddress) {
// 				flag = false;
// 			}
// 			Assert.isTrue(flag, 'value does not exist');
// 		});
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'page.result[1].type', 'redis');
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'page.result[2].type', 'mongo');
// 		Response.bodyJsonPropertyEquals(store.getLater('response'), 'page.result[3].type', 'influx');
// 		it('verify accessUrl', function () {
// 			const body = Response.getJsonBody(store.get('response'));
// 			let flag = true;
// 			for (var i = 1; i < body.page.result.length; i++) {
// 				if (!body.page.result[i].accessUrl) {
// 					flag = false;
// 				}
// 			}
// 			Assert.isTrue(flag, 'value does not exist');
// 		});
// 	});

// 	describe('C2074592: query iotWorks internal data source,verification of order type verification', function () {

// 		describe('sort by type', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'orderType=ASC' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 		});

// 		describe('sort by type ASC', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'orderType=ASC&orderBy=type' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 		});

// 		describe('sort by type DESC', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'orderType=DESC&orderBy=type' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 		});
// 	});

// 	describe('C2074600: query iotWorks internal data source,验证_pageSize和pageNo', function () {

// 		describe('enter the correct data', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'pageNo=1&pageSize=10' });
// 			Response.statusCodeEquals(store.getLater('response'), 200);
// 		});

// 		describe('enter the error pageNo', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'pageNo=0&pageSize=10' });
// 			Response.statusCodeEquals(store.getLater('response'), 500);
// 			verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 		});

// 		describe('enter the error pageNo is minus', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'pageNo=-1&pageSize=10' });
// 			Response.statusCodeEquals(store.getLater('response'), 500);
// 			verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 		});

// 		describe('enter the error pageSize', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'pageNo=1&pageSize=0' });
// 			Response.statusCodeEquals(store.getLater('response'), 500);
// 			verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 		});

// 		describe('enter the error pageSize is minus', function () {
// 			getInnerDataSource(store.putLater('response'), { criteria: 'pageNo=1&pageSize=-1' });
// 			Response.statusCodeEquals(store.getLater('response'), 400);
// 			verifyResponseSchema(store.getLater('response'), errorResponseSchema);
// 		});
// 	});
// });
