'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { getHistorianSchema } = require('../../../../test-data/schema/historian');
const { num, draftThingClassData, draftThingClassModelPropertiesData, thingClassModelInstanceData, locationData1, thingClassModelInstanceData2, locationData, draftThingClassData1, thingClassModelInstanceData1, draftGatewayClassData } = require('../../../../test-data/data/tasks/historian/upload/GYPT12694');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { getHistorianByModelAndThingId, getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian.js');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { postData } = require('../../../../test-data/util');

const store = new DataStore();

describe('GYPT-12694 : test MQTT4.0 protocol - Device administrators can obtain device location information through the 4.0 protocol', function () {

	describe('start', function () {
		//直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	describe('C188597 : Create a device model and send location information', function () {
		postData(topicDict['location_1.0'], thingClassModelInstanceData.thingId, locationData.locationDataBody);
	});

	describe('C188603 : Interface query validation', function () {
		getHistorianByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, locationData.tsQueryStr, store.putLater('response1'), { retryCode: 404, expectNum: 1 });
		verifySchema(store.getLater('response1'), getHistorianSchema);
		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
		});
	});

	describe('C188600 : The directly connected device sends location information', function () {
		getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response1'), { retryCode: 404, expectNum: num });
		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
		});
	});

	describe('C188601 : A device that is not directly connected sends location information', function () {
		postData(topicDict['location_1.0'], thingClassModelInstanceData2.thingId, locationData1.locationDataBody);

		getRealTimeByModelAndThingId(thingClassModelInstanceData1.thingId, draftThingClassData1.modelId, store.putLater('response'), { retryCode: 404, expectNum: num });
		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response'));
			Assert.deepEqual(thingClassModelInstanceData1.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
		});
	});

	describe('C188602&C188612 : Gateway devices send location information', function () {
		postData(topicDict['location_1.0'], thingClassModelInstanceData2.thingId, locationData.locationDataBody);

		getRealTimeByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, store.putLater('response1'), { retryCode: 404, expectNum: num });
		it('condition property parameter isequals request property', () => {
			const body = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData2.thingId, body.payload[0].thingId, 'Check parmetedata isequals');
		});
	});

	describe('end', function () {
		//直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		//非直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		//网关
		describe('delete gateway device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});
	});
});