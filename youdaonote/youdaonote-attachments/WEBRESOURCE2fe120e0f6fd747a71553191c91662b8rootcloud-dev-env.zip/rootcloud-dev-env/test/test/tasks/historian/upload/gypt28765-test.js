'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { log4js } = require('../../../../test-lib/logger');
const logger = log4js.getLogger('util');
const { draftThingClassData_1,
	draftThingClassData_2,
	draftGatewayClassData,
	draftThingClassData_4,
	draftThingClassData_5,
	draftThingClassData_6,
	draftThingClassData_7,
	draftThingClassData_8,
	thingClassModelInstanceData_4,
	thingClassModelInstanceData_5,
	thingClassModelInstanceData_6,
	thingClassModelInstanceData_7,
	thingClassModelInstanceData_8,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData_1,
	thingGatewayModelInstanceData,
	thingClassModelInstanceData_2,
	msgData_1,
	msgData_2,
	msgData_3,
	msgData_4,
	msgData_5
} = require('../../../../test-data/data/tasks/historian/upload/GYPT28765');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { getRealTimeByModelAndThingId, getHistorianByModelAndThingId } = require('../../../../test-lib/openApiHistorian.js');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { itWait } = require('../../../../test-data/util');
const store = new DataStore();

describe('gypt28765: post device lbs info', function () {

	describe('precondition', function () {
		//直连设备1
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		});

		//直连设备2
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_4.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_4.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_4.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_4.modelId, thingClassModelInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_4.thingInstanceBody);
		});

		//直连设备3
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_5.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_5.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_5.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_5.modelId, thingClassModelInstanceData_5.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_5.thingInstanceBody);
		});

		//直连设备4
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_6.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_6.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_6.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_6.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_6.modelId, thingClassModelInstanceData_6.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_6.thingInstanceBody);
		});

		//直连设备5
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_7.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_7.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_7.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_7.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_7.modelId, thingClassModelInstanceData_7.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_7.thingInstanceBody);
		});

		//直连设备6
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_8.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_8.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_8.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_8.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_8.modelId, thingClassModelInstanceData_8.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_8.thingInstanceBody);
		});

		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post gateway device', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingGatewayModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingGatewayModelInstanceData.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post not directlyLinked device', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	describe('C2248258 : post directlyLinked device with lbs and gps info', function () {

		describe('situation one: same device, post lbs info first, and post gps info subsequently', function () {

			describe('connect mqtt and close it', function () {
				getMqttClient(thingClassModelInstanceData_1.thingId, (client) => {
					store.put('client', client);
				});
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
				closeClient(store.getLater('client'));
			});

			describe('query history location information', function () {
				getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response1'), {
					retryCode: 404,
					expectNum: 7
				});
				it('verify', () => {
					const body1 = Response.getJsonBody(store.get('response1'));
					logger.info(body1);
					logger.info(body1.payload[0].data);
					Assert.deepEqual(thingClassModelInstanceData_1.thingId, body1.payload[0].thingId, 'fail to query the history information');
				});
			});

			describe('post directlyLinked device gps with mqtt1.1 using the same instance', function () {
				describe('connect mqtt and close', function () {
					getMqttClient(thingClassModelInstanceData_1.thingId, (client) => {
						store.put('client', client);
					});
					postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_4.mesBody);
					closeClient(store.getLater('client'));
				});

				describe('query history location information', function () {
					getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response1'), {
						retryCode: 404,
						expectNum: 7,
					});
					it('verify', () => {
						const body1 = Response.getJsonBody(store.get('response1'));
						logger.info(body1);
						logger.info(body1.payload[0].data);
						Assert.deepEqual(thingClassModelInstanceData_1.thingId, body1.payload[0].thingId, 'fail to query the history information');
					});
				});
			});
		});

		describe('situation two: same device, post gps info first, and post lbs info subsequently', function () {

			describe('connect mqtt and close', function () {
				getMqttClient(thingClassModelInstanceData_5.thingId, (client) => {
					store.put('client', client);
				});
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_4.mesBody);
				closeClient(store.getLater('client'));
			});
			describe('query history location information', function () {
				getRealTimeByModelAndThingId(thingClassModelInstanceData_5.thingId, draftThingClassData_5.modelId, store.putLater('response1'), {
					retryCode: 404,
					expectNum: 7
				});
				it('verify', () => {
					const body1 = Response.getJsonBody(store.get('response1'));
					logger.info(body1);
					logger.info(body1.payload[0].data);
					Assert.deepEqual(thingClassModelInstanceData_5.thingId, body1.payload[0].thingId, 'fail to query the history information');
				});
			});

			describe('get mqtt client and close it', function () {
				getMqttClient(thingClassModelInstanceData_5.thingId, (client) => {
					store.put('client', client);
				});
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
				closeClient(store.getLater('client'));

			});

			describe('query history location information', function () {
				getRealTimeByModelAndThingId(thingClassModelInstanceData_5.thingId, draftThingClassData_5.modelId, store.putLater('response1'), {
					retryCode: 404,
					expectNum: 7
				});
				it('verify', () => {
					const body1 = Response.getJsonBody(store.get('response1'));
					logger.info(body1);
					logger.info(body1.payload[0].data);
					Assert.deepEqual(thingClassModelInstanceData_5.thingId, body1.payload[0].thingId, 'fail to query the history information');
				});
			});
		});
	});

	describe('C2248259 : post not directlyLinked device lbs with mqtt1.1', function () {
		getMqttClient(thingGatewayModelInstanceData.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_2.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_2.thingId, draftThingClassData_2.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				logger.info(body1);
				logger.info(body1.payload[0].data);
				Assert.deepEqual(thingClassModelInstanceData_2.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2248261 : post directlyLinked device gps and lbs with mqtt1.1', function () {
		getMqttClient(thingClassModelInstanceData_4.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_3.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_4.thingId, draftThingClassData_4.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				logger.info(body1);
				logger.info(body1.payload[0].data);
				Assert.deepEqual(thingClassModelInstanceData_4.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2248261 : post directlyLinked device lbs and gps with mqtt1.1', function () {
		getMqttClient(thingClassModelInstanceData_6.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_5.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_6.thingId, draftThingClassData_6.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				logger.info(body1);
				logger.info(body1.payload[0].data);
				Assert.deepEqual(thingClassModelInstanceData_6.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2248262 : lbs周期上报（3S频率）稳定性 ', function () {
		getMqttClient(thingClassModelInstanceData_7.thingId, (client) => {
			store.put('client', client);
		});
		for (let i = 0; i < 5; i++) {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
			itWait(3000);
		}

		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData_7.thingId, draftThingClassData_7.modelId, msgData_1.tsQueryStr, store.putLater('response'), {
				retryCode: 404,
				expectNum: 5
			});
			it('Check access is in response', () => {
				Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][0].length == 5, true);
			});
		});
	});

	describe('C2811663: lbs周期上报（5S频率）稳定性 ', function () {
		getMqttClient(thingClassModelInstanceData_8.thingId, (client) => {
			store.put('client', client);
		});
		for (let i = 0; i < 5; i++) {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
			itWait(5000);
		}

		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData_8.thingId, draftThingClassData_8.modelId, msgData_1.tsQueryStr, store.putLater('response2'), {
				retryCode: 404,
				expectNum: 5
			});
			it('Check access is in response', () => {
				Response.bodyJsonEquals(Response.getJsonBody(store.get('response2')).payload[0].rows[0][0].length == 5, true);
			});
		});
	});

	describe('end', function () {
		//直连设备1
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//直连设备4
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_4.modelId, thingClassModelInstanceData_4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//直连设备5
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_5.modelId, thingClassModelInstanceData_5.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//直连设备6
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_6.modelId, thingClassModelInstanceData_6.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_6.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_6.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//直连设备6
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_7.modelId, thingClassModelInstanceData_7.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_7.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_7.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//直连设备8
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_8.modelId, thingClassModelInstanceData_8.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_8.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_8.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		//网关
		describe('delete gateway device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingGatewayModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
