'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassData_1,
	draftThingClassData_2,
	draftGatewayClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData_1,
	thingGatewayModelInstanceData,
	thingClassModelInstanceData_2,
	msgData_1,
	msgData_2,
	msgData_3,
	msgData_4,
	msgData_5,
	msgData_6,
	msgData_7,
	msgData_8
} = require('../../../../test-data/data/tasks/historian/upload/GYPT27218');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian.js');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-27218: new parameter __raw_loc__ is used to post device location information with mqtt ', function () {

	describe('precondition', function () {
		//直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device instance ', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		});

		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post gateway device', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingGatewayModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingGatewayModelInstanceData.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post not directlyLinked device', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	describe('C2190174 : post directlyLinked device location data with mqtt1.1', function () {
		getMqttClient(thingClassModelInstanceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_1.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190175 : post not directlyLinked device location data with mqtt1.1', function () {
		getMqttClient(thingGatewayModelInstanceData.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_2.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_2.thingId, draftThingClassData_2.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_2.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190176 : post directlyLinked device location data with mqtt1.1 with cells information', function () {
		getMqttClient(thingClassModelInstanceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_3.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_1.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190177 : post not directlyLinked device location data with mqtt1.1 with cells information', function () {
		getMqttClient(thingGatewayModelInstanceData.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_4.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_2.thingId, draftThingClassData_2.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_2.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190332 : post directlyLinked device location data with mqtt1.0', function () {
		getMqttClient(thingClassModelInstanceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.0'], msgData_5.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_1.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190333 : post not directlyLinked device location data with mqtt1.0', function () {
		getMqttClient(thingGatewayModelInstanceData.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.0'], msgData_6.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_2.thingId, draftThingClassData_2.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_2.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190334 : post directlyLinked device location data with mqtt1.0 with cells information', function () {
		getMqttClient(thingClassModelInstanceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.0'], msgData_7.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_1.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('C2190335 : post not directlyLinked device location data with mqtt1.0 with cells information', function () {
		getMqttClient(thingGatewayModelInstanceData.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.0'], msgData_8.mesBody);
		closeClient(store.getLater('client'));
		describe('query history location information', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_2.thingId, draftThingClassData_2.modelId, store.putLater('response1'), {
				retryCode: 404,
				expectNum: 7
			});
			it('verify', () => {
				const body1 = Response.getJsonBody(store.get('response1'));
				Assert.deepEqual(thingClassModelInstanceData_2.thingId, body1.payload[0].thingId, 'fail to query the history information');
			});
		});
	});

	describe('end', function () {
		//直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		//网关
		describe('delete gateway device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingGatewayModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
