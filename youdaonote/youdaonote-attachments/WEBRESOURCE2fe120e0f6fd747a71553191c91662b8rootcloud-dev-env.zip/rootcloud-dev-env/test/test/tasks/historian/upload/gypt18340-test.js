'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { getHistorianSchema } = require('../../../../test-data/schema/historian');
const { postData } = require('../../../../test-data/util');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData, draftThingClassPropertiesData, activeData, thingInstanceData, msgData3, msgData, msgData1, msgData2, draftThingClassData1, draftGatewayClassData, thingClassModelInstanceData1, thingClassModelInstanceData2 } = require('../../../../test-data/data/tasks/historian/upload/GYPT18340');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { getHistorianByModelAndThingId, getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload, verifyHistoryResult } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-18340 : test post the compress data', function () {

	describe('start', function () {
		//直连设备
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	describe('C195301 : Verify that the working condition data of the compressed directly connected device can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingInstanceData.thingId, msgData.mesBody, true);
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});
	});

	describe('C195307 : Verify that the working condition data of the compressed non-directly connected device can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData1.mesBody, true);
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData1.thingId, draftThingClassData1.modelId, msgData.tsQueryStr, store.putLater('response1'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response1'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response1'), [[11.0]]);
		});
	});

	describe('C195308 : Verify that the condition data of the compressed gateway device can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData.mesBody, true);
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});
	});

	describe('C195302 : Verify that the compressed condition data can be uploaded to the real-time data', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData.mesBody, true);
		});

		describe('query realtime data with model class id and device id', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			it('verify realtime data', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].thingId === thingClassModelInstanceData2.thingId, 'return data is true');
			});
		});
	});

	describe('C195303 : Verify that the compressed working condition data can be uploaded to check the historical data', function () {
		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1, queryString1: 'limit=1' });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});
	});

	describe('C195304 : Verify that 10 working conditions of compression can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData2, true);
		});

		describe('query realtime data with model class id and device id', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			it('verify realtime data', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].thingId === thingClassModelInstanceData2.thingId, 'return data is true');
			});
		});
	});

	describe('C195305 : Verify that 1000 working conditions of compression can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData3, true);
		});

		describe('query realtime data with model class id and device id', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			it('verify realtime data', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].thingId === thingClassModelInstanceData2.thingId, 'return data is true');
			});
		});
	});

	describe('C1880560 : Verify that compressed directly connected device history data can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingInstanceData.thingId, msgData.mesBody, true);
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});
	});

	describe('C1880561 : Verify that compressed non-directly connected device history data can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData1.mesBody, true);
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData1.thingId, draftThingClassData1.modelId, msgData.tsQueryStr, store.putLater('response1'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response1'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response1'), [[11.0]]);
		});
	});

	describe('C1880562 : Verify that compressed gateway device history data can be uploaded successfully', function () {
		describe('post live compress data with mqtt', function () {
			postData(topicDict['jsongz_live_1.1'], thingClassModelInstanceData2.thingId, msgData.mesBody, true);
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingClassModelInstanceData2.thingId, draftGatewayClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1, queryString1: 'limit=1' });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});
	});

	describe('end', function () {
		//直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('delete gateway device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

});