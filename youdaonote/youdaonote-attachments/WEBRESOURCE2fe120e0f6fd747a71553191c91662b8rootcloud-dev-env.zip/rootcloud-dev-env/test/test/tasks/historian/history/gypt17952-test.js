'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const uuid = require('uuid');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { getHistorianSchema } = require('../../../../test-data/schema/historian');
const { draftThingClassData, draftThingClassModelPropertiesData, thingClassModelInstanceData, msgData, msgData1 } = require('../../../../test-data/data/tasks/historian/history/GYPT17952');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { getHistorianByModelAndThingId, getHistorianAggByModelAndThingId1, getHistorianAggByModel, getHistorianByModelId } = require('../../../../test-lib/openApiHistorian.js');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload} = require('../../../../test-verify/verify');
const { postData } = require('../../../../test-data/util');

const store = new DataStore();

describe('GYPT-17952 : test Historical data pagination processing adds to the Bookmark', function () {

	describe('start', function () {
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});
	});

	describe('post data with mqtt', function () {
		for(var i=0; i<24; i++){
			postData(topicDict['pub_1.1'], thingClassModelInstanceData.thingId, msgData.mesBody);
			postData(topicDict['pub_1.1'], thingClassModelInstanceData.thingId, msgData1.mesBody);
		}
	});

	describe('C194801 : Adds a Bookmark to achieve pagination return data ', function () {
		
		const bookmark = uuid.v1();
		getHistorianByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response1'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response1'), getHistorianSchema);

		getHistorianByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData1.tsQueryStr, store.putLater('response2'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response2'), getHistorianSchema);

		getHistorianByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData1.tsQueryStr, store.putLater('response3'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response3'), getHistorianSchema);

		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
			const body2 = Response.getJsonBody(store.get('response2'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body2.payload[0].thingId, 'Check parmetedata isequals');
			const body3 = Response.getJsonBody(store.get('response3'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body3.payload[0].thingId, 'Check parmetedata isequals');
		});

		it('Check return data is next page data', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			const body2 = Response.getJsonBody(store.get('response2'));
			const body3 = Response.getJsonBody(store.get('response3'));

			let flag=false;
			for(var i=0;i<=body1.payload[0].rows.length;i++) {
				if(body1.payload[0].rows[i][0] !== body2.payload[0].rows[i][0]&&body2.payload[0].rows[i][0] !== body3.payload[0].rows[i][0]){
					return flag=true;
				}
			}
			Assert.isTrue(flag, 'return data is next page data');

		});
	});

	describe('C194802 : Adds a Bookmark to achieve pagination return data ', function () {
		const bookmark = uuid.v1();
		getHistorianAggByModelAndThingId1(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, `["${draftThingClassModelPropertiesData.name}"]`, 'COUNT', '300s', store.putLater('response1'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response1'), getHistorianSchema);

		getHistorianAggByModelAndThingId1(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, `["${draftThingClassModelPropertiesData.name}"]`, 'COUNT', '300s', store.putLater('response2'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response2'), getHistorianSchema);

		getHistorianAggByModelAndThingId1(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, `["${draftThingClassModelPropertiesData.name}"]`, 'COUNT', '300s', store.putLater('response3'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response3'), getHistorianSchema);

		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
			const body2 = Response.getJsonBody(store.get('response2'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body2.payload[0].thingId, 'Check parmetedata isequals');
			const body3 = Response.getJsonBody(store.get('response3'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body3.payload[0].thingId, 'Check parmetedata isequals');
		});

		it('Check return data is next page data', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			const body2 = Response.getJsonBody(store.get('response2'));
			const body3 = Response.getJsonBody(store.get('response3'));

			let flag=false;
			for(var i=0;i<=body1.payload[0].rows.length;i++) {
				if(body1.payload[0].rows[i][0] !== body2.payload[0].rows[i][0]&&body2.payload[0].rows[i][0] !== body3.payload[0].rows[i][0]){
					return flag=true;
				}
			}
			Assert.isTrue(flag, 'return data is next page data');
		});
	});

	describe('C194803 : Adds a Bookmark to achieve pagination return data ', function () {
		const bookmark = uuid.v1();
		getHistorianAggByModel(`["${thingClassModelInstanceData.thingId}"]`, draftThingClassData.modelId, msgData.tsQueryStr, `["count(${draftThingClassModelPropertiesData.name})"]`, '300s', store.putLater('response1'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response1'), getHistorianSchema);

		getHistorianAggByModel(`["${thingClassModelInstanceData.thingId}"]`, draftThingClassData.modelId, msgData.tsQueryStr, `["count(${draftThingClassModelPropertiesData.name})"]`, '300s', store.putLater('response2'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response2'), getHistorianSchema);

		getHistorianAggByModel(`["${thingClassModelInstanceData.thingId}"]`, draftThingClassData.modelId, msgData.tsQueryStr, `["count(${draftThingClassModelPropertiesData.name})"]`, '300s', store.putLater('response3'), { retryCode: 404, expectNum: 2, queryString1: `limit=2&bookmark=${bookmark}` });
		verifySchema(store.getLater('response3'), getHistorianSchema);

		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
			const body2 = Response.getJsonBody(store.get('response2'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body2.payload[0].thingId, 'Check parmetedata isequals');
			const body3 = Response.getJsonBody(store.get('response3'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body3.payload[0].thingId, 'Check parmetedata isequals');
		});

		it('Check return data is next page data', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			const body2 = Response.getJsonBody(store.get('response2'));
			const body3 = Response.getJsonBody(store.get('response3'));

			let flag=false;
			for(var i=0;i<=body1.payload[0].rows.length;i++) {
				if(body1.payload[0].rows[i][0] !== body2.payload[0].rows[i][0]&&body2.payload[0].rows[i][0] !== body3.payload[0].rows[i][0]){
					return flag=true;
				}
			}
			Assert.isTrue(flag, 'return data is next page data');
		});
	});

	describe('C194804 : Adds a Bookmark to achieve pagination return data ', function () {
		const bookmark = uuid.v1();
		getHistorianByModelId(`["${thingClassModelInstanceData.thingId}"]`, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response1'), { retryCode: 404, expectNum: 1, queryString1: `limit=1&bookmark=${bookmark}` });
		verifySchema(store.getLater('response1'), getHistorianSchema);

		getHistorianByModelId(`["${thingClassModelInstanceData.thingId}"]`, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response2'), { retryCode: 404, expectNum: 1, queryString1: `limit=1&bookmark=${bookmark}` });
		verifySchema(store.getLater('response2'), getHistorianSchema);

		getHistorianByModelId(`["${thingClassModelInstanceData.thingId}"]`, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response3'), { retryCode: 404, expectNum: 1, queryString1: `limit=1&bookmark=${bookmark}` });
		verifySchema(store.getLater('response3'), getHistorianSchema);

		it('condition property parameter isequals request property', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body1.payload[0].thingId, 'Check parmetedata isequals');
			const body2 = Response.getJsonBody(store.get('response2'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body2.payload[0].thingId, 'Check parmetedata isequals');
			const body3 = Response.getJsonBody(store.get('response3'));
			Assert.deepEqual(thingClassModelInstanceData.thingId, body3.payload[0].thingId, 'Check parmetedata isequals');
		});

		it('Check return data is next page data', () => {
			const body1 = Response.getJsonBody(store.get('response1'));
			const body2 = Response.getJsonBody(store.get('response2'));
			const body3 = Response.getJsonBody(store.get('response3'));

			let flag=false;
			for(var i=0;i<=body1.payload[0].rows.length;i++) {
				if(body1.payload[0].rows[i][0] !== body2.payload[0].rows[i][0]&&body2.payload[0].rows[i][0] !== body3.payload[0].rows[i][0]){
					return flag=true;
				}
			}
			Assert.isTrue(flag, 'return data is next page data');
		});
	});


	describe('end', function () {
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});
	});

});
