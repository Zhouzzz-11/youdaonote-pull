'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, getThingClassByModelID, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { topicDict } = require('../../../../test-data/requireData');
const { postData } = require('../../../../test-data/util');
const { PropertiesData, ThingClassData_1, postAlarmSeverities, ThingClassData_2, DeviceData_1, DeviceData_2, DeviceData_3, DeviceData_4, postdata, postdata_1, alarmTypeData_1, alarmTypeData_2, current_UTCtime } = require('../../../../test-data/data/tasks/historian/alarm/GYPT22362');
const { getRealTimeByModelAndThingId, getHistorianByModelAndThingId, getAlarmCountByThingId} = require('../../../../test-lib/openApiHistorian');
const { createAlarmType, createAlarmSeverities, deleteAlarmSeverities } = require('../../../../test-lib/alarmType');

describe('GYPT-22362 : basetime can be set to cloudtime or devicetime', function(){

	describe('C1880451 : basetime is cloudtime and devicedata do not have timestamp, so cloudtime is current time and localtime is null', function(){
		createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
		postDraftThingClass(ThingClassData_1.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_1.modelId, PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		createAlarmType(alarmTypeData_1.alarmTypeBody, store.putLater('response'), store.putLater('id'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		patchDraftThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData_1.modelId, DeviceData_1.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], DeviceData_1.thingId, postdata.mesBody);

		getRealTimeByModelAndThingId(DeviceData_1.thingId, ThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		it('timecloud is not null', function(){
			const time_cloud = Response.getJsonBody(store.get('response')).payload[0].data.GYPT22362.timeCloud;
			Response.bodyJsonEquals((time_cloud==null), false);
		});
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData.name}.timeLocal`, null);
	});

	describe('C1880452 : basetime is localtime and devicedata have timestamp, so localtime is ts', function(){
		postDraftThingClass(ThingClassData_2.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		createAlarmType(alarmTypeData_2.alarmTypeBody, store.putLater('response'), store.putLater('id'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		
		patchDraftThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData_2.modelId, DeviceData_2.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], DeviceData_2.thingId, postdata_1.mesBody);

		getRealTimeByModelAndThingId(DeviceData_2.thingId, ThingClassData_2.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData.name}.timeLocal`, current_UTCtime);
	});
    
	describe('C1880453: basetime is localtime and devicedata do not have timestamp, so localtime is null', function(){
		postThingInstancesByModelId(ThingClassData_2.modelId, DeviceData_3.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], DeviceData_3.thingId, postdata.mesBody);

		getRealTimeByModelAndThingId(DeviceData_3.thingId, ThingClassData_2.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData.name}.timeLocal`, null);
	});

	describe('C1880454: basetime is cloudtime and devicedata have timestamp, so cloudtime is current time and localtime is ts', function(){
		postThingInstancesByModelId(ThingClassData_1.modelId, DeviceData_4.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], DeviceData_4.thingId, postdata_1.mesBody);

		getRealTimeByModelAndThingId(DeviceData_4.thingId, ThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		it('timecloud is not null', function(){
			const time_cloud = Response.getJsonBody(store.get('response')).payload[0].data.GYPT22362.timeCloud;
			Response.bodyJsonEquals((time_cloud==null), false);
		});
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData.name}.timeLocal`, current_UTCtime);
	});

	describe('C1880455 : basetime is cloudtime, so history data is correct', function(){
		getHistorianByModelAndThingId(DeviceData_1.thingId, ThingClassData_1.modelId, postdata.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		it('check history data', function(){
			Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][0].length != 0 , true);
			Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][1], '3');
		});
	});
    
	describe('C1880456 : basetime is localtime, so history data is correct', function(){
		getHistorianByModelAndThingId(DeviceData_2.thingId, ThingClassData_2.modelId, postdata_1.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		it('check history data', function(){
			Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][0].length != 0 , true);
			Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][1], '3');
		});
	});
    
	describe('C1880457 : basetime is cloudtime, so alarm is correct', function(){
		getAlarmCountByThingId(DeviceData_1.thingId, ThingClassData_1.modelId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.totalNum', 1);
	});
	
	describe('C1880458 : basetime is localtime, so alarm is correct', function(){
		getAlarmCountByThingId(DeviceData_2.thingId, ThingClassData_2.modelId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.totalNum', 1);
	});

	describe('C1880459: verify that the alarm data is generated correctly when the basetime changes', function(){
		getAlarmCountByThingId(DeviceData_2.thingId, ThingClassData_2.modelId, store.putLater('response'));
		it('verify that the alarm data', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.isTrue(body.payload.totalNum > 0, 'alarm data production failed');
		});
	});

	describe('C1880461: when verifying the model creation, basetime defaults to the device time', function () {
		getThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.baseTime', ThingClassData_1.thingClassBody.connectionConfig.baseTime);
	});

	describe('delete thing instances1', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_1.modelId, DeviceData_1.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances2', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_2.modelId, DeviceData_2.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances3', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_2.modelId, DeviceData_3.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances4', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_1.modelId, DeviceData_4.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass2', function () {
		patchThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('delete thingClass2', function () {
		deleteDraftThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	//删除报警器级别
	describe('delete alarm level', function () {
		deleteAlarmSeverities(store.getLater('level'), store.putLater('response'));
	});
});