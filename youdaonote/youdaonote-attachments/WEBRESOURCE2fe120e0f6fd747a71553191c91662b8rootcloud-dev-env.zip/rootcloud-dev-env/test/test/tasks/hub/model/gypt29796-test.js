'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { getHistorianSchema } = require('../../../../test-data/schema/historian');
const { draftThingClassData, draftThingClassModelPropertiesBody, thingClassModelInstanceData, locationData, msgList1 } = require('../../../../test-data/data/tasks/hub/model/GYPT29796');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { getHistorianByModelAndThingId } = require('../../../../test-lib/openApiHistorian.js');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { getMqttClient, postDataWithClient } = require('../../../../test-lib/mqtt');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload, verifyHistoryResult } = require('../../../../test-verify/verify');
const { itWait } = require('../../../../test-data/util');

const store = new DataStore();

describe('GYPT-29796: test bug 28936', function () {

	describe('start', function () {
        after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
				store.put('client', client);
			});
        });

        describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[0].mesBody);
			itWait(500);
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[1].mesBody);
			itWait(500);
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[2].mesBody);
		});

        describe('Create a device model and send location information', function () {
            postDataWithClient(store.getLater('client'), topicDict['location_1.0'], locationData.locationDataBody);
        });

        describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[3].mesBody);
			itWait(500);
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[4].mesBody);
			itWait(500);
		});

        describe('after latency window will exec, get historian', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[5].mesBody);
			getHistorianByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgList1[0].tsQueryStr + '&properties=["a2"]', store.putLater('response'), { retryCode: 404, expectNum: 6 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[2.0], [5.0], [8.0], [5.0], [9.0], [26.0]]);
        });
	});
});
