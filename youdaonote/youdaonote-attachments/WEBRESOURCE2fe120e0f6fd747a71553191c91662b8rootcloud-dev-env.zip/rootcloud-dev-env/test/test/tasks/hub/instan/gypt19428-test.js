'use strict';
const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postBulkAddDeviceInstances } = require('../../../../test-lib/openApi');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { draftDirectDeviceClassData,
	draftGatewayClassData,
	draftNonDirectDeviceClassData,
	draftThingClassPropertiesData,
	activeData,
	gwInstanceData,
	directDeviceInstanceDataC1721893_1,
	directDeviceInstanceDataC1721893_2,
	directDeviceInstanceDataC1721893_3,
	directDeviceInstanceDataC1721894_1,
	directDeviceInstanceDataC1721894_2,
	gatewayInstanceDataC1721896_1,
	gatewayInstanceDataC1721896_2,
	gatewayInstanceDataC1721896_3,
	gatewayInstanceDataC1721897_1,
	gatewayInstanceDataC1721897_2,
	nonDirectDeviceInstanceDataC1721901_1,
	nonDirectDeviceInstanceDataC1721901_2,
	nonDirectDeviceInstanceDataC1721901_3,
	nonDirectDeviceInstanceDataC1721901_4,
	bulkDeviceInstanceDataC1721902_1,
	bulkDeviceInstanceDataC1721902_2,
	bulkDeviceInstanceDataC1721902_3,
	bulkDeviceInstanceDataC1721903_1,
	bulkDeviceInstanceDataC1721903_2,
	bulkDeviceInstanceDataC1721904_1,
	bulkDeviceInstanceDataC1721904_2,
	bulkDeviceInstanceDataC1721904_3,
	bulkDeviceInstanceDataC1721904_4,
} = require('../../../../test-data/data/tasks/hub/instan/GYPT19428');

describe('GYPT-19428: Limit length for userName, authToken and connectId when creating device', function () {

	describe('Precondition: post deviceType and properties', function () {

		describe('pre1: post device model class', function () {
			postDraftThingClass(draftDirectDeviceClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postDraftThingClass(draftNonDirectDeviceClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('pre2:post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftDirectDeviceClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postDraftThingClassPropertiesByModelID(draftNonDirectDeviceClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('pre3：active device model class by model id', function () {
			patchDraftThingClassByModelID(draftDirectDeviceClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			patchDraftThingClassByModelID(draftNonDirectDeviceClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('pre4: post a gateway instance for non direct device', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, gwInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

	});

	describe('C1721893: Limit length for userName, authToken and connectId when creating device', function () {

		describe('C1721893: length of userName is 256', function () {
			postThingInstancesByModelId(draftDirectDeviceClassData.modelId, directDeviceInstanceDataC1721893_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), directDeviceInstanceDataC1721893_1.thingInstanceBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.userName', directDeviceInstanceDataC1721893_1.thingInstanceBody.connectionConfig.userName);
		});
		describe('C1721893: length of userName is 258)', function () {
			postThingInstancesByModelId(draftDirectDeviceClassData.modelId, directDeviceInstanceDataC1721893_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});
		describe('C1721893: length of userName include $', function () {

			postThingInstancesByModelId(draftDirectDeviceClassData.modelId, directDeviceInstanceDataC1721893_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

	});

	describe('C1721894: Limit authToken length of direct device in [8,512]', function () {

		describe('C1721894: length of authToken is 512', function () {
			//length of authToken: 512
			postThingInstancesByModelId(draftDirectDeviceClassData.modelId, directDeviceInstanceDataC1721894_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), directDeviceInstanceDataC1721894_1.thingInstanceBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.authToken', directDeviceInstanceDataC1721894_1.thingInstanceBody.connectionConfig.authToken);
		});
		describe('C1721894: length of authToken is 514', function () {
			postThingInstancesByModelId(draftDirectDeviceClassData.modelId, directDeviceInstanceDataC1721894_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);

		});
	});


	describe('C1721896: Limit userName length of gateway', function () {

		describe('C1721896: length of userName is 256', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, gatewayInstanceDataC1721896_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), gatewayInstanceDataC1721896_1.thingInstanceBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.userName', gatewayInstanceDataC1721896_1.thingInstanceBody.connectionConfig.userName);

		});
		describe('C1721896: length of userName is 258)', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, gatewayInstanceDataC1721896_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);

			//length of userName include $
			postThingInstancesByModelId(draftGatewayClassData.modelId, gatewayInstanceDataC1721896_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});
		describe('C1721896: length of userName include $', function () {

			postThingInstancesByModelId(draftGatewayClassData.modelId, gatewayInstanceDataC1721896_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

	});

	describe('C1721897: Limit authToken length of gateway', function () {

		describe('C1721897: length of authToken is 512', function () {
			//length of authToken: 512
			postThingInstancesByModelId(draftGatewayClassData.modelId, gatewayInstanceDataC1721897_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), gatewayInstanceDataC1721897_1.thingInstanceBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.authToken', gatewayInstanceDataC1721897_1.thingInstanceBody.connectionConfig.authToken);
		});
		describe('C1721897: length of authToken is 514', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, gatewayInstanceDataC1721897_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);

		});
	});


	describe('C1721901: Limit connectId length of direct device in [0, 256], and only include a-zA-Z0-9_#:-@', function () {


		describe('C1721901: length of connectId: 256', function () {
			//length of connectId: 256
			postThingInstancesByModelId(draftNonDirectDeviceClassData.modelId, nonDirectDeviceInstanceDataC1721901_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.connectId', nonDirectDeviceInstanceDataC1721901_1.thingInstanceBody.connectionConfig.connectId);

		});

		describe('C1721901: length of connectId: in a-zA-Z0-9_#:-@', function () {
			postThingInstancesByModelId(draftNonDirectDeviceClassData.modelId, nonDirectDeviceInstanceDataC1721901_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.connectionConfig.connectId', nonDirectDeviceInstanceDataC1721901_2.thingInstanceBody.connectionConfig.connectId);
		});

		describe('C1721901: length of connectId: 258', function () {
			postThingInstancesByModelId(draftNonDirectDeviceClassData.modelId, nonDirectDeviceInstanceDataC1721901_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C1721901: length of connectId: not in a-zA-Z0-9_#:-@', function () {
			postThingInstancesByModelId(draftNonDirectDeviceClassData.modelId, nonDirectDeviceInstanceDataC1721901_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});
	});

	describe('C1721902: Limit length for userName, authToken and connectId when creating bulk device', function () {

		describe('C1721902: length of userName is 256', function () {
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721902_1, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', true);
		});

		describe('C1721902: length of userName is 258)', function () {
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721902_2, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', false);
		});
		describe('C1721902: length of userName include $', function () {

			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721902_3, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', false);
		});

	});

	describe('C1721903: Limit authToken length of direct device in [8,512] when creating bulk device', function () {

		describe('C1721903: length of authToken is 512', function () {
			//length of authToken: 512
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721903_1, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', true);
		});
		describe('C1721903: length of authToken is 514', function () {
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721903_2, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', false);
		});
	});

	describe('C1721904: Limit connectId length of direct device in [0, 256], and only include a-zA-Z0-9_#:-@ when creating bulk device', function () {

		describe('C1721904: length of connectId: 256', function () {
			//length of connectId: 256
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721904_1, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', true);
		});

		describe('C1721904: length of connectId: in a-zA-Z0-9_#:-@', function () {
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721904_2, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', true);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', true);
		});

		describe('C1721904: length of connectId: 258', function () {
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721904_3, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', false);
		});

		describe('C1721904: length of connectId: not in a-zA-Z0-9_#:-@', function () {
			postBulkAddDeviceInstances(bulkDeviceInstanceDataC1721904_4, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].success', false);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[2].success', false);
		});
	});

});