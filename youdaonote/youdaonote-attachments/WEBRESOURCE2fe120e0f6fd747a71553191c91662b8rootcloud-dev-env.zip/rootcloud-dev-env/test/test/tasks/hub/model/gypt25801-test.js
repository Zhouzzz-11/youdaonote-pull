'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { draftThingClassData,
        draftThingClassPropertiesData,
        updateDraftThingClassPropertiesData } = require('../../../../test-data/data/tasks/hub/model/GYPT25801');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, putDraftThingClassPropertiesByModelID, deleteDraftThingClassPropertiesByModelID, getDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-25801 : add created time of model properties', function () {
    //记录第一次属性创建时间
    let createdAt_1 = undefined;
    //记录更新后属性创建时间
    let createdAt_2 = undefined;
    //记录删除属性后再重新创建属性时间
    let createdAt_3 = undefined;
    describe('precondition', function () {
        describe('post device model class', function () {
            postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });
    });

    describe('C2190403 : add a property', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('query property to get created time', function () {
        getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        it('verify the response message', function () {
            const body = Response.getJsonBody(store.get('response'));
            createdAt_1 = body.payload[0].createdAt;
        });
    })

    describe('C2190404 : update the property', function () {
        putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updateDraftThingClassPropertiesData.UpdatethingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('query property to get updated time', function () {
        getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        it('verify the response message', function () {
            const body = Response.getJsonBody(store.get('response'));
            createdAt_2 = body.payload[0].createdAt;
            Assert.strictEqual(createdAt_1, createdAt_2, 'The created time should be equal');
        });
    })

    describe('C2190405: delete the property and create it again', function () {
        describe('delete draft device class by model Id', function () {
            deleteDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updateDraftThingClassPropertiesData.UpdatethingPropertiesBody.to.name, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });
        describe('create the property again', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });
    });

    describe('C2190406: query the time of the recent created property', function () {
        getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        it('verify the response message', function () {
            const body = Response.getJsonBody(store.get('response'));
            createdAt_3 = body.payload[0].createdAt;
            Assert.notStrictEqual(createdAt_2, createdAt_3, 'The created time should not be equal');
        });
    });

    describe('delete the device model', function () {
        deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 204);
    })
});
