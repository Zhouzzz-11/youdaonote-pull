'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData,
	draftThingClassModelPropertiesData,
	activeData,
	thingInstanceData,
	createInstructionsRequestData,
	responseData } = require('../../../../test-data/data/tasks/hub/instru/GYPT23523');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postInstructionRequests, getInstructionRequestsByRequestId1 } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage, closeClient } = require('../../../../test-lib/mqtt');

const store = new DataStore();

describe('GYPT-23523: OTA protocol optimization', function () {

	describe('create environment dependent data', function () {

		describe('creation draft thing class device model', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('add attributes to unpublished thing class device model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2074582: Whether the new payload is supported', function () {

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});
	});

	describe('C2074583: Whether wildcard subscriptions are supported', function () {

		describe('get data with mqtt', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_*_sub']);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData.instructionBody);
		});

		describe('close Client mqtt', function () {
			closeClient(store.getLater('client'));
		});
	});

	describe('C2074584: Successful device response', function () {
		getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'SUCCESS' });
		Response.statusCodeEquals(store.getLater('response'), 200);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		after(() => {
			const client = store.get('client');
			client.end();
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});


});