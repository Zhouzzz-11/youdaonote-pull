'use strict';

const { Response } = require('@rootcloud/darjeeling-http');
const { Assert, DataStore } = require('@rootcloud/darjeeling');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { msgData, msgData_1, msgData_2, msgData_3, msgData_4, msgData_5, msgData_6, msgData_7, msgData_8, msgData_9, msgData_9_1, msgData_10, msgData_10_1, msgData_11, msgData_12, msgData_13, msgData_14, msgData_15, msgData_ws1, msgData_ws2, msgData_ws3,
    draftThingClassData, draftThingClassData_1, draftThingClassModelPropertiesData,
    draftThingClassModelPropertiesData_1, draftThingClassModelPropertiesData_2, draftThingClassModelPropertiesData_3, draftThingClassModelPropertiesData_4, draftThingClassModelPropertiesData_5, draftThingClassModelPropertiesData_6,
    draftThingClassModelPropertiesData_7, draftThingClassModelPropertiesData_8, draftThingClassModelPropertiesData_9, draftThingClassModelPropertiesData_9_1, draftThingClassModelPropertiesData_10, draftThingClassModelPropertiesData_10_1,
    draftThingClassModelPropertiesData_11, draftThingClassModelPropertiesData_12, draftThingClassModelPropertiesData_13, draftThingClassModelPropertiesData_14, draftThingClassModelPropertiesData_15,
    draftThingClassPropertiesData_w, draftThingClassPropertiesData_w_f, draftThingClassPropertiesData_w1, draftThingClassPropertiesData_w1_f, draftThingClassPropertiesData_w2, draftThingClassPropertiesData_w2_f, draftThingClassPropertiesData_w3,
    draftThingClassPropertiesData_w4, draftThingClassPropertiesData_w4_f, draftThingClassPropertiesData_w5, draftThingClassPropertiesData_w5_f, draftThingClassPropertiesData_w6, draftThingClassPropertiesData_w6_f, draftThingClassPropertiesData_w7,
    draftThingClassPropertiesData_ws1, draftThingClassPropertiesData_ws2, draftThingClassPropertiesData_ws3,
    thingClassModelInstanceData, thingClassModelInstanceData1 } = require('../../../../test-data/data/tasks/hub/model/GYPT29301');
const { topicDict } = require('../../../../test-data/requireData');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();
describe('GYPT-29301 : 部分数据类型自动转换', function () {

    after(() => {
        const client = store.get('client');
        client.end();
    });
    describe('post device model class', function () {
        postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), draftThingClassSchema);
        verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
    });

    describe('add properties for model by model id', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('patch device model class by model id', function () {
        patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('post device model class1', function () {
        postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), draftThingClassSchema);
        verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
    });

    describe('add the first properties for model by model id', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassPropertiesData_ws2.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('add the second properties for model by model id', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassPropertiesData_ws3.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('patch device model class1 by model id', function () {
        patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('C2495837 : 属性类型为int，当上传的数据为int时，上数成功并正确', function () {

        describe('post device model instance by model id :int, Send condition : int', function () {
            postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_01', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_01', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData.name}.value`, 20);
        });
    });

    describe('C2495838 : 属性类型为int，当上传的数据为double，上数成功，值四舍五入取整', function () {

        describe('add properties for model by model id :int, Send condition : double', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_02', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_02', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_1.name}.value`, 11);
        });
    });

    describe('C2495844 : 属性类型为number，当上传的数据为int时，上数成功并正确', function () {

        describe('add properties for model by model id :number, Send condition : int', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_03', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_2.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_03', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 3 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_2.name}.value`, 10.00);
        });
    });

    describe('C2495845 : 属性类型为number，当上传的数据为double，上数成功并正确', function () {

        describe('add properties for model by model id :number, Send condition : double', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_04', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_3.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_04', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 4 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_3.name}.value`, 12.31);
        });
    });

    describe('C2495851 : 属性类型为string，当上传的数据为int时，上数成功并正确', function () {

        describe('add properties for model by model id :string, Send condition : int', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_4.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_05', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_4.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_05', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 5 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_4.name}.value`, '51');
        });
    });

    describe('C2495852 : 属性类型为string，当上传的数据为double，上数成功并正确', function () {

        describe('add properties for model by model id :string, Send condition : double', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_5.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_06', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_5.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_06', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 6 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_5.name}.value`, '23.83');
        });
    });

    describe('C2495853 : 属性类型为string，当上传的数据为string，上数成功并正确', function () {

        describe('add properties for model by model id :string, Send condition : string', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_6.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_07', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_6.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_07', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 7 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_6.name}.value`, 'asdf');
        });
    });

    describe('C2495854 : 属性类型为string，当上传的数据为boolean，上数成功，值会转换成"true"/"false"', function () {

        describe('add properties for model by model id :string, Send condition : boolean', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_7.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_08', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_7.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_08', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 8 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_7.name}.value`, 'true');
        });
    });

    describe('C2495857 : 属性类型为string，当上传的数据为binary，上数成功并正确', function () {

        describe('add properties for model by model id :string, Send condition : binary', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_8.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_09', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_8.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_09', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 9 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_8.name}.value`, '35');
        });
    });

    describe('C2495863 : 属性类型为boolean，当上传的数据为int时，0/1上数成功且正确，其他值失败', function () {

        describe('add properties for model by model id :boolean, Send condition : int', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_9.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_10', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_9.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_10', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 10 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_9.name}.value`, true);
        });

        describe('add properties for model by model id :boolean, Send condition : int != 0/1 ', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_9_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_10_1', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_9_1.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_10_1', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 10 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Assert.isFalse(`payload[0].data.${draftThingClassModelPropertiesData_9_1.name}.value` === true || false, '上数失败');
        });
    });

    describe('C2495864 : 属性类型为boolean，当上传的数据为double时，0/1上数成功且正确，其他值失败', function () {

        describe('add properties for model by model id :boolean, Send condition : double', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_10.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_11', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_10.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_11', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 11 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_10.name}.value`, true);
        });

        describe('add properties for model by model id :boolean, Send condition : double != 0/1', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_10_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_11_1', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_10_1.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_11_1', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 11 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Assert.isFalse(`payload[0].data.${draftThingClassModelPropertiesData_10_1.name}.value` === true || false, '上数失败');
        });
    });

    describe('C2495866 : 属性类型为boolean，当上传的数据为boolean，上数成功并正确', function () {

        describe('add properties for model by model id :boolean, Send condition : boolean', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_11.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_12', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_11.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_12', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 12 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_11.name}.value`, false);
        });
    });

    describe('C2495874 : 属性类型为json，当上传的数据为json，上数成功并正确', function () {

        describe('add properties for model by model id :json, Send condition : json', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_12.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_13', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_12.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_13', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 13 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_12.name}.value`, { "age": 30 });
        });
    });

    describe('C2495882 :属性类型为array，当上传的数据为array，上数成功并正确', function () {

        describe('add properties for model by model id :array, Send condition : array', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_13.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_14', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_13.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_14', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 14 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_13.name}.value`, [1, 2, 3]);
        });
    });

    describe('C2495886 :属性类型为binary，当上传的数据为string，上数成功并正确', function () {

        describe('add properties for model by model id :binary, Send condition : string', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_14.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_15', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_14.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_15', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 15 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_14.name}.value`, '12asdf');
        });
    });

    describe('C2495890 :属性类型为binary，当上传的数据为binary，上数成功并正确', function () {

        describe('add properties for model by model id :binary, Send condition : binary', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_15.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_16', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_15.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_16', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 16 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_15.name}.value`, '100011');
        });
    });

    describe('C2495901, window属性的计算方法是sum/min/max/range，当该属性的类型是number/integer，则window属性创建成功，其他类型则创建失败', function () {
       
        describe('post window properties, sum/min/max/range , number/integer', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post window properties, other type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w_f.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 400);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'operator为sum, min, max, range时，属性类型只能是Number或者Integer');
        });
    });

    describe('C2495902, window属性的计算方法是count，当该属性的类型是integer，window属性创建成功，其他类型则创建失败', function () {
        
        describe('post window properties, count , integer', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post window properties, other type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w1_f.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 400);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'operator为count时，属性类型只能是Integer');
        });
    });

    describe('C2495903, window属性的计算方法是avg/dev，当该属性类型是number，window属性创建成功，其他类型则创建失败', function () {
       
        describe('post window properties, avg/dev , number', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w2.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post window properties, other type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w2_f.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 400);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'operator为avg，dev时，属性类型只能是Number');
        });
    });

    describe('C2495904, window属性的计算方法是first/last/majority，该属性可以是任意数据类型，均能创建成功', function () {
       
        describe('post window properties, first/last/majority , Any data type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w3.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2581451, window属性的计算方法是sum/min/max/range，当该属性默认值的类型是number/integer，则window属性创建成功，其他类型则创建失败', function () {
        
        describe('post window properties, sum/min/max/range , windowDefaultValueJson: number/integer', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w4.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post window properties, windowDefaultValueJson: other type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w4_f.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 500);
        });
    });

    describe('C2581452, window属性的计算方法是count，当该属性默认值的类型是integer，window属性创建成功，其他类型则创建失败', function () {
       
        describe('post window properties, count , windowDefaultValueJson: integer', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w5.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post window properties, windowDefaultValueJson: other type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w5_f.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 400);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'windowDefaultValueJson 字段值 57.87 的类型与属性类型 Integer 不一致');
        });
    });

    describe('C2581453, window属性的计算方法是avg/dev，当该属性默认值的类型是number，window属性创建成功，其他类型则创建失败', function () {
       
        describe('post window properties, avg/dev , windowDefaultValueJson: number', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w6.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post window properties, windowDefaultValueJson: other type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w6_f.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 500);
        });
    });

    describe('C2581454, window属性的计算方法是first/last/majority，该属性的默认值可以是任意数据类型，均能创建成功', function () {
       
        describe('post window properties, first/last/majority , windowDefaultValueJson: Any data type', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_w7.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2495905 : 数据包中有一个属性不符合以上规则时，该属性上数失败，其他属性上数成功', function () {

        describe('add non compliant properties for model by model id, Send condition', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_ws1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_w1', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_ws1.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_w1', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 16 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Assert.isFalse(`payload[0].data.${draftThingClassPropertiesData_ws1.name}.value` === 'asdf', '上数失败');
        });
    });

    describe('C2495906: : 表达式不符合上述规则时，上数成功，表达式没有值', function () {

        describe('post device model instance by model id , Send condition', function () {
            postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceData1.thingInstanceBody);
            getMqttClient(thingClassModelInstanceData1.thingId, (client) => {
                store.put('client', client);
            });
        });

        describe('post data with mqtt_w2,_w3', function () {
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_ws2.mesBody);
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_ws3.mesBody);
            closeClient(store.getLater('client'));
        });

        describe('testing delivery condition_w2', function () {
            getRealTimeByModelAndThingId(thingClassModelInstanceData1.thingId, draftThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassPropertiesData_ws2.name}.value`, true);
        });
    });

    //删除模型
    describe('delete thing  instances', function () {
        deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('delete thing  instances1', function () {
        deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('patch thing class', function () {
        patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('patch thing class_1', function () {
        patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('delete draft device class by model Id', function () {
        deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 204);
    });

    describe('delete draft device class by model Id', function () {
        deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 204);
    });
});
