'use strict';

const { DataStore, Assert, getData } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData, instructionRequestsData, responseData7, thingInstanceData_3, thingInstanceData_4, thingInstanceData_16, responseData5, responseData6, instructionRequestsData_7, instructionRequestsData_5, instructionRequestsData_6, responseData3, responseData4, responseData2, instructionRequestsData_4, responseData1, instructionRequestsData_2, thingInstanceData_1, thingInstanceData_2, responseData, instructionRequestsData_1, instructionRequestsData2, draftThingClassPropertiesData, instructionRequestsData1, thingInstanceData, draftThingClassData1, draftGatewayClassData, thingClassModelInstanceData1, thingClassModelInstanceData2 } = require('../../../../test-data/data/tasks/hub/instru/GYPT19748');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postInstructionRequests, getInstructionRequestsByRequestId1 } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage } = require('../../../../test-lib/mqtt');

const store = new DataStore();

/*
	由于topic第一次建立延迟的问题，需要等待较长时间，故将指令下发的story移至最后执行
 */
describe('GYPT-19748: issued by the OTA', function () {

	describe('start, build environment dependency', function () {
		//直连设备
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	describe('C1849280: directly connected device delivery', function () {
		postInstructionRequests(instructionRequestsData.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1849281: delivered by non-directly connected devices', function () {
		postInstructionRequests(instructionRequestsData1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1849282: delivered by gateway devices', function () {
		postInstructionRequests(instructionRequestsData2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1849283: check if the device can receive the platform return', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message4'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message4'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_1.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});
	});

	describe('C1849284: check if the device can receive the platform return and ack = true', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});
		
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_2.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_2.thingId, (client) => { store.put('client', client); }, store.putLater('message3'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message3'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData1.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_1.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849285: check if the device can receive the platform return ack = false', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message2'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_4.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message2'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData2.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_4.requestId, store.putLater('response'), {status: 'RECEIVED'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849286: modify the "is Completed" field. When it is false, whether to display the progress progress', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_3.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message1'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_5.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message1'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData3.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_5.requestId, store.putLater('response'), {status: 'IN_PROGRESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'IN_PROGRESS');
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.progress', 100);
		});
	});

	describe('C1849287: check if the device can receive the platform return ack = false', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});
		
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_16.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_16.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_16.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_6.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData_6.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData4.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_6.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
			it('whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'SUCCESS', 'Issued by the successful');
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849288: for one instruction, the device returns status to the platform multiple times', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});
		
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_4.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message8'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['ota_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_7.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message8'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData_7.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData7.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_7.requestId, store.putLater('response'), {status: 'RECEIVED'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('response1', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData5.instructionBody);
		});

		describe('query instruction status1', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_7.requestId, store.putLater('response'), { status: 'IN_PROGRESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'IN_PROGRESS');
		});

		describe('response2', function () {
			postDataWithClient(store.getLater('client'), topicDict['ota_pub'], responseData6.instructionBody);
		});

		describe('query instruction status2', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_7.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('end remove environment dependencies', function () {
		//直连设备
		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_4.thingId, store.putLater('response'));
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_16.thingId, store.putLater('response'));
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('delete gateway device', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
