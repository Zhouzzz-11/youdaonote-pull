'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { valDict, topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { getHistorianSchema } = require('../../../../test-data/schema/historian');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { draftThingClassData, draftThingClassPropertiesData, activeData, thingInstanceData, msgData, bookmarkId } = require('../../../../test-data/data/tasks/hub/model/GYPT21117');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { getHistorianByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload, verifyHistoryResult } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-21117: /e2e test with device type properties', function () {
	before(function () {
		if (valDict.runEnv === 'qa' || valDict.runEnv === 'pre') {
			this.skip();
		}
	});

	describe('c1780373 e2e test', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
			getMqttClient(thingInstanceData.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			closeClient(store.getLater('client'));
		});

		describe('query historian data with model class id and device id', function () {
			getHistorianByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});

		describe('C2190808: cold data query', function () {
			getHistorianByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1, coldstoreOnly: true, bookmark: bookmarkId });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		})
	});
});
