'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID, patchThingClassByModelID, patchDraftThingClassByModelID, getDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { topicDict } = require('../../../../test-data/requireData');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { ThingClassData, ThingClassData_1, ThingClassData_2, DeviceData_1, DeviceData_2, PropertiesData_1, PropertiesData_2, PropertiesData_3, PropertiesData_4, PropertiesData_5, PropertiesData_6, PropertiesData_7, DeviceData, postdata } = require('../../../../test-data/data/tasks/hub/model/GYPT20402');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');

describe('GYPT-20402 : expression priority', function () {
	describe('preconditions: create directed device model', function () {
		postDraftThingClass(ThingClassData.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880716 : priority equals to zero when the propertity without priority', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getDraftThingClassPropertiesByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].priority', 0);
	});

	describe('preconditions: create directed device model', function () {
		postDraftThingClass(ThingClassData_1.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_1.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('preconditions: create directed device model', function () {
		postDraftThingClass(ThingClassData_2.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880717&C1880718: The higher priority is calculated first ', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_2.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_3.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('post data with mqtt', function () {
		getMqttClient(DeviceData.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], postdata.mesBody);
		closeClient(store.getLater('client'));

		getRealTimeByModelAndThingId(DeviceData.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_2.name}.value`, 4);
	});

	describe('C1880720: verify that low priority is referenced by high priority, and the result is null', function () {
		it('check propertity is not in response', function () {
			const key = Object.keys(Response.getJsonBody(store.get('response')).payload[0].data);
			Response.bodyJsonEquals(key.includes(`${PropertiesData_3.name}`), false);
		});
	});

	describe('C1880719 : It is calculated in alphabetical order when the priority is the same', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData_1.modelId, PropertiesData_4.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_1.modelId, PropertiesData_7.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData_1.modelId, DeviceData_1.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('post data with mqtt', function () {
		getMqttClient(DeviceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], postdata.mesBody);
		closeClient(store.getLater('client'));

		getRealTimeByModelAndThingId(DeviceData_1.thingId, ThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		it('check propertity is not in response', function () {
			const key = Object.keys(Response.getJsonBody(store.get('response')).payload[0].data);
			Response.bodyJsonEquals(key.includes(`${PropertiesData_4.name}`), false);
		});
	});

	describe('C1880722 : value is null when the expression includes \'window\'', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData_5.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData_6.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData_2.modelId, DeviceData_2.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('post data with mqtt', function () {
		getMqttClient(DeviceData_2.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], postdata.mesBody);
		closeClient(store.getLater('client'));

		getRealTimeByModelAndThingId(DeviceData_2.thingId, ThingClassData_2.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		it('check propertity is not in response', function () {
			const key = Object.keys(Response.getJsonBody(store.get('response')).payload[0].data);
			Response.bodyJsonEquals(key.includes(`${PropertiesData_6.name}`), false);
		});
	});

	describe('delete thing instances3', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});