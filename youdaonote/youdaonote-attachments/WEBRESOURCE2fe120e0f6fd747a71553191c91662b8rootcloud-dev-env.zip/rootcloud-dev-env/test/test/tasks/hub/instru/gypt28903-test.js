'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postInstructionTemplate } = require('../../../../test-lib/instructionTemplate');
const { postInstructionRequests } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const { draftThingClassData,
    draftThingClassModelPropertiesData,
    createInstructionsData,
    thingInstanceData,
    createInstructionsRequestData,
    draftThingClassData_1,
    draftThingClassModelPropertiesData_1,
    createInstructionsData_1,
    thingInstanceData_1,
    createInstructionsRequestData_1,
    draftThingClassData_2,
    draftThingClassModelPropertiesData_2,
    createInstructionsData_2,
    thingInstanceData_2,
    createInstructionsRequestData_2,
    draftThingClassData_3,
    draftThingClassModelPropertiesData_3,
    createInstructionsData_3,
    thingInstanceData_3,
    createInstructionsRequestData_3,
    draftThingClassData_4,
    draftThingClassModelPropertiesData_4,
    createInstructionsData_4,
    thingInstanceData_4,
    createInstructionsRequestData_4,
    draftThingClassData_5,
    draftThingClassModelPropertiesData_5,
    thingInstanceData_5,
    draftThingClassData_6,
    draftThingClassModelPropertiesData_6,
    createInstructionsData_6,
    thingInstanceData_6,
    createInstructionsRequestData_6,
    draftThingClassData_7,
    draftThingClassModelPropertiesData_7,
    createInstructionsData_7,
    thingInstanceData_7,
    createInstructionsRequestData_7,
    draftThingClassData_8,
    draftThingClassModelPropertiesData_8,
    createInstructionsData_8,
    thingInstanceData_8,
    createInstructionsRequestData_8,
    draftThingClassData_9,
    draftThingClassModelPropertiesData_9,
    createInstructionsData_9,
    thingInstanceData_9,
    createInstructionsRequestData_9,
    draftThingClassData_10,
    draftThingClassModelPropertiesData_10,
    createInstructionsData_10,
    thingInstanceData_10,
    createInstructionsRequestData_10
} = require('../../../../test-data/data/tasks/hub/instru/GYPT28903');
const store = new DataStore();

describe('GYPT-23903: 指令下发根据ExpressionType判断是否可下发', function () {

    describe('创建依赖环境ExpressionType=groovy', function () {

        describe('creation draft thing class device model', function () {
            postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657883: 指令下发根据ExpressionType判断是否可下发_直连设备_groovy_下发失败', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData.thingInstructionRequestsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 500);
            verifySchema(store.getLater('response'), errorResponseSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'LIVE下发指令属性: temp不支持expressionType为 groovy的类型');
        });
    });

    describe('创建依赖环境,ExpressionType=window', function () {

        describe('creation draft thing class device model', function () {
            postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657884: 指令下发根据ExpressionType判断是否可下发_直连设备_window_下发失败', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData_1.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_1.thingInstructionRequestsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 500);
            verifySchema(store.getLater('response'), errorResponseSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'LIVE下发指令属性: a2不支持expressionType为 window的类型');
        });
    });

    describe('创建依赖环境, ExpressionType=direct', function () {

        describe('creation draft thing class device model', function () {
            postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657885: 指令下发根据ExpressionType判断是否可下发_直连设备_Direct_下发成功', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_3.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_3.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), thingInstanceData_3.thingInstanceBody);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_3.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionRequestSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.msgId', store.getLater('requestId'));
        });
    });

    describe('创建依赖环境, ExpressionType=linear', function () {

        describe('creation draft thing class device model', function () {
            postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657886: 指令下发根据ExpressionType判断是否可下发_直连设备_linear_下发成功', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_2.modelId, createInstructionsData_2.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_2.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), thingInstanceData_2.thingInstanceBody);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionRequestSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.msgId', store.getLater('requestId'));
        });
    });

    describe('创建依赖环境, ExpressionType=constant', function () {

        describe('creation draft thing class device model', function () {
            postDraftThingClass(draftThingClassData_4.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_4.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_4.modelId, draftThingClassModelPropertiesData_4.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657887: 指令下发根据ExpressionType判断是否可下发_直连设备_constant_下发失败', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_4.modelId, createInstructionsData_4.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_4.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), thingInstanceData_4.thingInstanceBody);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_4.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 500);
            verifySchema(store.getLater('response'), errorResponseSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'LIVE下发指令属性: temp不支持expressionType为 constant的类型');
        });
    });

    describe('delete environment dependent data', function () {
        describe('delete thing device model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData_1.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingInstanceData_2.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_3.modelId, thingInstanceData_3.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_4.modelId, thingInstanceData_4.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            patchDraftThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete draft thing class', function () {
            deleteDraftThingClassByModelID(draftThingClassData.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteDraftThingClassByModelID(draftThingClassData_3.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
            deleteDraftThingClassByModelID(draftThingClassData_4.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('创建依赖环境,非直连设备 ExpressionType=groovy', function () {

        describe('creation draft thing class gateway model', function () {
            postDraftThingClass(draftThingClassData_5.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_5.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_5.modelId, draftThingClassModelPropertiesData_5.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_5.modelId, thingInstanceData_5.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), thingInstanceData_5.thingInstanceBody);
        });

        describe('creation draft thing class gateway model', function () {
            postDraftThingClass(draftThingClassData_6.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_6.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_6.modelId, draftThingClassModelPropertiesData_6.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657888: 指令下发根据ExpressionType判断是否可下发_非直连设备_groovy_下发失败', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_6.modelId, createInstructionsData_6.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_6.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_6.modelId, thingInstanceData_6.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_6.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 500);
            verifySchema(store.getLater('response'), errorResponseSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'LIVE下发指令属性: temp2不支持expressionType为 groovy的类型');
        });
    });

    describe('delete environment dependent data', function () {
        
        describe('delete thing device model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_6.modelId, thingInstanceData_6.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_6.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete draft thing class', function () {
            deleteDraftThingClassByModelID(draftThingClassData_6.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('创建依赖环境,非直连设备 ExpressionType=window', function () {

        describe('creation draft thing class not directly connected model', function () {
            postDraftThingClass(draftThingClassData_7.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_7.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_7.modelId, draftThingClassModelPropertiesData_7.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657889: 指令下发根据ExpressionType判断是否可下发_非直连设备_window_下发失败', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_7.modelId, createInstructionsData_7.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_7.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_7.modelId, thingInstanceData_7.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_7.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 500);
            verifySchema(store.getLater('response'), errorResponseSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'LIVE下发指令属性: a2不支持expressionType为 window的类型');
        });
    });

    describe('delete environment dependent data', function () {
        describe('delete thing device model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_7.modelId, thingInstanceData_7.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_7.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete draft thing class', function () {
            deleteDraftThingClassByModelID(draftThingClassData_7.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('创建依赖环境,非直连设备 ExpressionType=direct', function () {

        describe('creation draft thing class not directly connected model', function () {
            postDraftThingClass(draftThingClassData_8.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_8.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_8.modelId, draftThingClassModelPropertiesData_8.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657890: 指令下发根据ExpressionType判断是否可下发_非直连设备_Direct_下发成功', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_8.modelId, createInstructionsData_8.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_8.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_8.modelId, thingInstanceData_8.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_8.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionRequestSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.msgId', store.getLater('requestId'));
        });
    });

    describe('delete environment dependent data', function () {
        describe('delete thing device model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_8.modelId, thingInstanceData_8.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_8.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete draft thing class', function () {
            deleteDraftThingClassByModelID(draftThingClassData_8.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('创建依赖环境,非直连设备 ExpressionType=direct', function () {

        describe('creation draft thing class not directly connected model', function () {
            postDraftThingClass(draftThingClassData_9.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_9.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_9.modelId, draftThingClassModelPropertiesData_9.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657891: 指令下发根据ExpressionType判断是否可下发_非直连设备_linear_下发成功', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_9.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_9.modelId, thingInstanceData_9.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_9.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionRequestSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.msgId', store.getLater('requestId'));
        });
    });

    describe('delete environment dependent data', function () {
        describe('delete thing device model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_9.modelId, thingInstanceData_9.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete draft thing class', function () {
            deleteDraftThingClassByModelID(draftThingClassData_9.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('创建依赖环境,非直连设备 ExpressionType=constant', function () {

        describe('creation draft thing class not directly connected model', function () {
            postDraftThingClass(draftThingClassData_10.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_10.thingClassBody);
        });

        describe('add attributes to unpublished thing class device model', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_10.modelId, draftThingClassModelPropertiesData_10.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });

    describe('C2657891: 指令下发根据ExpressionType判断是否可下发_非直连设备_constant_下发失败', function () {

        describe('create instructions template', function () {
            postInstructionTemplate(draftThingClassData_10.modelId, createInstructionsData_10.instructionsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), instructionSchema);
        });

        describe('active device model class by model id1', function () {
            patchDraftThingClassByModelID(draftThingClassData_10.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData_10.modelId, thingInstanceData_10.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('implementation instructions issued', function () {
            postInstructionRequests(createInstructionsRequestData_10.thingInstructionRequestsBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 500);
            verifySchema(store.getLater('response'), errorResponseSchema);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'LIVE下发指令属性: temp不支持expressionType为 constant的类型');
        });
    });

    describe('delete environment dependent data', function () {
        describe('delete thing device model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_10.modelId, thingInstanceData_10.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete thing geteway model', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_5.modelId, thingInstanceData_5.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_10.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete draft thing class', function () {
            deleteDraftThingClassByModelID(draftThingClassData_10.modelId, store.getLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch draft thing class', function () {
            patchDraftThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });
    });
});