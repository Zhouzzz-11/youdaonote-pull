'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	createInstructionsData_1,
	createInstructionsData_2,
	createInstructionsData_3,
	updateInstructionsData_4,
	updateInstructionsData_5,
	draftThingClassData_9,
	draftThingClassModelPropertiesData_9,
	createInstructionsData_9,
	updateInstructionsData_9,
	createInstructionsData_12,
	draftThingClassData_3,
	draftThingClassModelPropertiesData_3,
	createInstructionsData_13,
	createInstructionsData_14,
	updateInstructionsData_15,
	createInstructionsData_16,
	updateInstructionsData_17
} = require('../../../../test-data/data/tasks/hub/instru/GYPT17896');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');
const { errorResponseSchema } = require('../../../../test-data/schema/common');

const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postInstructionTemplate, getInstructionTemplate, deleteInstructionTemplate, getThingInstructionTemplate, putInstructionTemplate } = require('../../../../test-lib/instructionTemplate');

const { verifySchema, verifyPayload, verifyMultiSchema } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('The setting of instruction requires draft mode', function () {

	describe('GYPT-17896: Create draft thing class ', function () {
		describe(' Create draft thing class ', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe(' Create draft thing class properties ', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe(' Create draft thing class ', function () {
			postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
		});

		describe(' Create draft thing class properties ', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe(' Create draft thing class ', function () {
			postDraftThingClass(draftThingClassData_9.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_9.thingClassBody);
		});

		describe(' Create draft thing class properties ', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_9.modelId, draftThingClassModelPropertiesData_9.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C194717: Create instructions ', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'draft');
		});

		describe('C194718: Create instructions, when model does not exist ', function () {
			postInstructionTemplate('', createInstructionsData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C194719: Create instructions, When the model does not correspond to tenantid ', function () {
			postInstructionTemplate('bum', createInstructionsData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C194720: Create instructions, when instruction is repeated', function () {
			describe('create instruction template ', function () {
				postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 400);
				verifySchema(store.getLater('response'), errorResponseSchema);
			});

			describe('delete instruction template ', function () {
				deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C194721: Create instructions, when association property does not exist', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 500);
		});

		describe('C194777: Create instructions in template', function () {
			describe('create instruction template ', function () {
				postInstructionTemplate(draftThingClassData.modelId, createInstructionsData_3.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('delete instruction template ', function () {
				deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData_3.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C194780: Query instructions ', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData_12.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('get instruction template ', function () {
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_12.instructionTemplateId });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), instructionSchema);
		});

		describe('delete instruction template ', function () {
			deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData_12.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});


		describe('C194778: Query instructions result is empty when validation model does not exist', function () {
			getInstructionTemplate('', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C194779: query instructions is empty when the validation model does not correspond to tenantid', function () {
			getInstructionTemplate('zzz12', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C194781: Query instructions,Results are in draft mode ', function () {
			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);

				getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].status', 'draft');
			});
		});

		describe('C194782:  Query instructions result is empty when instructonId does not exist ', function () {
			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: '' });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C194783:  Query instructions result is empty when instructonId does not correspond to tenantid ', function () {
			getThingInstructionTemplate('bum', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C194784:  The result of combination condition query is correct', function () {
			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
			});

			describe('patch draft thing class', function () {
				patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('delete unpublished instructions ', function () {
				deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C194785:  Verify that the results of the query are in published mode', function () {
			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData.modelId, createInstructionsData_3.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_3.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].status', 'active');
			});

			describe('cancel thing class', function () {
				patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C194786:  Failed to modify when verifying model and instruction do not correspond', function () {
			putInstructionTemplate(draftThingClassData.modelId, 'bum', updateInstructionsData_4.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C194787:  Failed to modify when verifying model and tenantId do not correspond', function () {
			putInstructionTemplate('bum', createInstructionsData_3.instructionTemplateId, updateInstructionsData_5.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C194788:  Modification of unpublished instructions succeeded', function () {
			putInstructionTemplate(draftThingClassData.modelId, createInstructionsData_3.instructionTemplateId, updateInstructionsData_5.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('C194793: delete unpublished instructions ', function () {
			deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData_3.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C194789:  Modification of published instructions succeeded', function () {
			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_13.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('get instruction template ', function () {
				getInstructionTemplate(draftThingClassData_3.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_13.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe(' update instruction template ', function () {
				putInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_13.instructionTemplateId, updateInstructionsData_5.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});
			describe(' delete instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData_3.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_13.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
			});
		});

		describe('C194794: delete published instructions ', function () {
			deleteInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_13.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
			patchThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C194791: Failed to verify that the model and instructions do not correspond to deletion ', function () {
			deleteInstructionTemplate(draftThingClassData.modelId, 'cit', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C194792: Failed to verify that the model and instructions do not correspond to deletion ', function () {
			deleteInstructionTemplate('bum', createInstructionsData_3.instructionId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C194795: publish the device model after verifying the added instruction ', function () {
			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_14.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData_3.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_14.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].instructionTemplateId', createInstructionsData_14.instructionTemplateId);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].type', 'LIVE');

			});
		});

		describe('C194797: publish the device model after verifying the update instruction ', function () {
			describe('cancel thing class', function () {
				patchThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe(' update instruction template ', function () {
				putInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_14.instructionTemplateId, updateInstructionsData_15.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
			});

			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData_3.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_14.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].instructionTemplateId', createInstructionsData_14.instructionTemplateId );
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].type', 'LIVE');
			});
		});
		describe('C194799: publish the device model after verifying the delete instruction ', function () {
			describe('cancel thing class', function () {
				patchThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			describe(' delete instruction template ', function () {
				deleteInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_14.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C194796: publish the device gateway after verifying the added instruction ', function () {
			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_9.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData_9.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_9.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].instructionTemplateId', '_Rouse_');
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].type', 'CMD');
			});
		});

		describe('C194798: publish the device model after verifying the update instruction ', function () {
			describe('cancel thing class', function () {
				patchThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe(' update instruction template ', function () {
				putInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_9.instructionTemplateId, updateInstructionsData_9.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('get instruction template ', function () {
				getThingInstructionTemplate(draftThingClassData_9.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData_9.instructionTemplateId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyMultiSchema(store.getLater('response'), instructionSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].instructionTemplateId', '_Rouse_');
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].type', 'CMD');
			});
		});

		describe('C194780: publish the device gateway after verifying the delete instruction ', function () {
			describe('patch  thing class', function () {
				patchThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe(' delete instruction template ', function () {
				deleteInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_9.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C194805: After verifying the addition / modification / deletion of multiple instructions, the device / gateway model is issued', function () {

			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_16.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe(' update instruction template ', function () {
				putInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_16.instructionTemplateId, updateInstructionsData_17.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe(' delete instruction template ', function () {
				deleteInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_16.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe(' create instruction template ', function () {
				postInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_3.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe(' update instruction template ', function () {
				putInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_3.instructionTemplateId, updateInstructionsData_5.instructionsBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionSchema);
			});

			describe(' delete instruction template ', function () {
				deleteInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_3.instructionTemplateId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('patch draft thing class', function () {
				patchDraftThingClassByModelID(draftThingClassData_9.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('delete draft thing class', function () {
				deleteDraftThingClassByModelID(draftThingClassData.modelId, store.getLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('delete draft thing class', function () {
				deleteDraftThingClassByModelID(draftThingClassData_3.modelId, store.getLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('delete draft thing class', function () {
				deleteDraftThingClassByModelID(draftThingClassData_9.modelId, store.getLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

		});
	});
});