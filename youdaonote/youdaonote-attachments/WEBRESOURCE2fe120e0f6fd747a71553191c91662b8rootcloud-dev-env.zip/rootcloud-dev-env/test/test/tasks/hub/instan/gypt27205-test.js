'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassData,
    draftThingClassModelPropertiesData,
    thingClassModelInstanceData,
    thingClassModelInstanceData_1,
    thingClassModelInstanceData_2,
    draftCompositeThingClassData_1,
    draftThingClassModelPropertiesData_1,
    thingClassModelInstanceCompositeData_1,
    thingClassModelInstanceCompositeData_2,
    updatethingClassModelInstanceCompositeData_1, } = require('../../../../test-data/data/tasks/hub/instan/GYPT27205');
const { draftThingClassSchema, draftCompositeThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema, thingInstanceCompositeSchema } = require('../../../../test-data/schema/thingInstance');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, putThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();
describe('/Preset product information can also be modified on the instance side', function () {

    describe('GYPT-27205: dependency data required to create environment', function () {

        describe('post device model class', function () {
            postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2190365: object instance device request parameter does not contain thingInfo', function () {
            postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
        });

        describe('C2190367: object instance device request parameter contains thingInfo', function () {
            postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
            //  Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfo', thingClassModelInstanceData_1.thingInfo);
        });

        describe('C2190369: Modifier instance _ device _thingInfo modifies parameter value', function () {
            putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            // Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfo', thingClassModelInstanceData_2.thingInfo);
        });

        describe('post device compositeThing model class', function () {
            postDraftThingClass(draftCompositeThingClassData_1.CompositeThingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftCompositeThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('patch device model class by model id', function () {
            patchDraftThingClassByModelID(draftCompositeThingClassData_1.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2190366: object instance compositeThing request parameter does not contain thingInfo', function () {
            postThingInstancesByModelId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_1.CompositeThingBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceCompositeData_1.CompositeThingBody);
        });

        describe('C2190368: object instance compositeThing request parameter contains thingInfo', function () {
            postThingInstancesByModelId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_2.CompositeThingBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceCompositeData_2.CompositeThingBody);
            // Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfo', thingClassModelInstanceCompositeData_2.thingInfo);
        });

        describe('C2190370: Modifier instance compositeThing thingInfo modifies parameter value', function () {
            putThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_2.thingId, updatethingClassModelInstanceCompositeData_1.CompositeThingBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
            // Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfo', updatethingClassModelInstanceCompositeData_1.thingInfo);
        });

        describe('delete thing  compositeThing', function () {
            deleteThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_1.thingId, store.putLater('response'));
            deleteThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_2.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete thing  instances', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
            deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('un-publish thingClass', function () {
            patchThingClassByModelID(draftCompositeThingClassData_1.modelId, store.putLater('response'));
            patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete thing  model', function () {
            deleteDraftThingClassByModelID(draftCompositeThingClassData_1.modelId, store.putLater('response'));
            deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });
    });
});
