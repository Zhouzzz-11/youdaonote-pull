'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { postAlarmTypeData,
		postAlarmCategories,
		postAlarmCategories2,
		postAlarmCategories3,
		postAlarmSeverities,
		postAlarmTypeData1,
		postAlarmTypeData2,
		postAlarmTypeData3,
		postAlarmTypeData4,
		draftThingClassData,
		draftThingClassPropertiesData } = require('../../../../test-data/data/tasks/hub/alarm/GYPT17931');

const { responseAlarmCategories, responseAlarmType } = require('../../../../test-data/schema/alarmType');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { createAlarmCategories, createAlarmSeverities, updateAlarmType, createAlarmType, deleteAlarmType } = require('../../../../test-lib/alarmType');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

describe('/test for alarmType', function () {

	
	describe('GYPT-17931: Create/Get/Update/Delete alarm type', function () {
		const store = new DataStore();

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('environmental dependence create alarm categories 3', function () {
			//environmentalDependence create alarmCategories 3
			describe('create the first alarm category', function () {
				createAlarmCategories(postAlarmCategories.alarmCategoriesBody, store.putLater('response'), store.putLater('cid1'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmCategories);
				verifyPayload(store.getLater('response'), postAlarmCategories.alarmCategoriesBody);
			});

			describe('create the second alarm category', function () {
				createAlarmCategories(postAlarmCategories2.alarmCategoriesBody, store.putLater('response'), store.putLater('cid2'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmCategories);
				verifyPayload(store.getLater('response'), postAlarmCategories2.alarmCategoriesBody);
			});

			describe('create the third alarm category', function () {
				createAlarmCategories(postAlarmCategories3.alarmCategoriesBody, store.putLater('response'), store.putLater('cid3'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmCategories);
				verifyPayload(store.getLater('response'), postAlarmCategories3.alarmCategoriesBody);
			});
		});

		describe('create alarm levels', function () {
			createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
			//Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('C193647: Create alarm type legal input category ids array to fill in multiple legal tags', function () {

			describe('Create alarm type legal input category ids array to fill in multiple legal tags', function () {
				//pass the alarm category id to the alarmType
				postAlarmTypeData.alarmTypeBody.categoryIds = [postAlarmCategories.cid, postAlarmCategories2.cid, postAlarmCategories3.cid];
				createAlarmType(postAlarmTypeData.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData.alarmTypeBody.alarmTypeId);
				it('Categories array the content is consistent', () => {
					const alarmTypeData = store.get('response');
					const body = Response.getJsonBody(alarmTypeData);
					let flag = 0;
					body.payload.alarmInfo.categories.forEach((item, index) => {
						if (item.cid !== postAlarmTypeData.alarmTypeBody.categoryIds[index]) {
							return flag = 1;
						}
					});
					Assert.strictEqual(flag, 0, `The content is consistent`);
				});
			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C193648: Create alarm type legal input category ids array to fill in 1 legal label', function () {
			describe('create alarm type', function () {
				//pass the alarm category id to the alarmType
				postAlarmTypeData1.alarmTypeBody.categoryIds = [postAlarmCategories.cid];
				createAlarmType(postAlarmTypeData1.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData1.alarmTypeBody.alarmTypeId);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData1.alarmTypeBody.categoryIds[0]);
			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C193649: Create alarm type legal input categoryIds array fill in non existent category id', function () {
			createAlarmType(postAlarmTypeData2.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 400);

		});

		describe('C193650: Create alarm type Illegal input category ids fill in non-array', function () {
			createAlarmType(postAlarmTypeData3.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C193651: Create alarm type Illegal input category ids fill in extra commas', function () {
			describe('create alarm type', function () {
				//pass the alarm category id to the alarmType
				postAlarmTypeData4.alarmTypeBody.categoryIds[0] = postAlarmCategories2.cid;
				createAlarmType(postAlarmTypeData4.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData4.alarmTypeBody.alarmTypeId);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData4.alarmTypeBody.categoryIds[0]);
			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});


		describe('C193652: Update alarm type legal input category ids array to fill in multiple legal tags', function () {
			describe('create a new alarm type', function () {
				//pass the alarm category id to the alarmType
				postAlarmTypeData1.alarmTypeBody.categoryIds = [postAlarmCategories.cid, postAlarmCategories2.cid, postAlarmCategories3.cid];
				createAlarmType(postAlarmTypeData1.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
			});

			describe('update alarmType', function () {
				updateAlarmType(postAlarmTypeData1.alarmTypeBody, store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData1.alarmTypeBody.alarmTypeId);
				it('Categories array the content is consistent', () => {
					const alarmTypeData = store.get('response');
					const body = Response.getJsonBody(alarmTypeData);
					let flag = 0;
					body.payload.alarmInfo.categories.forEach((item, index) => {
						if (item.cid !== postAlarmTypeData.alarmTypeBody.categoryIds[index]) {
							return flag = 1;
						}
					});
					Assert.strictEqual(flag, 0, `The content is consistent`);
				});
			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C193653: Update alarm type legal input category ids array to fill in 1 legal label', function () {
			describe('create alarmType', function () {
				//pass the alarm category id to the alarmType
				postAlarmTypeData.alarmTypeBody.categoryIds = [postAlarmCategories.cid, postAlarmCategories2.cid, postAlarmCategories3.cid];
				createAlarmType(postAlarmTypeData.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
			});

			describe('update alarmType', function () {
				postAlarmTypeData1.alarmTypeBody.categoryIds = [postAlarmCategories.cid];
				updateAlarmType(postAlarmTypeData1.alarmTypeBody, store.getLater('id'), store.putLater('response1'));
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifySchema(store.getLater('response1'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response1'), 'payload.alarmTypeId', postAlarmTypeData.alarmTypeBody.alarmTypeId);

			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C193654: Update alarmType legal input categoryIds array fill in non existent category id', function () {

			describe('create new alarmType', function () {
				postAlarmTypeData1.alarmTypeBody.categoryIds = [postAlarmCategories.cid];
				createAlarmType(postAlarmTypeData1.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData1.alarmTypeBody.alarmTypeId);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData1.alarmTypeBody.categoryIds[0]);
			});

			describe('update alarmType', function () {
				updateAlarmType(postAlarmTypeData2.alarmTypeBody, store.getLater('id'), store.putLater('response1'));
				Response.statusCodeEquals(store.getLater('response1'), 400);
			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C193655: Update alarm Type Illegal input categoryIds fill in non-array', function () {
			describe('create alarm type', function () {
				postAlarmTypeData1.alarmTypeBody.categoryIds = [postAlarmCategories.cid];
				createAlarmType(postAlarmTypeData1.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData1.alarmTypeBody.alarmTypeId);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData1.alarmTypeBody.categoryIds[0]);
			});

			describe('update alarm type', function () {
				updateAlarmType(postAlarmTypeData3.alarmTypeBody, store.getLater('id'), store.putLater('response1'));
				Response.statusCodeEquals(store.getLater('response1'), 400);
			});


			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C193656: Update alarm Type Illegal input categoryIds fill in extra commas', function () {

			describe('create the environment', function () {
				//pass the alarm category id to the alarmType
				postAlarmTypeData4.alarmTypeBody.categoryIds[0] = postAlarmCategories2.cid;
				createAlarmType(postAlarmTypeData4.alarmTypeBody, store.putLater('response'), store.putLater('id'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), responseAlarmType);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData4.alarmTypeBody.alarmTypeId);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData4.alarmTypeBody.categoryIds[0]);

			});

			describe('steps', function () {
				updateAlarmType(postAlarmTypeData4.alarmTypeBody, store.getLater('id'), store.putLater('response1'));
				Response.statusCodeEquals(store.getLater('response1'), 200);
				Response.bodyJsonPropertyEquals(store.getLater('response1'), 'payload.alarmTypeId', postAlarmTypeData4.alarmTypeBody.alarmTypeId);
				Response.bodyJsonPropertyEquals(store.getLater('response1'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData4.alarmTypeBody.categoryIds[0]);
			});

			describe('restore the environment', function () {
				deleteAlarmType(store.getLater('id'), store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});
	});
});