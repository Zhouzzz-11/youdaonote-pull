'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2
} = require('../../../../test-data/data/tasks/hub/model/GYPT16624');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postBulkRemoveDeviceInstances } = require('../../../../test-lib/openApi');
const {
	postDraftThingClass,
	deleteDraftThingClassByModelID,
	postDraftThingClassPropertiesByModelID,
	patchDraftThingClassByModelID,
	patchThingClassByModelID,
} = require('../../../../test-lib/openApiThingClass');

const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();


describe('GYPT-16624 : test The MongoDB database is actually deleted', function () {
	describe('precondition', function () {

		//设备
		describe('post draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		//网关
		describe('post draft Gateway class', function () {
			// step 1: create draft Gateway class
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class', function () {
			// step 2: create draft Gateway property
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			// step 3: publish draft Gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});
	});

	/*
     delete /draft/device/types/{deviceTypeId}
    */

	describe('C188414: DeviceType_ Database deletion (device type is terminal)', function () {
		describe('patch  device  class', function () {
			// step 5: unpublish draft device class
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});
		describe('delete device  class', function () {
			// step 1: delete  device class
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 204);
			// verifySchema(store.getLater('response'), draftThingClassSchema);
			// verifyPayload(store.getLater('response4'), {});
		});

		describe('post draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

	});

	describe('C188415: Delete DeviceType_ Database delete (device type gateway)', function () {
		describe('patch  gateway class', function () {
			// step 5: unpublish draft gateway class
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete gateway  class', function () {
			// step 1: delete  gateway class
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 204);
			// verifySchema(store.getLater('response'), draftThingClassSchema);

		});

		describe('post draft gateway class', function () {
			// step 1: create draft gateway class
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft gateway class properties', function () {
			// step 2: create draft Gateway property
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft gateway class', function () {
			// step 3: publish draft Gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});
	});

	/*
     delete /device/types/{deviceTypeId}/devices/{deviceId}
    */

	describe('C188416: Delete Device_ database delete (device type is terminal)', function () {
		describe('create device  class', function () {
			// step 1: create device
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('delete device class', function () {
			// step 1: delete  device class
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response4'), {});
		});
	});

	describe('C188417: Delete Device_ database delete (device type is gateway)', function () {
		describe('create device  class', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData1.thingInstanceBody);
		});

		describe('delete device class', function () {
			// step 1: delete  device class
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response4'), {});
		});
	});

	/*
     delete /bulk/devices/remove
   */

	describe('C188521: Batch delete Device_ Database delete (device type is terminal)', function () {
		describe('create device  class1', function () {
			// step 1: create device
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('create device  class2', function () {
			// step 1: create device
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});

		describe('Batch delete device', function () {
			const body = [
				{
					'thingId': `${thingClassModelInstanceData.thingId}`,
					'modelId': `${draftThingClassData.modelId}`
				},
				{
					'thingId': `${thingClassModelInstanceData2.thingId}`,
					'modelId': `${draftThingClassData.modelId}`
				}
			];
			// step 1: delete  device class
			postBulkRemoveDeviceInstances(body, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response4'), {});
		});
	});

	describe('C188522: Batch delete Device_ Database delete (device type is gateway)', function () {
		describe('create device  class1', function () {
			// step 1: create device
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData1.thingInstanceBody);
		});

		describe('create device  class2', function () {
			// step 1: create device
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});

		describe('Batch delete device', function () {
			const body = [
				{
					'thingId': `${thingClassModelInstanceData1.thingId}`,
					'modelId': `${draftGatewayClassData.modelId}`
				},
				{
					'thingId': `${thingClassModelInstanceData2.thingId}`,
					'modelId': `${draftGatewayClassData.modelId}`
				}
			];
			// step 1: delete  device class
			postBulkRemoveDeviceInstances(body, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response4'), {});
		});
	});

	describe('end', function () {

		//设备
		describe('patch  device  class', function () {
			// step 5: unpublish draft device class
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		//网关
		describe('patch  gateway class', function () {
			// step 5: unpublish draft gateway class
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);

		});
	});
});
