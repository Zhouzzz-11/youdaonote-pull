'use strict';

const { DataStore, Assert, getData } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData, responseData_1, thingInstanceData22, thingInstanceData21, thingInstanceData20, createInstructionsRequestData20, thingInstanceData_19, instructionRequestsData_19, thingInstanceData_30, thingInstanceData2, draftThingClassModelPropertiesData1, draftThingClassData_1, createInstructionsData2, createInstructionsRequestData2, responseData_3, instructionRequestsData_3, instructionRequestsData_2, thingInstanceData_18, instructionRequestsData_18, responseData18, thingInstanceData_17, instructionRequestsData_17, thingInstanceData_16, instructionRequestsData_16, thingInstanceData_15, instructionRequestsData_15, thingInstanceData_14, instructionRequestsData_14, thingInstanceData_13, instructionRequestsData_13, responseData13, thingInstanceData_11, instructionRequestsData_11, thingInstanceData_1, instructionRequestsData_1, createInstructionsData_3, createInstructionsData_2, responseData_2, draftThingClassPropertiesData, instructionRequestsData1, createInstructionsData, thingInstanceData, draftThingClassData1, draftGatewayClassData, thingClassModelInstanceData1, thingClassModelInstanceData2 } = require('../../../../test-data/data/tasks/hub/instru/GYPT17943.js');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postInstructionRequests, getInstructionRequestsByRequestId1 } = require('../../../../test-lib/instructionRequest');
const { postInstructionTemplate } = require('../../../../test-lib/instructionTemplate');
const { verifySchema, verifyPayload, } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage } = require('../../../../test-lib/mqtt');

const store = new DataStore();

describe('GYPT-17943 : The instruction issues a test to increase the timeout mechanism is business logic ', function () {

	describe('start', function () {
		//直连设备
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('Create instruction template1', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
		//直连设备2
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('Create instruction template2', function () {
			postInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('Create instruction template', function () {
			postInstructionTemplate(draftGatewayClassData.modelId, createInstructionsData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('Create instruction template', function () {
			postInstructionTemplate(draftThingClassData1.modelId, createInstructionsData_3.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

	});

	describe('C296196 : The result will be returned on time after the verification instruction is issued, and no timeout will be judged', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message1'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message1'), store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['cmd_pub'], responseData_1.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_1.requestId, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296197 : Validation instructions do not timeout when they have not been issued in a queue', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_11.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_11.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_11.thingId, (client) => { store.put('client', client); }, store.putLater('message2'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_11.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message2'), store.putLater('response'));
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_11.requestId, store.putLater('response'), { status: 'SENT' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SENT');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_11.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296201 : The validation instruction has issued a returned ACK and returned Response, and no timeout is determined', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_13.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_13.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_13.thingId, (client) => { store.put('client', client); }, store.putLater('message3'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_13.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message3'), store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['cmd_pub'], responseData13.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_13.requestId, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});
	});

	describe('C296202 : The verification instruction has been sent and has returned ack but has not returned response. The timeout will not be judged and the next instruction will not be affected', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});
		
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_14.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_14.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_14.thingId, (client) => { store.put('client', client); }, store.putLater('message4'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_14.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message4'), store.putLater('response'));
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_14.requestId, store.putLater('response'), { status: 'SENT' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SENT');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_14.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296203 : The validation instruction has been issued and does not return ack and does not return Response. A timeout is determined', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_30.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_30.thingInstanceBody);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData1.requestId, store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_13.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296205 : The status of the instruction is correct after the instruction is issued but before timeout', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_15.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_15.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_15.thingId, (client) => { store.put('client', client); }, store.putLater('message88'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_15.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message88'), store.putLater('response'));
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_15.requestId, store.putLater('response'), { status: 'SENT' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SENT');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_15.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296206 : When the validation instruction has expired, the state of the instruction is EXPIRED', function () {

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_16.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_16.thingInstanceBody);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_16.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_16.requestId, store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_16.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296207 : Verify that instructions without response link have been issued and an ACK has been returned. No timeout will be judged', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_17.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_17.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_17.thingId, (client) => { store.put('client', client); }, store.putLater('message5'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_17.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message5'), store.putLater('response'));
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'SENT' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SENT');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_17.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296208 : Verify that the timeout logic for directly connected instances/gateway instances/non-directly connected instances is normal', function () {
		describe('Verify that the timeout logic for the directly connected instance is normal', function () {
			
			after(() => {
				const client = store.get('client');
				client.end();
			});

			describe('post device model instance by model id', function () {
				postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_18.thingInstanceBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInstancePostSchema);
				verifyPayload(store.getLater('response'), thingInstanceData_18.thingInstanceBody);
			});

			describe('Connect the MQTT', function () {
				getMqttClient(thingInstanceData_18.thingId, (client) => { store.put('client', client); }, store.putLater('message6'));
			});

			describe('Subscribe', function () {
				subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
			});

			describe('Instruction issuing operation', function () {
				postInstructionRequests(instructionRequestsData_18.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionRequestSchema);
			});

			describe('Verify that the device subscribed successfully', function () {
				getSubMessage(store.getLater('message6'), store.putLater('response'));
			});

			describe('response', function () {
				postDataWithClient(store.getLater('client'), topicDict['cmd_pub'], responseData18.instructionBody);
			});

			describe('Query instruction status', function () {
				getInstructionRequestsByRequestId1(instructionRequestsData_18.requestId, store.putLater('response'), { status: 'RECEIVED' });
				Response.statusCodeEquals(store.getLater('response'), 200);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
			});

			describe('delete device ', function () {
				deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_18.thingId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
			});
		});

		describe('Verify that the timeout logic for the gateway instance is normal', function () {

			after(() => {
				const client = store.get('client');
				client.end();
			});

			describe('Connect the MQTT', function () {
				getMqttClient(thingClassModelInstanceData2.thingId, (client) => { store.put('client', client); }, store.putLater('message7'));
			});

			describe('Subscribe', function () {
				subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub']);
			});

			describe('Instruction issuing operation', function () {
				postInstructionRequests(instructionRequestsData_2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionRequestSchema);
			});

			describe('Verify that the device subscribed successfully', function () {
				getSubMessage(store.getLater('message7'), store.putLater('response'));

			});

			describe('response', function () {
				postDataWithClient(store.getLater('client'), topicDict['cmd_gateway_pub'], responseData_2.instructionBody);
			});

			describe('Verify that the timeout logic for the gateway instance is normal', function () {
				getInstructionRequestsByRequestId1(instructionRequestsData_2.requestId, store.putLater('response'), { status: 'RECEIVED' });
				Response.statusCodeEquals(store.getLater('response'), 200);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
			});
		});

		describe('Verify that the timeout logic for non-directly connected instances is normal', function () {
			
			after(() => {
				const client = store.get('client');
				client.end();
			});
			
			describe('Connect the MQTT', function () {
				getMqttClient(thingClassModelInstanceData2.thingId, (client) => { store.put('client', client); }, store.putLater('message11'));
			});

			describe('Subscribe', function () {
				subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub']);
			});

			describe('Instruction issuing operation', function () {
				postInstructionRequests(instructionRequestsData_3.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), instructionRequestSchema);
			});

			describe('Verify that the device subscribed successfully', function () {
				getSubMessage(store.getLater('message11'), store.putLater('response'));
				it('test', () => {
					const message = getData(store.get('response'));
					const msgId = getData(store.get('requestId'));
					const obj = JSON.parse(message);

					const subscribeMsgId = obj.header.msgId;
					Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
				});
			});

			describe('response', function () {
				postDataWithClient(store.getLater('client'), topicDict['cmd_gateway_pub'], responseData_3.instructionBody);
			});

			describe('Verify that the timeout logic for non-directly connected instances is normal', function () {
				getInstructionRequestsByRequestId1(instructionRequestsData_3.requestId, store.putLater('response'), { status: 'SUCCESS' });
				Response.statusCodeEquals(store.getLater('response'), 200);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
			});
		});
	});

	describe('C296209 : Verify that no timeout instruction has been set, and no timeout is determined', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData2.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData2.thingId, (client) => { store.put('client', client); }, store.putLater('message81'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(createInstructionsRequestData2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'SENT' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether a timeout is determined', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(body.payload.status === 'EXPIRED', 'not judge the timeout');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C296210 : Verify that the instruction library instruction timeout logic is normal', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_19.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_19.thingInstanceBody);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_19.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_19.requestId, store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_19.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1501147 : Verify that the configuration issue timeout logic is normal', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData20.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData20.thingInstanceBody);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(createInstructionsRequestData20.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData20.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1509642 : Verify that the get configuration timeout logic works', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData21.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData21.thingInstanceBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData21.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1730422 : When the validation timeout exceeds the default value, it is not issued and prompted', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData22.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData22.thingInstanceBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData22.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('end', function () {
		//直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
		});

		//直连设备2
		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response4'));
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response4'));
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('delete gateway device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});