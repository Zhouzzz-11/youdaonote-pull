'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassSchema, draftCompositeThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema, thingInstanceCompositeSchema } = require('../../../../test-data/schema/thingInstance');
const { draftThingClassData,
    draftThingClassData_1,
    draftThingClassModelPropertiesData,
    thingClassModelInstanceData_1,
    thingClassModelInstanceData_2,
    ThingClassData_2,
    draftThingClassData_2,
    draftThingClassModelPropertiesData_1,
    draftcompositeThingClassData,
    thingClassModelInstanceData,
    draftThingClassModelPropertiesData_2,
    compositeThingInstancesData,
    draftThingClassData_3,
    draftThingClassModelPropertiesData_3,
    thingClassModelInstanceData_3,
    draftThingClassData_4,
    draftThingClassData_5,
    ThingClassData_6,
    ThingClassData_7
} = require('../../../../test-data/data/tasks/hub/instan/GYPT23812');
const { postDraftThingClass, getDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, putDraftThingClassByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, getThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId, putThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-23812: The model adds a device-level product information field type', function () {

    describe('The thingInfoExtensions model contains multiple parameters', function () {

        describe('C2148569: post device model device thingInfoExtensions contains multiple parameters', function () {
            postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2148572: get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', draftThingClassData.thingInfoExtensions);
        });

        describe('C2148570: post gateway model device thingInfoExtensions contains multiple parameters', function () {
            postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
        });

        describe('C2148572: get model thingInfoExtensions contains multiple parameters, type: gateway', function () {
            getDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', draftThingClassData_2.thingInfoExtensions);

        });

        describe('C2148571: post compositeThing model device thingInfoExtensions contains multiple parameters', function () {
            postDraftThingClass(draftcompositeThingClassData.CompositeThingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
        });

        describe('C2148572: get model thingInfoExtensions contains multiple parameters, type: compositeThing', function () {
            getDraftThingClassByModelID(draftcompositeThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200); 
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', draftcompositeThingClassData.thingInfoExtensions);
        });

        describe('C2148573: Modifiers model unpublished status thingInfoExtensions modifies parameter content', function () {
            putDraftThingClassByModelID(draftThingClassData.modelId, draftThingClassData_1.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', draftThingClassData_1.thingInfoExtensions);
        });

        describe('C2148574: Modifiers model unpublished status ThingInfoExtensions adds parameters', function () {
            putDraftThingClassByModelID(draftThingClassData.modelId, draftThingClassData_4.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', draftThingClassData_4.thingInfoExtensions);
        });

        describe('C2148575: Modifiers model unpublished status ThingInfoExtensions deltete parameters', function () {
            putDraftThingClassByModelID(draftThingClassData.modelId, draftThingClassData_5.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', draftThingClassData_5.thingInfoExtensions);
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2148576: Modifiers model published status thingInfoExtensions modifies parameter content', function () {
            putDraftThingClassByModelID(draftThingClassData.modelId, ThingClassData_2.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', ThingClassData_2.thingInfoExtensions);
        });

        describe('C2148577: Modifiers model published status thingInfoExtensions adds parameter', function () {
            putDraftThingClassByModelID(draftThingClassData.modelId, ThingClassData_6.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', ThingClassData_6.thingInfoExtensions);
        });

        describe('C2148578: Modifiers model published status thingInfoExtensions delete parameter', function () {
            putDraftThingClassByModelID(draftThingClassData.modelId, ThingClassData_7.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('get model thingInfoExtensions contains multiple parameters, type: device', function () {
            getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', ThingClassData_7.thingInfoExtensions);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2148579: Creating the gateway thingInfoExtensions contains multiple parameters', function () {
            postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
        });

        describe('C2148583: get model thingInfoExtensions contains multiple parameters, type: gateway', function () {
            getThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', thingClassModelInstanceData.thingInfoExtensions);
        });

        describe('C2148580: Creating the device thingInfoExtensions contains multiple parameters', function () {
            postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
        });

        describe('C2148583: get model thingInfoExtensions contains multiple parameters, type: gateway', function () {
            getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', thingClassModelInstanceData_1.thingInfoExtensions);

        });

        describe('post not directly connected model device thingInfoExtensions contains multiple parameters', function () {
            postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2148581: Creating the not directly connected thingInfoExtensions contains multiple parameters', function () {
            postThingInstancesByModelId(draftThingClassData_3.modelId, thingClassModelInstanceData_3.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
        });

        describe('C2148583: get model thingInfoExtensions contains multiple parameters, type: not directly connected', function () {
            getThingInstancesByModelIdAndThingId(draftThingClassData_3.modelId, thingClassModelInstanceData_3.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', thingClassModelInstanceData_3.thingInfoExtensions);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftcompositeThingClassData.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('Patch thing draft thing-classes', function () {
            patchDraftThingClassByModelID(draftcompositeThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('C2148582: Creating the compositeThing thingInfoExtensions contains multiple parameters', function () {
            postThingInstancesByModelId(draftcompositeThingClassData.modelId, compositeThingInstancesData.CompositeThingBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
        });

        describe('C2148583: get model thingInfoExtensions contains multiple parameters, type: gateway', function () {
            getThingInstancesByModelIdAndThingId(draftcompositeThingClassData.modelId, compositeThingInstancesData.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', compositeThingInstancesData.thingInfoExtensions);
        });

        describe('C2148584: put the compositeThing thingInfoExtensions contains multiple parameters', function () {
            putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
        });

        describe('C2148583: get model thingInfoExtensions contains multiple parameters, type: gateway', function () {
            getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfoExtensions', thingClassModelInstanceData_1.thingInfoExtensions);
        });

        describe('delete thingInstances', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_3.modelId, thingClassModelInstanceData_3.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('delete thingInstances', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('delete compositeThing', function () {
            deleteThingInstancesByModelIdAndThingId(draftcompositeThingClassData.modelId, compositeThingInstancesData.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('delete thingInstances', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('unpublish thingClass', function () {
            patchThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('unpublish thingClass', function () {
            patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('unpublish thingClass', function () {
            patchThingClassByModelID(draftcompositeThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('unpublish thingClass', function () {
            patchThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete thingClass', function () {
            deleteDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });

        describe('delete thingClass', function () {
            deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });

        describe('delete thingClass', function () {
            deleteDraftThingClassByModelID(draftcompositeThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });

        describe('delete thingClass', function () {
            deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });
    });

});