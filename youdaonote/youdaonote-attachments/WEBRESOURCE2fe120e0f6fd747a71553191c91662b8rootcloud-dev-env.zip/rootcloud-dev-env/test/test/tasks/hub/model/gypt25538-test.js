'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID, patchThingClassByModelID, patchDraftThingClassByModelID, putDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { ThingClassData, compositeThing_1, compositeThing_2, compositeThing_3, compositeThing_4, compositeThing_5, PropertiesData_1, C_PropertiesData} = require('../../../../test-data/data/tasks/hub/model/GYPT25538');

describe('GYPT-25538 : compositeThing cannot exist a ring', function(){
	describe('precondition', function(){
		postDraftThingClass(ThingClassData.thingClassBody,store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));

		postDraftThingClass(compositeThing_1.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_1.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingClass(compositeThing_2.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_2.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2085537 : compositeThing creates failed with rings', function(){
		putDraftThingClassByModelID(compositeThing_1.modelId, compositeThing_4.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('check message contains \'环\'', function(){
			var message = Response.getJsonBody(store.get('response')).message;
			Response.bodyJsonEquals(message.indexOf('环') != -1, true);
		});
	});

	describe('C2085548 : compositeThing creates failed with itself', function(){
		putDraftThingClassByModelID(compositeThing_1.modelId, compositeThing_5.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('check message contains \'环\'', function(){
			var message = Response.getJsonBody(store.get('response')).message;
			Response.bodyJsonEquals(message.indexOf('环') != -1, true);
		});
	});

	describe('C2085535 : compositeThing is created successfully without rings', function(){
		postDraftThingClass(compositeThing_3.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.childThingNodes[0].childInterfaceId', compositeThing_2.modelId);
	});

	describe('delete thingClass3', function () {
		deleteDraftThingClassByModelID(compositeThing_3.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass2', function () {
		patchThingClassByModelID(compositeThing_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass2', function () {
		deleteDraftThingClassByModelID(compositeThing_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(compositeThing_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(compositeThing_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass', function () {
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass', function () {
		deleteDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});