'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	draftThingClassModelPropertiesData_1,
	draftThingClassModelPropertiesData_2,
	thingClassModelStaticPropertiesData,
	updateClassModelStaticPropertiesData,
	thingClassModelManyStaticPropertiesData,
	updateClassModelManyStaticPropertiesData,
	thingClassModelStaticPropertiesData_1,
	updateClassModelStaticPropertiesData_1,
	thingClassModelInstanceData,
	updateClassModelInstanceData,
	thingClassModelStaticPropertiesData_2,
	updateClassModelStaticPropertiesData_2,
	thingClassModelStaticPropertiesData_3,
	updateClassModelStaticPropertiesData_3,
	thingClassModelStaticPropertiesData_4,
	updateClassModelStaticPropertiesData_4,
	thingClassModelStaticPropertiesData_5,
	updateClassModelStaticPropertiesData_5,
	thingClassBulkInstanceBodyData_6,
	thingClassBulkInstanceBodyData_7,
	thingClassBulkInstanceBodyData_8,
	thingClassBulkInstanceBodyData_9,
	thingClassBulkInstanceBodyData_10,
	thingClassBulkInstanceBodyData_11,
	thingClassBulkInstanceBodyData_12,
	thingClassBulkInstanceBodyData_13,
	thingClassBulkInstanceBodyData_14,
	thingClassBulkInstanceBodyData_15,
	thingClassBulkInstanceBodyData_16,
	thingClassBulkInstanceBodyData_17, } = require('../../../../test-data/data/tasks/hub/alarm/GYPT13448');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { thingInstancePostSchema, thingInstanceBulkSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId, getThingInstancesByModelIdAndThingId, putThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postBulkAddDeviceInstances } = require('../../../../test-lib/openApi');
const { verifySchema, verifyPayload, verifyMultiSchema } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('/Set the static attribute contained in a device through API', function () {

	describe('GYPT-13448: Create/Get/Update/Delete device', function () {
		// step 1: create draft thing class
		postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
		// verification status code, payload and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		// step 2: create draft thing class {modelId}/properties
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
		// step 3: Patch  thing draft thing-classes  发布
		patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});

		describe('C188444: create device Legal  staticproperties parameter', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelStaticPropertiesData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelStaticPropertiesData.thingInstanceBody);
		});

		describe('C188453: get device Legal  staticproperties parameter', function () {
			// step 1: create draft thing class
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData.thingId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelStaticPropertiesData.thingInstanceBody);
		});

		describe('C188455: update device Legal  staticproperties parameter', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData.thingId, updateClassModelStaticPropertiesData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), updateClassModelStaticPropertiesData.thingInstanceBody);
			// step 2: delete devices Legal staticproperties parameter
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188445: create device Legal many staticproperties parameter', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelManyStaticPropertiesData.thingManyStaticPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelManyStaticPropertiesData.thingManyStaticPropertiesBody);
		});

		describe('C188454: get device Legal many staticproperties parameter', function () {
			// step 1: create draft thing class
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelManyStaticPropertiesData.thingId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelManyStaticPropertiesData.thingStaticPropertiesBody);
		});

		describe('C188456: update device Legal many staticproperties parameter', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelManyStaticPropertiesData.thingId, updateClassModelManyStaticPropertiesData.thingManyStaticPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), updateClassModelManyStaticPropertiesData.thingManyStaticPropertiesBody);
			// step 2: delete devices Legal staticproperties parameter
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelManyStaticPropertiesData.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188446: create device No propertyValueJson for Legal staticproperties parameter', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

		describe('C188457: update device No propertyValueJson for Legal many staticproperties parameter', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_1.thingId, updateClassModelStaticPropertiesData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

		describe('C188447: create device No staticProperties for Legal staticproperties parameter', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('C188458: update device No staticProperties for Legal many staticproperties parameter', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, updateClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), updateClassModelInstanceData.thingStaticPropertiesBody);
			// step 2: delete devices Legal staticproperties parameter
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188449: create device No propertyName for Legal staticproperties parameter', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C188460: update device No propertyName for Legal  staticproperties parameter', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_2.thingId, updateClassModelStaticPropertiesData_2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C188450: create device Propertyvaluejson illegal JSON', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_3.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelStaticPropertiesData_3.thingInstanceBody);
		});

		describe('C188461: update device Propertyvaluejson illegal JSON', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_3.thingId, updateClassModelStaticPropertiesData_3.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), updateClassModelStaticPropertiesData_3.thingInstanceBody);
			// step 2: delete devices Legal staticproperties parameter
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_3.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188451: create device Propertyvaluejson fill in non JSON string', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_4.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C188462: update device Propertyvaluejson fill in non JSON string', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_4.thingId, updateClassModelStaticPropertiesData_4.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C188452: create device no Propertyvaluejson', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_5.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C188463: update device no Propertyvaluejson ', function () {
			// step 1: update device Legal staticproperties parameter
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelStaticPropertiesData_5.thingId, updateClassModelStaticPropertiesData_5.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('C188514: create bulk add device StaticProperties contained', function () {
			// step 1: create draft thing class
			const body = [
				thingClassBulkInstanceBodyData_6.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_7.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_8.thingBulkInstanceBody,
			];
			postBulkAddDeviceInstances(body, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), thingInstanceBulkSchema);
		});

		describe('C188515: create bulk add device no StaticProperties', function () {
			// step 1: create draft thing class
			const body = [
				thingClassBulkInstanceBodyData_9.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_10.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_11.thingBulkInstanceBody,
			];
			postBulkAddDeviceInstances(body, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), thingInstanceBulkSchema);

		});

		describe('C188517: create bulk add device propertyName defect ', function () {
			// step 1: create draft thing class
			const body = [
				thingClassBulkInstanceBodyData_12.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_13.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_14.thingBulkInstanceBody,
			];
			postBulkAddDeviceInstances(body, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), thingInstanceBulkSchema);
		});

		describe('C188519: create bulk add device propertyValueJson defect ', function () {
			// step 1: create draft thing class
			const body = [
				thingClassBulkInstanceBodyData_15.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_16.thingBulkInstanceBody,
				thingClassBulkInstanceBodyData_17.thingBulkInstanceBody,
			];
			postBulkAddDeviceInstances(body, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), thingInstanceBulkSchema);
		});
	});
});
