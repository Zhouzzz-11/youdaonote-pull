'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { valDict } = require('../../../../test-data/requireData');
const { draftThingClassData, draftThingClassModelPropertiesData, thingClassModelInstanceData, thingClassModelInstanceData_1 } = require('../../../../test-data/data/tasks/hub/instan/GYPT19187');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('/The manufacturer name can be filled in manually when creating the device', function () {

	describe('GYPT-19187: Create/Delete device', function () {
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C286629: The manufacturer name can be filled in manually when creating the device', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfo.manufacturer', valDict.manufacturer);
			// step 2: delete devices by device ID
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C286630: Specify the vendor name and specify the vendor ID when creating the device', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.thingInfo.manufacturer', valDict.manufacturer);
			// step 2: delete devices by device ID
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 3:un-publish thingClass
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});

			// step 4: delete model
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
