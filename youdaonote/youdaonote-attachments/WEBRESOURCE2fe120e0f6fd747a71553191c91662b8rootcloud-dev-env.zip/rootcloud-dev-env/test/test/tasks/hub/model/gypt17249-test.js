'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { valDict } = require('../../../../test-data/requireData');
const { draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceData_1 } = require('../../../../test-data/data/tasks/hub/model/GYPT17249');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');

const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();
describe('GYPT-17249: /The manufacturer id can be filled in manually when creating the device', function () {

	describe('post device model class', function () {
		postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
	});

	describe('post device model class properties by model id', function () {
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('patch device model class by model id', function () {
		patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('C2074369: The manufacturer id can be filled in manually when creating the device', function () {
		postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), thingInstancePostSchema);
		verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.manufacturerId', valDict.manufacturerId);
	});

	describe('delete thing  instances', function () {
		deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('patch  thing class', function () {
		patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('delete thing  model', function () {
		deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);

	});

	describe('post gateway device model class', function () {
		postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
	});

	describe('post device model class properties by model id', function () {
		postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('patch device model class by model id', function () {
		patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('C2074375: post Gateway device model instance by model id', function () {
		postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), thingInstancePostSchema);
		verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.manufacturerId', valDict.manufacturerId);
	});

	describe('delete thing  instances', function () {
		deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('patch  thing class', function () {
		patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('delete thing  model', function () {
		deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

});