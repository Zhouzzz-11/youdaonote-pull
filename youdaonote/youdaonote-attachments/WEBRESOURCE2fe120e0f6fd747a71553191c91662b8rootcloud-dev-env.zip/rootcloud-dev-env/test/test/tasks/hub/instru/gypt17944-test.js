'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	activeData,
	thingInstanceData,
	draftThingClassData_9,
	createInstructionsData_9,
	thingInstanceData_9,
	createInstructionsRequestData,
	createInstructionsRequestData_3,
	createInstructionsRequestData_4,
	createInstructionsRequestData_5,
	createInstructionsRequestData_6,
	createInstructionsRequestData_7,
	instructionData,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	createInstructionsData_1,
	thingInstanceData_1,
	createInstructionsRequestData_1,
	instructionData_1,
	createInstructionsRequestData_8,
	createInstructionsRequestData_9,
	createInstructionsRequestData_10,
	createInstructionsRequestData_11,
	createInstructionsRequestData_12,
	draftThingClassData_2,
	draftThingClassModelPropertiesData_2,
	createInstructionsData_2,
	thingInstanceData_2,
	thingInstanceData_11,
	createInstructionsRequestData_2,
	instructionData_2,
	createInstructionsRequestData_13,
	createInstructionsRequestData_14,
	createInstructionsRequestData_15,
	createInstructionsRequestData_16,
	createInstructionsRequestData_17,
	createInstructionsRequestData_18,
	createInstructionsRequestData_19,
	createInstructionsRequestData_20,
	createInstructionsRequestData_21,
	createInstructionsRequestData_22,
	createInstructionsRequestData_23,
	createInstructionsRequestData_24,
	createInstructionsRequestData_25,
	createInstructionsRequestData_26,
	draftThingClassData_3,
	draftThingClassModelPropertiesData_3,
	createInstructionsData_3,
	thingInstanceData_3,
	thingInstanceData_16,
	createInstructionsRequestData_27,
	instructionData_3,
	createInstructionsRequestData_28,
	createInstructionsRequestData_29,
	createInstructionsRequestData_30,
	createInstructionsRequestData_31,
	createInstructionsRequestData_32,
	draftThingClassData_4,
	draftThingClassModelPropertiesData_4,
	createInstructionsData_4,
	thingInstanceData_4,
	thingInstanceData_17,
	createInstructionsRequestData_33,
	instructionData_4,
	createInstructionsRequestData_34,
	createInstructionsRequestData_35,
	createInstructionsRequestData_36,
	createInstructionsRequestData_37,
	createInstructionsRequestData_38,
	draftThingClassData_5,
	draftThingClassModelPropertiesData_5,
	createInstructionsData_5,
	thingInstanceData_5,
	thingInstanceData_18,
	createInstructionsRequestData_39,
	instructionData_5,
	createInstructionsRequestData_40,
	createInstructionsRequestData_41,
	createInstructionsRequestData_42,
	createInstructionsRequestData_43,
	createInstructionsRequestData_44,
	createInstructionsRequestData_45,
	createInstructionsRequestData_46,
	createInstructionsRequestData_47,
	createInstructionsRequestData_48,
	createInstructionsRequestData_49,
	createInstructionsRequestData_50,
	createInstructionsRequestData_51,
	createInstructionsRequestData_52,
	createInstructionsRequestData_53,
	draftThingClassData_6,
	draftThingClassModelPropertiesData_6,
	thingInstanceData_6,
	createInstructionsRequestData_54,
	instructionData_6,
	thingInstanceData_12,
	createInstructionsRequestData_55,
	createInstructionsRequestData_56,
	createInstructionsRequestData_57,
	createInstructionsRequestData_58,
	createInstructionsRequestData_59,
	draftThingClassData_7,
	draftThingClassModelPropertiesData_7,
	thingInstanceData_7,
	createInstructionsRequestData_60,
	instructionData_7,
	thingInstanceData_13,
	thingInstanceData_15,
	createInstructionsRequestData_61,
	createInstructionsRequestData_62,
	createInstructionsRequestData_63,
	createInstructionsRequestData_64,
	createInstructionsRequestData_65,
	draftThingClassData_8,
	draftThingClassModelPropertiesData_8,
	thingInstanceData_8,
	createInstructionsRequestData_66,
	instructionData_8,
	thingInstanceData_14,
	createInstructionsRequestData_67,
	createInstructionsRequestData_68,
	createInstructionsRequestData_69,
	createInstructionsRequestData_70,
	createInstructionsRequestData_71,
	createInstructionsRequestData_72,
	createInstructionsRequestData_73,
	createInstructionsRequestData_74,
	createInstructionsRequestData_75,
	createInstructionsRequestData_76,
	createInstructionsRequestData_77,
	createInstructionsRequestData_78,
	createInstructionsRequestData_79,
	createInstructionsRequestData_80,
	thingInstanceData_10 } = require('../../../../test-data/data/tasks/hub/instru/GYPT17944');

const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postInstructionTemplate } = require('../../../../test-lib/instructionTemplate');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage } = require('../../../../test-lib/mqtt');
const { postInstructionRequests, getInstructionRequestsByRequestId1, getInstructionRequestsByRequestId2 } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-17944: Instructions are issued sequentially', function () {

	describe('create environment dependent data', function () {

		describe('creation draft thing class device model', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('add attributes to unpublished thing class device model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722052: CMD instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['cmd_pub'], instructionData.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'RECEIVED', 'retry: response status is: RECEIVED');
			});
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_3.thingInstructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722053: CMD instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_5.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued,Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_4.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifySchema(store.getLater('response1'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
		});
	});

	describe('C1722054: CMD instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('creation draft thing class gateway model', function () {
			postDraftThingClass(draftThingClassData_9.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_9.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_9.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData_9.modelId, createInstructionsData_9.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_9.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_9.modelId, thingInstanceData_9.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_9.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_9.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub'],);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_6.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_7.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class gateway model', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722055: CMD instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData_10.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_10.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message1'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message1'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['cmd_gateway_pub'], instructionData_1.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['cmd_gateway_pub'], instructionData_1.instructionBody, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'RECEIVED', 'Issued by the successful');
			});
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_8.thingInstructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722056: CMD instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_10.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_9.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
		});
	});

	describe('C1722057: CMD instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_10.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_12.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_11.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifySchema(store.getLater('response1'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class Not directly connected model', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722058: CMD instruction timeout is greater than zero _ Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData_2.modelId, createInstructionsData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingInstanceData_11.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['cmd_gateway_pub'], instructionData_2.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['cmd_gateway_pub'], instructionData_2.instructionBody, store.putLater('response'), { status: 'SUCCESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'SUCCESS', 'Issued by the successful');
			});
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_13.thingInstructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722059: CMD instruction timeout is greater than zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_14.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_15.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
		});
	});

	describe('C1722060: CMD instruction timeout is greater than zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_16.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_17.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722061: CMD instruction  timeout is zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_18.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_19.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_20.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722062: CMD instruction The timeout is zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_21.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_22.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_23.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722063: CMD instruction The timeout is zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['cmd_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_24.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_25.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_26.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingInstanceData_11.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData_10.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class device model', function () {
			postDraftThingClass(draftThingClassData_6.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_6.thingClassBody);
		});

		describe('add attributes to unpublished thing class device model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_6.modelId, draftThingClassModelPropertiesData_6.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722064: CONFIG_GET instruction timeout is greater than zero  directly connected devices', function () {

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_6.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_6.modelId, thingInstanceData_6.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_6.thingInstanceBody);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_6.modelId, thingInstanceData_12.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_12.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_6.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_sub']);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_54.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_update_pub'], instructionData_6.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['config_update_pub'], instructionData_6.instructionBody, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'RECEIVED', 'Issued by the successful');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_6.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_sub'], store.getLater('message'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_55.instructionConfigRequestBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C1722065: CONFIG_GET instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_6.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_56.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_57.instructionConfigRequestBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
		});
	});

	describe('C1722066: CONFIG_GET instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_12.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_sub'],);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_58.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_59.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class gateway model', function () {
			postDraftThingClass(draftThingClassData_7.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_7.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_7.modelId, draftThingClassModelPropertiesData_7.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722067: CONFIG_GET instruction timeout is greater than zero gateway devices', function () {

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_7.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_7.modelId, thingInstanceData_7.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_7.thingInstanceBody);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_7.modelId, thingInstanceData_13.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_13.thingInstanceBody);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_7.modelId, thingInstanceData_15.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_60.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_gateway_pub'], instructionData_7.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['config_gateway_pub'], instructionData_7.instructionBody, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'RECEIVED', 'Issued by the successful');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_61.instructionConfigRequestBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C1722068: CONFIG_GET instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_62.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_63.instructionConfigRequestBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722069: CONFIG_GET instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_13.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_65.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_64.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class Not directly connected model', function () {
			postDraftThingClass(draftThingClassData_8.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_8.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_8.modelId, draftThingClassModelPropertiesData_8.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722070: CONFIG_GET instruction timeout is greater than zero _ Not directly connected devices', function () {

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_8.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_8.modelId, thingInstanceData_8.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_8.modelId, thingInstanceData_14.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_66.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_gateway_pub'], instructionData_8.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['config_gateway_pub'], instructionData_8.instructionBody, store.putLater('response'), { status: 'SUCCESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'SUCCESS', 'Issued by the successful');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_67.instructionConfigRequestBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C1722071: CONFIG_GET instruction timeout is greater than zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_68.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_69.instructionConfigRequestBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722072: CONFIG_GET instruction timeout is greater than zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_15.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_70.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_71.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722073: CONFIG_GET instruction The timeout is zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_6.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_72.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_73.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_74.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722074: CONFIG_GET instruction The timeout is zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_75.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_76.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_77.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722075: CONFIG_GET instruction The timeout is zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_7.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_gateway_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_78.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_79.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_80.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_6.modelId, thingInstanceData_6.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_6.modelId, thingInstanceData_12.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData_6.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_6.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_8.modelId, thingInstanceData_8.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_8.modelId, thingInstanceData_14.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData_8.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_8.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_7.modelId, thingInstanceData_7.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_7.modelId, thingInstanceData_13.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_7.modelId, thingInstanceData_15.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData_7.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_7.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class device model', function () {
			postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
		});

		describe('add attributes to unpublished thing class device model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722076: LIVE instruction timeout is greater than zero  directly connected devices', function () {

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData_3.modelId, createInstructionsData_3.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_3.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_3.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_3.thingInstanceBody);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_3.modelId, thingInstanceData_16.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_16.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub']);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_27.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['live_pub'], instructionData_3.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['live_pub'], instructionData_3.instructionBody, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'RECEIVED', 'Issued by the successful');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.getLater('message'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_28.thingInstructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C1722077: LIVE instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_29.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_30.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722078: LIVE instruction timeout is greater than zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_16.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'],);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_31.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_32.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class gateway model', function () {
			postDraftThingClass(draftThingClassData_4.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_4.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_4.modelId, draftThingClassModelPropertiesData_4.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722079: LIVE instruction timeout is greater than zero gateway devices', function () {

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData_4.modelId, createInstructionsData_4.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_4.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_4.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_4.thingInstanceBody);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_4.modelId, thingInstanceData_17.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData_17.thingInstanceBody);
		});


		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_33.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['live_pub'], instructionData_4.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['live_pub'], instructionData_4.instructionBody, store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'RECEIVED', 'Issued by the successful');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_34.thingInstructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C1722080: LIVE instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_35.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_36.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722081: LIVE instruction timeout is greater than zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_17.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_37.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_38.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('create environment dependent data', function () {

		describe('creation draft thing class Not directly connected model', function () {
			postDraftThingClass(draftThingClassData_5.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_5.thingClassBody);
		});

		describe('add attributes to unpublished thing class gateway model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_5.modelId, draftThingClassModelPropertiesData_5.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1722082: LIVE instruction timeout is greater than zero _ Not directly connected devices', function () {

		describe('create instructions template', function () {
			postInstructionTemplate(draftThingClassData_5.modelId, createInstructionsData_5.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData_5.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_5.modelId, thingInstanceData_5.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_5.modelId, thingInstanceData_18.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_39.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['cmd_pub'], instructionData_5.instructionBody);
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId2(store.getLater('requestId'), store.getLater('client'), topicDict['cmd_pub'], instructionData_5.instructionBody, store.putLater('response'), { status: 'SUCCESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'SUCCESS', 'Issued by the successful');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub']);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_40.thingInstructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C1722083: LIVE instruction timeout is greater than zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_41.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_42.thingInstructionRequestsBody, store.putLater('response1'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed null', function () {
			getSubMessage(store.getLater('message'), store.putLater('response1'), { flag: true });
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722084: LIVE instruction timeout is greater than zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_17.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub']);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_43.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('Query the execution of the request command', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Whether success can be issued', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.status === 'EXPIRED', 'retry: response status is: EXPIRED');
			});
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_44.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722085: LIVE instruction The timeout is zero  directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_45.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_46.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_47.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722086: LIVE instruction The timeout is zero gateway devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_48.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_49.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_50.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('C1722087: LIVE instruction The timeout is zero _Not directly connected devices', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscription', function () {
			subDataWithClient(store.getLater('client'), topicDict['live_sub'], store.putLater('response'));
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData_51.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_52.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('implementation instructions issued, Issue the next command', function () {
			postInstructionRequests(createInstructionsRequestData_53.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			// closeClient(store.getLater('client'));
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_3.modelId, thingInstanceData_3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_3.modelId, thingInstanceData_16.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_3.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_5.modelId, thingInstanceData_5.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_5.modelId, thingInstanceData_18.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchThingClassByModelID(draftThingClassData_5.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_5.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_4.modelId, thingInstanceData_4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_4.modelId, thingInstanceData_17.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_4.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});
});