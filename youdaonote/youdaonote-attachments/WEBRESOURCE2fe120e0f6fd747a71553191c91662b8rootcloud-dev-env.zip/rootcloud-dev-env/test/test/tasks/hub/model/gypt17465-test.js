'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, putDraftThingClassPropertiesByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, deleteDraftThingClassByModelID, patchThingClassByModelID, getDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, getThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { topicDict } = require('../../../../test-data/requireData');
const { postData } = require('../../../../test-data/util');
const { ThingClassData, postdata_1, postdata_2, postdata_3, PropertiesData_1, DeviceData_8, DeviceData_9, draftThingClassData, msgData2, msgData, draftThingClassPropertiesData, draftThingClassPropertiesData2, draftThingClassPropertiesData1, thingInstanceData, PropertiesData_2, PropertiesData_3, PropertiesData_4, PropertiesData_5, PropertiesData_6, PropertiesData_7, DeviceData_1, DeviceData_2, DeviceData_3, DeviceData_4, DeviceData_6, DeviceData_7, postdata } = require('../../../../test-data/data/tasks/hub/model/GYPT17465');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');

describe('GYPT-17465 : constant expression', function () {
	describe('precondition : create directed device model', function () {
		postDraftThingClass(ThingClassData.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2074521 : Define constant property successfully, Its type and value are correct', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_2.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getDraftThingClassPropertiesByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].propertyType', 'Number');
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[1].expression', '10.00');
	});

	describe('C2074522 : create a device and set a data, value is equal to the data', function () {
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_1.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_1.thingId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload.staticProperties[0].propertyName`, PropertiesData_2.name);
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload.staticProperties[0].propertyValueJson`, '10.00');

		postData(topicDict['pub_1.1'], DeviceData_1.thingId, postdata.mesBody);

		getRealTimeByModelAndThingId(DeviceData_1.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_2.name}.value`, 10.00);
	});

	describe('C2074523 : create a device and not set a data, give an error', function () {
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_2.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
	});

	describe('C2074524 : create a device without constant property, value is equal to original value', function () {
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_3.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_3.thingId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.staticProperties.length', 1);

		postData(topicDict['pub_1.1'], DeviceData_3.thingId, postdata_3.mesBody);

		getRealTimeByModelAndThingId(DeviceData_3.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_2.name}.value`, 10.00);
	});

	describe('C2074525 ：value is correct when expression includes constant', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_4.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_8.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], DeviceData_8.thingId, postdata_2.mesBody);

		getRealTimeByModelAndThingId(DeviceData_8.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_4.name}.value`, 6.00);
	});

	describe('C2074526 : constant expressions do not affect property priority', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_3.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_9.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], DeviceData_9.thingId, postdata_1.mesBody);

		getRealTimeByModelAndThingId(DeviceData_9.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_3.name}.value`, 2.00);
	});

	describe('C2074527 : post property, give an error when the expreession does not correspond to the propertyType', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_5.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('give a message when the expression does not correspond to the propertyType', function () {
			Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).message, 'expression type为constant时，表达式必须是一个合法的json. expression 字段值 hhh 不是合法的json');
		});
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2074528: post instance, give an error when the propertyValueJson does not correspond to the propertyType', function () {
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_4.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('give a message when the propertyValueJson does not correspond to the propertyType', function () {
			Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).message, 'propertyValueJson hhh 不是合法的json');
		});
	});

	describe('C2078397 : device with a non-existent property, query result does not contain this property', function () {
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_6.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_6.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		it('query result does not contain this property', function () {
			const keys_list = Object.keys(Response.getJsonBody(store.get('response')).payload);
			Response.bodyJsonEquals(keys_list.includes('staticProperties'), false);
		});
	});

	describe('C2078412 : Create the existing property of the device for the model, value is the device value', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_6.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_6.thingId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload.staticProperties[0].propertyValueJson`, '66.00');
	});

	describe('C2082803 : Create the existing property of the device for the model,  datatype is diffrent. value is the value of the model', function () {
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_7.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_7.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_7.thingId, store.putLater('response'));
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload.staticProperties[0].propertyValueJson`, '"7"');
	});

	describe('After modifying the data type of the attribute, give the number to the device to check whether the condition is successful', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post device model class properties1 by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post device model class properties2 by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('view thing model properties', function () {
			getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post data with mqtt', function () {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData.mesBody);
		});

		describe('query realTime data1', function () {
			getRealTimeByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2, name: draftThingClassPropertiesData1.name, value: 7 });
			Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassPropertiesData1.name}.value`, 7.00);
		});

		//更新属性1的类型为string
		describe('update device model class properties2 propertyType = string', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData2.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		//再次发布
		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post data with mqtt2', function () {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData2.mesBody);
		});

		describe('query realTime data2', function () {
			getRealTimeByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2, name: draftThingClassPropertiesData1.name, value: 23 });
			Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassPropertiesData1.name}.value`, 23.00);
		});

		describe('delete thing instances', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('delete thingClass1', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('delete thing instances1', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_1.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances3', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_3.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances6', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_6.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances7', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_7.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances7', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_8.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances7', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_9.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});