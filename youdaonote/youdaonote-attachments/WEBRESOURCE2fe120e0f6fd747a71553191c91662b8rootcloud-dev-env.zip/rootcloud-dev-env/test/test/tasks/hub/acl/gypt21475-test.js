'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { valDict } = require('../../../../test-data/requireData');
const { getDeviceInstances } = require('../../../../test-lib/openApi');
const { postDraftThingClass, patchDraftThingClassByModelID, postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, getThingInstancesByModelId, getThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { draftThingClassData, thingInstanceData, draftThingClassModelPropertiesData } = require('../../../../test-data/data/tasks/hub/acl/GYPT21475');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema, thingInstanceGetSchema, thingInstanceGetByModelIdSchema } = require('../../../../test-data/schema/thingInstance');
const { verifySchema, verifyPayload, verifyPayloadDeepEqual, verifyResponse } = require('../../../../test-verify/verify');
const { header, superUserToken, userToken } = require('../../../../test-data/data/adeployer/getToken');


describe('GYPT-21475: /acl test', function () {

	describe('c1849298 acl test', function () {

		const store = new DataStore();
		const queryDeviceByIdString = `?thingId=${thingInstanceData.thingId}`;

		before(function () {
			if (valDict.runEnv === 'local' || valDict.runEnv === 'ci') {
				this.skip();
			}
		});

		describe('post device model class with super user token', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'), { header: header, userKey: superUserToken });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create device with super user token', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'), { header: header, userKey: superUserToken });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		describe('get devcie with super user before acl test', function () {
			getDeviceInstances(store.putLater('getDeviceResponse'), { header: header, userKey: superUserToken, queryString: queryDeviceByIdString });
			verifySchema(store.getLater('getDeviceResponse'), thingInstanceGetSchema);
		});

		describe('get device with acl user', function () {
			const resBody = {
				payload: [
					{
						model: {},
						protocol: "TEST",
						userName: `${thingInstanceData.thingId}`
					}
				]
			};
			getDeviceInstances(store.putLater('response'), { header: header, userKey: userToken, queryString: queryDeviceByIdString });
			verifyPayloadDeepEqual(store.getLater('response'), resBody);
		});

		describe('get devcie with super user', function () {
			getDeviceInstances(store.putLater('response'), { header: header, userKey: superUserToken, queryString: queryDeviceByIdString });
			verifySchema(store.getLater('response'), thingInstanceGetSchema);
			verifyResponse(store.getLater('response'), store.getLater('getDeviceResponse'));
		});

		describe('get device by device type id with acl user', function () {
			getThingInstancesByModelId(draftThingClassData.modelId, store.putLater('response'), { header: header, userKey: userToken, queryString: queryDeviceByIdString });
			// TODO: GYPT-21213
		});

		describe('get devcie by device type id with super user', function () {
			getThingInstancesByModelId(draftThingClassData.modelId, store.putLater('response'), { header: header, userKey: superUserToken, queryString: queryDeviceByIdString });
			verifySchema(store.getLater('response'), thingInstanceGetByModelIdSchema);
			verifyPayload(store.getLater('response'), [thingInstanceData.thingInstanceBody]);
		});

		describe('get device by device type id and device id with acl user', function () {
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'), { header: header, userKey: userToken });
			// TODO: GYPT-21213
		});

		describe('get devcie by device type id and device id with super user', function () {
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'), { header: header, userKey: superUserToken });
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		describe('put device by device type id and device id with acl user', function () {

		});

		describe('get devcie with super user', function () {

		});

		describe('put device locations by devcie type id and device id with acl user', function () {

		});

		describe('get devcie with super user', function () {

		});
	});
});