'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass, patchDraftThingClassByModelID, postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');

const { postElecfenceByThingId, putElecfenceByThingId, deleteElecfenceByThingId, patchElecfenceByThingId } = require('../../../../test-lib/elecfence');
const { draftThingClassData,
    thingInstanceData,
    draftThingClassModelPropertiesData,
    elecfenceData,
    elecfenceData_1,
    elecfenceData_2,
    elecfenceData_3,
    elecfenceData_4,
    elecfenceData_5,
    elecfenceData_6,
    elecfenceData_7,
    elecfenceData_8,
    elecfenceData_9,
    elecfenceData_10,
    elecfenceData_11,
    elecfenceData_12,
    elecfenceData_13,
    elecfenceData_14,
    elecfenceData_15,
    elecfenceData_16,
    patchelecfence,
    patchelecfence_1 } = require('../../../../test-data/data/tasks/hub/elecfence/GYPT23810');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { errorResponseSchema } = require('../../../../test-data/schema/common');

const store = new DataStore();

describe('GYPT-23810: /elecfence', function () {

    describe('创建依赖环境', function () {
        postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), draftThingClassSchema);
        verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);

        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});

        patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});

        postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), thingInstancePostSchema);
        verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
    });

    describe('C2162556: 创建多边形的电子围栏成功', function () {
        postElecfenceByThingId(elecfenceData_1.elecfenceBody, store.putLater('response'), store.putLater('elecFenceRuleId'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2162611: 修改围栏状态为关闭，修改成功', function () {
        patchElecfenceByThingId(store.getLater('elecFenceRuleId'), patchelecfence.patchElecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('C2162606: 删除已关闭的围栏，删除成功', function () {
        deleteElecfenceByThingId(store.getLater('elecFenceRuleId'), store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('C2190330: 创建多边形的电子围栏，多边形点数小于3个时创建失败', function () {
        postElecfenceByThingId(elecfenceData_2.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162557: 创建圆形的电子围栏成功', function () {
        postElecfenceByThingId(elecfenceData.elecfenceBody, store.putLater('response'), store.putLater('elecFenceRuleId'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2162612: 修改围栏状态为失效，修改成功', function () {
        patchElecfenceByThingId(store.getLater('elecFenceRuleId'), patchelecfence_1.patchElecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2190327: 创建圆形的电子围栏,未设置半径时创建失败', function () {
        postElecfenceByThingId(elecfenceData_3.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162558: 创建路径的电子围栏成功', function () {
        postElecfenceByThingId(elecfenceData_4.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2190328: 创建路径的电子围栏，起止点缺失时创建失败', function () {
        postElecfenceByThingId(elecfenceData_5.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162559: 创建行政区域的电子围栏成功', function () {
        postElecfenceByThingId(elecfenceData_6.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2190329: 创建行政区域的电子围栏，未设置行政区域时创建失败', function () {
        postElecfenceByThingId(elecfenceData_7.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162560: 创建电子围栏时没有设备，创建失败', function () {
        postElecfenceByThingId(elecfenceData_8.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162563: 创建围栏时fenceType错误时，创建失败', function () {
        postElecfenceByThingId(elecfenceData_9.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162565: 创建围栏时起始时间晚于停止时间，创建失败 ', function () {
        postElecfenceByThingId(elecfenceData_10.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162566: 创建围栏时起始时间晚于停止时间，创建失败', function () {
        postElecfenceByThingId(elecfenceData_11.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162564:围栏创建成功后既是发布状态', function () {
        postElecfenceByThingId(elecfenceData_12.elecfenceBody, store.putLater('response'), store.putLater('elecFenceRuleId'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2162595:当围栏不存在时，更新失败', function () {
        putElecfenceByThingId('', elecfenceData_13.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 404);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162596: 更新围栏时没有设备，更新失败', function () {
        putElecfenceByThingId(store.getLater('elecFenceRuleId'), elecfenceData_14.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162598: 更新围栏时起始时间晚于停止时间，更新失败', function () {
        putElecfenceByThingId(store.getLater('elecFenceRuleId'), elecfenceData_15.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162599: 更新围栏时起始时间等于停止时间，更新失败', function () {
        putElecfenceByThingId(store.getLater('elecFenceRuleId'), elecfenceData_16.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2162605: 删除开启中的围栏，删除成功', function () {
        deleteElecfenceByThingId(store.getLater('elecFenceRuleId'), store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('C2162608: 删除不存在的围栏，删除失败', function () {
        deleteElecfenceByThingId('ghjhjk', store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 404);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });
});