'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { deviceStatusSchema, findDeviceStatusSchema } = require('../../../../test-data/schema/deviceOnlineStatus');
const { postData } = require('../../../../test-data/util');
const { draftThingClassData, draftThingClassPropertiesData, activeData, thingInstanceData, msgData, msgData1, thingInstanceData1 } = require('../../../../test-data/data/tasks/hub/instan/GYPT15212');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { getDevicesStatus, getDevicesStatusByRichFind, postDevicesStatusByRichFind } = require('../../../../test-lib/deviceOnlineStatus');
const { verifySchema, verifyPayload }  = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-15212: /test for device status', function () {

	describe('dependency data required to create environment', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device1 model instance by model id', function() {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
		//workingStatus=正常
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData.mesBody);
		});

		describe('post device2 model instance by model id', function() {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData1.thingInstanceBody);
		});
		//workingStatus=失败
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData1.mesBody);
		});
	});

	describe('GYPT-15212 filter equipment according to working status', function () {

		describe('C188468: Query the equipment whose workingStatus value exists', function () {

			getDevicesStatus(store.putLater('response'), {criteria: `workingStatus=正常`});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), deviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i<body.payload.length; i++){
					if ('正常' !== (body.payload[i].workingStatus))
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188469: query devices without workingStatus', function () {

			getDevicesStatus(store.putLater('response'), null);
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), deviceStatusSchema);
		});

		describe('C188470: Query devices whose working status value does not exist', function () {

			getDevicesStatus(store.putLater('response'), {criteria: 'workingStatus=失败'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), deviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if ('失败'!==(body.payload[i].workingStatus))
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188471: query device without entering working status', function () {

			getDevicesStatus(store.putLater('response'), null);
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), deviceStatusSchema);
		});

		describe('C188472: Query equipment according to working status and other conditions', function () {

			getDevicesStatus(store.putLater('response'), {criteria: `workingStatus=正常&thingId=${thingInstanceData.thingId}`});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), deviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if ('正常' !== (body.payload[i].workingStatus))
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C189211: Query the working status of the equipment corresponding to the equipment model', function () {

			getDevicesStatus(store.putLater('response'), {criteria: `workingStatus=正常&modelId=${draftThingClassData.modelId}`});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), deviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if ('正常' !== (body.payload[i].workingStatus))
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188473: Query the equipment whose working status value exists', function () {

			getDevicesStatusByRichFind(store.putLater('response'), {criteria: 'className=DeviceStatus&find={"workingStatus": {"$exists": true}}'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus === undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188474: Query devices whose working status value does not exist', function () {

			getDevicesStatusByRichFind(store.putLater('response'), {criteria: 'className=DeviceStatus&find={"workingStatus": {"$exists": false}}'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus !== undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188475: query equipment without working status', function () {

			getDevicesStatusByRichFind(store.putLater('response'), {criteria: 'className=DeviceStatus&find={"workingStatus": {"$exists": false}}'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus !== undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188476: Query equipment according to working status and other conditions', function () {

			getDevicesStatusByRichFind(store.putLater('response'), {criteria: 'className=DeviceStatus&find={"online":false, "workingStatus": "正常"}'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus === undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C189210: Query the working status of the equipment corresponding to the equipment model', function () {

			getDevicesStatusByRichFind(store.putLater('response'), {criteria: `className=DeviceStatus&find={"deviceTypeId": "${draftThingClassData.modelId}", "workingStatus": "正常"}`});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus === undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188477: Query the equipment whose working status value exists', function () {

			postDevicesStatusByRichFind({'className': 'DeviceStatus', 'find': '{"workingStatus": {"$exists": true}}'}, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus === undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188478: Query devices whose working status value does not exist', function () {

			postDevicesStatusByRichFind({'className': 'DeviceStatus', 'find': '{"workingStatus": {"$exists": false}}'}, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus !== undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188479: query devices without working status', function () {

			postDevicesStatusByRichFind({'className': 'DeviceStatus', 'find': '{"workingStatus": {"$exists": false}}'}, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus !== undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});

		describe('C188480: Query equipment according to working status and other conditions', function () {

			postDevicesStatusByRichFind({'className': 'DeviceStatus', 'find': '{"workingStatus": {"$exists": true}, "online": false}'}, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), findDeviceStatusSchema);
			it('verify data successfully', function () {
				const body = Response.getJsonBody(store.get('response'));
				let flag = true;
				for (let i = 0; i < body.payload.length; i++){
					if (body.payload[i].workingStatus === undefined)
						flag = false;
				}
				Assert.isTrue(flag, 'query data is abnormal');
			});
		});
	});

	describe('delete environmental data', function () {

		describe('delete workingStatus=失败 thing instances', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData1.thingId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete workingStatus=正常 thing instances', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thingClass', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});



