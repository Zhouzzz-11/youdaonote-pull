'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass } = require('../../../../test-lib/openApiThingClass');
const { postDraftThingInterfaces } = require('../../../../test-lib/openApiThingInterfaces');
const { draftDeviceThingClassData_1, draftDeviceThingClassData_2, draftGatewayThingClassData_1, draftGatewayThingClassData_2, draftGatewayThingClassData_3, draftThingInterfaceData_1, draftThingInterfaceData_2, draftThingInterfaceData_3, draftThingInterfaceData_4, draftDeviceThingClassData_3, headers, draftThingInterfaceData_5, draftThingInterfaceData_6, draftThingInterfaceData_7, draftDeviceThingClassData_4, deployerBody, deleteDeployerBody } = require('../../../../test-data/data/tasks/hub/model/GYPT19204');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInterfacesPostSchema } = require('../../../../test-data/schema/thingInterfaces');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { deployer, deleteDeployer } = require('../../../../test-lib/deployer');

const store = new DataStore();

describe('GYPT-19204: verify the uniqueness of the name of the thing class under individual tenant', function () {

	describe('C2074559: verify the uniqueness of thing class of type device', function () {
		//create a device model first and then create another device model with the same name
		describe('post first device model class', function () {
			postDraftThingClass(draftDeviceThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftDeviceThingClassData_1.thingClassBody);
		});

		describe('post second device model class with the same model name', function () {
			postDraftThingClass(draftDeviceThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			it('verify the failed response message', function () {
				const body = Response.getJsonBody(store.get('response'));
				const expectedMessage = 'name为'+draftDeviceThingClassData_2.name+'的模型已存在';
				Assert.strictEqual(body.message, expectedMessage, 'violate the uniqueness');
			});
		});
	});

	describe('C2074560: verify the uniqueness of thing class of type gateway', function () {
		//create a gateway model first and then create another gateway model with the same name
		describe('post first gateway model class', function () {
			postDraftThingClass(draftGatewayThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayThingClassData_1.thingClassBody);
		});

		describe('post second gateway model class with the same model name', function () {
			postDraftThingClass(draftGatewayThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			it('verify the failed response message', function () {
				const body = Response.getJsonBody(store.get('response'));
				const expectedMessage = 'name为'+draftGatewayThingClassData_2.name+'的模型已存在';
				Assert.strictEqual(body.message, expectedMessage, 'violate the uniqueness');
			});
		});
	});

	describe('C2074561: verify the uniqueness of thing class of type gateway and device', function () {
		//using the existed device model and create a gateway model which has the same name with that of the device model
		describe('post the gateway model which has the the same name with that of the created device model', function () {
			postDraftThingClass(draftGatewayThingClassData_3.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			it('verify the failed response message', function () {
				const body = Response.getJsonBody(store.get('response'));
				const expectedMessage = 'name为'+draftGatewayThingClassData_3.name+'的模型已存在';
				Assert.strictEqual(body.message, expectedMessage, 'violate the uniqueness');
			});
		});
	});

	describe('C2074573: verify the uniqueness of thing interfaces', function () {
		//create a thing interface and create another thing interface with the same name
		describe('post first thing interface', function () {
			postDraftThingInterfaces(draftThingInterfaceData_1.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), draftThingInterfaceData_1.draftThingInterfacesBody);
		});

		describe('post second thing interface with the same interface name', function () {
			postDraftThingInterfaces(draftThingInterfaceData_2.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			it('verify the failed response message', function () {
				const body = Response.getJsonBody(store.get('response'));
				const expectedMessage = 'name为'+draftThingInterfaceData_2.name+'的模型已存在';
				Assert.strictEqual(body.message, expectedMessage, 'violate the uniqueness');
			});
		});
	});

	describe('C2074574: verify the uniqueness of the name of thing interfaces and thing class', function () {
		//using the existed thing class of type device and create another thing interface with the same name as that of thing class.
		postDraftThingInterfaces(draftThingInterfaceData_3.draftThingInterfacesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('verify the failed response message', function () {
			const body = Response.getJsonBody(store.get('response'));
			const expectedMessage = 'name为'+draftThingInterfaceData_3.name+'的模型已存在';
			Assert.strictEqual(body.message, expectedMessage, 'violate the uniqueness');
		});
		//using the existed thing class of type gateway and create another thing interface with the same name as that of thing class.
		postDraftThingInterfaces(draftThingInterfaceData_4.draftThingInterfacesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('verify the failed response message', function () {
			const body = Response.getJsonBody(store.get('response'));
			const expectedMessage = 'name为'+draftThingInterfaceData_4.name+'的模型已存在';
			Assert.strictEqual(body.message, expectedMessage, 'violate the uniqueness');
		});
	});

	describe('create tenant and job', function() {
		//create another tenant
		deployer(deployerBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2074577: verify the name of thing class can be the same under different tenants ', function () {
		//using the existed tenant and create another tenant to create a thing class with the same name as that of the existed tenant.
		postDraftThingClass(draftDeviceThingClassData_3.thingClassBody, store.putLater('response'), {headers: headers});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftDeviceThingClassData_3.thingClassBody);
	});

	describe('C2074578: verify the name of thing interfaces can be the same under different tenants ', function () {
		//using the existed tenant and create another tenant to create a thing interface with the same name as that of the existed tenant.
		postDraftThingInterfaces(draftThingInterfaceData_5.draftThingInterfacesBody, store.putLater('response'), {headers: headers});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), thingInterfacesPostSchema);
		verifyPayload(store.getLater('response'), draftThingInterfaceData_5.draftThingInterfacesBody);
	});

	describe('C2074580: verify the name of thing interface and thing class can be the same under different tenants ', function () {
		//using a new class name of device type under one tenant and create another thing interface with the same name as that of the device under a different tenant.
		postDraftThingClass(draftDeviceThingClassData_4.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftDeviceThingClassData_4.thingClassBody);
		postDraftThingInterfaces(draftThingInterfaceData_6.draftThingInterfacesBody, store.putLater('response'), {headers: headers});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), thingInterfacesPostSchema);
		verifyPayload(store.getLater('response'), draftThingInterfaceData_6.draftThingInterfacesBody);
		//using the existed class name of gateway type under one tenant and create another thing interface with the same name as that of the gateway under a different tenant.
		postDraftThingInterfaces(draftThingInterfaceData_7.draftThingInterfacesBody, store.putLater('response'), {headers: headers});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), thingInterfacesPostSchema);
		verifyPayload(store.getLater('response'), draftThingInterfaceData_7.draftThingInterfacesBody);
	});

	describe('delete tenant and job', function() {
		//delete the created tenant
		deleteDeployer(deleteDeployerBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});


});




