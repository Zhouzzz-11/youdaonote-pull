'use strict';

const { DataStore,Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { valDict } = require('../../../../test-data/requireData');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { putUserAclGroup } = require('../../../../test-lib/getToken');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { postAclGroups1 } = require('../../../../test-lib/openApi');
const { postInstructionTemplate, getInstructionTemplate_1, getThingInstructionTemplate, getThingInstructionTemplate_1 } = require('../../../../test-lib/instructionTemplate');
const {
	draftThingClassData_1,
	draftThingClassData_2,
	thingInstanceData_1,
	thingInstanceData_2,
	createInstructionsData_1,
	createInstructionsData_2,
	postDevicePermissionData_1,
	postDevicePermissionData_2,
	postDevicePermissionData_3,
	draftThingClassPropertiesData,
} = require('../../../../test-data/data/tasks/hub/acl/GYPT23809');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { postUserData1 } = require('../../../../test-data/data/adeployer/getToken');

const store = new DataStore();


describe('GYPT-23809: test issuing the acl of instruction template', function () {

	before(function () {
		if (valDict.runEnv === 'local' || valDict.runEnv === 'ci') {
			this.skip();
		}
	});

	describe('precondition', function () {
		//建模型-属性-发布
		describe('post published device model class with super user token', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('post unpublished device model class with super user token', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post unpublished device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create active instructions', function () {
			postInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData_1.instructionsBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('create draft instructions', function () {
			postInstructionTemplate(draftThingClassData_2.modelId, createInstructionsData_2.instructionsBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create published device with super user token', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('create unpublished device with super user token', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_2.thingInstanceBody);
		});

		describe('query instructions and get instructionTemplate _id', function () {
			getThingInstructionTemplate_1(draftThingClassData_1.modelId, store.putLater('response'), store.putLater('_id'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2125989: test creating permission set of CMD instruction', function () {
		describe('Create a device permission set, name：0, id:1', function () {
			postAclGroups1(postDevicePermissionData_1, store.getLater('_id'), store.putLater('response'), store.putLater('aclGroupId'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2125990: add device permission set to user, name：0, id:1', function () {
		putUserAclGroup(postUserData1.userId, store.getLater('aclGroupId'), store.putLater('response1'), {
			header: true,
			userKey: 'superUserToken'
		});
		Response.statusCodeEquals(store.getLater('response1'), 200);
	});

	describe('C2125993: query instructions using commonUerToken, setting the name：0, id:1', function () {
		getThingInstructionTemplate(draftThingClassData_1.modelId, store.putLater('response'), {
			header: true,
			userKey: 'commonUserToken',
			instructionTemplateId: createInstructionsData_1.instructionTemplateId
		});
		Response.statusCodeEquals(store.getLater('response'), 200);
		it('test', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.isTrue(body.payload[0].name == undefined, 'name is not read as expected');
		});
	});

	describe('C2125994: query instructions using commonUerToken, setting the name:1, id:0', function () {
		describe('Create a device permission set, name:1, id:0', function () {
			postAclGroups1(postDevicePermissionData_2, store.getLater('_id'), store.putLater('response'), store.putLater('aclGroupId'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('C2125990: add device permission set to user, name:1, id:0', function () {
			putUserAclGroup(postUserData1.userId, store.getLater('aclGroupId'), store.putLater('response1'), {
				header: true,
				userKey: 'superUserToken'
			});
			Response.statusCodeEquals(store.getLater('response1'), 200);
		});
		describe('query instruction, name:1, id:0', function () {
			getThingInstructionTemplate(draftThingClassData_1.modelId, store.putLater('response'), {
				header: true,
				userKey: 'commonUserToken',
				instructionTemplateId: createInstructionsData_1.instructionTemplateId
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('test', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].name != undefined, 'name is  read as expected');
			});
		});
	});

	describe('C2125991: The permission set can be defined without deviceDownStream field', function () {
		describe('Create a device permission set, name:1, id:0', function () {
			postAclGroups1(postDevicePermissionData_1, store.getLater('_id'), store.putLater('response'), store.putLater('aclGroupId'), {
				header: true,
				userKey: 'superUserToken',
				noDownStream: true
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2125992: The permission set can be defined without instructionTemplate portion', function () {
		describe('Create a device permission set, name:1, id:0', function () {
			postAclGroups1(postDevicePermissionData_2, store.getLater('_id'), store.putLater('response'), store.putLater('aclGroupId'), {
				header: true,
				userKey: 'superUserToken',
				noTemplate: true
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2125998: The permission set can be defined using draft instruction template', function () {
		getInstructionTemplate_1(draftThingClassData_2.modelId, store.putLater('response'), store.putLater('_id'), {
			header: true,
			userKey: 'superUserToken',
		});
		Response.statusCodeEquals(store.getLater('response'), 200);

		postAclGroups1(postDevicePermissionData_3, store.getLater('_id'), store.putLater('response'), store.putLater('aclGroupId'), {
			header: true,
			userKey: 'superUserToken',
		});
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2125997: The permission set can be defined using non-existed templateId', function () {
		postAclGroups1(postDevicePermissionData_3, store.getLater('_id'), store.putLater('response'), store.putLater('aclGroupId'), {
			header: true,
			userKey: 'superUserToken',
			wrongTemplateId: true
		});
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('clear environments', function () {
		describe('delete device instances', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingInstanceData_1.thingId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken',
			});
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);

			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingInstanceData_2.thingId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken',
			});
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('delete device model class by model Id', function () {
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken',
			});
			Response.statusCodeEquals(store.getLater('response'), 200);

			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken',
			});
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);

			patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken',
			});
			Response.statusCodeEquals(store.getLater('response'), 200);

			deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'), {
				header: true,
				userKey: 'superUserToken',
			});
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});