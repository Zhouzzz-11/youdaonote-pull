'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { responseBulkAlarmType } = require('../../../../test-data/schema/alarmType.js');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { ALarmBulkType_c1, ALarmBulkType_T, postAlarmType, postAlarmType_1, postAlarmType_2, postAlarmType_3, postAlarmType_4, postAlarmType_5, postAlarmType_6, postAlarmType_7, draftThingClassData, draftThingClassModelPropertiesData_1, draftThingClassData_1, postAlarmSeverities, postAlarmCategories, draftThingClassModelPropertiesData } = require('../../../../test-data/data/tasks/hub/alarm/GYPT29575');
const { getAlarmTypes, createAlarmSeverities, createAlarmCategories, createBulkAlarmType, deleteBulkAlarmType, deleteAlarmSeverities, deleteAlarmCategories } = require('../../../../test-lib/alarmType');

const store = new DataStore();
describe('GYPT-29575: 增加批量导入报警接口', function () {

  describe('post draft device class', function () {
    postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('post draft device class 1', function () {
    postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('Successfully added properties to the first model', function () {
    postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('Successfully added properties to the second model', function () {
    postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('patch device model class by model id', function () {
    patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('active device second model class by model id', function () {
    patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('create alarm category', function () {
    //创建警报类别
    createAlarmCategories(postAlarmCategories.alarmCategoriesBody, store.putLater('response'), store.putLater('cid1'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('create alarm levels', function () {
    //创建警报级别
    createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
    //Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('C2480789: 批量导入时modelId存在，导入成功', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType.createBulkAlarmType, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifySchema(store.getLater('response'), responseBulkAlarmType);
  });

  describe('C2480781: 批量导入时modelId不存在，导入失败并给出错误提示', function () {
    createBulkAlarmType('', postAlarmType.createBulkAlarmType, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 404);
  });

  describe('C2480782: 批量导入时报警定义不符合规则，导入失败并给出错误提示', function () {
    createBulkAlarmType(draftThingClassData_1.modelId, postAlarmType_1.createBulkAlarmType, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 400);
    Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', 'body中的condition不能为空');
  });

  describe('C2480792: 批量导入时requestbody包含相同的报警定义，导入失败并给出提示', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType.createBulkAlarmType, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 400);
    Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', `body中的报警ID ${postAlarmType.name} 已经存在`);
  });

  describe('C2480783: 批量导入时选择部分成功，则当遇到导入失败时其他合规报警能成功导入', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType_2.createBulkAlarmType, store.putLater('response'), { criteria: 'partialAdd= ture' });
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifySchema(store.getLater('response'), responseBulkAlarmType);
  });

  describe('C2480784: 批量导入时不选择部分成功，则当遇到导入失败时全部都导入失败', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType_3.createBulkAlarmType, store.putLater('response'), { criteria: 'partialAdd= false' });
    Response.statusCodeEquals(store.getLater('response'), 400);
  });

  describe('C2480785: 批量导入时选择重名强制覆盖，则导入成功，重名的报警定义被新参数覆盖', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType_4.createBulkAlarmType, store.putLater('response'), { criteria: 'forceUpdate=true' });
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifySchema(store.getLater('response'), responseBulkAlarmType);
  });

  describe('C2480786: 批量导入时不选择重名强制覆盖，则导入失败，重名的报警定义未被改变', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType_5.createBulkAlarmType, store.putLater('response'), { criteria: 'forceUpdate=false' });
    Response.statusCodeEquals(store.getLater('response'), 400);
  });

  describe('C2480787: 批量导入时不选择部分成功和重名强制覆盖，则均按照false处理', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType_6.createBulkAlarmType, store.putLater('response'), { criteria: 'partialAdd= false & forceUpdate= true' });
    Response.statusCodeEquals(store.getLater('response'), 400);
  });

  describe('C2480788: 批量导入时同时选择部分成功和重名强制覆盖，则满足条件才能成功导入', function () {
    createBulkAlarmType(draftThingClassData.modelId, postAlarmType_7.createBulkAlarmType, store.putLater('response'), { criteria: 'partialAdd= true & forceUpdate= true' });
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifySchema(store.getLater('response'), responseBulkAlarmType);
  });

  describe('C2480790: 批量导入300条报警，导入成功', function () {
    createBulkAlarmType(draftThingClassData.modelId, ALarmBulkType_c1, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('C2480791: 批量导入超过300条报警，导入失败，并给出提示', function () {
    createBulkAlarmType(draftThingClassData.modelId, ALarmBulkType_T, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 400);
    Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', '批量创建报警定义数(303)超过了限制(300)');
  });

  //删除模型
  describe('patch thing class', function () {
    patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('patch thing class_1', function () {
    patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
  });

  describe('delete draft device class by model Id', function () {
    deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 204);
  });

  describe('delete draft device class by model Id', function () {
    deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 204);
  });

  //删除报警器相关
  describe('restore the environment Bulk Alarm Type', function () {
    //delete Bulk Alarm Type
    deleteBulkAlarmType(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
    getAlarmTypes(store.putLater('response'), {});
  });

  describe('restore the environment Bulk Alarm Type_1', function () {
    //delete Bulk Alarm Type
    deleteBulkAlarmType(draftThingClassData_1.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('restore the environment alarm level', function () {
    //delete alarm level
    deleteAlarmSeverities(store.getLater('level'), store.putLater('response'));
    //Response.statusCodeEquals(store.getLater('response'), 200);
    //verifyPayload(store.getLater('response'), {});
  });

  describe('restore the environment alarm category', function () {
    //delete alarm category
    deleteAlarmCategories(store.getLater('cid1'), store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });
});