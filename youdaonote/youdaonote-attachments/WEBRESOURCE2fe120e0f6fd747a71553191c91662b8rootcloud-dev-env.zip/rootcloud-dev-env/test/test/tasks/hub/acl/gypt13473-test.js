'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { valDict } = require('../../../../test-data/requireData');
const { postDraftThingClass, deleteDraftThingClassByModelID,patchThingClassByModelID, postDraftThingClassPropertiesByModelID,patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { putUserAclGroup } = require('../../../../test-lib/getToken');
const { putThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { postAclGroups, getDeviceInstances } = require('../../../../test-lib/openApi');
const {
	draftThingClassData,
	thingInstanceData1,
	postDevicePermissionData1,
	updateThingInstanceData1,
	header,
	superUserToken,
	updateThingInstanceData,
	commonUserToken,
	draftThingClassModelPropertiesData
} = require('../../../../test-data/data/tasks/hub/acl/GYPT13473');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { postUserData1 } = require('../../../../test-data/data/adeployer/getToken');

const store = new DataStore();


describe('GYPT-13473 : End-to-end testing of device model permission control', function () {

	const queryDeviceByIdString = `?thingId=${thingInstanceData1.thingId}`;

	before(function () {
		if (valDict.runEnv === 'local' || valDict.runEnv === 'ci') {
			this.skip();
		}
	});

	describe('start', function () {
		describe('post device model class with super user token', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'),{
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'),{
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('create device1 with super user token', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData1.thingInstanceBody, store.putLater('response'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData1.thingInstanceBody);
		});

	});

	describe('c188701:  Creates a device permission set and assigns it to a user who has access to the device within the permission', function () {
		describe('Create a device permission set', function () {
			postAclGroups(postDevicePermissionData1, store.putLater('response'), store.putLater('aclGroupid'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Add device permission set to user', function () {
			putUserAclGroup(postUserData1.userId, store.getLater('aclGroupid'), store.putLater('response'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('The user has access to the device within the permissions', function () {
			getDeviceInstances(store.putLater('response'), {
				header: header,
				userKey: commonUserToken,
				queryString: queryDeviceByIdString
			});
			Response.statusCodeEquals(store.getLater('response'), 200);

		});
	});

	describe('c188702:  Creates a device permission set and assigns it to a user who can access the properties within the permission', function () {
		describe('The user can access the property within the permission', function () {
			getDeviceInstances(store.putLater('response'), {
				header: header,
				userKey: commonUserToken,
				queryString: queryDeviceByIdString
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('user can read the property', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].assetId != undefined, 'ruturn true');
			});
		});
	});

	//只读
	describe('c188703:  Permissions on properties: read - only, verify compliance', function () {
		describe('The user can access the property within the permission', function () {
			getDeviceInstances(store.putLater('response'), {
				header: header,
				userKey: commonUserToken,
				queryString: queryDeviceByIdString
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('user can read the property', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].assetId != undefined, 'ruturn true');
			});
		});
	});

	//只写
	describe('c188704:  Permissions on properties: write only, verify compliance', function () {
		describe('The user can not access the property within the permission', function () {
			getDeviceInstances(store.putLater('response'), {
				header: header,
				userKey: commonUserToken,
				queryString: queryDeviceByIdString
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('user can not read the property', () => {
				const body = Response.getJsonBody(store.get('response'));
				if (body.payload.name == undefined) {
					Assert.isTrue(true, 'ruturn true');
				}
			});
		});
		describe('Users can modify properties with permissions', function () {
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData1.thingId, updateThingInstanceData.thingInstanceBody, store.putLater('response'), {
				header: header,
				userKey: commonUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	//读写
	describe('c188705:  Set permissions on properties: read and write, verify compliance', function () {
		describe('The user can  access the property within the permission', function () {
			getDeviceInstances(store.putLater('response'), {
				header: header,
				userKey: commonUserToken,
				queryString: queryDeviceByIdString
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('user can read the property', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].userName != undefined, 'ruturn true');
			});

		});

		describe('Users can modify properties with permissions', function () {
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData1.thingId, updateThingInstanceData1.thingInstanceBody, store.putLater('response'), {
				header: header,
				userKey: commonUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	//不可读不可写
	describe('c188706:  Set permissions on properties: unreadable and unwritable, verify compliance', function () {
		describe('The user can not access the property within the permission', function () {
			getDeviceInstances(store.putLater('response'), {
				header: header,
				userKey: commonUserToken,
				queryString: queryDeviceByIdString
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('user can not read the property', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].classId == undefined, 'ruturn true');
			});
		});
	});

	describe('end', function () {
		describe('delete device1 class', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData1.thingId, store.putLater('response'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'),{
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete device model class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'), {
				header: header,
				userKey: superUserToken
			});
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

});
