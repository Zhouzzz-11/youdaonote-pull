'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
    draftThingClassModelPropertiesData,
    thingClassModelInstanceData,
    draftThingClassData_1,
    thingClassModelInstanceData_1,
    activeData,
    draftThingClassData_2,
    draftThingClassModelPropertiesData_1,
    draftThingClassModelPropertiesData_4,
    msgData,
    draftThingClassData_3,
    postAlarmCategories,
    postAlarmSeverities,
    draftThingClassModelPropertiesData_2,
    draftThingClassModelPropertiesData_3,
    postAlarmTypeData,
    thingClassModelInstanceData_3,
    msgData_1,
    draftThingClassData_4,
    draftThingClassData_5
} = require('../../../../test-data/data/tasks/hub/instan/GYPT29585');
const { topicDict } = require('../../../../test-data/requireData');
const { getMqttClient, postDataWithClient } = require('../../../../test-lib/mqtt');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, putDraftThingClassByModelID, getThingClassByModelID, getThingClassPropertiesByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { getDeviceByDeviceOnlineStatusId } = require('../../../../test-lib/singleDevice');
const { createAlarmCategories, createAlarmSeverities, createAlarmType, deleteAlarmSeverities, deleteAlarmCategories } = require('../../../../test-lib/alarmType');
const { responseAlarmCategories, responseAlarmType, responseAlarmHistory } = require('../../../../test-data/schema/alarmType');
const { getRealTimeByModelAndThingId, getHistorianByModelAndThingId, getAlarmAll } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload, verifyMultiSchema } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-29585: 设备管理员可以使用非直连的online属性', function () {
    //记录实时工况的online数据
    let realTime_1 = undefined;
    //记录历史工况的online数据
    let Historian_2 = undefined;
    describe(' Create/Delete no Direct link device', function () {

        describe('post device model class', function () {
            postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_4.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('active device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post gateway device model instance by model id', function () {
            postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
            verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
        });
    });

    describe('C2662405: 创建模型，模型已有预置属性__online__，且是启用状态', function () {

        describe('post No Direct link device model class', function () {
            postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
        });
        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('active device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData_2.modelId, activeData, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('get device model class properties by model id', function () {
            getThingClassPropertiesByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].name', '__online__');
        });
    });

    describe('C2662420: 非直连模型__online__属性的表达式中，值默认是true', function () {

        describe('post No Direct link device model class', function () {
            postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('active device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData_1.modelId, activeData, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('get device model class properties by model id', function () {
            getThingClassPropertiesByModelID(draftThingClassData_1.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].expression', '$connect("__online__", true)');

        });
    });

    describe('C2662416: 从未上数的设备，则__online__没有值，firstDataTime没有值。设备状态是未激活', function () {

        describe('post No Direct link device model class,never online', function () {
            postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
        });

        describe('No Direct link status check,never online', function () {
            getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'), { flag: false });
            Response.statusCodeEquals(store.getLater('response'), 200);
            it('check access is in response', () => {
                const body = Response.getJsonBody(store.get('response'));
                Assert.isFalse(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does not contain the firstDataTime field');
                Assert.isFalse(Object.prototype.hasOwnProperty.call(body.payload, '__online__'), 'check does not contain the __online__ field');
            });
        });
    });

    describe('C2662418: 给设备上数，__online__的值为true，设备显示在线', function () {

        describe('post data with mqtt', function () {
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
        });

        describe(' No Direct link device status check, ', function () {
            after(() => {
                const client = store.get('client');
                client.end();
            });
            getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'), { flag: true });
            Response.statusCodeEquals(store.getLater('response'), 200);
            it('check access is in response', () => {
                const body = Response.getJsonBody(store.get('response'));
                Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
            });
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.online', true);
        });
    });

    describe('C2662417: 上过数的设备，则__online__有值，firstDataTime有值，设备状态是离线/在线', function () {

        describe(' No Direct link device status check ', function () {
            after(() => {
                const client = store.get('client');
                client.end();
            });
            getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'), { flag: true });
            Response.statusCodeEquals(store.getLater('response'), 200);
            it('check access is in response', () => {
                const body = Response.getJsonBody(store.get('response'));
                Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
            });
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.online', true);
        });
    });

    describe('C2662407&C2662409: 查看__online__的实时工况，查询的数据正确', function () {

        describe(' No Direct link device status check ', function () {

            getRealTimeByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            it('verify the response message', function () {
                const body = Response.getJsonBody(store.get('response'));
                realTime_1 = body.payload[0].data['__online__.connected'].value;
            });
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].data[\'__online__.connected\'].value', true);
        });
    });

    describe('C2662408: 查看__online__的历史工况，查询的数据正确', function () {

        describe(' No Direct link device status check ', function () {
            getHistorianByModelAndThingId(thingClassModelInstanceData_1.thingId, draftThingClassData_1.modelId, msgData.tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
            Response.statusCodeEquals(store.getLater('response'), 200);
            it('check access is in response', () => {
                it('verify the response message', function () {
                    const body = Response.getJsonBody(store.get('response'));
                    Historian_2 = body.payload[0].data['__online__.connected'].value;
                    Assert.strictEqual(realTime_1, Historian_2, 'The online value should be equal');
                });
                Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][0].length != 0, true);
                Response.bodyJsonEquals(Response.getJsonBody(store.get('response')).payload[0].rows[0][1], true);
            });
        });
    });

    describe('C2662410: __online__参与报警，正确触发报警', function () {
        describe('create the first alarm category', function () {
            createAlarmCategories(postAlarmCategories.alarmCategoriesBody, store.putLater('response'), store.putLater('cid1'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), responseAlarmCategories);
            verifyPayload(store.getLater('response'), postAlarmCategories.alarmCategoriesBody);
        });

        describe('create alarm levels', function () {
            createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
            //Response.statusCodeEquals(store.getLater('response'), 200);
        });

        describe('post No Direct link device model class', function () {
            postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post device model class properties by model id', function () {
            postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('create alarm type', function () {
            createAlarmType(postAlarmTypeData.alarmTypeBody, store.putLater('response'), store.putLater('id'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), responseAlarmType);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData.alarmTypeBody.alarmTypeId);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData.alarmTypeBody.categoryIds[0]);
        });

        describe('active device model class by model id', function () {
            patchDraftThingClassByModelID(draftThingClassData_3.modelId, activeData, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('post No Direct link device model class', function () {
            postThingInstancesByModelId(draftThingClassData_3.modelId, thingClassModelInstanceData_3.thingInstanceBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), thingInstancePostSchema);
        });

        describe('post data with mqtt', function () {
            getMqttClient(thingClassModelInstanceData.thingId, (client) => {
                store.put('client', client);
            });
            postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
        });

        describe('verify alarm sent successfully', function () {
            after(() => {
                const client = store.get('client');
                client.end();
            });
            getAlarmAll(store.putLater('responseHistory'), { retryCode: 404, expectNum: 1, criteria: `thingIds=["${thingClassModelInstanceData_3.thingId}"]` });
            Response.statusCodeEquals(store.getLater('responseHistory'), 200);
            verifyMultiSchema(store.getLater('responseHistory'), responseAlarmHistory);
        });
    });

    describe('C2662411：离线检测周期默认是120s', function () {

        describe('get draft thing model class', function () {
            getThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.offlineCheckPeriod', 120000);
        });
    });

    describe('C2662412: 离线检测周期默认是60s', function () {

        describe('put draft thing model class', function () {
            putDraftThingClassByModelID(draftThingClassData_2.modelId, draftThingClassData_4.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.offlineCheckPeriod', 60000);
        });
    });

    describe('C2662413: 离线检测周期小于60s，给出错误提示', function () {

        describe('put draft thing model class', function () {
            putDraftThingClassByModelID(draftThingClassData_2.modelId, draftThingClassData_5.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 400);
            Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', '离线检查周期不能小于60000 毫秒');

        });
    });

    describe('删除依赖环境', function () {

        describe('delete thing  instances', function () {
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
            deleteThingInstancesByModelIdAndThingId(draftThingClassData_3.modelId, thingClassModelInstanceData_3.thingId, store.putLater('response'));
            deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('un-publish thingClass', function () {
            patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            patchThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
            patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifyPayload(store.getLater('response'), {});
        });

        describe('delete thing  model', function () {
            deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
            deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });

        describe('delete alarm Categories', function () {
            deleteAlarmCategories(store.getLater('cid1'), store.putLater('response'));
        });

        describe('delete alarm Severities', function () {
            deleteAlarmSeverities(store.getLater('level'), store.putLater('response'));
        });
    });
});   