'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassSchema, draftCompositeThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema, thingInstanceCompositeBulkSchema } = require('../../../../test-data/schema/thingInstance');
const { 
	draftThingClassData_1,
	draftThingClassPropertiesData_1,
	thingInstanceData_1,
	draftCompositeThingClassData_1,
	draftThingClassData_2,
	draftThingClassPropertiesData_2,
	thingInstanceData_2,
	draftCompositeThingClassData_2,
	draftThingClassData_3,
	draftThingClassPropertiesData_3,
	thingInstanceData_3,
	draftCompositeThingClassData_3,
	draftThingClassData_4,
	draftThingClassPropertiesData_4,
	thingInstanceData_4,
	draftCompositeThingClassData_4,
	thingClassModelInstanceCompositeThingBulkData_1,
	thingClassModelInstanceCompositeThingBulkData_2
} = require('../../../../test-data/data/tasks/hub/instan/GYPT20509');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID,patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, postThingInstancesBulk } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload }  = require('../../../../test-verify/verify');

const store = new DataStore();

describe('/e2e test for bulk add thing-instances', function () {
	//复合物实例批量创建
	describe('GYPT-20509: bulk add thing-instances', function () {
		//创建物模型1
		describe('post draft thing-class', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});
		//一把梭1
		describe('post draft thing-class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
		//发布物模型
		describe('Publishing unpublished object models 1', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
		//创建设备实例1
		describe('post device-instance by model id', function() {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			//TODO: need to add verification to payload
		});
		//创建复合物模型1
		describe('post draft composite thing-class', function () {
			postDraftThingClass(draftCompositeThingClassData_1.CompositeThingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			//TODO: need to add verification to payload
		});
		//创建物模型2
		describe('post draft thing-class', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});
		//一把梭2
		describe('post draft thing-class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassPropertiesData_2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
		//发布物模型2
		describe('Publishing unpublished object models 2', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
		//创建设备实例2
		describe('post device-instance by model id', function() {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			//TODO: need to add verification to payload
		});
		//创建复合物模型2
		describe('post draft composite thing-class', function () {
			postDraftThingClass(draftCompositeThingClassData_2.CompositeThingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			//TODO: need to add verification to payload
		});
		//批量创建复合物实例1
		describe('C1849317: post bulk add composite thing-instances', function () {
			postThingInstancesBulk(thingClassModelInstanceCompositeThingBulkData_1.CompositeThingBulkBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeBulkSchema);
			//TODO: need to add verification to payload
		});

		//验证部分成功部分失败
		describe('C1849319: support partial success and partial failure', function () {
			//创建物模型3
			describe('post draft thing-class', function () {
				postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
			});
			//一把梭3
			describe('post draft thing-class properties by model id', function () {
				postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassPropertiesData_3.thingPropertiesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			//发布物模型3
			describe('Publishing unpublished object models 3', function () {
				patchDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			//创建设备实例3
			describe('post device-instance by model id', function() {
				postThingInstancesByModelId(draftThingClassData_3.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInstancePostSchema);
				//TODO: need to add verification to payload
			});
			//创建复合物模型3
			describe('post draft composite thing-class', function () {
				postDraftThingClass(draftCompositeThingClassData_3.CompositeThingClassBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
				//TODO: need to add verification to payload
			});
			describe('post draft thing-class properties by model id', function () {
				postDraftThingClassPropertiesByModelID(draftCompositeThingClassData_3.modelId, draftThingClassPropertiesData_2.thingPropertiesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			//发布物模型2
			describe('Publishing unpublished object models 2', function () {
				patchDraftThingClassByModelID(draftCompositeThingClassData_3.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			//创建物模型4
			describe('post draft thing-class', function () {
				postDraftThingClass(draftThingClassData_4.thingClassBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftThingClassData_4.thingClassBody);
			});
			//一把梭4
			describe('post draft thing-class properties by model id', function () {
				postDraftThingClassPropertiesByModelID(draftThingClassData_4.modelId, draftThingClassPropertiesData_4.thingPropertiesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			//发布物模型4
			describe('Publishing unpublished object models 4', function () {
				patchDraftThingClassByModelID(draftThingClassData_4.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
			//创建设备实例4
			describe('post device-instance by model id', function() {
				postThingInstancesByModelId(draftThingClassData_4.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInstancePostSchema);
				//TODO: need to add verification to payload
			});
			//创建复合物模型4
			describe('post draft composite thing-class', function () {
				postDraftThingClass(draftCompositeThingClassData_4.CompositeThingClassBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
				//TODO: need to add verification to payload
			});
			//删除复合物模型4
			describe('delete draft composite thing-class by model id', function () {
				deleteDraftThingClassByModelID(draftCompositeThingClassData_4.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);

			});
			//批量创建复合物实例2
			describe('partial success and partial failure', function(){
				postThingInstancesBulk(thingClassModelInstanceCompositeThingBulkData_2.CompositeThingBulkBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInstanceCompositeBulkSchema);
				//TODO: need to add verification to payload
				it('verify partial success and partial failure', () => {
					const body = Response.getJsonBody(store.get('response'));
					Assert.strictEqual(true, body.payload[0].success, 'return true');
					Assert.strictEqual(false, body.payload[1].success, 'return false');
				});
			});
		
		});
	});
});