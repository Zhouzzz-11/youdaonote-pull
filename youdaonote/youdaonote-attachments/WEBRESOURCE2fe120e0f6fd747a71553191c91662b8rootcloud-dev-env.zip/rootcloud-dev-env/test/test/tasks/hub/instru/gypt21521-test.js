'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	createInstructionsData_1,
	updateInstructionsData,
	updateInstructionsData_1 } = require('../../../../test-data/data/tasks/hub/instru/GYPT21521');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');

const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postInstructionTemplate, deleteInstructionTemplate, putInstructionTemplate } = require('../../../../test-lib/instructionTemplate');

const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-21521: Instruction template data structure modification', function () {

	describe('Add device properties to create instruction template _LIVE', function () {

		describe(' Create draft thing class ', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe(' Create draft thing class properties ', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C1880649: Add device properties to create instruction template _LIVE ', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.type', 'LIVE');
		});

		describe('C1880651:  Modification of  instructions succeeded', function () {
			putInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, updateInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.name', 'tag');
		});

		describe(' delete  instructions ', function () {
			deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe(' delete draft thing class ', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('Add device properties to create instruction template _CMD', function () {

		describe(' Create draft thing class ', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe(' Create draft thing class properties ', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C1880650: Add device properties to create instruction template _CMD ', function () {
			postInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.type', 'CMD');
		});

		describe('C1880652:  Modification of unpublished instructions succeeded', function () {
			putInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData_1.instructionTemplateId, updateInstructionsData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.name', 'tager');
		});

		describe(' delete instructions ', function () {
			deleteInstructionTemplate(draftThingClassData_1.modelId, createInstructionsData_1.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});