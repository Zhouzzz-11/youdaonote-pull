'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsTemplateData,
	createInstructionsTemplateData_1,
	createInstructionsTemplateData_2,
	createInstructionsTemplateData_3,
	// createInstructionsTemplateData_4,
	createInstructionsTemplateData_5,
	createInstructionsTemplateData_6,
	// createInstructionsTemplateData_7,
	createInstructionsTemplateData_8,
	createInstructionsTemplateData_9,
	preparePayload
} = require('../../../../test-data/data/tasks/hub/instru/GYPT29581');
const { batchAddInstructionTemplates } = require('../../../../test-lib/instructionTemplate');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload,verifyResponseMessage } = require('../../../../test-verify/verify');
const { batchInstructionSchema } = require('../../../../test-data/schema/instructionTemplate');

const store = new DataStore();

describe('GYPT-29581: 指令下发配置增加批量导入接口自动化', function () {
	
	describe('构建环境', function () {
		describe('Create draft thing class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('创建属性', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2491989: 检查批量增加cmd指令是否OK', function () {

		describe('使用CMD类型创建指令配置', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				[createInstructionsTemplateData.instructionsBody, createInstructionsTemplateData_3.instructionsBody], 
				store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), batchInstructionSchema);
			verifyPayload(store.getLater('response'), 
				preparePayload(createInstructionsTemplateData.instructionsBody, createInstructionsTemplateData_3.instructionsBody));
		});
	});

	describe('C2491990: 检查批量增加live指令是否OK', function () {

		describe('使用LIVE类型创建指令配置', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				[createInstructionsTemplateData_1.instructionsBody, createInstructionsTemplateData_2.instructionsBody], 
				store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), batchInstructionSchema);
			verifyPayload(store.getLater('response'), 
				preparePayload(createInstructionsTemplateData_1.instructionsBody, createInstructionsTemplateData_2.instructionsBody));
		});
	});

	describe('C2491991: 检查批量增加cmd+live 指令是否OK', function () {

		describe('使用CMD&LIVE类型创建指令配置', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				[createInstructionsTemplateData.instructionsBody, createInstructionsTemplateData_2.instructionsBody], 
				store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), batchInstructionSchema);
			verifyPayload(store.getLater('response'), 
				preparePayload(createInstructionsTemplateData.instructionsBody, createInstructionsTemplateData_2.instructionsBody));
		});
	});

	describe('C2491992: 查checkDuplicate是否生效', function () {

		describe('设置query参数checkDuplicate=true', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				[createInstructionsTemplateData_1.instructionsBody, createInstructionsTemplateData_2.instructionsBody], 
				store.putLater('response'), {query:{checkDuplicate: true}});
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), 'item exist already');
		});
	});

	describe('C2491993: 检查批量增加2000条指令时接口的响应时间', function () {
		describe('创建并发送2000条指令', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				createInstructionsTemplateData_8, 
				store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), batchInstructionSchema);
			verifyPayload(store.getLater('response'), 
				preparePayload(...createInstructionsTemplateData_8));
		});

		describe('重新发送2000条指令，并检查重复性', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				createInstructionsTemplateData_8, 
				store.putLater('response'), {query:{checkDuplicate: true}});
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), 'item exist already');
		});

		describe('发送另外的2000条指令，并检查重复性', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				createInstructionsTemplateData_9, 
				store.putLater('response'), {query:{checkDuplicate: true}});
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), batchInstructionSchema);
			verifyPayload(store.getLater('response'), 
				preparePayload(...createInstructionsTemplateData_9));
		});
	});

	describe('C2491994: 检查参数timeout的上限', function () {

		describe('创建timeout值很小的指令', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				[createInstructionsTemplateData.instructionsBody, createInstructionsTemplateData_5.instructionsBody], 
				store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 422);
			verifyResponseMessage(store.getLater('response'), 'timeout');
		});
	});
	
	describe('C2491995: 检查数据类型不正确的情况', function () {

		describe('创建数据类型不正确的指令模板', function () {
			batchAddInstructionTemplates(draftThingClassData.modelId, 
				[createInstructionsTemplateData_6.instructionsBody], 
				store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			//verifyResponseMessage(store.getLater('response'), 'Couldn\'t deserialize body');
		});
	});

	// describe('C2491996: 检查各参数数据容错性', function () {
	// /*
	// 	目前数据容错性有问题，比如`timeout:'3000'` 这种fail了，`displayName: 22` 这种pass了
	// */
	// 	describe('创建数据类型不匹配的指令', function () {
	// 		batchAddInstructionTemplates(draftThingClassData.modelId, 
	// 			[createInstructionsTemplateData_4.instructionsBody, createInstructionsTemplateData_7.instructionsBody], 
	// 			store.putLater('response'));
	// 		Response.statusCodeEquals(store.getLater('response'), 200);
	// 		verifySchema(store.getLater('response'), batchInstructionSchema);
	// 		verifyPayload(store.getLater('response'), 
	// 			preparePayload(createInstructionsTemplateData_4.instructionsBody, createInstructionsTemplateData_7.instructionsBody));
		
	// 	});
	// });

	describe('清理环境', function () {
		describe('删除物件模型', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});