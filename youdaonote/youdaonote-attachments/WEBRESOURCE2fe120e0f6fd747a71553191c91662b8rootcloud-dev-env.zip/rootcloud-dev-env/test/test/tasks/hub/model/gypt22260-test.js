'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const {
	draftThingClassData_c1,
	multipleProperties_c1,
	draftThingClassData_c2,
	multipleProperties_c2,
	draftThingClassData_c3,
	multipleProperties_c3,
	draftThingClassData_c4,
	multipleProperties_c4,
	draftThingClassData_c5,
	multipleProperties_c5,
	draftThingClassData_c6,
	multipleProperties_c6,
	draftThingClassData_c7,
	multipleProperties_c7,
	multipleProperties_c8,
} = require('../../../../test-data/data/tasks/hub/model/GYPT22260');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const {
	postDraftThingClass,
} = require('../../../../test-lib/openApiThingClass');
const { postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT--22260: test: batch add 10 device properties supporting partialAdd and forceUpdate', function () {
	describe('C1880641: conditions: all of the properties are unique with legal values; partialAdd:false, forceUpdate:false ', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c1.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c1.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c1.modelId, multipleProperties_c1, store.putLater('response'));
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880642: conditions: all of the properties are not unique but legal values(the 9th mappingName is the same as the 10th); partialAdd:false, forceUpdate:false', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c2.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c2.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c2.modelId, multipleProperties_c2, store.putLater('response'));
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880643: conditions: all of the properties are unique but the value of 10th property expression is illegal ; partialAdd:true, forceUpdate:false', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c3.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c3.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c3.modelId, multipleProperties_c3, store.putLater('response'), {partialAdd: true});
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
		it('verify the response message', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload[9].success, false, 'violate the regulations');
		});
	});

	describe('C1880644: conditions: all of the properties are not unique but legal values(the 9th mappingName is the same as the 10th); partialAdd:true, forceUpdate:false', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c4.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c4.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c4.modelId, multipleProperties_c4, store.putLater('response'), {partialAdd: true});
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880645: conditions: all of the properties are unique with legal values; partialAdd:false, forceUpdate:true ', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c5.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c5.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c5.modelId, multipleProperties_c5, store.putLater('response'), {forceUpdate:true});
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880646: conditions: all of the properties are not unique but legal values(the 9th mappingName is the same as the 10th); partialAdd:false, forceUpdate:true', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c6.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c6.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c6.modelId, multipleProperties_c6, store.putLater('response'), {forceUpdate: true});
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C1880647: conditions: all of the properties are unique but the value of 10th property expression is illegal ; partialAdd:true, forceUpdate:true', function () {
		// step 1: create draft device class
		postDraftThingClass(draftThingClassData_c7.thingClassBody, store.putLater('response'));
		// verification status code, paylod and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData_c7.thingClassBody);
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c7.modelId, multipleProperties_c7, store.putLater('response'), {partialAdd: true, forceUpdate:true});
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
		it('verify the response message', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload[9].success, false, 'violate the regulations');
		});
	});

	describe('C1880648: conditions: all of the properties are not unique but legal values(the 9th mappingName is the same as the 10th); partialAdd:true, forceUpdate:true', function () {
		// bulk adding
		postDraftThingClassPropertiesByModelID(draftThingClassData_c1.modelId, multipleProperties_c8, store.putLater('response'), {forceUpdate: true, partialAdd: true});
		// verification status code
		Response.statusCodeEquals(store.getLater('response'), 200);
		it('verify the response message', function () {
			const body = Response.getJsonBody(store.get('response'));
			const iterable = body.payload;
			for (const obj of iterable) {
				Assert.strictEqual(obj.success, true, 'failed to create the property');
			}
		});
	});
	
});


