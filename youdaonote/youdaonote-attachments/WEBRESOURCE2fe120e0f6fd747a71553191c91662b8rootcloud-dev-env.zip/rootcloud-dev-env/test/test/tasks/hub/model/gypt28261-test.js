'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassData,draftThingClassModelPropertiesData_7,draftThingClassModelPropertiesData_8, msgData, thingClassModelInstanceData, updatedDraftThingInterfacesPropertiesData_5, updatedDraftThingInterfacesPropertiesData_2, updatedDraftThingInterfacesPropertiesData_3, updatedDraftThingInterfacesPropertiesData_4, updatedDraftThingInterfacesPropertiesData_1, updatedDraftThingInterfacesPropertiesData, postDraftThingInterfacesPropertiesData_4, postDraftThingInterfacesPropertiesData_5, postDraftThingInterfacesPropertiesData_6, postDraftThingInterfacesPropertiesData_7, postDraftThingInterfacesPropertiesData_8, postDraftThingInterfacesPropertiesData_9, postDraftThingInterfacesPropertiesData_3, interfaceDirectTypeAllDataType, postDraftThingInterfacesPropertiesData_2, interfaceMultipleDirectTypeProperties, postDraftThingInterfacesPropertiesData_1, postDraftThingInterfacesPropertiesData, postDraftThingInterfacesData, updatedraftThingClassModelPropertiesData_7, updatedraftThingClassModelPropertiesData_8, updatedraftThingClassModelPropertiesData_9, updatedraftThingClassModelPropertiesData_10, updatedraftThingClassModelPropertiesData_6, updatedraftThingClassModelPropertiesData_5, updatedraftThingClassModelPropertiesData_4, updatedraftThingClassModelPropertiesData_3, updatedraftThingClassModelPropertiesData_2, updatedraftThingClassModelPropertiesData_1, updatedraftThingClassModelPropertiesData, directTypeAllDataType, draftThingClassModelPropertiesData_6, draftThingClassModelPropertiesData_4, draftThingClassModelPropertiesData_2, draftThingClassModelPropertiesData_3, draftThingClassModelPropertiesData, multipleDirectTypeProperties, draftThingClassModelPropertiesData_1 } = require('../../../../test-data/data/tasks/hub/model/GYPT28261');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { postDraftThingClass, deleteAllDraftThingClassPropertiesByModelID,getThingClassPropertiesByModelID, getDraftThingClassPropertiesByModelID, patchThingClassByModelID, patchDraftThingClassByModelID, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, putDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postDraftThingInterfaces, putDraftThingInterfacesPropertiesByDestId, postDraftThingInterfacesPropertiesByDestId, deleteDraftThingInterfacesByModelId } = require('../../../../test-lib/openApiThingInterfaces');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { topicDict } = require('../../../../test-data/requireData');
const { getDeviceByDeviceOnlineStatusId } = require('../../../../test-lib/singleDevice');
const store = new DataStore();

describe('GYPT-28261 : OpenAPI support DirectExpression', function () {

	describe('Create environment', function () {

		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});
	});

	describe('C2190929 : Successfully created a property of type Direct', function () {

		describe('Successfully created a property of type Direct', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190935 : Property of type direct was modified successfully', function () {

		describe('Property of type direct was modified successfully', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190936 : When modifying direct, fromproperty is null', function () {

		describe('When modifying direct, fromproperty is null', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_1.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为direct时，fromProperty不能为空');
			});
		});
	});

	describe('C2190937 : When modifying the direct type, propertytype supports any current data type', function () {

		describe('When modifying the direct type, propertytype supports any current data type', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_2.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190944 : Successfully batch created properties of type Direct', function () {

		describe('Successfully batch created properties of type Direct', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, multipleDirectTypeProperties, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190930 : When creating direct, fromproperty is null', function () {

		describe('When creating direct, fromproperty is null', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为direct时，fromProperty不能为空');
			});
		});
	});

	describe('C2190931 : When creating a direct type, propertytype supports any current data type', function () {

		describe('When creating a direct type, propertytype supports any current data type', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, directTypeAllDataType, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190932 : Successfully created attribute of type linear', function () {

		describe('Successfully created attribute of type linear', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190938 : The attribute of linear type was modified successfully', function () {

		describe('The attribute of linear type was modified successfully', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_3.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190939 : When creating linear, the attribute does not contain scale and base', function () {

		describe('When creating linear, the attribute does not contain scale and base', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_4.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，scale不能为空');
			});
		});
	});

	describe('C2190940 : When modifying linear type, propertytype only Integer Number type', function () {

		describe('type is number', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_10.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('type is String', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_5.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Array', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_6.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Boolean', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_7.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Json', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_8.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Binary', function () {
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassModelPropertiesData_9.UpdatethingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});
	});

	describe('C2190933 : When creating linear, the attribute does not contain scale and base', function () {

		describe('When creating linear, the attribute does not contain scale and base', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，scale不能为空');
			});
		});
	});

	describe('C2190934 : When creating linear type, propertytype only supports numeric type', function () {

		describe('type is number', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_4.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('type is Array', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_6.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});
	});

	describe('C2190946 : Create the direct type attribute successfully through the object interface', function () {

		describe('Create environment', function () {
			postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Create the direct type attribute successfully through the object interface', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_1.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190953 : Attribute of direct type was modified successfully by object interface', function () {

		describe('Attribute of direct type was modified successfully by object interface', function () {
			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, updatedDraftThingInterfacesPropertiesData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190954 : When modifying direct by object interface, fromproperty is null', function () {

		describe('When modifying direct by object interface, fromproperty is null', function () {
			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, updatedDraftThingInterfacesPropertiesData_1, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为direct时，fromProperty不能为空');
			});
		});
	});

	describe('C2190955 : Supports any type of propertydirect when modifying the current data type', function () {

		describe('Supports any type of propertydirect when modifying the current data type', function () {
			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, updatedDraftThingInterfacesPropertiesData_2, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190947 : Batch creation of direct type attributes by object interface', function () {

		describe('Batch creation of direct type attributes by object interface', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, interfaceMultipleDirectTypeProperties, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190948 : When modifying direct, fromproperty is null by object interface', function () {

		describe('When modifying direct, fromproperty is null by object interface', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_2.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为direct时，fromProperty不能为空');
			});
		});
	});

	describe('C2190949 : When creating direct type by object interface, propertytype supports any data type', function () {

		describe('When creating direct type by object interface, propertytype supports any data type', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, interfaceDirectTypeAllDataType, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190950 : Create the linear type attribute successfully through the object interface', function () {

		describe('Create the linear type attribute successfully through the object interface', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190951 : When creating linear by object interface, the attribute does not contain scale and base', function () {

		describe('When creating linear by object interface, the attribute does not contain scale and base', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_3.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，scale不能为空');
			});
		});
	});

	describe('C2190952 : When creating linear type by object interface, propertytype only supports numerical type', function () {

		describe('type is number', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_4.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('type is String', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_5.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Array', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_6.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Boolean', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_7.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Json', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_8.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});

		describe('type is Binary', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, postDraftThingInterfacesPropertiesData_9.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});
	});

	describe('C2190956 : Attribute of linear type was successfully modified by object interface', function () {

		describe('Attribute of linear type was successfully modified by object interface', function () {
			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, updatedDraftThingInterfacesPropertiesData_3, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2190957 : When modifying linear by object interface, the attribute does not contain scale and base', function () {

		describe('When modifying linear by object interface, the attribute does not contain scale and base', function () {
			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, updatedDraftThingInterfacesPropertiesData_4, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，scale不能为空');
			});
		});
	});

	describe('C2190958 : Propertytype only supports numerical type when the object interface is linear type', function () {

		describe('Propertytype only supports numerical type when the object interface is linear type', function () {
			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, draftThingClassData.modelId, updatedDraftThingInterfacesPropertiesData_5, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1014');
				Assert.isTrue(body.message == 'expression type为linear时，属性类型只支持Number类型');
			});
		});
	});

	describe('C2190941 : The published and unpublished properties of direct type were successfully queried', function () {

		describe('Query unpublished properties of type direct', function () {
			getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].expressionType == 'direct');
				Assert.isTrue(body.payload[body.payload.length - 1].expressionType == 'linear');
			});
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Query published properties of type direct', function () {
			getThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].expressionType == 'direct');
				Assert.isTrue(body.payload[body.payload.length - 1].expressionType == 'linear');
			});
		});
	});

	describe('C2190942 : The sending condition of direct attribute is normal', function () {

		describe('delete all draft thing class properties by modelID', function () {
			deleteAllDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('The direct attribute was successfully deleted', function () {
			getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C2190945 : Successfully created a property of type Direct', function () {

			describe('Successfully created a property of type Direct', function () {
				postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_7.thingPropertiesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Creation instance', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			getMqttClient(thingClassModelInstanceData.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			closeClient(store.getLater('client'));
		});

		describe('Check whether the number is successful', function () {
			getDeviceByDeviceOnlineStatusId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'));
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});
	});

	describe('C2190943 : The sending condition of linear attribute is normal', function () {

		describe('delete all draft thing class properties by modelID', function () {
			deleteAllDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('Successfully created a property of type linear', function () {

			describe('Successfully created a property of type linear', function () {
				postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_8.thingPropertiesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			getMqttClient(thingClassModelInstanceData.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			closeClient(store.getLater('client'));
		});

		describe('Check whether the number is successful', function () {
			getDeviceByDeviceOnlineStatusId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'));
			});
		});

	});

	describe('Clear environment', function () {

		describe('delete all draft thing class properties by modelID', function () {
			deleteAllDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('delete thingClass', function () {
			deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('Delete object instance', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('patch thing class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
