'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict, errMesDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { getHistorianSchema } = require('../../../../test-data/schema/historian');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { draftThingClassData, draftThingClassPropertiesData1, draftThingClassPropertiesData2, draftThingClassPropertiesData3, 
	draftThingClassPropertiesData4, draftThingClassPropertiesData5, 
	activeData, thingInstanceData, msgList1, draftThingClassPropertiesData6, thingInstanceData6, draftThingClassData6, msgList2,
	draftThingClassData7,
	draftThingClassPropertiesData7,
	thingInstanceData7,
	msgList3} = require('../../../../test-data/data/tasks/hub/model/GYPT28262');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { getHistorianByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload, verifyHistoryResult, verifyResponseMessage} = require('../../../../test-verify/verify');
const { itWait } = require('../../../../test-data/util');

describe('GYPT-28262: 对Window参数的设置需要遵守一定规则', function () {

	const store = new DataStore();

	describe('prepare', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});
	});


	describe('c2190880 window allow latency less than 0', function () {

		describe('window allow latency less than 0', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), errMesDict['not_valid_range']);
		});
	});

	describe('c2190884 window allow latency bigger than window size', function () {

		describe('window allow latency bigger than window size', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), errMesDict['not_valid_range']);
		});
	});

	describe('c2190887 window step than window size', function () {

		describe('window step bigger than window size', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), errMesDict['big_or_eq']);
		});
	});

	describe('c2190891 window size 8 multiples of window step', function () {

		describe('window size 8 multiples of window step', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData4.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), errMesDict['big_or_eq']);
		});
	});

	describe('c2190881, c2190890 window size 5 multiples of window step and allow latency is 0', function () {

		describe('window size 5 multiples of window step and allow latency is 0', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData5.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
        
		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
			getMqttClient(thingInstanceData.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[0].mesBody);
			itWait(500);
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[1].mesBody);
			itWait(500);
		});

		describe('after latency window will exec, get historian', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList1[2].mesBody);
			closeClient(store.getLater('client'));
			getHistorianByModelAndThingId(thingInstanceData.thingId, draftThingClassData.modelId, msgList1[0].tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 6 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0], [11.0], [11.0], [11.0], [11.0], [13.0]]);
		});
	});
	
	describe('c2190883, c2190888 window size eq window step and eq allow latency', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData6.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData6.thingClassBody);
		});
		
		describe('window size eq window step and allow latency', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData6.modelId, draftThingClassPropertiesData6.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
        
		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData6.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData6.modelId, thingInstanceData6.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData6.thingInstanceBody);
			getMqttClient(thingInstanceData6.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList2[0].mesBody);
			itWait(1000);
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList2[1].mesBody);
			itWait(1000);
		});

		describe('after latency window will exec, get historian', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList2[2].mesBody);
			closeClient(store.getLater('client'));
			getHistorianByModelAndThingId(thingInstanceData6.thingId, draftThingClassData6.modelId, msgList2[0].tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[11.0]]);
		});
	});
	
	describe('c2190882, c2190888 window allow latency between 0 and window size, window size is 5 and window step is 2', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData7.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData7.thingClassBody);
		});
		
		describe('window size eq window step and allow latency', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData7.modelId, draftThingClassPropertiesData7.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
        
		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData7.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData7.modelId, thingInstanceData7.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData7.thingInstanceBody);
			getMqttClient(thingInstanceData7.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList3[0].mesBody);
			itWait(1000);
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList3[1].mesBody);
			itWait(1000);
			// c2190885： post data in latency
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList3[2].mesBody);
			itWait(1000);
		});

		describe('after latency window will exec, get historian', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList3[3].mesBody);
			itWait(1000);
			// c2190886： post data after latency
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgList3[4].mesBody);
			closeClient(store.getLater('client'));
			getHistorianByModelAndThingId(thingInstanceData7.thingId, draftThingClassData7.modelId, msgList3[0].tsQueryStr, store.putLater('response'), { retryCode: 404, expectNum: 3 });
			verifySchema(store.getLater('response'), getHistorianSchema);
			verifyHistoryResult(store.getLater('response'), [[1.0], [5.0], [7.0]]);
		});
	});
});
        