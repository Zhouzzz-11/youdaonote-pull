'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { multipleDraftDeviceData,
	multipleDraftGatewayData,
	draftThingClassModelPropertiesData,
	multipleGatewayInstanceData,
	multipleDeviceInstanceData } = require('../../../../test-data/data/tasks/hub/other/GYPT23808');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { getDevicesStatusByRichFind, postDevicesStatusByRichFind } = require('../../../../test-lib/deviceOnlineStatus');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');


const store = new DataStore();

describe('GYPT-23808: supporting distinct query in find apis to improve the efficiency of finding operative gateway', function () {
	describe('precondition: post five devices connected with five gateways', function () {
		//模型->属性->发布->设备实例
		//step1：6个设备模型
		for (let i = 0; i < 6; i++) {
			postDraftThingClass(multipleDraftDeviceData[i].thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), multipleDraftDeviceData[i].thingClassBody);
		}
		//step2: 6个网关模型
		for (let i = 0; i < 6; i++) {
			postDraftThingClass(multipleDraftGatewayData[i].thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), multipleDraftGatewayData[i].thingClassBody);
		}
		//step3: 添加属性
		for (let i = 0; i < 6; i++) {
			postDraftThingClassPropertiesByModelID(multipleDraftDeviceData[i].modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postDraftThingClassPropertiesByModelID(multipleDraftGatewayData[i].modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		}
		//step4: 发布
		for (let i = 0; i < 6; i++) {
			patchDraftThingClassByModelID(multipleDraftDeviceData[i].modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			patchDraftThingClassByModelID(multipleDraftGatewayData[i].modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		}
		//step5: 6个网关实例和6个设备实例
		for (let i = 0; i < 6; i++) {
			postThingInstancesByModelId(multipleDraftGatewayData[i].modelId, multipleGatewayInstanceData[i].thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), multipleGatewayInstanceData[i].thingInstanceBody);

			postThingInstancesByModelId(multipleDraftDeviceData[i].modelId, multipleDeviceInstanceData[i].thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			//非直连device注册物实例时关联网关返回payload没有authToken导致payload验证失败
		}
	});

	describe('C2076562: rich find gatewayId using post api with distinct body field', function () {
		postDevicesStatusByRichFind({ 'className': 'Device', 'find': '{"classId": "DEVICE", "gatewayId": {"$exists": true}}', 'distinct': 'gatewayId' }, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		let count = 0;
		it('verify the created operative gateways are all found', function () {
			const body = Response.getJsonBody(store.get('response'));
			const gatewayIdArray = body.payload;
			count = 6;
			for (const index of gatewayIdArray) {
				switch (index) {
					case multipleGatewayInstanceData[0].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[1].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[2].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[3].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[4].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[5].thingId:
						count = count - 1;
						break;
					default:
						break;
				}
			}
			Assert.strictEqual(count, 0, 'The operative gateways found are not correct');
		});
	});

	describe('C2076563: rich find gatewayId using post api without distinct body field', function () {
		postDevicesStatusByRichFind({
			'className': 'Device',
			'find': '{"classId": "DEVICE", "gatewayId": {"$exists": true}}'
		}, store.putLater('response'), { criteria: '_skip=1000' });
		Response.statusCodeEquals(store.getLater('response'), 200);

		let count = 0;
		it('verify the created operative gateways are all found', function () {
			const body = Response.getJsonBody(store.get('response'));
			const iterable = body.payload;
			count = 6;
			for (const obj of iterable) {
				switch (obj.gatewayId) {
					case multipleGatewayInstanceData[0].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[1].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[2].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[3].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[4].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[5].thingId:
						count = count - 1;
						break;
					default:
						break;
				}
			}
		});
	});

	describe('C2076565: rich find gatewayId using get api with distinct body field', function () {
		getDevicesStatusByRichFind(store.putLater('response'), { criteria: 'className=Device&find={"classId":"DEVICE","gatewayId":{"$exists": true}}&distinct=gatewayId' });
		Response.statusCodeEquals(store.getLater('response'), 200);
		it('verify the created operative gateways are all found', function () {
			const body = Response.getJsonBody(store.get('response'));
			const gatewayIdArray = body.payload;
			let count = 6;
			for (const index of gatewayIdArray) {
				switch (index) {
					case multipleGatewayInstanceData[0].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[1].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[2].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[3].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[4].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[5].thingId:
						count = count - 1;
						break;
					default:
						break;
				}
			}
			Assert.strictEqual(count, 0, 'The operative gateways found are not correct');
		});
	});

	describe('C2076566: rich find gatewayId using get api without distinct body field', function () {
		getDevicesStatusByRichFind(store.putLater('response'), { criteria: 'className=Device&find={"classId":"DEVICE","gatewayId":{"$exists": true}}&_skip=1000' });
		Response.statusCodeEquals(store.getLater('response'), 200);
		let count = 0;
		it('verify the created operative gateways are all found', function () {
			const body = Response.getJsonBody(store.get('response'));
			const iterable = body.payload;
			count = 6;
			for (const obj of iterable) {
				switch (obj.gatewayId) {
					case multipleGatewayInstanceData[0].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[1].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[2].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[3].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[4].thingId:
						count = count - 1;
						break;
					case multipleGatewayInstanceData[5].thingId:
						count = count - 1;
						break;
					default:
						break;
				}
			}
		});
	});

	describe('clear the environment', function () {
		//删实例
		for (let i = 0; i < 6; i++) {
			deleteThingInstancesByModelIdAndThingId(multipleDraftDeviceData[i].modelId, multipleDeviceInstanceData[i].thingId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			deleteThingInstancesByModelIdAndThingId(multipleDraftGatewayData[i].modelId, multipleGatewayInstanceData[i].thingId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		}
		//取消发布
		for (let i = 0; i < 6; i++) {
			patchThingClassByModelID(multipleDraftDeviceData[i].modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			patchThingClassByModelID(multipleDraftGatewayData[i].modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		}
		//删模型
		for (let i = 0; i < 6; i++) {
			deleteDraftThingClassByModelID(multipleDraftDeviceData[i].modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
			deleteDraftThingClassByModelID(multipleDraftGatewayData[i].modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		}
	});

});