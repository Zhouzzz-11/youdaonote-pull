
'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { getDeviceTags, getDeviceTagfields } = require('../../../../test-lib/openApi');
const {
	draftThingClassData_1,
	draftThingClassData_2,
	draftThingClassData_3,
	draftThingClassPropertiesData_1,
	draftThingClassPropertiesData_2,
	draftThingClassPropertiesData_3,
} = require('../../../../test-data/data/tasks/hub/other/GYPT21527');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');


const store = new DataStore();

describe('GYPT-21527: test the query result of tags of thing models', function () {

	describe('precondition', function () {
		//create 4 device types and add properties on them described in test-data
		describe('post device model class 1', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('post device model class 1 properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class 1 by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model class 2', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});

		describe('post device model class 2 properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassPropertiesData_2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class 1 by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model class 3', function () {
			postDraftThingClass(draftThingClassData_3.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_3.thingClassBody);
		});

		describe('post device model class 3 properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_3.modelId, draftThingClassPropertiesData_3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C2074660: query tags information of published device', function () {
		getDeviceTags(draftThingClassData_1.modelId, store.putLater('response'));
		it('verify the tags information is correct', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(true, body[0] != undefined, 'fail to query tags');
			Assert.strictEqual(true, body[1] != undefined, 'fail to query tags');
		});
	});

	describe('C2074661: query tags information of draft device', function () {
		getDeviceTags(draftThingClassData_3.modelId, store.putLater('response'));
		it('verify the tags information is correct', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(true, body[0] == undefined, 'draft tags should not be found');
			Assert.strictEqual(true, body[1] == undefined, 'draft tags should not be found');
		});
	});

	describe('C2074661: query tags information of published device without specifying tags', function () {
		getDeviceTags(draftThingClassData_2.modelId, store.putLater('response'));
		it('verify the tags information is correct', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual('default', body[0].tag, 'draft tags should not be found');
		});
	});

	describe('C2074661: query tags detailed information of published device', function () {
		getDeviceTagfields(draftThingClassData_1.modelId, store.putLater('response'));
		it('verify the tags information is correct', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(true, body[0].tags != undefined, 'tags are not found');
			Assert.strictEqual(true, body[0].name != undefined, 'tags are not found');
		});
	});

	describe('C2074664:  query detailed tags information of draft device', function () {
		getDeviceTagfields(draftThingClassData_3.modelId, store.putLater('response'));
		it('verify the tags information is correct', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(true, body[0] == undefined, 'tags are not found');
		});
	});

	describe('C2074661: query detailed tags information of published device without specifying tags', function () {
		getDeviceTagfields(draftThingClassData_2.modelId, store.putLater('response'));
		it('verify the tags information is correct', function () {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(true, body[0].name != undefined, 'other information should be found');
		});
	});

	describe('clear the environment', function () {
		patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
		deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
		deleteDraftThingClassByModelID(draftThingClassData_3.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

});