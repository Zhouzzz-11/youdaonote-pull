'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingInterfacesData, postDraftThingInterfacesData1, postDraftThingInterfacesPropertiesData2, putDraftThingInterfacesData, putDraftThingInterfacesPropertiesData, putDraftThingInterfacesPropertiesData1, putDraftThingInterfacesPropertiesData2, putDraftThingInterfacesData1, postDraftThingClassData, postDraftThingClassModelPropertiesData, postDraftThingInterfacesPropertiesData } = require('../../../../test-data/data/tasks/hub/model/GYPT13437Interfaces');
const { thingInterfacesPostSchema, thingInterfacesGetByModelIdSchema, draftThingInterfacesModelPropertiesSchema } = require('../../../../test-data/schema/thingInterfaces');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { getDraftThingInterfaces, deleteDraftThingInterfacesPropertiesByDestId, deleteAllDraftThingInterfacesPropertiesByModelId, putDraftThingInterfacesPropertiesByDestId, getDraftThingInterfacesPropertiesByDestId, putDraftThingInterfacesByModelId, getThingInterfaces, patchThingInterfacesByModelId, getThingInterfacesByModelId, getDraftThingInterfacesByModelId, postDraftThingInterfaces, patchDraftThingInterfacesByModelId, deleteDraftThingInterfacesByModelId, postDraftThingInterfacesPropertiesByDestId } = require('../../../../test-lib/openApiThingInterfaces');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

describe('/test for thingInterfaces', function () {

	describe('GYPT-13437-interfaces: Create/Get/Update/Delete/Patch thingInterfaces', function () {
		const store = new DataStore();

		describe('C189112: Query when the ID does not exist to see if the return is correct', function () {
			getDraftThingInterfaces(store.putLater('response'), { modelId: 'no-find' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
		});

		describe('C189113: Query when ID exists to see if the return is correct', function () {
			describe('create thingInterface', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});
			describe('perform query operations', function () {
				getDraftThingInterfaces(store.putLater('response'), { modelId: postDraftThingInterfacesData.modelId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].modelId', postDraftThingInterfacesData.modelId);
			});
		});

		//构建发布物接口的环境依赖
		describe('The environment required to create the publication thingInterface', function () {
			describe('creation thingClass', function () {
				postDraftThingClass(postDraftThingClassData.thingClassBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), postDraftThingClassData.thingClassBody);
			});

			describe('add attributes to the thingClass', function () {
				postDraftThingClassPropertiesByModelID(postDraftThingClassData.modelId, postDraftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('publication thingClass', function () {
				patchDraftThingClassByModelID(postDraftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('create posted thingInterface', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData1.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData1.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData1.modelId);
			});

			describe('add attributes to the thingInterfaces', function () {
				postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData1.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('release thingInterfaces', function () {
				patchDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189114: Query when the ID has been published to see if the return is correct', function () {

			describe('perform query operations', function () {
				getDraftThingInterfaces(store.putLater('response'), { modelId: postDraftThingInterfacesData.modelId });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].modelId', postDraftThingInterfacesData.modelId);
			});
		});

		describe('C189115: When the ID does not correspond to the tenant Id, check to see if the return is correct', function () {

			describe('perform query operations', function () {
				getDraftThingInterfaces(store.putLater('response'), { modelId: 'mismatch' });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
			});
		});

		describe('C189116: check if the query returns no results', function () {

			describe('perform query operations', function () {
				getDraftThingInterfaces(store.putLater('response'), { modelId: 'noResult' });
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
			});
		});

		//delete C189113 create thingInterfaces
		describe('delete created thingInterfaces', function () {
			deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C189117: When the object interface is not repeated, check whether the object interface is created correctly', function () {

			//create new thingInterfaces
			describe('create new thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});

			describe('restore the environment', function () {
				deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C189118: Operate when the name of the object interface is repeated', function () {

			describe('create new thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});

			describe('create repeated thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 400);
			});
		});

		describe('C189126: Query when the ID does not exist to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), { modelId: 'noResult' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
		});

		describe('C189127: Query when ID exists to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), postDraftThingInterfacesData);
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
		});

		describe('C189128: Query when the ID has been published to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), { modelId: postDraftThingInterfacesData1.modelId } );
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].modelId', postDraftThingInterfacesData1.modelId);
		});

		describe('C189129: When the ID does not correspond to the tenant Id, check to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), { modelId: 'noResult' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
		});

		describe('C189130: When the query has no results, check whether the return is correct', function () {

			getThingInterfaces(store.putLater('response'), { modelId: 'noResult' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload', []);
		});

		describe('C189131: Query when the ID is not entered to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), { modelId: null, otherQuery: '_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
			it('verify the returned data length > 0', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0, 'failed to verify data, data length = 0');
			});
		});

		describe('C189132: Query when the ID is not entered to see if the return is correct', function () {

			getDraftThingInterfaces(store.putLater('response'), { otherQuery: '_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
			it('verify the returned data length > 0', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0, 'failed to verify data, data length = 0');
			});
		});

		describe('C189133: Query according to other conditions to see if the return is correct', function () {

			getDraftThingInterfaces(store.putLater('response'), { modelId: null, name: 'GYPT13437Interfaces' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
			it('verify the returned data length > 0', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0, 'failed to verify data, data length = 0');
			});
		});

		describe('C189134: Query by other conditions to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), { modelId: null, name: 'GYPT13437Interfaces' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
			it('verify the returned data length > 0', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0, 'failed to verify data, data length = 0');
			});
		});

		describe('C189135: Query when ID exists to see if the return is correct', function () {

			getDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
		});

		describe('C189136: Query when the ID has been published to see if the return is correct', function () {

			getDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), postDraftThingInterfacesData1.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData1.modelId);
		});

		describe('C189137: When the ID does not correspond to the tenant Id, check to see if the return is correct', function () {

			getDraftThingInterfacesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189138: When the query has no results, check whether the return is correct', function () {

			getDraftThingInterfacesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189139: Query when the ID is not entered to see if the return is correct', function () {

			getDraftThingInterfacesByModelId(null, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('verify the returned data length > 0', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0, 'failed to verify data, data length = 0');
			});
		});

		describe('C189142: Query when the object interface has been published to see if the return is correct', function () {

			getThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), postDraftThingInterfacesData1.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData1.modelId);
		});

		describe('C189143: Query when the object interface is not released to see if the return is correct', function () {

			getThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189144: Query when the object interface has been published to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), postDraftThingInterfacesData1);
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesGetByModelIdSchema);
			it('verify the returned data length > 0', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0, 'failed to verify data, data length = 0');
			});
		});

		describe('C189145: Query when the object interface is not released to see if the return is correct', function () {

			getThingInterfaces(store.putLater('response'), postDraftThingInterfacesData);
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189146: Operate when the ID does not exist, check whether the return is correct', function () {

			patchThingInterfacesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189147: Operate when the ID has been published, check whether the return is correct', function () {

			patchThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});

			describe('resume published thingInterfaces', function () {
				patchDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189148: Operate when the ID is not published, check whether the return is correct', function () {

			patchThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189149: Operate when the ID is inconsistent with the tenant Id, check whether the return is correct', function () {

			patchThingInterfacesByModelId('inconsistent', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189150: Operate when the ID does not exist, check whether the return is correct', function () {

			getDraftThingInterfacesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189151: Operate when ID exists, check if the return is correct', function () {

			getDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
		});

		describe('C189152: Operate when the ID does not exist, check whether the object interface is correctly modified', function () {

			putDraftThingInterfacesByModelId('noResult', putDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189153: Operate when the ID is not published, check whether the return is correct', function () {

			getDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
		});

		describe('C189154: Operate when the ID is inconsistent with the tenant Id, check whether the return is correct', function () {

			getDraftThingInterfacesByModelId('inconsistent', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189155: Operate when the ID already exists, check whether the object interface is modified correctly', function () {

			putDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, putDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), putDraftThingInterfacesData.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', putDraftThingInterfacesData.modelId);
		});

		describe('C189156: Operate when the ID has been published, check whether the return is correct', function () {

			putDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, putDraftThingInterfacesData1.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInterfacesPostSchema);
			verifyPayload(store.getLater('response'), putDraftThingInterfacesData1.draftThingInterfacesBody);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', putDraftThingInterfacesData1.modelId);
		});

		describe('C189157: Operate when ID does not correspond to tenant Id, check if the return is correct', function () {

			putDraftThingInterfacesByModelId('doesNotCorrespondModelId', putDraftThingInterfacesData1.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189158: Operate when the content of the object interface is repeated to check whether the return is correct', function () {

			putDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, putDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C189159: Operate when the ID does not exist, check whether the return is correct', function () {

			deleteDraftThingInterfacesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189160: Operate when ID exists, check whether the object interface is deleted correctly', function () {

			deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

			//create new thingInterfaces
			describe('create new thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});
		});

		describe('C189161: Operate when the ID has been published, check whether the return is correct', function () {

			deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C189162: Operate when the ID is inconsistent with the tenant Id, check whether the return is correct', function () {

			deleteDraftThingInterfacesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189163: Operate when the ID does not exist, check whether the return is correct', function () {

			patchDraftThingInterfacesByModelId('nonexistentModelId', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189164: Operate when the ID exists to see if the object interface is correctly published', function () {

			describe('add attributes to the thingInterfaces', function () {
				postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('perform this step', function () {
				patchDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189165: Operate when the ID has been published, check whether the interface of the thing is correctly published', function () {

			describe('perform this step', function () {
				patchDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('un-publish thingInterfaces', function () {
				patchThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189166: When the ID does not correspond to the tenant Id, check whether the return is correct', function () {

			patchDraftThingInterfacesByModelId('nonexistentModelId', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189167: Operate when ID corresponds to dest Id, check if the return is correct', function () {

			getDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingInterfacesModelPropertiesSchema);
			it('verify the data is correct ', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.strictEqual(body.payload[0].name, postDraftThingInterfacesPropertiesData.name, 'failed to verify data，name attribute does not match');
			});
		});

		describe('C189168: Operate when ID and dest Id do not correspond, check if the return is correct', function () {

			getDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, 'noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189169: Operate when ID/dest Id does not exist, check whether the return is correct', function () {

			getDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, 'noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189170: Operate when the object interface has no attributes, check whether the return is correct', function () {

			describe('delete the thing interface and its attributes', function () {
				deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('create a new thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});

			describe('perform query operation', function () {
				getDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, 'noResult', store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189171: Operate when the object interface has been released, check whether the return is correct', function () {

			getDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData1.modelId, 'noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189172: Operate when the ID corresponds to dest Id to see if the attribute is modified correctly', function () {

			describe('add attributes to the thingInterfaces', function () {
				postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('execution update operating', function () {
				putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, putDraftThingInterfacesPropertiesData, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189173: Operate when ID does not correspond to dest Id, check whether the attribute is modified correctly', function () {

			putDraftThingInterfacesPropertiesByDestId('postDraftThingInterfacesData.modelId', postDraftThingClassData.modelId, putDraftThingInterfacesPropertiesData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189174: Operate when ID/dest Id does not exist, check whether the return is correct', function () {

			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, 'postDraftThingClassData.modelId', putDraftThingInterfacesPropertiesData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189175: Operate when the attribute does not exist, check whether the return is correct', function () {

			putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, putDraftThingInterfacesPropertiesData1, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189176: Operate when the object model has been published and check whether the return is correct', function () {

			describe('delete the thing interface and its attributes', function () {
				deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('create a new thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});

			describe('add attributes to the thingInterfaces', function () {
				postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('perform this step', function () {
				patchDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('perform update', function () {
				putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, putDraftThingInterfacesPropertiesData, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('un-publish thingInterfaces', function () {
				patchThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189177: Operate when the attribute information is repeated to check whether the return is correct', function () {

			describe('delete the thing interface and its attributes', function () {
				deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('create a new thingInterfaces', function () {
				postDraftThingInterfaces(postDraftThingInterfacesData.draftThingInterfacesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInterfacesPostSchema);
				verifyPayload(store.getLater('response'), postDraftThingInterfacesData.draftThingInterfacesBody);
				Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', postDraftThingInterfacesData.modelId);
			});

			describe('add attributes to the thingInterfaces', function () {
				postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('perform update', function () {
				putDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, putDraftThingInterfacesPropertiesData2, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});
		});

		describe('C189178: Operate when ID and dest Id correspond, check whether the return is correct', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData2.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189179: Operate when ID and dest Id do not correspond, check if the return is correct', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData1.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData2.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189180: Operate when ID/dest Id does not exist, check whether the return is correct', function () {
			postDraftThingInterfacesPropertiesByDestId('postDraftThingInterfacesData1.modelId', postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData2.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete all attributes', function () {
			deleteAllDraftThingInterfacesPropertiesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C189181: Operate when the attribute does not exist, check whether the return is correct', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189182: Operate when the object model is not released, check whether the return is correct', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData2.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C189183: Operate when the object model is not released, check whether the return is correct', function () {
			postDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, postDraftThingInterfacesPropertiesData2.thingInterfaceProperitesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C189184: Operate when ID corresponds to dest Id to see if the attribute is deleted correctly', function () {
			deleteDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, [{ name: postDraftThingInterfacesPropertiesData.name }], store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C189185: Operate when ID and dest Id do not correspond, check if the return is correct', function () {
			deleteDraftThingInterfacesPropertiesByDestId('postDraftThingInterfacesData.modelId', postDraftThingClassData.modelId, [{ name: postDraftThingInterfacesPropertiesData.name }], store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189186: Operate when ID/dest Id does not exist, check whether the return is correct', function () {
			deleteDraftThingInterfacesPropertiesByDestId('postDraftThingInterfacesData.modelId', postDraftThingClassData.modelId, [{ name: postDraftThingInterfacesPropertiesData.name }], store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189186: Operate when ID/dest Id does not exist, check whether the return is correct', function () {
			deleteDraftThingInterfacesPropertiesByDestId('postDraftThingInterfacesData.modelId', postDraftThingClassData.modelId, [{ name: postDraftThingInterfacesPropertiesData.name }], store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189187: Operate when the attribute does not exist, check whether the return is correct', function () {
			deleteDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData.modelId, postDraftThingClassData.modelId, [{ name: 'thingInterfacesPropertiesData.name' }], store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189188: Operate when the object model has been published and check whether the return is correct', function () {
			deleteDraftThingInterfacesPropertiesByDestId(postDraftThingInterfacesData1.modelId, postDraftThingClassData.modelId, [{ name: postDraftThingInterfacesPropertiesData.name }], store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C189189: Operate when the ID exists to see if the attribute is deleted correctly', function () {
			deleteAllDraftThingInterfacesPropertiesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C189190: Operate when the ID does not exist, and check whether the attribute is deleted correctly', function () {
			deleteAllDraftThingInterfacesPropertiesByModelId('noResult', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189191: When the ID does not correspond to the tenant Id, check whether the attribute is deleted correctly', function () {
			deleteAllDraftThingInterfacesPropertiesByModelId('does not correspond', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C189192: When the ID does not correspond to the tenant Id, check whether the attribute is deleted correctly', function () {
			deleteAllDraftThingInterfacesPropertiesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C189193: Operate when the ID has been published, check whether the return is correct', function () {
			deleteAllDraftThingInterfacesPropertiesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//delete C189117 create thingInterfaces
		describe('delete created thingInterfaces', function () {
			deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//删除发布的物接口、物模型
		describe('remove environmental dependencies', function () {
			describe('un-publish thingInterfaces', function () {
				patchThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('delete posted thingInterfaces', function () {
				deleteDraftThingInterfacesByModelId(postDraftThingInterfacesData1.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('un-publish thingClass', function () {
				patchThingClassByModelID(postDraftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('delete thingClass', function () {
				deleteDraftThingClassByModelID(postDraftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 204);
			});


		});
	});
});