'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { ThingClassData, PropertiesData_1, InterfaceData, PropertiesData_2, DeviceData } = require('../../../../test-data/data/tasks/hub/model/GYPT25537');
const { postDraftThingInterfaces, deleteDraftThingInterfacesByModelId, postDraftThingInterfacesPropertiesByDestId, patchDraftThingInterfacesByModelId, patchThingInterfacesByModelId } = require('../../../../test-lib/openApiThingInterfaces');
const { postThingInstancesByModelId, getThingInstances, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema} = require('../../../../test-verify/verify');
const { thingInstanceListSchema} = require('../../../../test-data/schema/thingInstance');

describe('GYPT-25537 : OpenAPI modification', function(){
	describe('precondition', function(){
		postDraftThingClass(ThingClassData.thingClassBody,store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingInterfaces(InterfaceData.draftThingInterfacesBody,store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingInterfacesPropertiesByDestId(InterfaceData.modelId, ThingClassData.modelId, PropertiesData_2.thingInterfaceProperitesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('cancel payload : PATCH /draft/thing/thing-classes/{modelId}', function(){
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('cancel payload : PATCH /thing/thing-classes/{modelId}', function(){
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('cancel payload : PATCH /draft/thing/thing-interfaces/{modelId}', function(){
		patchDraftThingInterfacesByModelId(InterfaceData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('cancel payload : PATCH /thing/thing-interfaces/{modelId}', function(){
		patchThingInterfacesByModelId(InterfaceData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('schema modification : GET /thing/thing-instances', function(){
		postThingInstancesByModelId(ThingClassData.modelId, DeviceData.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		getThingInstances(store.putLater('response'), {criteria: '_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]'});
		verifySchema(store.getLater('response'), thingInstanceListSchema);
	});

	describe('delete posted thingInterfaces', function () {
		deleteDraftThingInterfacesByModelId(InterfaceData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('delete thing instances1', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass', function () {
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass', function () {
		deleteDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});