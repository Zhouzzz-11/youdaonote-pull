'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { Response } = require('@rootcloud/darjeeling-http');

const {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	multipleDevice,
	deleteMulDevice,
	multipleDevice1,
	deleteMulDevice1,
	addLessDeviceTime,
	addMoreDeviceTime,
	lessDevice,
	moreDevice
} = require('../../../../test-data/data/tasks/hub/instan/GYPT20701');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstanceBulkSchema } = require('../../../../test-data/schema/thingInstance');
const { postBulkAddDeviceInstances, postBulkRemoveDeviceInstances } = require('../../../../test-lib/openApi');
const {
	postDraftThingClass,
	deleteDraftThingClassByModelID,
	postDraftThingClassPropertiesByModelID,
	patchDraftThingClassByModelID,
	patchThingClassByModelID,
} = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload, verifyMultiSchema } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-20701 : test Batch registration equipment', function () {
	describe('precondition', function () {
		//设备
		describe('post draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});
	});

	describe(`C1856595:  Batch registration _${lessDevice}`, function () {
		describe('Batch add device', function () {
			// step 1: create draft thing class
			postBulkAddDeviceInstances(multipleDevice, store.putLater('response'), store.putLater('time'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it(`When ${lessDevice} devices are registered, the server returns success in ${addLessDeviceTime} seconds or less`, () => {
				const time = getData(store.get('time'));
				let m = time / 1000;
				if (m <= addLessDeviceTime) {
					Assert.isTrue(true, `server returns success in ${addLessDeviceTime} seconds or less`);
				} else {
					Assert.isTrue(false, `server returns success in ${addLessDeviceTime} seconds or more`);
				}
			});
			verifyMultiSchema(store.getLater('response'), thingInstanceBulkSchema);
			it('retuen success', () => {
				const body = Response.getJsonBody(store.get('response'));
				body.payload.forEach((item, index) => {
					Assert.strictEqual(true, body.payload[index].success, 'Successful registration');
				});
			});
		});

		describe('Batch delete device', function () {
			// step 1: delete  device class
			postBulkRemoveDeviceInstances(deleteMulDevice, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe(`C1856596:  Batch registration _${moreDevice}`, function () {
		describe('Batch add device', function () {
			// step 1: create draft thing class
			postBulkAddDeviceInstances(multipleDevice1, store.putLater('response'), store.putLater('time'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it(`When ${moreDevice} devices are registered, the server returns success in ${addMoreDeviceTime} seconds or less`, () => {
				const body = getData(store.get('time'));
				let m = body / 1000;
				if (m <= addMoreDeviceTime) {
					Assert.isTrue(true, `server returns success in ${addMoreDeviceTime} seconds or less`);
				} else {
					Assert.isTrue(false, `server returns success in ${addMoreDeviceTime} seconds or more`);
				}
			});
			verifyMultiSchema(store.getLater('response'), thingInstanceBulkSchema);
			it('retuen success', () => {
				const body = Response.getJsonBody(store.get('response'));
				body.payload.forEach((item, index) => {
					Assert.strictEqual(true, body.payload[index].success, 'Successful registration');
				});
			});
		});

		describe('Batch delete device', function () {
			// step 1: delete  device class
			postBulkRemoveDeviceInstances(deleteMulDevice1, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('end', function () {
		//设备
		describe('patch  device  class', function () {
			// step 5: unpublish draft device class
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);

		});
	});
});
