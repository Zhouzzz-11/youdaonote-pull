'use strict';

const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId,putThingInstancesByModelIdAndThingId} = require('../../../../test-lib/openApiThingInstances');
const { deviceAggregate} = require('../../../../test-lib/singleDevice');
const { 
	thingClassCompositeData,
	thingclassDeviceData,
	thingPropertyData,
	thingInstanceData,
	thingPropertyData2,
	thingCompositeInstanceData,
	thingclassGatewayData,
	thingPropertyDataGateway,
	thingInstanceGateway,
	thingclassNDeviceData,
	thingPropertyDataNDevice,
	thingInstanceNDevice,
	thingclassDeviceData2,
	thingPropertyData22,
	thingInstanceData2,
	thingInstanceData_1
} = require('../../../../test-data/data/tasks/hub/instan/GYPT32442');
const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { draftThingClassSchema, draftCompositeThingClassSchema } = require('../../../../test-data/schema/thingClass');
const store = new DataStore();
describe('【GYPT-32442】自定义属性维度，查询设备总数，可以支持跨模型',function () {
	describe('C2675206 根据属性过滤，查询直连设备实例总数',function () {
		describe('create  device thing class ',function () {
			postDraftThingClass(thingclassDeviceData.thingClassBody,store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'),200);
			verifySchema(store.getLater('response1'),draftThingClassSchema);
			verifyPayload(store.getLater('response1'),thingclassDeviceData.thingClassBody);

			postDraftThingClassPropertiesByModelID(thingclassDeviceData.modelId,thingPropertyData.thingPropertiesBody,store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'),200);

			patchDraftThingClassByModelID(thingclassDeviceData.modelId,store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'),200);

			postThingInstancesByModelId(thingclassDeviceData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);

			deviceAggregate('description',thingclassDeviceData.modelId,store.putLater('response13'));
			Response.statusCodeEquals(store.getLater('response13'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response13'), `payload[0].count`, 1);

			
		});
		describe('C2675209 根据属性过滤，查询复合物实例总数',function () {
			postDraftThingClass(thingClassCompositeData.CompositeThingClassBody,store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'),200);
			verifySchema(store.getLater('response2'),draftCompositeThingClassSchema);

			postDraftThingClassPropertiesByModelID(thingClassCompositeData.modelId,thingPropertyData2.thingPropertiesBody,store.putLater('response3'));
			Response.statusCodeEquals(store.getLater('response3'),200);

			patchDraftThingClassByModelID(thingClassCompositeData.modelId,store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'),200);

			postThingInstancesByModelId(thingClassCompositeData.modelId, thingCompositeInstanceData.CompositeThingBody, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);

			deviceAggregate('description',thingclassDeviceData.modelId,store.putLater('response13'));
			Response.statusCodeEquals(store.getLater('response13'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response13'), `payload[0].count`, 2);
		});

		describe('C2675208 根据属性过滤，查询网关设备实例总数',function () {
			postDraftThingClass(thingclassGatewayData.thingClassBody,store.putLater('response5'));
			Response.statusCodeEquals(store.getLater('response5'),200);

			postDraftThingClassPropertiesByModelID(thingclassGatewayData.modelId,thingPropertyDataGateway.thingPropertiesBody,store.putLater('response6'));
			Response.statusCodeEquals(store.getLater('response6'),200);

			patchDraftThingClassByModelID(thingclassGatewayData.modelId,store.putLater('response7'));
			Response.statusCodeEquals(store.getLater('response7'),200);

			postThingInstancesByModelId(thingclassGatewayData.modelId,thingInstanceGateway.thingInstanceBody,store.putLater('response8'));
			Response.statusCodeEquals(store.getLater('response8'),200);

			deviceAggregate('description',thingclassDeviceData.modelId,store.putLater('response13'));
			Response.statusCodeEquals(store.getLater('response13'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response13'), `payload[0].count`, 3);
		});
		
		describe('C2675207 根据属性过滤，查询非直连设备实例总数',function () {
			postDraftThingClass(thingclassNDeviceData.thingClassBody,store.putLater('response9'));
			Response.statusCodeEquals(store.getLater('response9'),200);

			postDraftThingClassPropertiesByModelID(thingclassNDeviceData.modelId,thingPropertyDataNDevice.thingPropertiesBody,store.putLater('response10'));
			Response.statusCodeEquals(store.getLater('response10'),200);

			patchDraftThingClassByModelID(thingclassNDeviceData.modelId,store.putLater('response11'));
			Response.statusCodeEquals(store.getLater('response11'),200);

			postThingInstancesByModelId(thingclassNDeviceData.modelId,thingInstanceNDevice.thingInstanceBody,store.putLater('response12'));
			Response.statusCodeEquals(store.getLater('response12'),200);

			deviceAggregate('description',thingclassDeviceData.modelId,store.putLater('response13'));
			Response.statusCodeEquals(store.getLater('response13'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response13'), `payload[0].count`, 4);
			
		});
		describe('C2675211 根据属性过滤，查询设备模型/网关/复合物模型的实例总数',function () {
			deviceAggregate('description',thingclassDeviceData.modelId,store.putLater('response13'));
			Response.statusCodeEquals(store.getLater('response13'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response13'), `payload[0].count`, 4);
		});
	
		describe('C2675215 检查属性值undefined null 为空 不存在 特殊字符等情况查询实例是否正常',function () {
			postDraftThingClass(thingclassDeviceData2.thingClassBody,store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'),200);
			verifySchema(store.getLater('response1'),draftThingClassSchema);
			verifyPayload(store.getLater('response1'),thingclassDeviceData2.thingClassBody);

			postDraftThingClassPropertiesByModelID(thingclassDeviceData2.modelId,thingPropertyData22.thingPropertiesBody,store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'),200);

			patchDraftThingClassByModelID(thingclassDeviceData2.modelId,store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'),200);

			postThingInstancesByModelId(thingclassDeviceData2.modelId, thingInstanceData2.thingInstanceBody, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);

			deviceAggregate('description',thingclassDeviceData2.modelId+'~!@#$%^&*()_+',store.putLater('response13'));
			Response.statusCodeEquals(store.getLater('response13'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response13'), `payload[0].count`, 1);

		});
		describe('C2675214 检查属性值修改以后，查询设备模型和复合物模型实例是否正常',function () {
			putThingInstancesByModelIdAndThingId(thingclassNDeviceData.modelId,thingInstanceNDevice.thingId,thingInstanceData_1.thingInstanceBody,store.putLater('response14'));
			Response.statusCodeEquals(store.getLater('response14'),200);

			deviceAggregate('description',thingclassDeviceData.modelId+'testd4d75a4d153c3f0e27c4df14c2053434',store.putLater('response15'));
			Response.statusCodeEquals(store.getLater('response15'),200);
			Response.bodyJsonPropertyEquals(store.getLater('response15'), `payload[0].count`, 1);
		});

	});
});
