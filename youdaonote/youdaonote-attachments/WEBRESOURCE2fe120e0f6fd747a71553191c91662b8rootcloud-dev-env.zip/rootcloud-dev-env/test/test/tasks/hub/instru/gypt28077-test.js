'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassData, draftThingClassModelPropertiesData, createInstructionsTemplateData, createInstructionsTemplateData_1, ListInstructionTemplateId_4, createInstructionsTemplateData_2, ListInstructionTemplateId_1, createInstructionsTemplateData_3, ListInstructionTemplateId_2, ListInstructionTemplateId_3 } = require('../../../../test-data/data/tasks/hub/instru/GYPT28077');
const { deleteAllInstructionTemplate, batchDeleteInstructionTemplate, postInstructionTemplate, getInstructionTemplate } = require('../../../../test-lib/instructionTemplate');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const store = new DataStore();

describe('GYPT-28077: Batch delete instructionTemplate', function () {

	describe('Create environment', function () {
		describe('Create draft thing class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Create draft thing class properties', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2242951:Delete instructionTemplate when Model not activated', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete instructionTemplate when Model not activated', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_2);
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242953: Delete deleted instructionTemplate', function () {

		describe('Delete deleted instructionTemplate', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_1);
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242952:Delete all instructionTemplate when model not activated', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete all instructionTemplate when model not activated', function () {
			deleteAllInstructionTemplate(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('C2242942: Delete published instructionTemplate', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_3.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete published instructionTemplate', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_2);
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242943: Delete unpublished instructionTemplate', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete unpublished instructionTemplate', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_2);
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('C2242945:Delete instructionTemplate failed when model does not exist', function () {

		describe('Delete instructionTemplate failed when model does not exist', function () {
			batchDeleteInstructionTemplate('', store.putLater('response'), createInstructionsTemplateData.instructionsBody.instructionTemplateId);
			Response.statusCodeEquals(store.getLater('response'), 404);
		});
	});

	describe('C2242944: Delete published and unpublished instructions', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete published and unpublished instructionTemplate', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_3);
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('C2247840: Delete nonexistent and existing instructionTemplate', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete nonexistent and existing instructionTemplate', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_4);
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242946: Unselected instructionTemplate will not be deleted', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_3.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Unselected instructionTemplate will not be deleted', function () {
			batchDeleteInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), ListInstructionTemplateId_1);
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('Verify that unselected instructionTemplate are not deleted', function () {
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData_3.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length > 0);
			});
		});
	});

	describe('C2242948: Delete all unpublished instructionTemplate', function () {

		describe('Delete all unpublished instructionTemplate', function () {
			deleteAllInstructionTemplate(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242947: Delete all issued instructionTemplate', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete all issued instructionTemplate', function () {
			deleteAllInstructionTemplate(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242949: Delete all published and unpublished instructionTemplate', function () {

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Create instructionTemplate', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsTemplateData_3.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete all published and unpublished instructionTemplate', function () {
			deleteAllInstructionTemplate(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsTemplateData.instructionsBody.instructionTemplateId });
			it('Check return value', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.length == 0);
			});
		});
	});

	describe('C2242950: Delete instructionTemplate failed when model does not exist', function () {

		describe('Delete instructionTemplate failed when model does not exist', function () {
			deleteAllInstructionTemplate('', store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 404);
		});
	});

	describe('C2242954:Delete all instructionTemplate again', function () {

		describe('Delete all instructionTemplate again', function () {
			deleteAllInstructionTemplate(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('Clear environment', function () {
		describe('patch thing class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('delete thing  model', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
