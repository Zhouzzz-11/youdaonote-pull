'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postAlarmCategories,
	postAlarmTypeData,
	msgData,
	msgData1,
	msgData2,
	msgData3,
	msgData4,
	postDraftThingClassData1,
	PostDraftThingClassModelPropertiesData2,
	postAlarmTypeData2,
	thingInstanceData1,
	msgData5,
	msgData6,
	msgData7,
	msgData8,
	msgData9,
	msgData10,
	msgData11,
	postAlarmTypeData1,
	postAlarmTypeData3,
	PostDraftThingClassModelPropertiesData,
	PostDraftThingClassModelPropertiesData1,
	PostDraftThingClassModelPropertiesData3,
	postAlarmTypeData4,
	thingInstanceData,
	postDraftThingClassData,
	postAlarmTypeData5,
	postDraftThingClassData2,
	thingInstanceData2,
	postAlarmSeverities } = require('../../../../test-data/data/tasks/hub/alarm/GYPT21550');
const { responseAlarmCategories, responseAlarmType, responseAlarmHistory } = require('../../../../test-data/schema/alarmType');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { postData, itWait } = require('../../../../test-data/util');
const { topicDict } = require('../../../../test-data/requireData');
const { createAlarmCategories, createAlarmSeverities, createAlarmType, deleteAlarmSeverities, deleteAlarmCategories } = require('../../../../test-lib/alarmType');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { getAlarmAll, getAlarmCountByThingId } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload, verifyMultiSchema } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-21550: E2E test everyTimeInterval in everyTime mode', function () {

	describe('environmental dependence create alarm categories 3', function () {
		//environmentalDependence create alarmCategories
		describe('create the first alarm category', function () {
			createAlarmCategories(postAlarmCategories.alarmCategoriesBody, store.putLater('response'), store.putLater('cid1'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), responseAlarmCategories);
			verifyPayload(store.getLater('response'), postAlarmCategories.alarmCategoriesBody);
		});

		describe('create alarm levels', function () {
			createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
			//Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('The environment required to create the publication thing class', function () {
			postDraftThingClass(postDraftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), postDraftThingClassData.thingClassBody);
		});

		describe('add attributes to the thingClass', function () {
			postDraftThingClassPropertiesByModelID(postDraftThingClassData.modelId, PostDraftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('add attributes1 to the thingClass', function () {
			postDraftThingClassPropertiesByModelID(postDraftThingClassData.modelId, PostDraftThingClassModelPropertiesData1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('restore the environment', function () {
			createAlarmType(postAlarmTypeData.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), responseAlarmType);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData.alarmTypeBody.alarmTypeId);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData.alarmTypeBody.categoryIds[0]);
		});

		describe('create alarm type', function () {
			createAlarmType(postAlarmTypeData1.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), responseAlarmType);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData1.alarmTypeBody.alarmTypeId);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData1.alarmTypeBody.categoryIds[0]);
		});

		describe('publication thingClass', function () {
			patchDraftThingClassByModelID(postDraftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function() {
			postThingInstancesByModelId(postDraftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
	});

	describe('C2069866: verify that every time interval is not set and every alarm will be sent', function () {

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData.mesBody);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData1.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData7.mesBody);
		});

		//find alarm history
		describe('verify alarm sent successfully', function () {
			getAlarmAll(store.putLater('responseHistory'), { retryCode: 404, expectNum: 3, criteria: `thingIds=["${thingInstanceData.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory'), 200);
			verifyMultiSchema(store.getLater('responseHistory'), responseAlarmHistory);
		});
	});

	describe('wait for 3000ms', function () {
		itWait(3000);
	});

	describe('C2069867: Verify that every time interval is set to 0, and every alarm will be sent', function () {

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData2.mesBody);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData3.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData.thingId, msgData8.mesBody);
		});

		//find alarm history
		describe('verify alarm sent successfully', function () {
			getAlarmAll(store.putLater('responseHistory'), { retryCode: 404, expectNum: 6, criteria: `thingIds=["${thingInstanceData.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory'), 200);
			verifyMultiSchema(store.getLater('responseHistory'), responseAlarmHistory);
		});
	});

	describe('C2069870: Verify that the Every Time Interval is set to non-zero and no alarm will be sent when the interval is not reached', function () {
		describe('The environment required to create the publication thing class', function () {
			postDraftThingClass(postDraftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), postDraftThingClassData1.thingClassBody);
		});

		describe('add attributes to the thingClass', function () {
			postDraftThingClassPropertiesByModelID(postDraftThingClassData1.modelId, PostDraftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('add attributes to the thingClass', function () {
			postDraftThingClassPropertiesByModelID(postDraftThingClassData1.modelId, PostDraftThingClassModelPropertiesData3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('restore the environment2', function () {
			createAlarmType(postAlarmTypeData2.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), responseAlarmType);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData2.alarmTypeBody.alarmTypeId);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData2.alarmTypeBody.categoryIds[0]);
		});

		describe('restore the environment4', function () {
			createAlarmType(postAlarmTypeData4.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), responseAlarmType);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData4.alarmTypeBody.alarmTypeId);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData4.alarmTypeBody.categoryIds[0]);
		});

		describe('publication thingClass', function () {
			patchDraftThingClassByModelID(postDraftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function() {
			postThingInstancesByModelId(postDraftThingClassData1.modelId, thingInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData1.thingInstanceBody);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData4.mesBody);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData5.mesBody);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData6.mesBody);
		});

		//find alarm history
		describe('verify alarm sent successfully', function () {
			getAlarmAll(store.putLater('responseHistory1'), { retryCode: 404, expectNum: 1, criteria: `thingIds=["${thingInstanceData1.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory1'), 200);
			verifyMultiSchema(store.getLater('responseHistory1'), responseAlarmHistory);
		});
	});

	describe('C2069869: Verify that the Every Time Interval is set to non-zero. If the alarm condition is not met, the sent alarms are all set to off.', function () {
		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData6.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData11.mesBody);
		});

		//find alarm history
		describe('verify alarm sent successfully', function () {
			getAlarmAll(store.putLater('responseHistory2'), { retryCode: 404, expectNum: 1, criteria: `thingIds=["${thingInstanceData1.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory2'), 200);
			verifyMultiSchema(store.getLater('responseHistory2'), responseAlarmHistory);
			Response.bodyJsonPropertyEquals(store.getLater('responseHistory2'), 'payload[0].closed', true);
		});
	});

	describe('C2069868: Verify that every Time Interval is set to non-zero, and send an alarm at this value', function () {
		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData5.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData9.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData10.mesBody);
		});

		//find alarm history
		describe('verify alarm sent successfully', function () {
			getAlarmAll(store.putLater('responseHistory3'), { retryCode: 404, expectNum: 2, criteria: `thingIds=["${thingInstanceData1.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory3'), 200);
			verifyMultiSchema(store.getLater('responseHistory3'), responseAlarmHistory);
		});

		describe('wait for 3000ms', function () {
			itWait(3000);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData5.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData9.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData1.thingId, msgData10.mesBody);
		});

		//find alarm history
		describe('wait for 3000ms and trigger the alarm again', function () {
			getAlarmAll(store.putLater('responseHistory3'), { retryCode: 404, expectNum: 3, criteria: `thingIds=["${thingInstanceData1.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory3'), 200);
			verifyMultiSchema(store.getLater('responseHistory3'), responseAlarmHistory);
		});
	});
	
	describe('C2069871: Verify that when the alarm method is "becomesTrue", setting the Every Time Interval fails and gives a prompt', function () {
		createAlarmType(postAlarmTypeData3.alarmTypeBody, store.putLater('response'), store.putLater('id'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		verifySchema(store.getLater('response'), errorResponseSchema);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', '不合法的触发方式(body中的everyTimeInterval只能用于everyTime触发方式)');
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'code', 'CMS-1014');
	});

	describe('C2069872: Verify that the Every Time Interval and delay Period are non-zero, and the alarm will be sent when both are met', function () {

		describe('The environment required to create the publication thing class', function () {
			postDraftThingClass(postDraftThingClassData2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), postDraftThingClassData2.thingClassBody);
		});

		describe('add attributes to the thingClass', function () {
			postDraftThingClassPropertiesByModelID(postDraftThingClassData2.modelId, PostDraftThingClassModelPropertiesData3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('restore the environment4', function () {
			createAlarmType(postAlarmTypeData5.alarmTypeBody, store.putLater('response'), store.putLater('id'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), responseAlarmType);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmTypeId', postAlarmTypeData5.alarmTypeBody.alarmTypeId);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.alarmInfo.categories[0].cid', postAlarmTypeData5.alarmTypeBody.categoryIds[0]);
		});

		describe('publication thingClass', function () {
			patchDraftThingClassByModelID(postDraftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function() {
			postThingInstancesByModelId(postDraftThingClassData2.modelId, thingInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData2.thingInstanceBody);
		});

		//send condition
		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData2.thingId, msgData7.mesBody);
		});

		describe('check if the alarm is triggered within the delay time', function () {
			getAlarmCountByThingId(thingInstanceData2.thingId, postDraftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.totalNum', 0);
		});

		describe('wait for 1000ms', function () {
			itWait(1000);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData2.thingId, msgData.mesBody);
		});

		describe('1 send continuously within the period, check whether the alarm is triggered', function () {
			getAlarmAll(store.putLater('responseHistory4'), { retryCode: 404, expectNum: 1, criteria: `thingIds=["${thingInstanceData2.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory4'), 200);
			verifyMultiSchema(store.getLater('responseHistory4'), responseAlarmHistory);
		});

		describe('check if the alarm is triggered within the delay time', function () {
			getAlarmCountByThingId(thingInstanceData2.thingId, postDraftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.totalNum', 1);
		});

		describe('wait for 3000ms', function () {
			itWait(3000);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData2.thingId, msgData.mesBody);
		});

		describe('post data with mqtt', function() {
			postData(topicDict['pub_1.1'], thingInstanceData2.thingId, msgData1.mesBody);
		});

		describe('2 send continuously within the period, check whether the alarm is triggered', function () {
			getAlarmAll(store.putLater('responseHistory4'), { retryCode: 404, expectNum: 2, criteria: `thingIds=["${thingInstanceData2.thingId}"]`});
			Response.statusCodeEquals(store.getLater('responseHistory4'), 200);
			verifyMultiSchema(store.getLater('responseHistory4'), responseAlarmHistory);
		});
	});

	describe('remove created environment dependencies', function () {

		describe('delete thing instances', function () {
			deleteThingInstancesByModelIdAndThingId(postDraftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(postDraftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thingClass', function () {
			deleteDraftThingClassByModelID(postDraftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//删除创建的第二个设备   C2069872
		describe('delete thing instances2', function () {
			deleteThingInstancesByModelIdAndThingId(postDraftThingClassData2.modelId, thingInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass2', function () {
			patchThingClassByModelID(postDraftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thingClass2', function () {
			deleteDraftThingClassByModelID(postDraftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//删除第一个设备
		describe('delete thing instances1', function () {
			deleteThingInstancesByModelIdAndThingId(postDraftThingClassData1.modelId, thingInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass1', function () {
			patchThingClassByModelID(postDraftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thingClass1', function () {
			deleteDraftThingClassByModelID(postDraftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//删除报警器相关
		describe('restore the environment', function () {
			//delete alarm level
			deleteAlarmSeverities(store.getLater('level'), store.putLater('response'));
			// Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('restore the environment', function () {
			//delete alarm category
			deleteAlarmCategories(store.getLater('cid1'), store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});
});