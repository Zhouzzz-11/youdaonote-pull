'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID, patchThingClassByModelID, patchDraftThingClassByModelID, putDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { topicDict } = require('../../../../test-data/requireData');
const { ThingClassData, ThingClassData_2, PropertiesData_1, PropertiesData_2, PropertiesData_3, DeviceData_1, DeviceData_3, postdata_1, postdata_2, postdata_3 } = require('../../../../test-data/data/tasks/hub/model/GYPT15596');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');

describe('GYPT-15596 : workingstatus data source can be a mapping or a expression', function () {
	describe('precondition', function () {
		postDraftThingClass(ThingClassData.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postDraftThingClass(ThingClassData_2.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2126122 : workingstatus value is correct when its source is a mapping and the postdata has mapping data', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postThingInstancesByModelId(ThingClassData.modelId, DeviceData_1.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		getMqttClient(DeviceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], postdata_1.mesBody);
		closeClient(store.getLater('client'));

		getRealTimeByModelAndThingId(DeviceData_1.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_1.name}.value`, '正常');
	});

	describe('C2126150 : workingstatus value is not updated when its source is a mapping and the postdata not has mapping data', function () {
		getMqttClient(DeviceData_1.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], postdata_2.mesBody);
		closeClient(store.getLater('client'));
		getRealTimeByModelAndThingId(DeviceData_1.thingId, ThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_1.name}.value`, '正常');
	});

	describe('C2126123 : workingstatus value is correct when its source is a expression', function () {
		postDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		// patchDraftThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
		// Response.statusCodeEquals(store.getLater('response'), 200);
		// postThingInstancesByModelId(ThingClassData_2.modelId, DeviceData_3.thingInstanceBody, store.putLater('response'));
		// Response.statusCodeEquals(store.getLater('response'), 200);

		postDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData_2.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		putDraftThingClassPropertiesByModelID(ThingClassData_2.modelId, PropertiesData_3.UpdatethingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData_2.modelId, DeviceData_3.thingInstanceBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		getMqttClient(DeviceData_3.thingId, (client) => {
			store.put('client', client);
		});
		postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], postdata_3.mesBody);
		closeClient(store.getLater('client'));

		getRealTimeByModelAndThingId(DeviceData_3.thingId, ThingClassData_2.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${PropertiesData_1.name}.value`, '作业');
	});

	describe('delete thing instances1', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData.modelId, DeviceData_1.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});