'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { errMesDict } = require('../../../../test-data/requireData');
const { draftThingClassData, draftThingClassModelPropertiesData } = require('../../../../test-data/data/tasks/hub/model/GYPT29577');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { postDraftThingClass,  postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload, verifyResponseMessage } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-29577: 不允许对int做线性变换', function () {

	describe('对Int做线性变换', function () {

		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });
        
		describe('post properties with int', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), errMesDict['only_support_number']);
        });
        
        describe('post properties with string', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyResponseMessage(store.getLater('response'), errMesDict['only_support_number']);
		});
    });
});