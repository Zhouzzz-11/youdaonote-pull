'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	activeData,
	thingInstanceData,
	cloudTimeData,
} = require('../../../../test-data/data/tasks/hub/instru/GYPT18571');

const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');

const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage, closeClient } = require('../../../../test-lib/mqtt');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-18571: The device initiates the CloudTime instruction end-to-end test', function () {

	describe('create environment dependent data', function () {

		describe('creation draft thing class device model', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('add attributes to unpublished thing class device model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
	});

	describe('C2126164: The device initiates the CloudTime instruction end-to-end test', function () {

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('get data with mqtt', function () {
			subDataWithClient(store.getLater('client'), topicDict['sub_1.0'], store.putLater('response'));
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_cloud_1.0'], cloudTimeData.cloudTimeBody);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
		});

		describe('close Client mqtt', function () {
			closeClient(store.getLater('client'));
		});
	});

	describe('delete environment dependent data', function () {
		describe('delete thing device model', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft thing class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft thing class', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.getLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});
});
