'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData, instructionRequestsData, thingInstanceData_3, thingInstanceData_6, responseData5, responseData6, instructionRequestsData_6, thingInstanceData_4, instructionRequestsData_3, instructionRequestsData_5, thingInstanceData_5, responseData3, responseData4, responseData2, instructionRequestsData_4, responseData1, instructionRequestsData_2, thingInstanceData_1, thingInstanceData_2, responseData, instructionRequestsData_1, instructionRequestsData2, draftThingClassPropertiesData, instructionRequestsData1, thingInstanceData, draftThingClassData1, draftGatewayClassData, thingClassModelInstanceData1, thingClassModelInstanceData2 } = require('../../../../test-data/data/tasks/hub/instru/GYPT20732');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postInstructionRequests, getInstructionRequestsByRequestId1 } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage } = require('../../../../test-lib/mqtt');
const store = new DataStore();

describe('GYPT-20732: instruction request by file issuance', function () {

	describe('start  build environment dependency', function () {
		//直连设备
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});
		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});
	});

	describe('C1849288: directly connected device delivery', function () {
		postInstructionRequests(instructionRequestsData.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1849289: delivered by non-directly connected devices', function () {
		postInstructionRequests(instructionRequestsData1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1849290: delivered by gateway devices', function () {
		postInstructionRequests(instructionRequestsData2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1849291: check if the device can receive the platform return', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_pub'], responseData.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_1.requestId, store.putLater('response'), { status: 'IN_PROGRESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'IN_PROGRESS');

			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});
	
	describe('C1849292: check if the device can receive the platform return and ack = true', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_2.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_2.thingId, (client) => { store.put('client1', client); }, store.putLater('message1'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client1'), topicDict['files_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message1'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client1'), topicDict['files_pub'], responseData1.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_2.requestId, store.putLater('response'), {status: 'RECEIVED'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');

			after(() => {
				const client = store.get('client1');
				client.end();
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849293: check if the device can respond to the platform: ack is false', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_3.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message2'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_3.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message2'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_pub'], responseData2.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_3.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');

			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849294: modify the "is Completed" field. When it is false, whether to display the progress progress', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_4.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message3'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_4.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message3'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_pub'], responseData3.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_4.requestId, store.putLater('response'), {status: 'IN_PROGRESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'IN_PROGRESS');

			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849295: modify the "is Completed" field. When it is true, whether the progress progress is not displayed', function () {
		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_5.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_5.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_5.thingId, (client) => { store.put('client', client); }, store.putLater('message4'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_5.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message4'),store.putLater('response'));
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_pub'], responseData4.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_5.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');

			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_5.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1849296: for one instruction, the device returns status to the platform multiple times', function () {

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_6.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_6.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData_6.thingId, (client) => { store.put('client', client); }, store.putLater('message6'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_6.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message6'),store.putLater('response'));
		});

		describe('response1', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_pub'], responseData5.instructionBody);
		});

		describe('query instruction status1', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_6.requestId, store.putLater('response'), { status: 'IN_PROGRESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'IN_PROGRESS');
		});

		describe('response2', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_pub'], responseData6.instructionBody);
		});

		describe('query instruction status2', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_6.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');

			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_6.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('end remove environment dependencies', function () {
		//直连设备
		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('delete gateway device', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
