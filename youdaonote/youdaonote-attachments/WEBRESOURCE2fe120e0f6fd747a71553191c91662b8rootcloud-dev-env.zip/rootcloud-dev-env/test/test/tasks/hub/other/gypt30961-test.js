'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { draftThingClassData,
  draftThingClassModelPropertiesData,
  draftThingClassModelPropertiesData_1,
  thingClassModelInstanceData,
  msgData,
  msgData_1 } = require('../../../../test-data/data/tasks/hub/other/GYPT30961');
const { topicDict } = require('../../../../test-data/requireData');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');

const store = new DataStore();
describe('GYPT-30961: 添加一个属性后发布并给新属性上数，新属性实时数据没有值', function () {

  after(() => {
    const client = store.get('client');
    client.end();
  });
  describe('post draft device class', function () {
    postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifySchema(store.getLater('response'), draftThingClassSchema);
    verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
  });

  describe('Successfully added the first properties to model', function () {
    postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('patch device model class by model id', function () {
    patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('post device model instance by model id, Send condition', function () {
    postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifySchema(store.getLater('response'), thingInstancePostSchema);
    verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
    getMqttClient(thingClassModelInstanceData.thingId, (client) => {
      store.put('client', client);
    });
  });

  describe('post the first data with mqtt', function () {
    postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
    closeClient(store.getLater('client'));
  });

  describe('testing the first delivery condition', function () {
    getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
    Response.statusCodeEquals(store.getLater('response'), 200);
    Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData.name}.value`, 11);
  });

  describe('Successfully added the second properties to model', function () {
    postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('patch device model class by model id', function () {
    patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
    getMqttClient(thingClassModelInstanceData.thingId, (client) => {
      store.put('client', client);
    });
  });

  describe('post the second data with mqtt', function () {
    postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData_1.mesBody);
    closeClient(store.getLater('client'));
  });

  describe('testing the second delivery condition', function () {
    getRealTimeByModelAndThingId(thingClassModelInstanceData.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 2 });
    Response.statusCodeEquals(store.getLater('response'), 200);
    Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${draftThingClassModelPropertiesData_1.name}.value`, 21);
  });

  describe('delete thing device model', function () {
    deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('patch draft thing class', function () {
    patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });

  describe('delete draft thing class', function () {
    deleteDraftThingClassByModelID(draftThingClassData.modelId, store.getLater('response'));
    Response.statusCodeEquals(store.getLater('response'), 200);
    verifyPayload(store.getLater('response'), {});
  });
});
