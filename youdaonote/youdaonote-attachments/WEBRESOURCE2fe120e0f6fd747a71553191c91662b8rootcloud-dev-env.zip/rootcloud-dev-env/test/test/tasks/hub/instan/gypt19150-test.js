'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	activeData,
	thingClassModelInstanceData,
	thingClassModelInstanceData_7,
	thingClassModelInstanceData_3,
	msgData,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceData_1,
	thingClassModelInstanceData_4,
	thingClassModelInstanceData_6,
	thingClassModelInstanceData_8,
	draftThingClassData_2,
	draftThingClassModelPropertiesData_2,
	thingClassModelInstanceData_2,
	thingClassModelInstanceData_5,
	thingClassModelInstanceData_9,
	msgData1,
	msgData2 } = require('../../../../test-data/data/tasks/hub/instan/GYPT19150');
const { topicDict } = require('../../../../test-data/requireData');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { getDeviceByDeviceOnlineStatusId } = require('../../../../test-lib/singleDevice');
const { getRealTimeByModelAndThingId } = require('../../../../test-lib/openApiHistorian');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('/Definition of device status inactive changed to never go online', function () {

	describe('GYPT-19150: Create/Delete Direct link device', function () {

		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id, no online', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('C285206: Directly connected terminal equipment, Never Online', function () {
			getDeviceByDeviceOnlineStatusId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'), { flag: false });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
		});

		describe('post device model instance by model id, Continuous delivery condition', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_7.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_7.thingInstanceBody);
		});

		describe('post data with mqtt', function () {
			getMqttClient(thingClassModelInstanceData_7.thingId, (client) => {
				store.put('client', client);
			});
			for (let i = 0; i < 3; i++) {
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			}
		});

		describe('C285207: Directly connected terminal equipment, Continuous delivery condition', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_7.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			Response.statusCodeEquals(store.getLater('response'), 200);
			getDeviceByDeviceOnlineStatusId(draftThingClassData.modelId, thingClassModelInstanceData_7.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('post device model instance by model id, Send first condition', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_3.thingInstanceBody);
			getMqttClient(thingClassModelInstanceData_3.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			closeClient(store.getLater('client'));
		});

		describe('C285208: Directly connected terminal equipment, Never Online, Send first condition', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_3.thingId, draftThingClassData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			Response.statusCodeEquals(store.getLater('response'), 200);
			getDeviceByDeviceOnlineStatusId(draftThingClassData.modelId, thingClassModelInstanceData_3.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
		});

		describe('delete thing  instances, no online', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  instances, no online', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_7.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  instances, Send first condition', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing model', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('GYPT-19150: Create/Delete gateway device', function () {

		describe('post gateway device model class', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post Gateway device model instance by model id, no online', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		});

		describe('C285209: Gateway device status check, no online', function () {
			getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'), { flag: false });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
		});

		describe('post device model instance by model id, Continuous delivery condition', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_8.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_8.thingInstanceBody);
		});

		describe('post data with mqtt', function () {
			getMqttClient(thingClassModelInstanceData_8.thingId, (client) => {
				store.put('client', client);
			});
			for (let i = 0; i < 3; i++) {
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			}
		});

		describe('C285210:Gateway device status check, Continuous delivery condition', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_8.thingId, draftThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			Response.statusCodeEquals(store.getLater('response'), 200);
			getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_8.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('post device model instance by model id, Send first condition', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_4.thingInstanceBody);
		});

		describe('post data with mqtt', function () {
			getMqttClient(thingClassModelInstanceData_8.thingId, (client) => {
				store.put('client', client);
			});
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
			closeClient(store.getLater('client'));
		});

		describe('C285211:Gateway device status check, Send first condition', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_8.thingId, draftThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			Response.statusCodeEquals(store.getLater('response'), 200);
			getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_8.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
		});
	});

	describe('GYPT-19150: Create/Delete No Direct link device', function () {

		describe('post No Direct link device model class', function () {
			postDraftThingClass(draftThingClassData_2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_2.thingClassBody);
		});
		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, activeData, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post Gateway device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_6.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_6.thingInstanceBody);
		});

		describe('post No Direct link device model class,never online', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

		describe('C285212:  No Direct link status check,never online', function () {
			getDeviceByDeviceOnlineStatusId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, store.putLater('response'), { flag: false });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does not contain the firstDataTime field');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('post No Direct link device model class,Continuous delivery condition', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_9.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);

		});

		describe('post data with mqtt', function () {
			getMqttClient(thingClassModelInstanceData_8.thingId, (client) => {
				store.put('client', client);
			});
			for (let i = 0; i < 3; i++) {
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData2.mesBody);
			}
		});

		describe('C285213: No Direct link device status check, Continuous delivery condition', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_8.thingId, draftThingClassData_1.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			Response.statusCodeEquals(store.getLater('response'), 200);
			getDeviceByDeviceOnlineStatusId(draftThingClassData_1.modelId, thingClassModelInstanceData_8.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
			after(() => {
				const client = store.get('client');
				client.end();
			});
		});

		describe('post No Direct link device model class, Send first condition', function () {
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_5.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			getMqttClient(thingClassModelInstanceData_6.thingId, (client) => {
				store.put('client', client);
			});
		});

		describe('post data with mqtt', function () {
			postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData1.mesBody);
			closeClient(store.getLater('client'));
		});

		describe('C285214: No Direct link device status check, Send first condition', function () {
			getRealTimeByModelAndThingId(thingClassModelInstanceData_5.thingId, draftThingClassData_2.modelId, store.putLater('response'), { retryCode: 404, expectNum: 1 });
			Response.statusCodeEquals(store.getLater('response'), 200);
			getDeviceByDeviceOnlineStatusId(draftThingClassData_2.modelId, thingClassModelInstanceData_5.thingId, store.putLater('response'), { flag: true });
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(Object.prototype.hasOwnProperty.call(body.payload, 'firstDataTime'), 'check does contain the firstDataTime field');
			});
		});

		describe('delete thing  instances, no online', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  instances, Send first condition', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_5.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  instances, Continuous delivery condition', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_9.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  model', function () {
			deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('delete thing  gateway device, no online', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  gateway device, Send first condition', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  gateway device, Continuous delivery condition', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_6.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  gateway device, Continuous delivery condition', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_8.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  model', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});