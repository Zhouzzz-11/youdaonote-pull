'use strict';

const { Assert, DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	draftCompositeThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceCompositeData_1,
	updatethingClassModelInstanceCompositeData_1,
	thingClassModelInstanceCompositeData_2,
	updatethingClassModelInstanceCompositeData_3,
	thingClassModelInstanceCompositeData_4,
	updatethingClassModelInstanceCompositeData_5,
	thingClassModelInstanceCompositeData_6,
	updatethingClassModelInstanceCompositeData_7, } = require('../../../../test-data/data/tasks/hub/instan/GYPT19396');
const { draftThingClassSchema, draftCompositeThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema, thingInstanceCompositeSchema } = require('../../../../test-data/schema/thingInstance');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, putThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();
describe('/The manufacturer name can be filled in manually when creating the device', function () {

	describe('GYPT-19396: Create/Delete device', function () {
		// step 1: create draft thing class
		postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
		// verification status code, payload and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		// step 2: create draft thing class {modelId}/properties
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
		// step 3: Patch  thing draft thing-classes  发布
		patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
		// step 2: create draft thing class
		postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
		// verification status code, payload and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), thingInstancePostSchema);
		verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);

		describe('C1720532: post ID is compositeThing', function () {
			// step 1: create draft thing class
			postDraftThingClass(draftCompositeThingClassData_1.CompositeThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			// step 2: create draft thing class {modelId}/properties
			postDraftThingClassPropertiesByModelID(draftCompositeThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 3: Patch  thing draft thing-classes  发布
			patchDraftThingClassByModelID(draftCompositeThingClassData_1.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 4: create draft CompositeThing class
			postThingInstancesByModelId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_1.CompositeThingBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceCompositeData_1.CompositeThingBody);
			it('Check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.deepEqual(body.payload.assetId, body.payload.thingId, 'true');
			});
		});

		describe('C1720536: update ID is compositeThing', function () {
			// step 1: update compositeThing
			putThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_1.thingId, updatethingClassModelInstanceCompositeData_1.CompositeThingBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			// step 2: delete compositeThing
			deleteThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_1.thingId, store.putLater('response'));
			verifyPayload(store.getLater('response'), {});
		});

		describe('C1720533: post ID is compositeThing,When assertId already exists', function () {
			// step 4: create draft CompositeThing class
			postThingInstancesByModelId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_2.CompositeThingBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceCompositeData_2.CompositeThingBody);
			it('Check that the values are equal', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(body.payload.assetId === body.payload.thingId, 'true');
			});
		});

		describe('C1720537: update ID is compositeThing', function () {
			// step 1: update compositeThing
			putThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_2.thingId, updatethingClassModelInstanceCompositeData_3.CompositeThingBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			// step 2: delete compositeThing
			deleteThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_2.thingId, store.putLater('response'));
			verifyPayload(store.getLater('response'), {});
		});

		describe('C1720534: post ID is compositeThing,When assertId is correct and does not exist under this tenant', function () {
			// step 4: create draft CompositeThing class
			postThingInstancesByModelId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_4.CompositeThingBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceCompositeData_4.CompositeThingBody);
			it('Check that the values are equal', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(body.payload.assetId === body.payload.thingId, 'true');
			});
		});

		describe('C1720538: update ID is compositeThing', function () {
			// step 1: update compositeThing
			putThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_4.thingId, updatethingClassModelInstanceCompositeData_5.CompositeThingBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			// step 2: delete compositeThing
			deleteThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_4.thingId, store.putLater('response'));
			verifyPayload(store.getLater('response'), {});
		});

		describe('C1720535: post ID is compositeThing, When assertId exists under other tenants', function () {
			// step 4: create draft CompositeThing class
			postThingInstancesByModelId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_6.CompositeThingBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceCompositeData_6.CompositeThingBody);
			it('Check that the values are equal', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isFalse(body.payload.assetId === body.payload.thingId, 'true');
			});
		});

		describe('C1720539: update ID is compositeThing', function () {
			// step 1: update compositeThing
			putThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_6.thingId, updatethingClassModelInstanceCompositeData_7.CompositeThingBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			// step 2: delete compositeThing
			deleteThingInstancesByModelIdAndThingId(draftCompositeThingClassData_1.modelId, thingClassModelInstanceCompositeData_6.thingId, store.putLater('response'));
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  thing compositeThing class', function () {
			patchThingClassByModelID(draftCompositeThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing compositeThing  model', function () {
			deleteDraftThingClassByModelID(draftCompositeThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('delete thing  instances', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  thing class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing  model', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
