'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { errMesDict } = require('../../../../test-data/requireData');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { postAlarmTypeDataList, num, alarmTypeIdList, postAlarmSeverities,	draftThingClassData, draftThingClassPropertiesData } = require('../../../../test-data/data/tasks/hub/alarm/GYPT27260');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { getAlarmTypes, createAlarmSeverities, createAlarmType, deleteAlarmTypeByModeId, } = require('../../../../test-lib/alarmType');
const { verifySchema, verifyResponseMessage } = require('../../../../test-verify/verify');

describe('GYPT-27260: 测试批量删除AlarmType接口，支持list<alarmTypeId>与全删除两种参数', function () {

	const store = new DataStore();
 
	describe('post device model class', function () {
		postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('post device model class properties by model id', function () {
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('query alarm levels and create alarm types', function () {
		// Create alarm level
		createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
		for ( let i = 0; i < num; i++) {
			createAlarmType(postAlarmTypeDataList[i].alarmTypeBody, store.putLater('response'), store.putLater('id'));
		}
	});

	describe('C2190345: delete multi alarm types with not exist model id', function () {
		deleteAlarmTypeByModeId('modelIdNotExist', store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyResponseMessage(store.getLater('response'), {});
		getAlarmTypes(store.putLater('response'), {modelId: draftThingClassData.modelId});
		it ('verify alarm type number', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload.length, num, `Get alarm type numer with: \n Actual Number: ${body.payload.length} \n Expect Number: ${num}`);
		});
	});
        
	describe('C2190344: pass string into the list field', function () {
		deleteAlarmTypeByModeId(draftThingClassData.modelId, store.putLater('response'), { alarmTypeIds: 'stringId'});
		Response.statusCodeEquals(store.getLater('response'), 400);
		verifyResponseMessage(store.getLater('response'), errMesDict['not_valid_json']);
		verifySchema(store.getLater('response'), errorResponseSchema);
		getAlarmTypes(store.putLater('response'), {modelId: draftThingClassData.modelId});
		it ('verify alarm type number', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload.length, num, `Get alarm type numer with: \n Actual Number: ${body.payload.length} \n Expect Number: ${num}`);
		});
	});

	describe('C2190343: delete not exist alarm type id', function () {
		deleteAlarmTypeByModeId(draftThingClassData.modelId, store.putLater('response'), { alarmTypeIds: ['not_exist_alarm_type_id']});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyResponseMessage(store.getLater('response'), {});
		getAlarmTypes(store.putLater('response'), {modelId: draftThingClassData.modelId});
		it ('verify alarm type number', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload.length, num, `Get alarm type numer with: \n Actual Number: ${body.payload.length} \n Expect Number: ${num}`);
		});
	});

	describe('C2190342: delete with one alarm type id', function () {
		deleteAlarmTypeByModeId(draftThingClassData.modelId, store.putLater('response'), { alarmTypeIds: [alarmTypeIdList[0]]});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyResponseMessage(store.getLater('response'), {});
		getAlarmTypes(store.putLater('response'), {modelId: draftThingClassData.modelId});
		it ('verify alarm type number', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload.length, num-1, `Get alarm type numer with: \n Actual Number: ${body.payload.length} \n Expect Number: ${num-1}`);
		});
	});

	describe('C2190341: delete with multi alarm type ids', function () {
		deleteAlarmTypeByModeId(draftThingClassData.modelId, store.putLater('response'), { alarmTypeIds: [alarmTypeIdList[1], alarmTypeIdList[2]]});
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyResponseMessage(store.getLater('response'), {});
		getAlarmTypes(store.putLater('response'), {modelId: draftThingClassData.modelId});
		it ('verify alarm type number', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload.length, num-3, `Get alarm type numer with: \n Actual Number: ${body.payload.length} \n Expect Number: ${num-3}`);
		});
	});

	describe('C2190340: delete without passing alarm type ids', function () {
		deleteAlarmTypeByModeId(draftThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyResponseMessage(store.getLater('response'), {});
		getAlarmTypes(store.putLater('response'), {modelId: draftThingClassData.modelId});
		it ('verify alarm type number', () => {
			const body = Response.getJsonBody(store.get('response'));
			Assert.strictEqual(body.payload.length, 0, `Get alarm type numer with: \n Actual Number: ${body.payload.length} \n Expect Number: 0`);
		});
	});

});