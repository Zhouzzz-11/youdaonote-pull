'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { Response } = require('@rootcloud/darjeeling-http');

const {
	draftThingClassData,
	draftThingClassData_1,
	multipleProperties1,
	deleteMulProperties1,
	multipleProperties,
	deleteMulProperties,
	addLessPropertiesTime,
	addMorePropertiesTime,
	lessProperties,
	moreProperties
} = require('../../../../test-data/data/tasks/hub/model/GYPT22030');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const {
	postDraftThingClass,
	deleteDraftThingClassByModelID,
} = require('../../../../test-lib/openApiThingClass');
const { postBulkAddDeviceProperties, BulkDeleteDeviceProperties } = require('../../../../test-lib/openApi');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-21116: test: batch add properties', function () {
	describe('precondition', function () {
		//设备
		describe('post draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});
		describe('post second draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
		});
	});

	describe('C1856593: batch add 200 properties to the created device model', function () {
		describe('bulk add 200 properties',function () {
			postBulkAddDeviceProperties(draftThingClassData.modelId, multipleProperties, store.putLater('response'), store.putLater('time'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
			it(`When ${lessProperties} properties are added, the server returns success in ${addLessPropertiesTime} seconds or less`, () => {
				const time = getData(store.get('time'));
				let m = time / 1000;
				if (m <= addLessPropertiesTime) {
					Assert.isTrue(true, `server returns success in ${addLessPropertiesTime} seconds or less`);
				} else {
					Assert.isTrue(false, `server returns success in ${addLessPropertiesTime} seconds or more`);
				}
			});
		});

		describe('Batch delete properties', function () {
			BulkDeleteDeviceProperties(draftThingClassData.modelId, deleteMulProperties, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});


	describe('C1856594: batch add 500 properties to the created device model', function () {
		describe('bulk add 500 properties',function () {
			postBulkAddDeviceProperties(draftThingClassData_1.modelId, multipleProperties1, store.putLater('response'), store.putLater('time'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
			it(`When ${moreProperties} properties are added, the server returns success in ${addMorePropertiesTime} seconds or less`, () => {
				const time = getData(store.get('time'));
				let m = time / 1000;
				if (m <= addMorePropertiesTime) {
					Assert.isTrue(true, `server returns success in ${addMorePropertiesTime} seconds or less`);
				} else {
					Assert.isTrue(false, `server returns success in ${addMorePropertiesTime} seconds or more`);
				}
			});
		});
		describe('Batch delete properties', function () {
			BulkDeleteDeviceProperties(draftThingClassData_1.modelId, deleteMulProperties1, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('delete draft device class by model Id', function () {
		deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		//verification status code
		Response.statusCodeEquals(store.getLater('response'), 204);
		deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
		//verification status code
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

});




