'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData, draftThingClassModelPropertiesData, thingClassModelInstanceData, updatethingClassModelInstanceData, draftThingClassData_1, draftThingClassModelPropertiesData_1, thingClassModelInstanceData_1, updatethingClassModelInstanceData_1, draftThingClassData_2, draftThingClassModelPropertiesData_2, thingClassModelInstanceData_2, updatethingClassModelInstanceData_2, thingClassModelInstanceData_3, updatethingClassModelInstanceData_3, thingClassModelInstanceData_4, updatethingClassModelInstanceData_4, thingClassModelInstanceData_5, updatethingClassModelInstanceData_5 } = require('../../../../test-data/data/tasks/hub/model/GYPT13437Instances');
const { draftThingClassSchema, draftCompositeThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema, thingInstanceCompositeSchema } = require('../../../../test-data/schema/thingInstance');
const { postThingInstancesByModelId, getThingInstancesByModelId, getThingInstancesByModelIdAndThingId, putThingInstancesByModelIdAndThingId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { errorResponseSchema } = require('../../../../test-data/schema/common');

const store = new DataStore();

describe('/openapi-thing model-instance', function () {

	describe('GYPT-13437-instances: Create/Get/Update/Delete device', function () {
		// step 1: create draft thing class
		postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
		// verification status code, payload and schema
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), draftThingClassSchema);
		verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		// step 2: create draft thing class {modelId}/properties
		postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
		// step 3: Patch  thing draft thing-classes  发布
		patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
		// verification status code, payload
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});

		describe('C188872: post ID is device', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('C188863: get devices by criteria', function () {
			// step 1: get devices by criteria
			getThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('C188837: get devices by device ID', function () {
			// step 1:get devices by device ID
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('C188849: update devices by device ID', function () {
			// step 1: update devices by device ID
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, updatethingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), updatethingClassModelInstanceData.thingInstanceBody);
		});

		describe('C188856: delete devices by device ID', function () {
			// step 1: delete devices by device ID
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('GYPT-13437: Create/Get/Update/Delete gateway', function () {

		describe('C188873: post ID is gateway', function () {
			// step 1: create draft thing class
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);
			// step 2: create draft thing class {modelId}/properties
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 3: Patch  thing draft thing-classes  发布
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 4: create draft thing class
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		});

		describe('C188864: get gateway by criteria', function () {

			// step 1: get gateway by criteria
			getThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		});

		describe('C188839: get gateway by device ID', function () {

			// step 1:get devices by gateway ID
			getThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_1.thingInstanceBody);
		});

		describe('C188850: update gateway by device ID', function () {

			// step 1: update devices by gateway ID
			putThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, updatethingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), updatethingClassModelInstanceData_1.thingInstanceBody);
		});

		describe('C188857: delete gateway by device ID', function () {

			// step 1: delete devices by gateway ID
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 2: cancel model
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 3: delete model
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('GYPT-13437: Create/Get/Update/Delete compositeThing', function () {

		describe('C188874: post ID is compositeThing', function () {
			// step 1: create draft thing class
			postDraftThingClass(draftThingClassData_2.CompositeThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			// step 2: create draft thing class {modelId}/properties
			postDraftThingClassPropertiesByModelID(draftThingClassData_2.modelId, draftThingClassModelPropertiesData_2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 3: Patch  thing draft thing-classes  发布
			patchDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 5: create draft thing class  device
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_3.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_3.thingInstanceBody);
			// step 6: create draft CompositeThing class
			postThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.CompositeThingBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData_2.CompositeThingBody);
		});

		describe('C188865: get compositeThing by criteria', function () {

			// step 1: get compositeThing by criteria
			getThingInstancesByModelId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
		});

		describe('C188841: get compositeThing by device ID', function () {

			// step 1:get compositeThing by gateway ID
			getThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
		});

		describe('C188851: update compositeThing by device ID', function () {

			// step 1: update compositeThing by gateway ID
			putThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, updatethingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstanceCompositeSchema);
		});

		describe('C188858: delete compositeThing by device ID', function () {

			// step 1: delete compositeThing by gateway ID
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_2.modelId, thingClassModelInstanceData_2.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 2: cancel model
			patchThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
			// step 3: delete model
			deleteDraftThingClassByModelID(draftThingClassData_2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('GYPT-13437: Create/Get/Update/Delete ID is inconsistent with tenantid', function () {

		describe('C188875: post ID is inconsistent with tenantid', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId('bum', thingClassModelInstanceData_4.thingInstanceBody, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188866: get ID is inconsistent with tenantid', function () {
			// step 1: get compositeThing by criteria
			getThingInstancesByModelId('bum', store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188842: get ID is inconsistent with modelid', function () {
			// step 1:get compositeThing by gateway ID
			getThingInstancesByModelIdAndThingId('bum', thingClassModelInstanceData_3.thingId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188843: get ID is inconsistent with tenantid', function () {
			// step 1:get compositeThing by gateway ID
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, 'bumdev', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188852: update ID is inconsistent with modelid', function () {
			// step 1: update compositeThing by gateway ID
			putThingInstancesByModelIdAndThingId('bum', thingClassModelInstanceData_3.thingId, updatethingClassModelInstanceData_3.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188853: update ID is inconsistent with tenantid', function () {
			// step 1: update compositeThing by gateway ID
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, 'bumdev', updatethingClassModelInstanceData_4.thingInstanceBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188859: delete ID is inconsistent with modelId', function () {
			// step 1: delete ID is inconsistent with modelId
			deleteThingInstancesByModelIdAndThingId('bum', thingClassModelInstanceData_3.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188860: delete ID is inconsistent with tenantid', function () {
			// step 1:  delete ID is inconsistent with tenantid
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, 'bumdev', store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 404);
			// step 2: delete devices by device ID
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_3.thingId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('GYPT-13437: Create/Get/Update/Delete ID does not exist', function () {

		describe('C188876: post ID does not exist', function () {
			// step 1: create draft thing class
			postThingInstancesByModelId('', thingClassModelInstanceData_5.thingInstanceBody, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188848: get thingID does not exist', function () {
			// step 1:get thingID does not exist
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, '', store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('C188867: get modelID does not exist', function () {
			// step 1: get modelID does not exist
			getThingInstancesByModelId('', store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188871: get When ID has no device instance', function () {
			// step 1:get When ID has no device instance
			getThingInstancesByModelIdAndThingId(draftThingClassData.modelId, '', store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('C188854: update When ID has no device instance', function () {
			// step 1: update When ID has no device instance
			putThingInstancesByModelIdAndThingId(draftThingClassData.modelId, 'bumdev', updatethingClassModelInstanceData_5.thingInstanceBody, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188859: delete When ID has no device instance', function () {
			// step 1: delete When ID has no device instance
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, '', store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 404);
			// step 2: cancel model
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188877: post When the ID is an unpublished model', function () {
			// step 1: create draft thing class When the ID is an unpublished model
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_5.thingInstanceBody, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'),errorResponseSchema);
		});

		describe('C188870: get When the ID is an unpublished model', function () {
			// step 1:getWhen the ID is an unpublished model
			getThingInstancesByModelId(draftThingClassData.modelId, store.putLater('response'));
			// verification status code
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'),errorResponseSchema);
		});
	});
});
