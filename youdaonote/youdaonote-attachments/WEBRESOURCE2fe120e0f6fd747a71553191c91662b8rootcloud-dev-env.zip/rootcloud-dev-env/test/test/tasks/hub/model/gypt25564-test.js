'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassByModelID, patchThingClassByModelID, patchDraftThingClassByModelID, putDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { ThingClassData, compositeThing_1, compositeThing_2, compositeThing_3, compositeThing_4, compositeThing_5, compositeThing_6, compositeThing_7, compositeThing_1_1, compositeThing_2_1, compositeThing_3_1, PropertiesData_1, C_PropertiesData} = require('../../../../test-data/data/tasks/hub/model/GYPT25564');

describe('GYPT-25564 : compositeThing should not exceed 5 layers', function(){
	describe('precondition', function(){
		postDraftThingClass(ThingClassData.thingClassBody,store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData.modelId, PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));

		postDraftThingClass(compositeThing_1.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_1.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingClass(compositeThing_2.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_2.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingClass(compositeThing_3.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_3.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_3.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2078392 : compositeThing creates successfully when it has no more than 5 layers,', function(){
		postDraftThingClass(compositeThing_4.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2078393 : compositeThing creates failed when it has more than 5 layers', function(){
		postDraftThingClass(compositeThing_5.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('check message contains \'层级超过5层\'', function(){
			var message = Response.getJsonBody(store.get('response')).message;
			Response.bodyJsonEquals(message.indexOf('层级超过5层') != -1, true);
		});
	});

	describe('C2085616 : compositeThing creates successfully when another node has no more than 4 layers', function(){
		postDraftThingClass(compositeThing_6.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2125961 : check whether the ancestor is more than 5 levels when create a compositeThing', function(){
		postDraftThingClass(compositeThing_1_1.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_1_1.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_1_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingClass(compositeThing_2_1.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_2_1.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_2_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingClass(compositeThing_3_1.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(compositeThing_3_1.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(compositeThing_3_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		putDraftThingClassByModelID(compositeThing_3.modelId, compositeThing_7.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		it('check message contains \'层级超过5层\'', function(){
			var message = Response.getJsonBody(store.get('response')).message;
			Response.bodyJsonEquals(message.indexOf('层级超过5层') != -1, true);
		});
	});

	describe('delete thingClass composite4', function () {
		deleteDraftThingClassByModelID(compositeThing_4.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('delete thingClass composite6', function () {
		deleteDraftThingClassByModelID(compositeThing_6.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass composite3', function () {
		patchThingClassByModelID(compositeThing_3.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass composite3', function () {
		deleteDraftThingClassByModelID(compositeThing_3.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass composite2', function () {
		patchThingClassByModelID(compositeThing_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass composite2', function () {
		deleteDraftThingClassByModelID(compositeThing_2.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass composite1', function () {
		patchThingClassByModelID(compositeThing_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass composite1', function () {
		deleteDraftThingClassByModelID(compositeThing_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass compositeThing_3_1', function () {
		patchThingClassByModelID(compositeThing_3_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass compositeThing_3_1', function () {
		deleteDraftThingClassByModelID(compositeThing_3_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass compositeThing_2_1', function () {
		patchThingClassByModelID(compositeThing_2_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass compositeThing_2_1', function () {
		deleteDraftThingClassByModelID(compositeThing_2_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass compositeThing_1_1.', function () {
		patchThingClassByModelID(compositeThing_1_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass compositeThing_1_1.', function () {
		deleteDraftThingClassByModelID(compositeThing_1_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(ThingClassData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});