'use strict';

const { DataStore, Assert, getData } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData, thingClassModelInstanceData1_1, thingInstanceData3, instructionRequestsData_5, responseData6, responseData7, responseData5, instructionRequestsData2_1, thingClassModelInstanceData4, thingClassModelInstanceData2_1, thingClassModelInstanceData3, responseData4, instructionRequestsData2, responseData3, instructionRequestsData3, instructionRequestsData1, responseData2, responseData1, instructionRequestsData_2, thingInstanceData1, thingInstanceData2, responseData, instructionRequestsData_1, draftThingClassPropertiesData, thingInstanceData, draftThingClassData1, draftGatewayClassData, thingClassModelInstanceData1, thingClassModelInstanceData2 } = require('../../../../test-data/data/tasks/hub/instru/GYPT22240');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postInstructionRequests, getInstructionRequestsByRequestId1 } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage } = require('../../../../test-lib/mqtt');
const store = new DataStore();

/*
	由于topic第一次建立延迟的问题，需要等待较长时间，故将指令下发的story移至最后执行
 */
describe('GYPT-22240: mqtt file upload', function () {

	describe('start, build environment dependency', function () {
		//直连设备
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});
		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});
	});

	describe('C1875195: check if the device can receive the platform return isAck = true', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData1.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData_1.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_pub'], responseData.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_1.requestId, store.putLater('response'), {status: 'RECEIVED'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});
	
	describe('C1875196: check if the device can receive the platform return and ack = false', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData2.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData2.thingId, (client) => { store.put('client', client); }, store.putLater('message1'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message1'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData_2.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_pub'], responseData1.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_2.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C1875197: check if the non-directly connected device can receive the platform return and ack = true', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData2.thingId, (client) => { store.put('client', client); }, store.putLater('message2'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_gateway_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message2'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData1.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_gateway_pub'], responseData2.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData1.requestId, store.putLater('response'), {status: 'RECEIVED'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});
	});

	describe('C1875198: check if the non-directly connected device can receive the platform return and ack = false', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2_1.thingInstanceBody);
		});

		describe('post non-directly connected device', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData2_1.thingId, (client) => { store.put('client', client); }, store.putLater('message3'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_gateway_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData3.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message3'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData3.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_gateway_pub'], responseData3.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData3.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete gateway device', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1875199: check if the gateway device can receive the platform return isAck = true', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData3.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData3.thingId, (client) => { store.put('client', client); }, store.putLater('message4'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_gateway_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData2.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message4'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData2.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_gateway_pub'], responseData4.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData2.requestId, store.putLater('response'), {status: 'RECEIVED'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete gateway device', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1875200: check if the gateway device can receive the platform return isAck = false', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post gateway device2', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData4.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData4.thingId, (client) => { store.put('client', client); }, store.putLater('message5'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_gateway_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData2_1.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message5'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData2_1.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_gateway_pub'], responseData5.instructionBody);
		});

		describe('query instruction status', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData2_1.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete gateway device', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});
	});

	describe('C1875201: for one instruction, the device returns status to the platform multiple times', function () {
		
		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData3.thingInstanceBody);
		});

		describe('connect the MQTT', function () {
			getMqttClient(thingInstanceData3.thingId, (client) => { store.put('client', client); }, store.putLater('message6'));
		});

		describe('subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['files_get_sub']);
		});

		describe('instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_5.thingInstructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message6'),store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				const msgId = getData(instructionRequestsData_5.requestId);
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response1', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_pub'], responseData6.instructionBody);
		});

		describe('query instruction status1', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_5.requestId, store.putLater('response'), { status: 'IN_PROGRESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'IN_PROGRESS');
		});

		describe('response2', function () {
			postDataWithClient(store.getLater('client'), topicDict['files_get_pub'], responseData7.instructionBody);
		});

		describe('query instruction status2', function () {
			getInstructionRequestsByRequestId1(instructionRequestsData_5.requestId, store.putLater('response'), {status: 'SUCCESS'});
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('end remove environment dependencies', function () {
		//直连设备
		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//非直连设备
		describe('delete device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft device2 class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('delete gateway device', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});
