'use strict';

const { DataStore, Assert, getData } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../../../test-data/requireData');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances.js');
const { draftThingClassData, instructionRequestsData_14, responseData_14, thingInstanceData_3, thingInstanceData_4, instructionRequestsData_13, responseData_13, instructionRequestsData_12, responseData_12, instructionRequestsData31, responseData_31, instructionRequestsData_21, responseData_21, instructionRequestsData_11, responseData_11, instructionRequestsData1, responseData_3, instructionRequestsData_2, responseData_1, thingInstanceData_1, instructionRequestsData_1, responseData_2, draftThingClassPropertiesData, thingInstanceData, draftThingClassData1, draftGatewayClassData, thingClassModelInstanceData1, thingClassModelInstanceData2, thingClassModelInstanceData3, thingInstanceData_2, thingClassModelInstanceData4, thingClassModelInstanceData5 } = require('../../../../test-data/data/tasks/hub/instru/GYPT10809');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { instructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');
const { postInstructionRequests, getInstructionRequestsByRequestId1 } = require('../../../../test-lib/instructionRequest');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, subDataWithClient, getSubMessage } = require('../../../../test-lib/mqtt');
const store = new DataStore();

describe('GYPT-10809 : instuction request of config', function () {

	describe('start', function () {
		//直连设备
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class property', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData2.thingInstanceBody);
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData3.thingInstanceBody);
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData4.thingInstanceBody);
		});

		describe('post Gateway device ', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData5.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData5.thingInstanceBody);
		});

		//非直连设备
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
		});

	});

	describe('C2074758 : The directly connected device is configured with SET to issue, verifying whether the platform can issue successfully', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_1.thingId, (client) => { store.put('client', client); }, store.putLater('message'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_req_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_1.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_req_pub'], responseData_1.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C2074761 : The gateway device is configured with SET to issue, verifying whether the platform can issue successfully', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData2.thingId, (client) => { store.put('client', client); }, store.putLater('message1'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_set_gateway_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_2.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message1'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_set_gateway_pub'], responseData_2.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});
	});

	describe('C2074762 : Non-directly connected device is configured with SET to issue, verifying whether the platform can issue successfully', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData3.thingId, (client) => { store.put('client', client); }, store.putLater('message2'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_set_gateway_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData1.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message2'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_set_gateway_pub'], responseData_3.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'SUCCESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});
	});

	describe('C2074763 : The directly connected device is configured with GET to issue, verifying whether the platform can issue successfully', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_2.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_2.thingId, (client) => { store.put('client', client); }, store.putLater('message4'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_11.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message4'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_update_pub'], responseData_11.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C2074764 : The gateway device is configured with GET to issue, verifying whether the platform can issue successfully', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData4.thingId, (client) => { store.put('client', client); }, store.putLater('message5'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_gateway_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_21.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message5'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_update_gateway_pub'], responseData_21.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});
	});

	describe('C2074765 : Non-directly connected device is configured with GET to issue, verifying whether the platform can issue successfully', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingClassModelInstanceData5.thingId, (client) => { store.put('client', client); }, store.putLater('message9'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_update_gateway_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData31.instructionConfigRequestBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message9'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_update_gateway_pub'], responseData_31.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'SUCCESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});
	});

	describe('C2074760 : Query the device for successful response', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData.thingId, (client) => { store.put('client', client); }, store.putLater('message7'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_req_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_12.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message7'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_req_pub'], responseData_12.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});
	});

	describe('C2074759 : Check if the device can respond to the platform: ACK is true', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_3.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_3.thingId, (client) => { store.put('client', client); }, store.putLater('message11'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_req_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_13.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message11'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_req_pub'], responseData_13.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'RECEIVED' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'RECEIVED');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('C2074766 : Check if the device can respond to the platform: ACK false', function () {

		after(() => {
			const client = store.get('client');
			client.end();
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_4.thingInstanceBody);
		});

		describe('Connect the MQTT', function () {
			getMqttClient(thingInstanceData_4.thingId, (client) => { store.put('client', client); }, store.putLater('message12'));
		});

		describe('Subscribe', function () {
			subDataWithClient(store.getLater('client'), topicDict['config_req_sub']);
		});

		describe('Instruction issuing operation', function () {
			postInstructionRequests(instructionRequestsData_14.configRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});

		describe('Verify that the device subscribed successfully', function () {
			getSubMessage(store.getLater('message12'), store.putLater('response'));
			it('test', () => {
				const message = getData(store.get('response'));
				const msgId = getData(store.get('requestId'));
				const obj = JSON.parse(message);
				const subscribeMsgId = obj.header.msgId;
				Assert.isTrue(subscribeMsgId === msgId, 'subscribe message is successful');
			});
		});

		describe('response', function () {
			postDataWithClient(store.getLater('client'), topicDict['config_req_pub'], responseData_14.instructionBody);
		});

		describe('Query instruction status', function () {
			getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'SUCCESS' });
			Response.statusCodeEquals(store.getLater('response'), 200);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'SUCCESS');
		});

		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData_4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});
	});

	describe('end', function () {
		//直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
		//非直连设备
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData1.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
		//网关
		describe('delete gateway device2 ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete gateway device3 ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData3.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete gateway device4 ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData4.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete gateway device5 ', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData5.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('patch  gateway class', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});