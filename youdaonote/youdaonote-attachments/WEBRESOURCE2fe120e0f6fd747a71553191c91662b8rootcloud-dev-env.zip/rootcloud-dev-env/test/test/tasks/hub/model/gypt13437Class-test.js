'use strict';

const { Assert, DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	draftGatewayClassData,
	draftCompositeThingClassData,
	unpublishDraftThingClassData,
	draftThingClassNoThingTypeData,
	draftThingClassWrongThingTypeData,
	draftThingClassData2,
	draftGatewayClassData2,
	draftCompositeThingClassData2,
	updateDraftThingClassData,
	updateDraftGatewayClassData,
	updateDraftCompositeThingClassData,
	unpublishDraftThingClassData1,
	draftCompositeThingClassData3,
	unpublishDraftGatewayClassData,
	thingClassModelInstanceData,
	draftCompositeThingClassData4,
	draftThingClassModelPropertiesData1,
	draftCompositeThingClassData5,
	draftThingClassModelPropertiesData2,
	unpublishDraftThingClassData2,
	draftGatewayClassData3,
	draftCompositeThingClassData6,
} = require('../../../../test-data/data/tasks/hub/model/GYPT13437Class');
const { draftThingClassSchema, draftCompositeThingClassSchema, draftThingClassModelPropertiesSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const {
	postDraftThingClass,
	deleteDraftThingClassByModelID,
	getThingClass,
	postDraftThingClassPropertiesByModelID,
	patchDraftThingClassByModelID,
	patchThingClassByModelID,
	getThingClassByModelID,
	getDraftThingClass,
	getDraftThingClassByModelID,
	putDraftThingClassByModelID,
	getDraftThingClassPropertiesByModelID,
	putDraftThingClassPropertiesByModelID,
	deleteDraftThingClassPropertiesByModelID,
	deleteAllDraftThingClassPropertiesByModelID,
} = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload, verifyMultiSchema } = require('../../../../test-verify/verify');

const store = new DataStore();

describe('GYPT-13437-Class : test for  thing class', function () {

	describe('crud test for  thing class', function () {
		//设备
		describe('post draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		//创建不发布的设备
		describe('create draft device class not  publish', function () {
			// step 1: create draft device class
			postDraftThingClass(unpublishDraftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), unpublishDraftThingClassData.thingClassBody);
		});

		//网关
		describe('post draft gateway class', function () {
			// step 1: create draft gateway class
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class', function () {
			// step 2: create draft Gateway property
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			// step 3: publish draft Gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		//复合物
		describe('post draft compositeThing class', function () {
			// step 1: create draft compositeThing class
			postDraftThingClass(draftCompositeThingClassData.CompositeThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
		});

		describe('post draft compositeThing Properties', function () {
			// step 2: create draft compositeThing property
			postDraftThingClassPropertiesByModelID(draftCompositeThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft compositeThing class', function () {
			// step 3: publish draft compositeThing class
			patchDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		/*
		  GET ​/thing-model​/thing-classes
		*/

		describe('C188727: Instead of entering a thingType query, see if the returned result is equal to the device query result', function () {
			// step 4: get  device class
			getThingClass(store.putLater('response3'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response3'), 400);
		});

		describe('C188728: ThingType input device to query to see if the return is correct', function () {
			// step 4: get  device class
			getThingClass(store.putLater('response'), { queryString: 'thingType=device&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188729: The thingType enters the Gateway to query to see if the return is correct', function () {
			// step 4: get  device class
			getThingClass(store.putLater('response'), { queryString: 'thingType=gateway&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188730:The thingType enters its compositeThing to query to see if the return is correct', function () {
			// step 4: get  compositeThing class
			getThingClass(store.putLater('response'), { queryString: 'thingType=compositeThing&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftCompositeThingClassSchema);
		});

		describe('C188731: ThingType is unlimited, and when a query does not produce a result, it checks to see if it is returned correctly', function () {
			// step 4: get  compositeThing class
			getThingClass(store.putLater('response'), { queryString: 'thingType=device11' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188743: ThingType is unlimited to see if the return contains an unpublished model', function () {
			// step 4: get  compositeThing class
			getThingClass(store.putLater('response31'), { queryString: 'thingType=device&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response31'), 200);
			verifyMultiSchema(store.getLater('response31'), draftThingClassSchema);
			it('if the return contains an unpublished model', () => {
				const body = Response.getJsonBody(store.get('response31'));
				body.payload.forEach((item, index) => {
					Assert.strictEqual(true, body.payload[index].updated !== null, 'return not contains  unpublished model');
				});
			});
		});

		describe('C188732: Query through a combination of thingType and other criteria to see if the return is correct', function () {
			// step 4: get  compositeThing class
			getThingClass(store.putLater('response'), { queryString: 'thingType=device&name=GYPT13437' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);

			it('Query through a combination of thingType and other conditions', () => {
				const body = Response.getJsonBody(store.get('response'));
				body.payload.forEach((item, index) => {
					if (body.payload[index].name.indexOf('GYPT13437') != -1) {
						Assert.isTrue(true, 'Check return ture');
					}
				});
			});
		});

		/*
		  GET ​/thing-model​/thing-classes​/{id}
		*/

		describe('C188733: When the ID does not exist, query to see if the return is correct', function () {
			// step 4: get  device class
			getThingClassByModelID('sdfghjjyfdsa', store.putLater('response3'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response3'), 400);
		});

		describe('C188734: When the ID exists and corresponds to tenantId, query to see if the return is correct', function () {
			// step 4: get  device class
			getThingClassByModelID('38f2a59f', store.putLater('response3'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response3'), 400);
		});

		describe('C188735: Query when the ID exists but does not correspond to tenantId to see if the return is correct', function () {
			// step 4: get  device class
			getThingClassByModelID('38f', store.putLater('response3'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response3'), 400);
		});

		describe('C188736: Query without an ID to see if the return is correct', function () {
			// step 4: get  device class
			getThingClassByModelID('', store.putLater('response3'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response3'), 400);
		});

		describe('C188741: When the ID is an unpublished model, query to see if the return is correct', function () {
			// step 2: get  device class
			getThingClassByModelID(unpublishDraftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188744: The thingType enters the Gateway to query to see if the return is correct', function () {

			describe('get device class', function () {
				// step 4: get  device class
				getThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
			});

			describe('get gateway class', function () {
				// step 4: get  gateway class
				getThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
			});

			describe('get compositeThing class', function () {
				// step 4: get  compositeThing class
				getThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});
		});

		/*
		  PATCH ​/thing-model​/thing-classes​/{id}
		*/

		describe('C188737: When the ID does not exist, check to see if the return is correct', function () {
			// step 3: publish draft device class
			patchThingClassByModelID('aaaaaasdf', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188738: Operate when the ID exists and corresponds to tenantId to see if the model becomes unpublished', function () {
			// step 3: publish draft device class
			patchThingClassByModelID('38f2a59f', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188739: If the ID exists but does not correspond to tenantId, check to see if the return is correct', function () {
			// step 3: publish draft device class
			patchThingClassByModelID('38f', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188740: Not entering an ID is an operation to see if the return is correct', function () {
			// step 3: publish draft device class
			patchThingClassByModelID('', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188742: When the ID is an unpublished model, query to see if the return is correct', function () {
			// step 5: unpublish draft device class
			patchThingClassByModelID(unpublishDraftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188745: Query when the ID is the device model/gateway model/composite model to see if the return is correct', function () {

			describe('when the ID is the compositeThing model', function () {

				describe('patch draft compositeThing class', function () {
					// step 3: publish draft compositeThing class
					patchDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response2'));
					// verification status code, payload and schema
					Response.statusCodeEquals(store.getLater('response2'), 200);
					verifyPayload(store.getLater('response2'), {});
				});

				describe('patch compositeThing class', function () {
					// step 5: unpublish draft compositeThing class
					patchThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response4'));
					// verification status code, payload and schema
					Response.statusCodeEquals(store.getLater('response4'), 200);
					verifyPayload(store.getLater('response4'), {});
				});
			});

			describe('when the ID is the device model', function () {

				describe('patch draft device class', function () {
					// step 3: publish draft device class
					patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
					// verification status code, payload and schema
					Response.statusCodeEquals(store.getLater('response2'), 200);
					verifyPayload(store.getLater('response2'), {});
				});

				describe('patch  device class', function () {
					// step 5: unpublish draft device class
					patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
					// verification status code, payload and schema
					Response.statusCodeEquals(store.getLater('response4'), 200);
					verifyPayload(store.getLater('response4'), {});
				});
			});

			describe('when the ID is the Gateway model', function () {

				describe('patch draft Gateway class', function () {
					// step 3: publish draft Gateway class
					patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
					// verification status code, payload and schema
					Response.statusCodeEquals(store.getLater('response2'), 200);
					verifyPayload(store.getLater('response2'), {});
				});

				describe('patch  gateway class', function () {
					// step 5: unpublish draft gateway class
					patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
					// verification status code, payload and schema
					Response.statusCodeEquals(store.getLater('response4'), 200);
					verifyPayload(store.getLater('response4'), {});
				});
			});
		});

		//复合物
		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('patch draft compositeThing class', function () {
			// step 3: publish draft compositeThing class
			patchDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('patch compositeThing class', function () {
			// step 5: unpublish draft compositeThing class
			patchThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft compositeThing class by model Id', function () {
			// step 6: delete draft compositeThing class by model Id
			deleteDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//设备
		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('patch  device class', function () {
			// step 5: unpublish draft device class
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//删除不发布的设备
		describe('delete draft device class by model Id', function () {
			// step 3: delete draft thing class by model Id
			deleteDraftThingClassByModelID(unpublishDraftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('patch draft Gateway class', function () {
			// step 3: publish draft Gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('patch  gateway class', function () {
			// step 5: unpublish draft gateway class
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			// step 6: delete draft gateway class by model Id
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('crud test for  thing class', function () {
		//设备
		describe('post draft device class', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		//创建不发布的设备
		describe('create draft device class not  publish', function () {
			// step 1: create draft device class
			postDraftThingClass(unpublishDraftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), unpublishDraftThingClassData.thingClassBody);
		});

		//网关
		describe('post draft Gateway class', function () {
			// step 1: create draft Gateway class
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class', function () {
			// step 2: create draft Gateway property
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft Gateway class', function () {
			// step 3: publish draft Gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		//复合物
		describe('post draft compositeThing class', function () {
			// step 1: create draft compositeThing class
			postDraftThingClass(draftCompositeThingClassData.CompositeThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
		});

		describe('post draft compositeThing class', function () {
			// step 2: create draft compositeThing property
			postDraftThingClassPropertiesByModelID(draftCompositeThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft compositeThing class', function () {
			// step 3: publish draft compositeThing class
			patchDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});
		describe('patch draft compositeThing class', function () {
			// step 3: publish draft compositeThing class
			patchDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});
		/*
            GET ​/thing-model​/draft​/thing-classes
        */

		describe('C188746: not enter a thingType query to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188747: ThingType input device to query to see if the return is correct', function () {			// step 4: get  device class
			// step 4: get  device class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=device&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188748: The thingType enters the Gateway to query to see if the return is correct', function () {
			// step 4: get  Gateway class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=gateway&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188749: The thingType enters the compositeThing to query to see if the return is correct', function () {
			// step 4: get  compositeThing class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=compositeThing&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftCompositeThingClassSchema);
		});

		describe('C188750: ThingType is unlimited, and when a query does not produce a result, it checks to see if it is returned correctly', function () {
			// step 4: get  device class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=device&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188751: ThingType is unlimited to see if the returned model contains a published model', function () {
			// step 4: get  device class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=device&_limit=1&_sort=[{"field": "created", "sortType": "DESC"}]' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);

			it('if the returned model contains a published model', () => {
				const body = Response.getJsonBody(store.get('response'));
				body.payload.forEach((item, index) => {
					if (body.payload[index].updated !== null) {
						Assert.isTrue(true, 'Check Contains published models');
					}
				});
			});
		});

		describe('C188752: Query through a combination of thingType and other criteria to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=device&name=GYPT13437' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), draftThingClassSchema);

			it('Query through a combination of thingType and other conditions', () => {
				const body = Response.getJsonBody(store.get('response'));
				body.payload.forEach((item, index) => {
					if (body.payload[index].name.indexOf('GYPT13437') != -1) {
						Assert.isTrue(true, 'Check return ture');
					}
				});
			});
		});

		describe('C188753: Query when the thingType is incorrectly filled in to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClass(store.putLater('response'), { queryString: 'thingType=devi' });
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		/*
          POST ​/thing-model​/draft​/thing-classes
        */

		describe('C188754: Operate when the thingType has no value to see if the return is correct', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassNoThingTypeData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188755: Operate when the thingType is a device to see if the device model has been created correctly', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData2.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData2.thingClassBody);

			// step 3: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftThingClassData2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C188756: When the thingType is the Gateway, check to see if the gateway model was created correctly', function () {
			// step 1: create draft Gateway class
			postDraftThingClass(draftGatewayClassData2.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData2.thingClassBody);

			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftGatewayClassData2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C188757: When the thingType is the compositeThing, check to see if the compositeThing model was created correctly', function () {
			// step 1: create draft compositeThing class
			postDraftThingClass(draftCompositeThingClassData2.CompositeThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);

			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftCompositeThingClassData2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C188758: Operate when the thingType is wrong to see if the return is correct', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassWrongThingTypeData.draftThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188759: The model was created in an unpublished state', function () {
			// step 1: create draft device class
			postDraftThingClass(draftThingClassData2.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData2.thingClassBody);

			it('The model created is an unpublished state', () => {
				//获取接口返回值
				const body = Response.getJsonBody(store.get('response'));
				// eslint-disable-next-line no-prototype-builtins
				Assert.isFalse(body.payload.hasOwnProperty('updated'), 'Check is unpublic');
			});

			// step 3: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftThingClassData2.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		/*
           GET /thing-model​/draft​/thing-classes​/{id}
         */

		describe('C188760: When the ID does not exist, query to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClassByModelID('asdfsdf', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188761: When the ID exists and corresponds to tenantId, query to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClassByModelID('38f2a59f', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188762: Query when the ID exists but does not correspond to tenantId to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClassByModelID('38f22345', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188763: Query without an ID to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClassByModelID('', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188764: When the ID is a published model, query to see if the return is correct', function () {
			// step 4: get  device class
			getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('C188765: Query when the ID is the device model/gateway model/composite model to see if the return is correct', function () {

			describe('when the ID is the device model', function () {
				// step 4: get  device class
				getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
			});

			describe('when the ID is the gateway model', function () {
				// step 4: get  gateway class
				getDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
			});

			describe('when the ID is the compositeThing model', function () {
				// step 4: get  compositeThing class
				getDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});
		});

		/*
          PUT ​/thing-model​/draft​/thing-classes​/{id}
        */

		describe('C188766: When the ID is the device model, check to see if the model has been modified correctly', function () {
			// step 4: update  device class
			putDraftThingClassByModelID(draftThingClassData.modelId, updateDraftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188767: When the ID is the gateway model, check to see if the model has been modified correctly', function () {
			// step 4: update  gateway class
			putDraftThingClassByModelID(draftGatewayClassData.modelId, updateDraftGatewayClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188768: When the ID is the compositeThing model, check to see if the model has been modified correctly', function () {
			// step 4: update  compositeThing class
			putDraftThingClassByModelID(draftCompositeThingClassData.modelId, updateDraftCompositeThingClassData.CompositeThingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
		});

		describe('C188769: When the ID does not exist, check to see if the return is correct', function () {
			// step 4: update  device class
			putDraftThingClassByModelID('qwertyjhgfd', updateDraftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188770: When the ID is a published model, check to see if the return is correct', function () {
			// step 4: update  device class
			putDraftThingClassByModelID(draftThingClassData.modelId, updateDraftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('C188777: When the ID is a published model, check to see if the return is correct', function () {
			// step 4: update  device class
			putDraftThingClassByModelID('2345tghfg', updateDraftThingClassData.thingClassBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		/*
           DELETE ​/thing-model​/draft​/thing-classes​/{id}
        */

		describe('C188771: When the ID is the device model, check to see if the model has been deleted correctly', function () {

			describe('create draft device class', function () {
				// step 1: create draft device class
				postDraftThingClass(unpublishDraftThingClassData1.thingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), unpublishDraftThingClassData1.thingClassBody);
			});

			describe('delete draft thing class by model Id', function () {
				// step 2: delete draft thing class by model Id
				deleteDraftThingClassByModelID(unpublishDraftThingClassData1.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

		});

		describe('C188772: When the ID is the gateway model, check to see if the model has been deleted correctly', function () {

			describe('create draft gateway class', function () {
				// step 1: create draft gateway class
				postDraftThingClass(unpublishDraftGatewayClassData.thingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), unpublishDraftGatewayClassData.thingClassBody);
			});

			describe('delete draft thing class by model Id', function () {
				// step 6: delete draft gateway class by model Id
				deleteDraftThingClassByModelID(unpublishDraftGatewayClassData.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});


		describe('C188773: When the ID is the compositeThing model, check to see if the model has been deleted correctly', function () {

			describe('create draft compositeThing class', function () {
				// step 1: create draft compositeThing class
				postDraftThingClass(draftCompositeThingClassData3.CompositeThingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});

			describe('delete draft compositeThing class by model Id', function () {
				// step 6: delete draft compositeThing class by model Id
				deleteDraftThingClassByModelID(draftCompositeThingClassData3.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

		});

		describe('C188774: When the ID does not exist, check to see if the return is correct', function () {

			// step 1: delete draft compositeThing class by model Id
			deleteDraftThingClassByModelID('asdfghjkldsaswedfrtgy', store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 400);

		});

		describe('C188775: Operate when the ID is a published model to see if the return is correct', function () {

			// step 1: delete draft compositeThing class by model Id
			deleteDraftThingClassByModelID('asdfghjkldsaswedfrtgy', store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 400);

		});

		describe('C188776: When the ID does not match tenantId, check to see if the return is correct', function () {

			// step 1: delete draft compositeThing class by model Id
			deleteDraftThingClassByModelID('456dfghyh', store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 400);

		});

		describe('C188836: When an instance of the model already exists, check to see if the return is correct', function () {

			describe('create draft device thing class', function () {
				// step 1: create draft device class
				postDraftThingClass(unpublishDraftThingClassData1.thingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), unpublishDraftThingClassData1.thingClassBody);
			});

			describe('post draft device thing property', function () {
				// step 2: create draft device  property
				postDraftThingClassPropertiesByModelID(unpublishDraftThingClassData1.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('patch  device thing class', function () {
				// step 3: publish draft device class
				patchDraftThingClassByModelID(unpublishDraftThingClassData1.modelId, store.putLater('response2'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response2'), 200);
				verifyPayload(store.getLater('response2'), {});
			});

			describe('create device  class', function () {
				// step 1: create draft thing class
				postThingInstancesByModelId(unpublishDraftThingClassData1.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), thingInstancePostSchema);
				verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
			});

			describe('When an instance of the model already exists, check to see if the return is correct', function () {

				// step 1: delete draft compositeThing class by model Id
				deleteDraftThingClassByModelID(unpublishDraftThingClassData1.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 400);
			});

			describe('delete device by device ID', function () {
				// step 1: delete devices by device ID
				deleteThingInstancesByModelIdAndThingId(unpublishDraftThingClassData1.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifyPayload(store.getLater('response'), {});
			});

			describe('patch  device  class', function () {
				// step 5: unpublish draft device class
				patchThingClassByModelID(unpublishDraftThingClassData1.modelId, store.putLater('response4'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response4'), 200);
				verifyPayload(store.getLater('response4'), {});
			});

			describe('delete draft device class by model Id', function () {
				// step 6: delete draft thing class by model Id
				deleteDraftThingClassByModelID(unpublishDraftThingClassData1.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		/*
          PATCH ​/thing-model​/draft​/thing-classes​/{id}
         */


		describe('C188779:  When the ID is the device model, check to see if the model is published correctly', function () {
			// step 3: publish draft device class
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('C188780:  When the ID is the gateway	model, check to see if the model is published correctly', function () {
			// step 3: publish draft gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('C188781:  When the ID is the compositeThing model, check to see if the model is published correctly', function () {

			describe('post draft compositeThing class', function () {
				// step 1: create draft compositeThing class
				postDraftThingClass(draftCompositeThingClassData4.CompositeThingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});

			describe('post draft compositeThing property', function () {
				// step 2: create draft compositeThing property
				postDraftThingClassPropertiesByModelID(draftCompositeThingClassData4.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('patch draft compositeThing class', function () {
				// step 3: publish draft compositeThing class
				patchDraftThingClassByModelID(draftCompositeThingClassData4.modelId, store.putLater('response2'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response2'), 200);
				verifyPayload(store.getLater('response2'), {});
			});
			describe('patch compositeThing class', function () {
				// step 5: unpublish draft compositeThing class
				patchThingClassByModelID(draftCompositeThingClassData4.modelId, store.putLater('response4'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response4'), 200);
				verifyPayload(store.getLater('response4'), {});
			});

			describe('delete draft compositeThing class by model Id', function () {
				// step 6: delete draft compositeThing class by model Id
				deleteDraftThingClassByModelID(draftCompositeThingClassData4.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C188782:  When the ID does not exist, check to see if the return is correct', function () {
			// step 3: publish draft compositeThing class
			patchDraftThingClassByModelID('zxcvbnjkjhgf', store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 400);
		});

		describe('C188783:  Operate when the ID is a published model to see if the return is correct', function () {
			// step 3: publish draft gateway class
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('C188784:  When the ID does not exist, check to see if the return is correct', function () {
			// step 3: publish draft compositeThing class
			patchDraftThingClassByModelID('45t6yhiuf', store.putLater('response2'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response2'), 400);
		});

		/*
            GET /thing-model​/draft​/thing-classes​/{id}​/properties
         */

		describe('C188785: When the ID is the device model, see if the property is correctly fetched', function () {
			// step 3: get draft compositeThing class properties
			getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
		});

		describe('C188786: When the ID is the gateway model, see if the property is correctly fetched', function () {
			// step 3: get draft gateway class properties
			getDraftThingClassPropertiesByModelID(draftCompositeThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
		});

		describe('C188787: When the ID is the compositeThing model, see if the property is correctly fetched', function () {
			// step 3: get draft compositeThing class properties
			getDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
		});

		describe('C188788: When the ID does not exist, check to see if the return is correct', function () {
			// step 3: get draft compositeThing class properties
			getDraftThingClassPropertiesByModelID('23edfcasdfg', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188789: Operate when the ID is a published model to see if the return is correct', function () {
			// step 3: get draft compositeThing class properties
			getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
		});

		describe('C188790: When the ID does not match tenantId, check to see if the return is correct', function () {
			// step 3: get draft compositeThing class properties
			getDraftThingClassPropertiesByModelID('tr2345fghu', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		/*
         PUT ​/thing-model​/draft​/thing-classes​/{id}​/properties
        */

		describe('C188808: When the ID is the device model, check to see if the model has been modified correctly', function () {
			// step 3: put draft compositeThing class properties
			putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData1.UpdatethingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
		});

		describe('C188809: When the ID is the gateway model, check to see if the model has been modified correctly', function () {
			// step 3: put draft gateway class properties
			putDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData1.UpdatethingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
		});

		describe('C188810: When the ID is the compositeThing model, check to see if the model has been modified correctly', function () {

			describe('post draft compositeThing class', function () {
				// step 1: create draft compositeThing class
				postDraftThingClass(draftCompositeThingClassData5.CompositeThingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});

			describe('post draft compositeThing Properties', function () {
				// step 2: create draft compositeThing property
				postDraftThingClassPropertiesByModelID(draftCompositeThingClassData5.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('put draft compositeThing Properties', function () {
				// step 3: put draft compositeThing class properties
				putDraftThingClassPropertiesByModelID(draftCompositeThingClassData5.modelId, draftThingClassModelPropertiesData1.UpdatethingPropertiesBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
			});

			describe('delete draft compositeThing class by model Id', function () {
				// step 6: delete draft compositeThing class by model Id
				deleteDraftThingClassByModelID(draftCompositeThingClassData5.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C188811: Operate when the ID is a published model to see if the return is normal', function () {

			describe('post draft compositeThing class', function () {
				// step 1: create draft compositeThing class
				postDraftThingClass(draftCompositeThingClassData5.CompositeThingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});

			describe('post draft compositeThing Properties', function () {
				// step 2: create draft compositeThing property
				postDraftThingClassPropertiesByModelID(draftCompositeThingClassData5.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});
			describe('patch draft compositeThing class', function () {
				// step 3: publish draft compositeThing class
				patchDraftThingClassByModelID(draftCompositeThingClassData5.modelId, store.putLater('response2'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response2'), 200);
				verifyPayload(store.getLater('response2'), {});
			});

			describe('put draft compositeThing Properties', function () {
				// step 3: put draft compositeThing class properties
				putDraftThingClassPropertiesByModelID(draftCompositeThingClassData5.modelId, draftThingClassModelPropertiesData1.UpdatethingPropertiesBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassModelPropertiesSchema);
			});

			describe('patch compositeThing class', function () {
				// step 5: unpublish draft compositeThing class
				patchThingClassByModelID(draftCompositeThingClassData5.modelId, store.putLater('response4'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response4'), 200);
				verifyPayload(store.getLater('response4'), {});
			});

			describe('delete draft compositeThing class by model Id', function () {
				// step 6: delete draft compositeThing class by model Id
				deleteDraftThingClassByModelID(draftCompositeThingClassData5.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C188812: When the ID is not match tenantId, check to see if the return is correct', function () {
			// step 3: put draft compositeThing class properties
			putDraftThingClassPropertiesByModelID('asdfghjgfrdes', draftThingClassModelPropertiesData1.UpdatethingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188813: When the property is not exist, check to see if the return is correct', function () {
			// step 3: put draft compositeThing class properties
			putDraftThingClassPropertiesByModelID(unpublishDraftThingClassData.modelId, draftThingClassModelPropertiesData1.UpdatethingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		/*
          POST ​/thing-model​/draft​/thing-classes​/{id}​/properties
         */

		describe('C188814: When the ID is the device model, see if the property has been added properly', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(unpublishDraftThingClassData.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188815: When the ID is the gateway model, see if the property has been added properly', function () {
			// step 2: create draft gateway  property
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188816: When the ID is the compositeThing model, see if the property has been added properly', function () {
			// step 2: create draft compositeThing  property
			postDraftThingClassPropertiesByModelID(draftCompositeThingClassData.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188819: Operate when the ID is a published model to see if the return is correct', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('C188820: When the ID does not match tenantId, check to see if the return is correct', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID('sdfghjkljnhb', draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188821: When the property already exists, check to see if the return is correct', function () {
			// step 2: create draft device  property
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		/*
          DELETE ​/thing-model​/draft​/thing-classes​/{id}​/properties
         */

		describe('C188823: When the ID is the device model, see if the property has been added properly', function () {
			//设备
			describe('post draft device class', function () {
				// step 1: create draft device class
				postDraftThingClass(unpublishDraftThingClassData2.thingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), unpublishDraftThingClassData2.thingClassBody);
			});

			describe('post draft device property', function () {
				// step 2: create draft device  property
				postDraftThingClassPropertiesByModelID(unpublishDraftThingClassData2.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('delete draft device property', function () {
				// step 2: delete draft device  property
				deleteDraftThingClassPropertiesByModelID(unpublishDraftThingClassData2.modelId, draftThingClassModelPropertiesData2.name, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 204);
			});


		});

		describe('C188824: When the ID is the gateway model, see if the property has been added properly', function () {
			describe('post draft gateway class', function () {
				// step 1: create draft gateway class
				postDraftThingClass(draftGatewayClassData3.thingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftThingClassSchema);
				verifyPayload(store.getLater('response'), draftGatewayClassData3.thingClassBody);
			});

			describe('post draft gateway class properties', function () {
				// step 2: create draft gateway property
				postDraftThingClassPropertiesByModelID(draftGatewayClassData3.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('delete draft gateway property', function () {
				// step 2: delete draft gateway  property
				deleteDraftThingClassPropertiesByModelID(draftGatewayClassData3.modelId, draftThingClassModelPropertiesData2.name, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

		});

		describe('C188825: When the ID is the compositeThing model, see if the property has been added properly', function () {
			describe('post draft compositeThing class', function () {
				// step 1: create draft compositeThing class
				postDraftThingClass(draftCompositeThingClassData6.CompositeThingClassBody, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 200);
				verifySchema(store.getLater('response'), draftCompositeThingClassSchema);
			});

			describe('post draft compositeThing Properties', function () {
				// step 2: create draft compositeThing property
				postDraftThingClassPropertiesByModelID(draftCompositeThingClassData6.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('delete draft compositeThing property', function () {
				// step 2: delete draft compositeThing  property
				deleteDraftThingClassPropertiesByModelID(draftCompositeThingClassData6.modelId, draftThingClassModelPropertiesData2.name, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

		});

		describe('C188826: Operate when the ID is a published model to see if the return is correct', function () {
			// step 2: delete draft compositeThing  property
			deleteDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData2.name, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C188827: When the ID does not match tenantId, check to see if the return is correct', function () {
			// step 2: delete draft compositeThing  property
			deleteDraftThingClassPropertiesByModelID('sdfghjk', draftThingClassModelPropertiesData2.name, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188828: When the property does not exist, check to see if the return is correct', function () {
			// step 2: delete draft compositeThing  property
			deleteDraftThingClassPropertiesByModelID(draftThingClassData.modelId, 'fghnbvc', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		describe('C188835: When a property is built in, check to see if the return is correct', function () {
			// step 2: delete draft compositeThing  property
			deleteDraftThingClassPropertiesByModelID(draftThingClassData.modelId, '__workingStatus__', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 404);
		});

		/*
        DELETE ​/thing-model​/draft​/thing-classes​/{id}​/allProperties
         */

		describe('C188829: When the ID is the device model, check to see if the property is deleted properly', function () {

			describe('post draft device property', function () {
				// step 2: create draft device  property
				postDraftThingClassPropertiesByModelID(unpublishDraftThingClassData2.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('delete draft device property class by model Id', function () {
				// step 2: delete draft compositeThing  property
				deleteAllDraftThingClassPropertiesByModelID(unpublishDraftThingClassData2.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('delete draft device class by model Id', function () {
				// step 6: delete draft thing class by model Id
				deleteDraftThingClassByModelID(unpublishDraftThingClassData2.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C188830: When the ID is the gateway model, check to see if the property is deleted properly', function () {

			describe('post draft gateway class properties', function () {
				// step 2: create draft gateway property
				postDraftThingClassPropertiesByModelID(draftGatewayClassData3.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('delete draft gateway property class by model Id', function () {
				// step 2: delete draft gateway  property
				deleteAllDraftThingClassPropertiesByModelID(draftGatewayClassData3.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('delete draft gateway class by model Id', function () {
				// step 6: delete draft gateway class by model Id
				deleteDraftThingClassByModelID(draftGatewayClassData3.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C188831: When the ID is the compositeThing model, check to see if the property is deleted properly', function () {

			describe('post draft compositeThing Properties', function () {
				// step 2: create draft compositeThing property
				postDraftThingClassPropertiesByModelID(draftCompositeThingClassData6.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response1'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response1'), 200);
				verifyPayload(store.getLater('response1'), {});
			});

			describe('delete draft compositeThing property class by model Id', function () {
				// step 2: delete draft compositeThing  property
				deleteAllDraftThingClassPropertiesByModelID(draftCompositeThingClassData6.modelId, store.putLater('response'));
				// verification status code, payload and schema
				Response.statusCodeEquals(store.getLater('response'), 204);
			});

			describe('delete draft compositeThing class by model Id', function () {
				// step 6: delete draft compositeThing class by model Id
				deleteDraftThingClassByModelID(draftCompositeThingClassData6.modelId, store.putLater('response'));
				// verification status code, payload
				Response.statusCodeEquals(store.getLater('response'), 204);
			});
		});

		describe('C188832: Operate when the ID is a published model to see if the return is correct', function () {
			// step 2: delete draft compositeThing  property
			deleteAllDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('C188833: When the ID does not match tenantId, check to see if the return is correct', function () {
			// step 2: delete draft compositeThing  property
			deleteAllDraftThingClassPropertiesByModelID('sdfghjk', store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 400);
		});

		describe('C188834: Check to see if the built-in properties have been removed', function () {
			// step 2: delete draft compositeThing  property
			deleteAllDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//复合物
		describe('patch compositeThing class', function () {
			// step 5: unpublish draft compositeThing class
			patchThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft compositeThing class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftCompositeThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//设备
		describe('patch  device class', function () {
			// step 5: unpublish draft device class
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//删除不发布的设备
		describe('delete draft device class by model Id', function () {
			// step 3: delete draft thing class by model Id
			deleteDraftThingClassByModelID(unpublishDraftThingClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		//网关
		describe('patch  gateway class', function () {
			// step 5: unpublish draft gateway class
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response4'));
			// verification status code, payload and schema
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft gateway class by model Id', function () {
			// step 6: delete draft thing class by model Id
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			// verification status code, payload
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

});
