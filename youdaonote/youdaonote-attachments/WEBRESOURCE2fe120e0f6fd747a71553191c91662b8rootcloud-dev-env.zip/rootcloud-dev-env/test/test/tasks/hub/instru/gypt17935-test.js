'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');

const { draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	updateInstructionsData,
	draftThingClassData1,
	draftThingClassModelPropertiesData1,
	createInstructionsData2,
	createInstructionsData3,
	createInstructionsData4,
	createInstructionsData5,
	createInstructionsData6,
	createInstructionsRequestData,
	thingInstanceData,
	draftThingClassData2,
	draftGatewayClassData,
	thingClassModelInstanceData,
	createInstructionsRequestData1,
	createInstructionsRequestData2,
	draftThingClassData3,
	draftThingClassModelPropertiesData2,
	thingInstanceData2,
	createInstructionsRequestData3,
	createInstructionsData1,
	draftThingClassModelPropertiesData3 } = require('../../../../test-data/data/tasks/hub/instru/GYPT17935');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { instructionSchema } = require('../../../../test-data/schema/instructionTemplate');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { instructionRequestSchema, getInstructionRequestSchema } = require('../../../../test-data/schema/instructionRequest');

const { postDraftThingClass, postDraftThingClassPropertiesByModelID, getDraftThingClassByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postInstructionTemplate, getInstructionTemplate, deleteInstructionTemplate, putInstructionTemplate } = require('../../../../test-lib/instructionTemplate');
const { postInstructionRequests,getInstructionRequestsByRequestId1, getInstructionRequests } = require('../../../../test-lib/instructionRequest');

const { verifySchema, verifyPayload, verifyMultiPayload, verifyMultiSchema } = require('../../../../test-verify/verify');
const store = new DataStore();

describe('GYPT-17935: write instruction code reconstruction', function () {
	describe('create environment dependent data', function () {

		describe('creation draft thing class model', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('add attributes to unpublished thing class model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('creation draft thing class model1', function () {
			postDraftThingClass(draftThingClassData1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData1.thingClassBody);
		});

		describe('add attributes to unpublished thing class model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData1.modelId, draftThingClassModelPropertiesData1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

	});

	describe('C188553: CRUD test for instruction templates', function () {

		describe('create instructions', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData.instructionsBody);
		});

		describe('query instructions', function () {
			getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData.instructionTemplateId });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), instructionSchema);
			verifyMultiPayload(store.getLater('response'), createInstructionsData.instructionsBody);
		});

		describe('modification of unpublished instructions', function () {
			putInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, updateInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete the created instruction', function () {
			deleteInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('C188554: CRUD test for instruction templates where type = CMD', function () {

		describe('create instructions', function () {
			postInstructionTemplate(draftThingClassData1.modelId, createInstructionsData1.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.instructionTemplateId', createInstructionsData1.instructionTemplateId);
		});

		describe('query instructions ', function () {
			getInstructionTemplate(draftThingClassData1.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData1.instructionTemplateId });
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyMultiSchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].instructionTemplateId', createInstructionsData1.instructionTemplateId);
		});

		describe('modification of unpublished instructions', function () {
			putInstructionTemplate(draftThingClassData1.modelId, createInstructionsData1.instructionTemplateId, updateInstructionsData.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete the created instruction', function () {
			deleteInstructionTemplate(draftThingClassData1.modelId, createInstructionsData1.instructionTemplateId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

	describe('C188555: create multiple instructions of the same type under the same device type', function () {

		describe('create instructions1', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData2.instructionsBody);
		});

		describe('create instructions2', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData3.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData3.instructionsBody);
		});
	});

	describe('C188556: create multiple different types of instructions under the same device type', function () {

		describe('create instructions3', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData4.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData4.instructionsBody);
		});

		describe('create instructions4', function () {
			postInstructionTemplate(draftThingClassData.modelId, createInstructionsData5.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData5.instructionsBody);
		});
	});

	describe('C188557: instructionId repeat: create under different device types', function () {

		describe('create instructions for draftThingClassData1', function () {
			postInstructionTemplate(draftThingClassData1.modelId, createInstructionsData4.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData4.instructionsBody);
		});
	});

	describe('C188558: instructionId repeat: created under the same device type', function () {

		postInstructionTemplate(draftThingClassData.modelId, createInstructionsData4.instructionsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 400);
		verifySchema(store.getLater('response'), errorResponseSchema);
		verifyPayload(store.getLater('response'), []);
	});

	describe('C188559: required non required item inspection', function () {

		getInstructionTemplate(draftThingClassData.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData2.instructionTemplateId });
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyMultiSchema(store.getLater('response'), instructionSchema);
		verifyMultiPayload(store.getLater('response'), createInstructionsData2.instructionsBody);
	});

	describe('C188560: query operations on deleted instructions', function () {
		getInstructionTemplate(draftThingClassData1.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData1.instructionTemplateId });
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), []);
	});

	describe('C188561: update the deleted instruction', function () {
		putInstructionTemplate(draftThingClassData.modelId, createInstructionsData.instructionTemplateId, updateInstructionsData.instructionsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 404);
		verifySchema(store.getLater('response'), errorResponseSchema);
	});

	describe('delete thing class model1', function () {
		deleteDraftThingClassByModelID(draftThingClassData1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);

	});

	describe('C188562: instruction issuing operation', function () {

		describe('creation draft thing class model2', function () {
			postDraftThingClass(draftThingClassData2.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData2.thingClassBody);
		});

		describe('add attributes to unpublished thing class model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData2.modelId, draftThingClassModelPropertiesData3.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create instructions for draftThingClassData', function () {
			postInstructionTemplate(draftThingClassData2.modelId, createInstructionsData2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData2.instructionsBody);
		});

		describe('create CMD instructions', function () {
			postInstructionTemplate(draftThingClassData2.modelId, createInstructionsData6.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.instructionTemplateId', createInstructionsData6.instructionTemplateId);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData2.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData.instructionRequestsBody, store.putLater('response'), store.putLater('requestId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});
	});

	describe('C188563: command to issue instructions', function () {
		postInstructionRequests(createInstructionsRequestData.instructionRequestsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C188564: verify command status', function () {

		getInstructionTemplate(draftThingClassData2.modelId, store.putLater('response'), { instructionTemplateId: createInstructionsData2.instructionTemplateId });
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyMultiSchema(store.getLater('response'), instructionSchema);
		verifyMultiPayload(store.getLater('response'), createInstructionsData2.instructionsBody);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].status', 'draft');
	});

	describe('C188565: successfully issued verification command', function () {

		getInstructionRequestsByRequestId1(store.getLater('requestId'), store.putLater('response'), { status: 'EXPIRED' });
		Response.statusCodeEquals(store.getLater('response'), 200);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.status', 'EXPIRED');
	});

	describe('C188566: view historical device response results', function () {

		getInstructionRequests(store.putLater('response'), { queryString: `modelId=${draftThingClassData2.modelId}&thingId=${thingInstanceData.thingId}` });
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyMultiSchema(store.getLater('response'), getInstructionRequestSchema);
	});

	describe('C188567: directly connected devices issue commands', function () {

		postInstructionRequests(createInstructionsRequestData.instructionRequestsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C188569: send instructions to the gateway device', function () {
		//网关
		describe('post draft gateway class', function () {
			postDraftThingClass(draftGatewayClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftGatewayClassData.thingClassBody);
		});

		describe('post draft Gateway class', function () {
			postDraftThingClassPropertiesByModelID(draftGatewayClassData.modelId, draftThingClassModelPropertiesData1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create instructions for draftThingClassData', function () {
			postInstructionTemplate(draftGatewayClassData.modelId, createInstructionsData2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData2.instructionsBody);
		});

		describe('patch draft Gateway class', function () {
			patchDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create gateway device', function () {
			postThingInstancesByModelId(draftGatewayClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});

		describe('give instructions', function () {
			postInstructionRequests(createInstructionsRequestData1.instructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});
	});

	describe('C188568: commands issued by non directly connected devices', function () {

		describe('create a non directly connected model', function () {
			postDraftThingClass(draftThingClassData3.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData3.thingClassBody);
		});

		describe('add attributes to unpublished thing class model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData3.modelId, draftThingClassModelPropertiesData2.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('create instructions for draftThingClassData', function () {
			postInstructionTemplate(draftThingClassData3.modelId, createInstructionsData2.instructionsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionSchema);
			verifyPayload(store.getLater('response'), createInstructionsData2.instructionsBody);
		});

		describe('active device model class by model id1', function () {
			patchDraftThingClassByModelID(draftThingClassData3.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance by model id', function () {
			postThingInstancesByModelId(draftThingClassData3.modelId, thingInstanceData2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('implementation instructions issued', function () {
			postInstructionRequests(createInstructionsRequestData3.instructionRequestsBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), instructionRequestSchema);
		});
	});

	describe('C1721889: type is live give instructions', function () {

		postInstructionRequests(createInstructionsRequestData.instructionRequestsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1721890: type is live give instructions', function () {
		postInstructionRequests(createInstructionsRequestData1.instructionRequestsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('C1721891: type is cmd give instructions', function () {
		postInstructionRequests(createInstructionsRequestData2.instructionRequestsBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), instructionRequestSchema);
	});

	describe('delete environmental data', function () {

		describe('delete thing class model', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		describe('check whether the deletion is successful', function () {
			getDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		//delete non directly connected equipment
		describe('delete thing instances device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData3.modelId, thingInstanceData2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData3.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing class model', function () {
			deleteDraftThingClassByModelID(draftThingClassData3.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		describe('check whether the deletion is successful', function () {
			getDraftThingClassByModelID(draftThingClassData3.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		//delete published model
		describe('delete thing instances device', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData2.modelId, thingInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass', function () {
			patchThingClassByModelID(draftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing class model1', function () {
			deleteDraftThingClassByModelID(draftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		describe('check whether the deletion is successful', function () {
			getDraftThingClassByModelID(draftThingClassData2.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});

		describe('delete thing instances gateway', function () {
			deleteThingInstancesByModelIdAndThingId(draftGatewayClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('un-publish thingClass gateway', function () {
			patchThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('delete thing class gateway', function () {
			deleteDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);

		});

		describe('check whether the deletion is successful', function () {
			getDraftThingClassByModelID(draftGatewayClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
		});
	});
});