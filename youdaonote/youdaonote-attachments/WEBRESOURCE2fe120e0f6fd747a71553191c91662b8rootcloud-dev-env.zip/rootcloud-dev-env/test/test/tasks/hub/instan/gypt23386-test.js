
'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');
const { putLocationByDeviceTypeIdAndDeviceId } = require('../../../../test-lib/openApi');
const { postCountDeviceByState, postCountDeviceByCity } = require('../../../../test-lib/openApi');
const { draftThingClassData, draftThingClassPropertiesData, thingInstanceData_1, thingInstanceData_2, thingInstanceData_3, thingInstanceData_4, thingInstanceData_5, locationData_1, locationData_2, locationData_3, locationData_4, locationData_5, countByStateData, countByCityData } = require('../../../../test-data/data/tasks/hub/instan/GYPT23386');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { putSingleDeviceLocationSchema } = require('../../../../test-data/schema/deviceOnlineStatus');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { loggerCase } = require('../../../../test-lib/logger');

const store = new DataStore();

describe('GYPT-23386: test devices location', function () {

	describe('precondition', function () {
		//create a single device model and 5 device instances with the same model
		describe('post device model class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post device model class properties by model id', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('active device model class by model id', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifyPayload(store.getLater('response'), {});
		});

		describe('post device model instance1 by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
		});

		describe('post device model instance2 by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_2.thingInstanceBody);
		});

		describe('post device model instance3 by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_3.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_3.thingInstanceBody);
		});

		describe('post device model instance4 by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_4.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_4.thingInstanceBody);
		});

		describe('post device model instance5 by model id', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData_5.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingInstanceData_5.thingInstanceBody);
		});

		describe('put devices location', function () {
			//allocate location information for each device created
			//verify status code, payload and schema
			putLocationByDeviceTypeIdAndDeviceId(draftThingClassData.modelId, thingInstanceData_1.thingId, locationData_1.locationBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), putSingleDeviceLocationSchema);
			verifyPayload(store.getLater('response'), locationData_1.locationBody);

			putLocationByDeviceTypeIdAndDeviceId(draftThingClassData.modelId, thingInstanceData_2.thingId, locationData_2.locationBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'),200);
			verifySchema(store.getLater('response'), putSingleDeviceLocationSchema);
			verifyPayload(store.getLater('response'), locationData_2.locationBody);

			putLocationByDeviceTypeIdAndDeviceId(draftThingClassData.modelId, thingInstanceData_3.thingId, locationData_3.locationBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'),200);
			verifySchema(store.getLater('response'), putSingleDeviceLocationSchema);
			verifyPayload(store.getLater('response'), locationData_3.locationBody);

			putLocationByDeviceTypeIdAndDeviceId(draftThingClassData.modelId,thingInstanceData_4.thingId, locationData_4.locationBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'),200);
			verifySchema(store.getLater('response'), putSingleDeviceLocationSchema);
			verifyPayload(store.getLater('response'), locationData_4.locationBody);

			putLocationByDeviceTypeIdAndDeviceId(draftThingClassData.modelId, thingInstanceData_5.thingId, locationData_5.locationBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'),200);
			verifySchema(store.getLater('response'), putSingleDeviceLocationSchema);
			verifyPayload(store.getLater('response'), locationData_5.locationBody);
		});
	});

	describe('C1880569: query devices count by state', function () {
		//query devices location information by state
		postCountDeviceByState(countByStateData.countDeviceByStateBody, store.putLater('response'));
		//verify status code
		Response.statusCodeEquals(store.getLater('response'),200);
		it('verify the result is consistent with the input data ', function () {
			const body = Response.getJsonBody(store.get('response'));
			const iterable = body.payload;
			for(const obj of iterable){
				switch (obj.provinceName) {
					case '山西省':
						Assert.strictEqual(obj.count, 1, 'result is not correct');
						break;
					case '湖北省':
						Assert.strictEqual(obj.count, 4 ,'result is not correct');
						break;
					default:
						loggerCase.info('input and output locations are not consistent');
				}
			}
		});
	});

	describe('C1880568', function () {
		//query devices location information by city
		postCountDeviceByCity('山西省', countByCityData.countDeviceByCityBody, store.putLater('response'));
		//verify status code
		Response.statusCodeEquals(store.getLater('response'),200);
		it('verify the result is consistent with the input data ', function () {
			const body = Response.getJsonBody(store.get('response'));
			const iterable = body.payload;
			for(const obj of iterable){
				switch (obj.city) {
					case '太原市':
						Assert.strictEqual(obj.count, 1, 'result is not correct');
						break;
					default:
						loggerCase.info('input and output locations are not consistent');
				}
			}
		});

		postCountDeviceByCity('湖北省', countByCityData.countDeviceByCityBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'),200);
		it('verify the result is consistent with the input data ', function () {
			const body = Response.getJsonBody(store.get('response'));
			const iterable = body.payload;
			for(const obj of iterable){
				switch (obj.city) {
					case '武汉市':
						Assert.strictEqual(obj.count, 2, 'result is not correct');
						break;
					case '孝感市':
						Assert.strictEqual(obj.count, 1, 'result is not correct');
						break;
					case '宜昌市':
						Assert.strictEqual(obj.count, 1, 'result is not correct');
						break;
					default:
						loggerCase.info('input and output locations are not consistent');
				}
			}
		});
	});
});







