'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass, patchDraftThingClassByModelID, postDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId } = require('../../../../test-lib/openApiThingInstances');

const { postElecfenceByThingId, deleteElecfenceByThingId } = require('../../../../test-lib/elecfence');
const { putDraftThingInterfacesByModelId, getThingInterfacesByModelId, deleteDraftThingInterfacesByModelId } = require('../../../../test-lib/openApiThingInterfaces');
const {
    draftThingClassData,
    thingInstanceData,
    draftThingClassModelPropertiesData,
    elecfenceData,
    elecfenceData_1,
    draftThingInterfaces,
    draftThingInterfaces_1,
    draftThingInterfaces_2,
    draftThingClassData_1,
    draftThingClassModelPropertiesData_1,
    thingInstanceData_1,
    elecfenceData_2
} = require('../../../../test-data/data/tasks/hub/elecfence/GYPT28225');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { thingInstancePostSchema } = require('../../../../test-data/schema/thingInstance');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { valDict } = require('../../../../test-data/requireData');

const store = new DataStore();

describe('GYPT-28225: /elecfence', function () {

    describe('创建依赖环境', function () {
        postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), draftThingClassSchema);
        verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);

        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});

        patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});

        postThingInstancesByModelId(draftThingClassData.modelId, thingInstanceData.thingInstanceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), thingInstancePostSchema);
        verifyPayload(store.getLater('response'), thingInstanceData.thingInstanceBody);
    });

    describe('C2414063: 创建电子围栏，会自动创建出物接口，物接口为已发布状态 ', function () {
        postElecfenceByThingId(elecfenceData.elecfenceBody, store.putLater('response'), store.putLater('elecFenceRuleId1'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        getThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, store.putLater('response'), store.putLater('created'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.isPublished', true);
    });

    describe('C2414072&C2414064:物接口名称为saas-elec-fence-interface，模型id为tenantId+saas-elec-fence-interface', function () {
        getThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', `${valDict.tenantId}_saas_elec_fence_interface`);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.name', 'saas_elec_fence_interface');
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.properties[0].name', '__location__');
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.properties[0].propertyType', 'Json');
    });

    describe('C2414065: 再次创建电子围栏，不会再创建物接口', function () {
        postElecfenceByThingId(elecfenceData_1.elecfenceBody, store.putLater('response'), store.putLater('elecFenceRuleId'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        getThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
    });

    describe('C2414066: 修改物接口的属性，修改失败并给出提示', function () {
        putDraftThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, draftThingInterfaces.updateThingInterfacesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', `模型ID为${valDict.tenantId}_saas_elec_fence_interface抽象物接口被引用了，不能修改/删除/不激活`);
    });

    describe('C2414070: 添加物接口的属性，添加失败并给出提示', function () {
        putDraftThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, draftThingInterfaces_1.updateThingInterfacesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', `模型ID为${valDict.tenantId}_saas_elec_fence_interface抽象物接口被引用了，不能修改/删除/不激活`);
    });

    describe('C2414067: 删除物接口，删除失败并给出提示', function () {
        deleteDraftThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', `模型ID为${valDict.tenantId}_saas_elec_fence_interface抽象物接口被引用了，不能修改/删除/不激活`);
    });

    describe('C2414071: 修改物接口，修改失败并给出提示', function () {
        putDraftThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, draftThingInterfaces_2.updateThingInterfacesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', `模型ID为${valDict.tenantId}_saas_elec_fence_interface抽象物接口被引用了，不能修改/删除/不激活`);
    });

    describe('创建依赖环境', function () {
        postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), draftThingClassSchema);
        verifyPayload(store.getLater('response'), draftThingClassData_1.thingClassBody);

        postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});

        patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});

        postThingInstancesByModelId(draftThingClassData_1.modelId, thingInstanceData_1.thingInstanceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), thingInstancePostSchema);
        verifyPayload(store.getLater('response'), thingInstanceData_1.thingInstanceBody);
    });

    describe('C2414068: 创建电子围栏，当关联的设备对应的物模型没有启用当前位置时，围栏创建失败并给出提示 ', function () {
        postElecfenceByThingId(elecfenceData_2.elecfenceBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'message', `模型ID为${draftThingClassData_1.modelId} physicalInterface 的属性没有继承所有的${valDict.tenantId}_saas_elec_fence_interface抽象物接口的属性`);
    });

    describe('C2414069: 删除租户下所有电子围栏，物接口不会被删除', function () {
        deleteElecfenceByThingId(store.getLater('elecFenceRuleId'), store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        deleteElecfenceByThingId(store.getLater('elecFenceRuleId1'), store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
        getThingInterfacesByModelId(`${valDict.tenantId}_saas_elec_fence_interface`, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.modelId', `${valDict.tenantId}_saas_elec_fence_interface`);
    });
});