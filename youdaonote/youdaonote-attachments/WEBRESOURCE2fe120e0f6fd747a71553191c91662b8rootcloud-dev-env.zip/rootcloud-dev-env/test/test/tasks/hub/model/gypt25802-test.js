/* eslint-disable indent */
'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { draftThingClassData, draftExpressionData_1, draftExpressionData, draftThingClassPropertiesData, updatedraftThingClassPropertiesData } = require('../../../../test-data/data/tasks/hub/model/GYPT25802');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, putDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const { postExpression, deleteExpression, putExpression } = require('../../../../test-lib/expression.js');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');
const { errorResponseSchema } = require('../../../../test-data/schema/common.js');

const { expressionSchema } = require('../../../../test-data/schema/expression.js');

const store = new DataStore();

describe('GYPT-25802 : The device manager may not set the multiplier to 0', function () {

    describe('start', function () {
        describe('post device model class', function () {
            postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), draftThingClassSchema);
            verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
        });
    });

    describe('C2148843 : Increase attribute multiplier by device model to 0', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2148844 : The attribute multiplier of modified model is 0', function () {
        putDraftThingClassPropertiesByModelID(draftThingClassData.modelId, updatedraftThingClassPropertiesData.UpdatethingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2190084 : Creates an expression for a property evaluation or rule', function () {
        postExpression(draftExpressionData.postExpressionBody, store.putLater('response'), store.putLater('expressionId'));
        Response.statusCodeEquals(store.getLater('response'), 400);
        verifySchema(store.getLater('response'), errorResponseSchema);
    });

    describe('C2190085 : Update the expression by ID (unpublished status)', function () {
        describe('creates  expression', function () {
            postExpression(draftExpressionData_1.postExpressionBody, store.putLater('response'), store.putLater('expressionId'));
            Response.statusCodeEquals(store.getLater('response'), 200);
            verifySchema(store.getLater('response'), expressionSchema);
        });

        describe('update expression', function () {
            putExpression(store.getLater('expressionId'), draftExpressionData.postExpressionBody, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 400);
            verifySchema(store.getLater('response'), errorResponseSchema);
        });

        describe('delete expression', function () {
            deleteExpression(store.getLater('expressionId'), store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 200);
        });
    });

    describe('end', function () {
        describe('delete draft device class by model Id', function () {
            deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
            Response.statusCodeEquals(store.getLater('response'), 204);
        });
    });

});
