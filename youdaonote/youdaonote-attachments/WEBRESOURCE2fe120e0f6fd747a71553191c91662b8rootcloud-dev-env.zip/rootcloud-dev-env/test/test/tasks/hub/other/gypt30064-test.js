
'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, deleteDraftThingClassPropertiesByModelID, getDraftThingClassPropertiesByModelID } = require('../../../../test-lib/openApiThingClass');
const {
    draftThingClassData,
    draftThingClassPropertiesData_1,
    draftThingClassPropertiesData_2,
    draftThingClassPropertiesData_3,
} = require('../../../../test-data/data/tasks/hub/other/GYPT30064');
const { draftThingClassSchema } = require('../../../../test-data/schema/thingClass');
const { verifySchema, verifyPayload } = require('../../../../test-verify/verify');

const store = new DataStore();
describe('GYPT-30064:删除单个属性时，会将模型中的所有属性都删除', function () {

    describe('post device model class ', function () {
        postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifySchema(store.getLater('response'), draftThingClassSchema);
        verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
    });

    describe('post device model class  properties 1', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_1.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('post device model class  properties 2', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_2.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('post device model class  properties 3', function () {
        postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_3.thingPropertiesBody, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        verifyPayload(store.getLater('response'), {});
    });

    describe('delete device model class  properties 1', function () {
        deleteDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassPropertiesData_1.name, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 204);
    });

    describe('查询 properties 2，properties 3', function () {
        getDraftThingClassPropertiesByModelID(draftThingClassData.modelId, store.putLater('response'));
        Response.statusCodeEquals(store.getLater('response'), 200);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.[0].name', draftThingClassPropertiesData_2.name);
        Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload.[1].name', draftThingClassPropertiesData_3.name);

    });
});
