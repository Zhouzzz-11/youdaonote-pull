'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const store = new DataStore();
const { postDraftThingClass, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { topicDict } = require('../../../../test-data/requireData');
const { postData } = require('../../../../test-data/util');
const { ThingClassData_1, CompositeThingData, C_PropertiesData_7, C_PropertiesData, compositeDeviceData, C_PropertiesData_1, C_PropertiesData_2, C_PropertiesData_3, C_PropertiesData_4, C_PropertiesData_5, C_PropertiesData_6,PropertiesData, postdata, deviceData_1, deviceData_2, deviceData_3} = require('../../../../test-data/data/tasks/hub/model/GYPT24641');
const { getRealTimeByModelAndThingId} = require('../../../../test-lib/openApiHistorian');

describe('GYPT-24641 : functions of multi nodes in compositeThing', function(){
	describe('precondition', function(){
		postDraftThingClass(ThingClassData_1.thingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(ThingClassData_1.modelId, PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		patchDraftThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(ThingClassData_1.modelId, deviceData_1.thingInstanceBody, store.putLater('response'));
		postThingInstancesByModelId(ThingClassData_1.modelId, deviceData_2.thingInstanceBody, store.putLater('response'));
		postThingInstancesByModelId(ThingClassData_1.modelId, deviceData_3.thingInstanceBody, store.putLater('response'));
        
		postDraftThingClass(CompositeThingData.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_1.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_2.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_3.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_4.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_5.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_6.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
        
		patchDraftThingClassByModelID(CompositeThingData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(CompositeThingData.modelId, compositeDeviceData.CompositeThingBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('C2076446 : sum', function(){
		postData(topicDict['pub_1.1'], deviceData_2.thingId, postdata.mesBody);
		postData(topicDict['pub_1.1'], deviceData_3.thingId, postdata.mesBody);

		getRealTimeByModelAndThingId(compositeDeviceData.thingId, CompositeThingData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 7 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData.name}.value`, 6);
	});
    
	describe('C2076447 : count', function(){
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData_1.name}.value`, 2);
	});
    
	describe('C2076448 : avg', function(){
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData_2.name}.value`, 3);
	});
    
	describe('C2076449 : min', function(){
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData_3.name}.value`, 3);
	});
    
	describe('C2076450 : max', function(){
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData_4.name}.value`, 3);
	});
    
	describe('C2076452 : dev', function(){
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData_5.name}.value`, 0);
	});
    
	describe('C2076453 : range', function(){
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData_6.name}.value`, 0);
	});

	describe('delete thing instances composite', function () {
		deleteThingInstancesByModelIdAndThingId(CompositeThingData.modelId, compositeDeviceData.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass composite', function () {
		patchThingClassByModelID(CompositeThingData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass composite', function () {
		deleteDraftThingClassByModelID(CompositeThingData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('operate when the index data type is different', function () {

		postDraftThingClass(CompositeThingData.CompositeThingClassBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postDraftThingClassPropertiesByModelID(CompositeThingData.modelId, C_PropertiesData_7.thingPropertiesBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		patchDraftThingClassByModelID(CompositeThingData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		postThingInstancesByModelId(CompositeThingData.modelId, compositeDeviceData.CompositeThingBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);

		postData(topicDict['pub_1.1'], deviceData_3.thingId, postdata.mesBody);

		getRealTimeByModelAndThingId(compositeDeviceData.thingId, CompositeThingData.modelId, store.putLater('response'), { retryCode: 404, expectNum: 7 });
		Response.bodyJsonPropertyEquals(store.getLater('response'), `payload[0].data.${C_PropertiesData.name}.value`, 6);

		describe('C2074774: When the target value is non-numeric, use sum\\count\\AVG \\min\\ Max \\dev\\range and the result has no value', function(){
			it('no calculation result', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].data[7] === undefined,'verification failed');
			});
		});

		describe('C2074778: when the compound property type does not match the target value, the calculated result has no value', function () {
			it('data types are inconsistent and no data calculation is performed', function () {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload[0].data[7] === undefined,'verification failed');
			});
		});
	});

	describe('delete thing instances composite', function () {
		deleteThingInstancesByModelIdAndThingId(CompositeThingData.modelId, compositeDeviceData.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass composite', function () {
		patchThingClassByModelID(CompositeThingData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass composite', function () {
		deleteDraftThingClassByModelID(CompositeThingData.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});

	describe('delete thing instances1', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_1.modelId, deviceData_1.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances2', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_1.modelId, deviceData_2.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thing instances3', function () {
		deleteThingInstancesByModelIdAndThingId(ThingClassData_1.modelId, deviceData_3.thingId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('un-publish thingClass1', function () {
		patchThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('delete thingClass1', function () {
		deleteDraftThingClassByModelID(ThingClassData_1.modelId, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 204);
	});
});
