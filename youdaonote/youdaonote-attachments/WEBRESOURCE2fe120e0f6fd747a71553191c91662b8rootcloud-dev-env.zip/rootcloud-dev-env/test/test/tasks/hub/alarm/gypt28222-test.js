'use strict';

const { DataStore, Assert } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { draftThingClassData,thingClassModelInstanceData_2,msgData,draftThingClassModelPropertiesData_1,thingClassModelInstanceData_1,draftThingClassData_1,updatepostAlarmTypeData,postAlarmTypeData_1,postAlarmTypeData,postAlarmSeverities,postAlarmCategories, createDraftAlarmRulesData_1, updateDraftAlarmRulesData, createDraftAlarmRulesData, thingClassModelInstanceData, draftThingClassModelPropertiesData } = require('../../../../test-data/data/tasks/hub/alarm/GYPT28222');
const { postDraftThingClass, patchThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, deleteDraftThingClassByModelID } = require('../../../../test-lib/openApiThingClass');
const { postThingInstancesByModelId, deleteThingInstancesByModelIdAndThingId } = require('../../../../test-lib/openApiThingInstances');
const { postRules,updateAlarmType,createAlarmSeverities,createAlarmCategories,createAlarmType, putAlarmRules } = require('../../../../test-lib/alarmType');
const { errorResponseSchema } = require('../../../../test-data/schema/common');
const { verifySchema } = require('../../../../test-verify/verify');
const { getMqttClient, postDataWithClient, closeClient } = require('../../../../test-lib/mqtt');
const { topicDict } = require('../../../../test-data/requireData');
const {  getAlarmCountByThingId } = require('../../../../test-lib/openApiHistorian');


const store = new DataStore();

describe('GYPT-28222 : The alarm rule can select the object to execute', function () {

	describe('Create environment', function () {

		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('post draft device class 1', function () {
			postDraftThingClass(draftThingClassData_1.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Successfully added properties to the first model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Successfully added properties to the second model', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData_1.modelId, draftThingClassModelPropertiesData_1.thingPropertiesBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('active device model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('active device second model class by model', function () {
			patchDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Creation instance', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Create a second object model instance', function () {
			postThingInstancesByModelId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Creation instance 2', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData_2.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});
	});

	describe('C2248002 : Enter a valid UUID for the device acceptedthings list', function () {

		describe('Enter a valid UUID for the device acceptedthings list', function () {
			postRules(createDraftAlarmRulesData.draftAlarmRulesBody, store.putLater('response'),store.putLater('ruleId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.acceptedThings.length > 0);
			});
		});
	});

	describe('C2248003 : Modify alarm rule device list and input valid UUID', function () {

		describe('Modify alarm rule device list and input valid UUID', function () {
			putAlarmRules(updateDraftAlarmRulesData.draftAlarmRulesBody,store.getLater('ruleId'), store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.acceptedThings.length > 0);
				Assert.isTrue(body.payload.ruleMode == 'becomeTrue');
			});
		});
	});

	describe('C2248004 : Create alarm rule device acceptedthings list, input UUID is empty', function () {

		describe('Create alarm rule device acceptedthings list, input UUID is empty', function () {
			postRules(createDraftAlarmRulesData_1.draftAlarmRulesBody, store.putLater('response'),store.putLater('ruleId'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1013');
				Assert.isTrue(body.message == 'acceptedThings不能为空数组');
			});
		});
	});

	describe('C2248005 : Create an alarm type device acceptedthings list and enter a valid UUID', function () {

		describe('create the first alarm category', function () {
			createAlarmCategories(postAlarmCategories.alarmCategoriesBody, store.putLater('response'), store.putLater('cid1'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('create alarm levels', function () {
			createAlarmSeverities(postAlarmSeverities, store.putLater('response'), store.putLater('level'));
			//Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Create an alarm type device acceptedthings list and enter a valid UUID', function () {
			createAlarmType(postAlarmTypeData.alarmTypeBody, store.putLater('response'), store.putLater('alarmTypeId'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.acceptedThings.length > 0);
			});
		});
	});

	describe('C2248006 : Update the alarm type acceptedthings device list and enter a valid device UUID', function () {

		describe('Update the alarm type acceptedthings device list and enter a valid device UUID', function () {
			updateAlarmType(updatepostAlarmTypeData.alarmTypeBody,store.getLater('alarmTypeId'),store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.payload.acceptedThings.length > 0);
			});
		});
	});

	describe('C2248007 : Create alarm type acceptedthings list is empty', function () {

		describe('Create alarm type acceptedthings list is empty', function () {
			createAlarmType(postAlarmTypeData_1.alarmTypeBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 400);
			verifySchema(store.getLater('response'), errorResponseSchema);
			it('check access is in response', () => {
				const body = Response.getJsonBody(store.get('response'));
				Assert.isTrue(body.code == 'CMS-1013');
				Assert.isTrue(body.message == 'acceptedThings不能为空数组');
			});
		});
	});

	describe('C2457026 : Verify the device alarms in the accepted things device list',function () {
		describe('Verify that the device inherits the alarm', function () {
			describe('active device model class by model', function () {
				patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				getMqttClient(thingClassModelInstanceData.thingId, (client) => {
					store.put('client', client);
				});
			});
			describe('post data with mqtt', function () {
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
				closeClient(store.getLater('client'));
			});
	
			describe('Query alarm count',function () {
				getAlarmCountByThingId(thingClassModelInstanceData.thingId,draftThingClassData.modelId, store.putLater('response'),{ retryCode: 404, expectNum: 0});
				Response.statusCodeEquals(store.getLater('response'), 200);
				it('check access is in response', () => {
					const body = Response.getJsonBody(store.get('response'));
					Assert.isTrue(body.payload.totalNum > 0);
				});
			});
		});
	
		describe('If the device is not selected, it will not alarm',function () {
			describe('connect Mqqt',function () {
				getMqttClient(thingClassModelInstanceData_2.thingId, (client) => {
					store.put('client', client);
				});
			});
			describe('post data with mqtt', function () {
				postDataWithClient(store.getLater('client'), topicDict['pub_1.1'], msgData.mesBody);
				closeClient(store.getLater('client'));
			});
	
			describe('Query alarm times',function () {
				getAlarmCountByThingId(thingClassModelInstanceData_2.thingId,draftThingClassData.modelId, store.putLater('response'));
				Response.statusCodeEquals(store.getLater('response'), 200);
				it('check access is in response', () => {
					const body = Response.getJsonBody(store.get('response'));
					Assert.isTrue(body.payload.totalNum === 0);
				});
			});
		});
	});

	describe('Clear environment', function () {

		describe('Delete object instance', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete object instance', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData_1.modelId, thingClassModelInstanceData_1.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('Delete object instance 2', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData_2.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('patch thing class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('patch thing class', function () {
			patchThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData_1.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});
});