'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { deployerBody } = require('../../test-data/data/adeployer/deployer');
const { deployer } = require('../../test-lib/deployer');

describe('/deployer tenant and job', function() {

	describe('deployer tenant', function() {
		const store = new DataStore();
		deployer(deployerBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});
});
