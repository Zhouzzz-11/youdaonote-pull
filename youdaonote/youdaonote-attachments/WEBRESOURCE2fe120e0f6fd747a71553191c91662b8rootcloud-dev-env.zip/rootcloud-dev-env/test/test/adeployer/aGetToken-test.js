'use strict';

const {Response} = require('@rootcloud/darjeeling-http');
const {loginSuperAdminData, loginSuperUserList, postCompanyList, postServiceList} = require('../../test-data/data/adeployer/aGetToken');
const {valDict, store, tenantKey, setHeader} = require('../../test-data/requireData');
const {loginUser, postCompany, loginTenantUser, postServiceLicense} = require('../../test-lib/getToken');


describe('/get tokens of private tenant', function () {

	before(function () {
		if (valDict.runEnv === 'local' || valDict.runEnv === 'ci' || valDict.runEnv === 'ci1') {
			this.skip();
		}
	});

	describe('login super admin', function () {
		loginUser(loginSuperAdminData, store.putLater('response'), store.putLater('token'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('get company by id and post company if not exist', function () {
		postCompany(postCompanyList, store.getLater('token'), store.putLater('response'));
		postServiceLicense(postServiceList, store.getLater('token'), store.putLater('response'));
	});

	describe('login super user token', function () {
		loginTenantUser(loginSuperUserList, tenantKey);
		setHeader();
	});
});

