'use strict';

const {DataStore} = require('@rootcloud/darjeeling');
const {Response} = require('@rootcloud/darjeeling-http');
const {loginSuperAdminData, loginSuperUserData, loginUserData, postUserData, postUserData1, loginUserData1, postCompanyData, postAclGroupData, header, saveToken, superUserToken, userToken, commonUserToken} = require('../../test-data/data/adeployer/getToken');
const {valDict} = require('../../test-data/requireData');
const {loginUser, postCompany, getCompanyById, postUser, putUserAclGroup} = require('../../test-lib/getToken');
const {postAclGroups} = require('../../test-lib/openApi');
const {saveData} = require('../../test-data/util');

describe('/get token for acl test', function () {
	const store = new DataStore();

	before(function () {
		if (valDict.runEnv === 'local' || valDict.runEnv === 'ci' || valDict.runEnv === 'ci1') {
			this.skip();
		}
	});

	describe('login super admin', function () {
		loginUser(loginSuperAdminData, store.putLater('response'), store.putLater('token'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('get company by id and post company if not exist', function () {
		getCompanyById(postCompanyData.companyId, store.getLater('token'), store.putLater('resonse'), store.putLater('existed'));
		postCompany(postCompanyData.companyBody, store.getLater('token'), store.putLater('response'));
	});

	describe('login super user token', function () {
		loginUser(loginSuperUserData, store.putLater('response'), store.putLater('token'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		saveData(saveToken, superUserToken, store.getLater('token'), 'token');
		postAclGroups(postAclGroupData, store.putLater('response'), store.putLater('aclGroupid'),
			{
				header: header,
				userKey: superUserToken
			});
	});
	describe('post user', function () {
		postUser(postUserData.userBody, store.getLater('token'), store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('post common user', function () {
		postUser(postUserData1.userBody, store.getLater('token'), store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});

	describe('put user acl group', function () {
		putUserAclGroup(postUserData.userId, store.getLater('aclGroupid'), store.putLater('response'), {
			header: header,
			userKey: superUserToken
		});
	});

	describe('get user token', function () {
		loginUser(loginUserData, store.putLater('response'), store.putLater('token'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		saveData(saveToken, userToken, store.getLater('token'), 'token');
	});

	describe('get common user token', function () {
		loginUser(loginUserData1, store.putLater('response'), store.putLater('token'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		saveData(saveToken, commonUserToken, store.getLater('token'), 'token');
	});
});
