'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { topicDict } = require('../../test-data/requireData');
const { draftThingClassData, draftThingClassModelPropertiesData, thingClassModelInstanceData, msgData } = require('../../test-data/data/tasks-py2js/GYPT7119.js');
const { draftThingClassSchema } = require('../../test-data/schema/thingClass');
const { postDraftThingClass, deleteDraftThingClassByModelID, postDraftThingClassPropertiesByModelID, patchDraftThingClassByModelID, patchThingClassByModelID } = require('../../test-lib/openApiThingClass');
const { deleteThingInstancesByModelIdAndThingId } = require('../../test-lib/openApiThingInstances.js');
const { getHistorianByModelAndThingId1, getHistorianAggByModelAndThingId1 } = require('../../test-lib/openApiHistorian.js');
const { thingInstancePostSchema } = require('../../test-data/schema/thingInstance');
const { postThingInstancesByModelId } = require('../../test-lib/openApiThingInstances');
const { verifySchema, verifyPayload, verifyHistoryResult } = require('../../test-verify/verify');
const { postData } = require('../../test-data/util');
const { patchHistorianDate, getHistorianDevicesetByModelId, patchHistorianDevicesetDate, getHistorianAggByModelId } = require('../../test-lib/historian.js');
const { historianDevicesetSchema, getHistorianSchema } = require('../../test-data/schema/historian.js');

const store = new DataStore();

describe('GYPT-7119 : get Historical data', function () {

	describe('start', function () {
		describe('post draft device class', function () {
			postDraftThingClass(draftThingClassData.thingClassBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
			verifyPayload(store.getLater('response'), draftThingClassData.thingClassBody);
		});

		describe('post draft device property', function () {
			postDraftThingClassPropertiesByModelID(draftThingClassData.modelId, draftThingClassModelPropertiesData.thingPropertiesBody, store.putLater('response1'));
			Response.statusCodeEquals(store.getLater('response1'), 200);
			verifyPayload(store.getLater('response1'), {});
		});

		describe('patch draft device class', function () {
			patchDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response2'));
			Response.statusCodeEquals(store.getLater('response2'), 200);
			verifyPayload(store.getLater('response2'), {});
		});

		describe('post device ', function () {
			postThingInstancesByModelId(draftThingClassData.modelId, thingClassModelInstanceData.thingInstanceBody, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), thingInstancePostSchema);
			verifyPayload(store.getLater('response'), thingClassModelInstanceData.thingInstanceBody);
		});
	});

	describe('post data with mqtt', function () {
		postData(topicDict['pub_1.1'], thingClassModelInstanceData.thingId, msgData.mesBody);
	});

	describe('test query data from historian ', function () {
		getHistorianByModelAndThingId1(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response1'), store.putLater('time'), { retryCode: 404, expectNum: 1 });
		Response.statusCodeEquals(store.getLater('response1'), 200);
		verifySchema(store.getLater('response1'), getHistorianSchema);
		verifyHistoryResult(store.getLater('response1'), [[89.0]]);
	});

	describe('test patch data from historian ', function () {
		patchHistorianDate(draftThingClassData.modelId, thingClassModelInstanceData.thingId, draftThingClassModelPropertiesData.name, store.getLater('time'), store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('test query data from historian2 ', function () {
		getHistorianByModelAndThingId1(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, store.putLater('response'), store.putLater('time'), { retryCode: 404, expectNum: 1 });
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifySchema(store.getLater('response'), getHistorianSchema);
		verifyHistoryResult(store.getLater('response'), [[7.0]]);
	});

	describe('test query data with deviceset ', function () {
		const devices = `["${thingClassModelInstanceData.thingId}"]`
		getHistorianDevicesetByModelId(draftThingClassData.modelId, devices, msgData.tsQueryStr, store.putLater('response1'), store.putLater('time'), { retryCode: 404, expectNum: 1 });
		Response.statusCodeEquals(store.getLater('response1'), 200);
		verifySchema(store.getLater('response1'), historianDevicesetSchema);
		Response.bodyJsonPropertyEquals(store.getLater('response'), 'payload[0].rows[0][1]', 7);
	});

	describe('test patch data with deviceset ', function () {
		patchHistorianDevicesetDate(draftThingClassData.modelId, thingClassModelInstanceData.thingId, draftThingClassModelPropertiesData.name, store.getLater('time'), store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
		verifyPayload(store.getLater('response'), {});
	});

	describe('test query data with deviceset2 ', function () {
		const devices = `["${thingClassModelInstanceData.thingId}"]`
		getHistorianDevicesetByModelId(draftThingClassData.modelId, devices, msgData.tsQueryStr, store.putLater('response1'), store.putLater('time'), { retryCode: 404, expectNum: 1 });
		Response.statusCodeEquals(store.getLater('response1'), 200);
		verifySchema(store.getLater('response1'), historianDevicesetSchema);
		Response.bodyJsonPropertyEquals(store.getLater('response1'), 'payload[0].rows[0][1]', 8);
	});

	describe('test query data with device id and thingId aggregation', function () {
		getHistorianAggByModelAndThingId1(thingClassModelInstanceData.thingId, draftThingClassData.modelId, msgData.tsQueryStr, `["${draftThingClassModelPropertiesData.name}"]`, 'COUNT', '300s', store.putLater('response1'), { retryCode: 404, expectNum: 5, queryString1: 'limit=5' });
		Response.statusCodeEquals(store.getLater('response1'), 200);
		verifySchema(store.getLater('response1'), getHistorianSchema);
		Response.bodyJsonPropertyEquals(store.getLater('response1'), 'payload[0].rows[0][1]', 0);
	});

	describe('test query data with device id  aggregation', function () {
		const devices = `["${thingClassModelInstanceData.thingId}"]`
		getHistorianAggByModelId(draftThingClassData.modelId, msgData.tsQueryStr, devices, `["count(${draftThingClassModelPropertiesData.name})"]`, '300s', store.putLater('response1'), { retryCode: 404, expectNum: 5, queryString1: `limit=5` });
		Response.statusCodeEquals(store.getLater('response1'), 200);
		verifySchema(store.getLater('response1'), historianDevicesetSchema);
		Response.bodyJsonPropertyEquals(store.getLater('response1'), 'payload[0].rows[0][1]', 0);
	});

	describe('end', function () {
		describe('delete device ', function () {
			deleteThingInstancesByModelIdAndThingId(draftThingClassData.modelId, thingClassModelInstanceData.thingId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 200);
			verifySchema(store.getLater('response'), draftThingClassSchema);
		});

		describe('patch  device class', function () {
			patchThingClassByModelID(draftThingClassData.modelId, store.putLater('response4'));
			Response.statusCodeEquals(store.getLater('response4'), 200);
			verifyPayload(store.getLater('response4'), {});
		});

		describe('delete draft device class by model Id', function () {
			deleteDraftThingClassByModelID(draftThingClassData.modelId, store.putLater('response'));
			Response.statusCodeEquals(store.getLater('response'), 204);
		});
	});

});
