'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const { Response } = require('@rootcloud/darjeeling-http');
const { deleteTenantBody } = require('../../test-data/data/adeployer/deployer');
const { deleteDeployer } = require('../../test-lib/deployer');

describe('/delete tenant and job', function() {

	describe('delete tenant', function() {
		const store = new DataStore();
		deleteDeployer(deleteTenantBody.tenantBody, store.putLater('response'));
		Response.statusCodeEquals(store.getLater('response'), 200);
	});
});
