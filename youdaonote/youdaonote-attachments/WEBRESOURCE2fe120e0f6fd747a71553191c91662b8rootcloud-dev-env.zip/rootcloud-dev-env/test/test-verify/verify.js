'use strict';

const _ = require('lodash');
const { getData } = require('@rootcloud/darjeeling/dist/src/data-store');
const { Assert } = require('@rootcloud/darjeeling');
const { log4js } = require('./../test-lib/logger');
const logger = log4js.getLogger('util');

function verifyResponseSchema(responseGetter, schema) {

	it(`verify schema`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		try {
			await schema.validateAsync(body);
		}
		catch (exc) {
			Assert.fail(`Verify schema with error message: ${exc.message}`);
		}
	});
}

function verifySchema(responseGetter, schema) {

	it(`verify schema`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		try {
			await schema.validateAsync(body.payload);

		}
		catch (exc) {
			Assert.fail(`Verify schema with error message: ${exc.message}`);
		}
	});
}

function verifyPayload(responseGetter, postBody) {

	it(`verify payload`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		Assert.isTrue(_.isMatch(body.payload, postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload)}`);
	});
}

function verifyPayloadDeepEqual(responseGetter, postBody) {

	it(`verify payload deep equal`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		Assert.deepEqual(body, postBody, `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body)}`);
	});
}

function verifyResponse(responseGetter, expectResponseGetter) {

	it(`verify two response getter`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		const expectResponse = getData(expectResponseGetter);
		const expectBody = JSON.parse(expectResponse.body);
		Assert.deepEqual(body, expectBody, `\nExpect body: \n  ${JSON.stringify(expectBody)}\nActual body: \n  ${JSON.stringify(body)}`);
	});
}

function verifyResponseMessage(responseGetter, expectMes) {

	it(`verify response message`, async () => {
		const response = getData(responseGetter);
		const mes = JSON.parse(response.body).message;
		Assert.include(mes, expectMes, `\nExpect message: \n  ${expectMes}\nActual body: \n  ${mes}`);
	});
}

function verifyHistoryResult(responseGetter, expectResult) {

	it(`verify historian result`,  () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		logger.info(body);
		let rows = body['payload'][0]['rows'];
		logger.info('rows : '+ rows);
		logger.info('expectResult : '+ expectResult);
		for ( let i = 0; i < rows.length; i++) {
			for ( let j = 0; j < rows[i].length-1; j++) {
				logger.info('rows[i][j+1] : '+rows[i][j+1]);
				logger.info('expectResult[i][j] : '+expectResult[i][j]);
				if (rows[i][j+1] !== expectResult[i][j]) {
					Assert.fail(`\n  Expect value: ${expectResult[i][j]}\n  Actual value: ${rows[i][j+1]}`);
				}
			}
		}
	});
}

function verifyMultiSchema(responseGetter, schema) {

	it(`verifyMultiSchema`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);

		for (let i = 0; i < body.payload.length; i++) {
			try {
				await schema.validateAsync(body.payload[i]);
			}
			catch (exc) {
				Assert.fail(`Verify multi schema with error message: ${exc.message}`);
			}
		}
	});
}

function verifyMultiPayload(responseGetter, postBody) {

	it(`verifyMultiPayload`, async () => {
		const response = getData(responseGetter);
		const body = JSON.parse(response.body);
		const num = body.payload.length;
		if (num == 0) {
			Assert.isTrue(_.isMatch(body.payload, postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload)}`);
		}
		Assert.isTrue(_.isMatch(body.payload[num - 1], postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload[num - 1])}`);
	});
}

module.exports = {
	verifySchema,
	verifyPayload,
	verifyPayloadDeepEqual,
	verifyResponse,
	verifyHistoryResult,
	verifyMultiSchema,
	verifyMultiPayload,
	verifyResponseSchema,
	verifyResponseMessage
};
