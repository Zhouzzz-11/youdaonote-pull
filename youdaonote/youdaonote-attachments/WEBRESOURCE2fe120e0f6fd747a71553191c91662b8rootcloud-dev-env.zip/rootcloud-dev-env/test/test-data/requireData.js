'use strict';

const { DataStore } = require('@rootcloud/darjeeling');
const store = new DataStore();

const Moment = require('moment');
const { bp } = require('./blueprint');
const { loggerCommon } = require('./../test-lib/logger');
const hubDict = bp.hubDict;
const openApiDict = bp.openApiDict;
const identityDict = bp.identityDict;
const iotDict = bp.iotWorksDict;
const mqttHost = bp.mqttHost;
const superAdmin = bp.superUser;
const runEnv = bp.runEnv;
const myDate = Moment.utc().format('YYYYMMDD');
const randNum = parseInt(Math.random() * 100000000);
loggerCommon.log(`random num is: ${randNum}`);

const desStr = 'description string';
const persistStrategyAlways = 'always';
const expressionTypeGroovy = 'groovy';
const privilegeReadWrite = 'ReadWrite';
const privilegeReadOnly = 'ReadOnly';
const persistStrategyOnChange = 'onChange';
const protocolV4 = 'ROOTCLOUD_V4';
const manufacturer = '树根互联';
const manufacturerId = '树根互联';
const password = '123abcABC';
const tenantId = bp.tenantId;
const tenantS1Id = bp.tenantS1Id;
const tenantS2Id = bp.tenantS2Id;
const tenantS3Id = bp.tenantS3Id;
const tenantList = [tenantId, tenantS1Id, tenantS2Id, tenantS3Id];
const tenantKey = ['tenantId', 'tenantS1Id', 'tenantS2Id', 'tenantS3Id'];

const header = ['local', 'ci', 'ci1'].includes(runEnv) ? { 'X-RCD-Tenant-Id': bp.tenantId, 'Authorization': bp.userToken } : { 'Authorization': '' };

function setHeader(_tenantId='tenantId') {

	it('get bearer token ', () => {
		header.Authorization = headerDict[_tenantId].Authorization;
		return header;
	});
}

let headerDict = {
	tenantId: { 'Authorization': '' },
	tenantS1Id: { 'Authorization': '' },
	tenantS2Id: { 'Authorization': '' },
	tenantS3Id: { 'Authorization': '' }
}

const errMesDict = {
	'not_exist': '不存在',
	'not_valid_json': '不合法的JSON',
	'not_valid_range': '大于等于零，并且小于等于',
	'big_or_eq': '大于或等于',
	'only_support_number': '属性类型只支持Number类型',
};

const topicDict = {
	'ntp_sub': 'v4/s/get/cloud/time/json/1.0',
	'cmd_sub': 'v4/s/post/device/cmd/json/1.0',
	'cmd_pub': 'v4/p/resp/post/device/cmd/json/1.0',
	'cmd_gateway_sub': 'v4/s/post/gateway/cmd/json/1.0',
	'cmd_gateway_pub': 'v4/p/resp/post/gateway/cmd/json/1.0',
	'config_req_sub': 'v4/s/set/device/config/json/1.0',
	'config_req_pub': 'v4/p/resp/set/device/config/json/1.0',
	'config_update_sub': 'v4/s/get/device/config/json/1.0',
	'config_update_pub': 'v4/p/resp/get/device/config/json/1.0',
	'config_gateway_sub': 'v4/s/get/gateway/config/json/1.0',
	'config_gateway_pub': 'v4/p/resp/get/gateway/config/json/1.0',
	'config_set_gateway_sub': 'v4/s/set/gateway/config/json/1.0',
	'config_set_gateway_pub': 'v4/p/resp/set/gateway/config/json/1.0',
	'config_update_gateway_sub': 'v4/s/get/gateway/config/json/1.0',
	'config_update_gateway_pub': 'v4/p/resp/get/gateway/config/json/1.0',
	'live_sub': 'v4/s/set/thing/live/json/1.0',
	'live_pub': 'v4/p/resp/set/thing/live/json/1.0',
	'pub_1.0': 'v4/p/post/thing/live/json/1.0',
	'pub_1.1': 'v4/p/post/thing/live/json/1.1',
	'sub_1.0': 'v4/s/get/cloud/time/json/1.0',
	'pub_cloud_1.0': 'v4/p/get/cloud/time/json/1.0',
	'sub_1.1': 'v4/s/get/cloud/time/json/1.1',
	'history_1.0': 'v4/p/post/thing/history/json/1.0',
	'history_1.1': 'v4/p/post/thing/history/json/1.1',
	'jsongz_live_1.1': 'v4/p/post/thing/live/jsongz/1.1',
	'jsongz_history_1.1': 'v4/p/post/thing/history/jsongz/1.1',
	'location_1.0': 'v4/p/post/device/location/json/1.0',
	'ota_sub': 'v4/s/post/device/ota/cmd/json/1.0',
	'ota_pub': 'v4/p/resp/post/device/ota/cmd/json/1.0',
	'files_get_sub': 'v4/s/get/device/files/json/1.0',
	'files_get_pub': 'v4/p/resp/get/device/files/json/1.0',
	'files_get_gateway_sub': 'v4/s/get/gateway/files/json/1.0',
	'files_get_gateway_pub': 'v4/p/resp/get/gateway/files/json/1.0',
	'ota_*_sub': 'v4/s/post/+/ota/cmd/+/+',
	'files_sub': 'v4/s/post/device/files/json/1.0',
	'files_pub': 'v4/p/resp/post/device/files/json/1.0',
};

const valDict = {
	desStr: desStr,
	expressionTypeGroovy: expressionTypeGroovy,
	manufacturer: manufacturer,
	manufacturerId: manufacturerId,
	mqttHost: mqttHost,
	password: password,
	privilegeReadWrite: privilegeReadWrite,
	privilegeReadOnly: privilegeReadOnly,
	onChange: persistStrategyOnChange,
	protocolV4: protocolV4,
	randStr: `${myDate}_${randNum}`,
	runEnv: runEnv,
	strategyAlways: persistStrategyAlways,
	superAdmin: superAdmin,
	tenantId: bp.tenantId,
};

const iotworksMysqlDict = {
	username: 'common_user',
	password: 'bkmC15FgLNlST7nILlPxW7/piwa0DbFG+U6Wel6dk8TQNA/X2WNugqaJnqlYdKDW4KB8vAVvtzsqGK0GPEG3U32y39SWyIi9KQpUmh+7OlvOvnHSSzXnQB02qMCXd4KqEt/nobtdvnJaYaqZ8GEINIJ0TSftciMlWHcsAJrH53A=',
	host: '10.70.40.144',
	port: '3307',
	database: 'auto_test_db'
}

const iotworksMongoDict = {
	username: 'Testuser',
	password: 'Testuser4',
	host: '10.70.40.42',
	port: '27017',
	database: 'otminer'
}

module.exports = {
	hubDict,
	openApiDict,
	header,
	headerDict,
	valDict,
	topicDict,
	identityDict,
	iotDict,
	setHeader,
	store,
	errMesDict,
	iotworksMysqlDict,
	iotworksMongoDict,
	tenantList,
	tenantKey
};
