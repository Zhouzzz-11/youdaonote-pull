'use strict';

const { dataBody } = require('../../comData');

//添加
const prefix = 'GYPT7119';         //设备1
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
//添加设备
const prefix_13 = 'GYPT7119_1';
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_13);
//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'hum + 1', 'hum', 'Number');
//mqtt
const msgData = dataBody.mesBody({ 'hum': 88 });
const msgData1 = dataBody.mesBody({ 'hum': 11 });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	msgData,
	msgData1
};
