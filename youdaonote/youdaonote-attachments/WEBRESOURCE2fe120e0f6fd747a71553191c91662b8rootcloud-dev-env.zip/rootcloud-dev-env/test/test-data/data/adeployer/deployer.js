'use strict';

const { bp } = require('../../blueprint');
const { log4js } = require('../../../test-lib/logger');
const { dataBody } = require('../../comData');
const projectCode = 'project-code';
const jobModel = 'recoup';
const logger = log4js.getLogger('deployer');


function getLocalBody(_tenant_id, options = {}) {
	const deployerBody = {
		'tenantId': options.tenantId || _tenant_id ,
		'projectCode': options.projectCode || projectCode,
		'influxUrl': 'influxproxy:8086',
		'mongoUrl': 'mongodb:27017,mongodb:27018,mongodb:27019',
		'redisUrl': 'redis:6379',
		'redisMode': 'single',
		'flinkJobManagerUrl': 'jobmanager:8081',
		'emqUrl': 'emq:1883',
		'kafkaBroadcastAddress': 'kafka:9092',
		'hbaseUrl': 'hbase-phoenix:8765',
		'jobMode': options.jobModel || jobModel,
		'groovyTimeout': 10
	};
	return deployerBody;
}


function getQABody(_tenant_id, options = {}) {
	const deployerBody = {
		'tenantId': options.tenantId || _tenant_id ,
		'projectCode': options.projectCode || projectCode,
		'influxUrl': 'influxproxy.iot-qa.rootcloudapp.com:80',
		'mongoUrl': 'Testuser:Testuser4@10.70.40.10:27017,10.70.40.42:27017,10.70.40.12:27017',
		'redisKey': 'pP~W,[eC-/qj7n8',
		'redisUrl': '10.70.40.116:6379',
		'redisMode': 'cluster',
		'flinkJobManagerUrl': '10.70.40.24:8081',
		'emqUrl': '10.70.40.124:1883,10.70.40.81:1883',
		'kafkaBroadcastAddress': '10.70.40.140:9092',
		'jobMode': options.jobModel || jobModel,
		'groovyTimeout': 10
	};
	return deployerBody;
}


function getDevBody(_tenant_id, options = {}) {
	const deployerBody = {
		'tenantId': options.tenantId || _tenant_id ,
		'projectCode': options.projectCode || projectCode,
		'influxUrl': 'influxproxy.iot-dev.rootcloudapp.com:80',
		'mongoUrl': 'Devuser:DevuserV4@10.70.42.4:27017',
		'redisKey': 'pP~W,[eC-/qj7n8',
		'redisUrl': '10.70.40.84:6379',
		'redisMode': 'cluster',
		'flinkJobManagerUrl': '10.70.25.125:8081',
		'emqUrl': '10.70.22.72:1883,10.70.22.152:1883',
		'hiveUrl': '10.70.31.91:10000',
		'hdfsUrl': '10.70.31.91:8020',
		'kafkaBroadcastAddress': '10.70.25.125:9092,10.70.25.70:9092,10.70.25.116:9092',
		'jobMode': options.jobModel || jobModel,
		'groovyTimeout': 10
	};
	return deployerBody;
}

function getPreBody(_tenant_id, options = {}) {
	const deployerBody = {
		'tenantId': options.tenantId || _tenant_id ,
		'projectCode': options.projectCode || projectCode,
		'influxUrl': 'influxproxy.iot-pre.rootcloudapp.com:80',
		'mongoUrl': 'irootech_hub:ilgcYr9fW##DB1U@10.70.43.24:27017,10.70.43.27:27017,10.70.43.31:27017',
		'redisKey': 'appq*Cm5glP^',
		'redisUrl': '10.70.43.75:6379',
		'redisMode': 'cluster',
		'flinkJobManagerUrl': '10.70.43.19:8081',
		'emqUrl': '10.70.43.30:1883,10.70.43.32:1883',
		'hiveUrl': '10.70.43.19:10000',
		'hdfsUrl': '10.70.43.19:8020',
		'kafkaBroadcastAddress': '10.70.43.47:9092',
		'jobMode': options.jobModel || jobModel,
		'parallelism': 1,
		'enableSandBox': true,
		'groovyTimeout': 10
	};
	return deployerBody;
}

let deployerBody = {};
switch(bp.runEnv){
	case 'local':
	case 'ci':
	case 'ci1':
		deployerBody = getLocalBody(bp.tenantId);
		break;
	case 'qa':
		deployerBody = getQABody(bp.tenantId);
		break;
	case 'dev':
		deployerBody = getDevBody(bp.tenantId);
		break;
	case 'pre':
		deployerBody = getPreBody(bp.tenantId);
		break;
	default:
		logger.info(`bp.runEnv env is not support to deployer now`);
}

function getDeployerBody(options = {}){
	let deployerBody = {};
	switch(bp.runEnv){
		case 'local':
		case 'ci':
			deployerBody = getLocalBody(bp.tenantId, options);
			break;
		case 'qa':
			deployerBody = getQABody(bp.tenantId, options);
			break;
		case 'dev':
			deployerBody = getDevBody(bp.tenantId, options);
			break;
		case 'pre':
			deployerBody = getPreBody(bp.tenantId, options);
			break;
		default:
			logger.info(`bp.runEnv env is not support to deployer now`);
	}
	return deployerBody;
}

const deleteTenantBody = dataBody.deleteTenantBody(bp.tenantId);

module.exports = {
	deployerBody,
	getDeployerBody,
	deleteTenantBody,
};
