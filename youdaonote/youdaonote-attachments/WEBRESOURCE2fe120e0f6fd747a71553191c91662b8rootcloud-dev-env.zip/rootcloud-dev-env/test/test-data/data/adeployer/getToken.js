'use strict';

const {dataBody} = require('../../comData');
const {valDict} = require('../../requireData');

const prefix = 'gt';
const companyId = 't_c2';
const header = {'Authorization': ''};
const superUserName = `${companyId}_super_username`;
const superUserToken = 'superUserToken';
const userToken = 'userToken';
const commonUserToken = 'commonUserToken';
let saveToken = {superUserToken: '', userToken: '', commonUserToken: ''};

const loginSuperAdminData = dataBody.loginBody(valDict.superAdmin.username, valDict.superAdmin.password);
const postCompanyData = dataBody.companyBody(prefix, companyId, {username: superUserName});
const loginSuperUserData = dataBody.loginBody(superUserName, postCompanyData.password);
const postUserData = dataBody.userBody(prefix);
const loginUserData = dataBody.loginBody(postUserData.username, postUserData.password);
const postAclGroupData = dataBody.devicePermissionBody('');

const prefix_1 = 'g1';
const postUserData1 = dataBody.userBody(prefix_1);
const loginUserData1 = dataBody.loginBody(postUserData1.username, postUserData1.password);
module.exports = {
	loginSuperAdminData,
	loginSuperUserData,
	loginUserData,
	postUserData,
	postCompanyData,
	postAclGroupData,
	header,
	saveToken,
	superUserToken,
	userToken,
	commonUserToken,
	postUserData1,
	loginUserData1
};

