'use strict';

const {dataBody} = require('../../comData');
const {valDict, tenantList} = require('../../requireData');

const prefix = 'gt';

const loginSuperAdminData = dataBody.loginBody(valDict.superAdmin.username, valDict.superAdmin.password);

let postCompanyList = []
let postServiceList = []
let loginSuperUserList = []

tenantList.forEach(id => {
	postCompanyList.push(dataBody.companyBody(prefix, id, {username: `${id}_super_username`}))
	postServiceList.push(dataBody.serviceLicenseBody(id));
	loginSuperUserList.push(dataBody.loginBody(`${id}_super_username`, valDict.password))
});

module.exports = {
	postCompanyList,
	postServiceList,
	loginSuperUserList,
	loginSuperAdminData,
};

