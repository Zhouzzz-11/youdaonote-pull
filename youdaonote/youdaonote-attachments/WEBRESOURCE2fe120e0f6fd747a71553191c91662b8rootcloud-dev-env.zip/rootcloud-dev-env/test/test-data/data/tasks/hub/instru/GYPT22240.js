'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT22240';
const prefix_1 = 'GYPT22240_1';
const prefix_11 = 'GYPT22240_11';
const prefix_12 = 'GYPT22240_12';
const prefix_13 = 'GYPT22240_13';
const prefix_14 = 'GYPT22240_14';
const prefix_15 = 'GYPT22240_15';
const prefix_16 = 'GYPT22240_16';
const prefix_2 = 'GYPT22240_2';
const prefix_3 = 'GYPT22240_3';
const prefix_4 = 'GYPT22240_4';
const prefix_5 = 'GYPT22240_5';
const timestamp = Date.parse(new Date());

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//直连设备
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_11);
const thingInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_12);
const thingInstanceData3 = dataBody.thingClassModelInstanceBody(prefix_13);
//添加网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');
//网关设备
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
const thingClassModelInstanceData2_1 = dataBody.thingClassModelInstanceBody(prefix_4);
const thingClassModelInstanceData3 = dataBody.thingClassModelInstanceBody(prefix_15);
const thingClassModelInstanceData4 = dataBody.thingClassModelInstanceBody(prefix_5);
//非直连物模型
const draftThingClassData1 = dataBody.draftThingClassBody(prefix_3, 'device', { directlyLinked: false });
//非直连设备
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_3, { gatewayId: thingClassModelInstanceData2.thingId });
const thingClassModelInstanceData1_1 = dataBody.thingClassModelInstanceBody(prefix_11, {connectId: 'connectId11', gatewayId: thingClassModelInstanceData2_1.thingId });

let files = {'file': {'key': 'sdfs','zip': null}};

//直连设备指令下发
const instructionRequestsData_1 = dataBody.thingInstructionRequestsBody(prefix_11, files, undefined, undefined, thingInstanceData1.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 120000 });
const instructionRequestsData_2 = dataBody.thingInstructionRequestsBody(prefix_12, files, undefined, undefined, thingInstanceData2.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_4 = dataBody.thingInstructionRequestsBody(prefix_13, files, undefined, undefined, thingInstanceData1.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_5 = dataBody.thingInstructionRequestsBody(prefix_16, files, undefined, undefined, thingInstanceData3.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });

//网关设备指令下发
const instructionRequestsData2 = dataBody.thingInstructionRequestsBody(prefix_2, files, undefined, undefined, thingClassModelInstanceData3.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData2_1 = dataBody.thingInstructionRequestsBody(prefix_5, files, undefined, undefined, thingClassModelInstanceData4.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });

//非直连设备指令下发
const instructionRequestsData1 = dataBody.thingInstructionRequestsBody(prefix_1, files, undefined, undefined, thingClassModelInstanceData1.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData3 = dataBody.thingInstructionRequestsBody(prefix_14, files, undefined, undefined, thingClassModelInstanceData1_1.thingId, { type: 'FILE_GET', trigger: 'realTime', timeout: 60000 });

//直连设备响应
const responseData = dataBody.filesInstructionBody(instructionRequestsData_1.requestId, timestamp);
const responseData1 = dataBody.filesInstructionBody(instructionRequestsData_2.requestId, timestamp, { isAck: false });
const responseData6 = dataBody.filesInstructionBody(instructionRequestsData_5.requestId, timestamp, { isAck: false, isCompleted: false });
const responseData7 = dataBody.filesInstructionBody(instructionRequestsData_5.requestId, timestamp, { isAck: false });
//非直连设备响应
const responseData2 = dataBody.filesInstructionBody(instructionRequestsData1.requestId, timestamp);
const responseData3 = dataBody.filesInstructionBody(instructionRequestsData3.requestId, timestamp, { isAck: false, thingType: 'Device', id: thingClassModelInstanceData1_1.connectId });
//网关响应
const responseData4 = dataBody.filesInstructionBody(instructionRequestsData2.requestId, timestamp);
const responseData5 = dataBody.filesInstructionBody(instructionRequestsData2_1.requestId, timestamp, { isAck: false, thingType: 'Gateway', id: '' });

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	thingClassModelInstanceData2_1,
	thingInstanceData,
	draftThingClassData1,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2,
	thingClassModelInstanceData1_1,
	instructionRequestsData_5,
	instructionRequestsData2_1,
	thingClassModelInstanceData4,
	thingClassModelInstanceData3,
	thingInstanceData3,
	instructionRequestsData3,
	responseData1,
	responseData2,
	responseData3,
	responseData4,
	responseData5,
	responseData6,
	responseData7,
	responseData,
	thingInstanceData2,
	instructionRequestsData1,
	instructionRequestsData_2,
	instructionRequestsData_4,
	instructionRequestsData2,
	thingInstanceData1,
	instructionRequestsData_1,
};
