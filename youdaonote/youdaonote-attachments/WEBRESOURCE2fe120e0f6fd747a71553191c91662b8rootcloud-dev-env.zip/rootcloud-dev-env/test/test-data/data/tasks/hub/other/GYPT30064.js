'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT30064';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number');
const draftThingClassPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', 'temp + 1', 'temp_1', 'Number');
const draftThingClassPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_2`, 'Number', 'temp + 1', 'temp_2', 'Number');

module.exports = {
    draftThingClassData,
    draftThingClassPropertiesData_1,
    draftThingClassPropertiesData_2,
    draftThingClassPropertiesData_3,
};