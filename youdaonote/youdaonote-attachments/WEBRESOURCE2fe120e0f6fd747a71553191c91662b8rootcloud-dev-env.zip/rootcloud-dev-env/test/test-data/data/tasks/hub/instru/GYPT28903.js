'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT28903';
const number = Math.round(Math.random() * (400));

// 指令下发根据ExpressionType判断是否可下发_直连设备_groovy_下发失败
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp' });
const createInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`, { name1: 'temp' });
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const createInstructionsRequestData = dataBody.thingInstructionRequestsBody(prefix, { 'temp': `${number}` }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_直连设备_window_下发失败
const draftThingClassData_1 = dataBody.draftThingClassBody(`${prefix}_1`, 'device');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', 'a1', 'a1', 'Number', {
    expressionType: 'window',
    operator: 'sum',
    windowSizeMills: 2000,
    windowStepMills: 1000,
    windowAllowedLatenessMills: 0,
    name: 'a2'
});
const createInstructionsData_1 = dataBody.createInstructionsBody(`${prefix}_1`, `${number}`, { name1: 'a2' });
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}_1`);
const createInstructionsRequestData_1 = dataBody.thingInstructionRequestsBody(`${prefix}_1`, { 'a2': `${number}` }, createInstructionsData_1.instructionTemplateId, draftThingClassData_1.modelId, thingInstanceData_1.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_直连设备_Direct_下发成功
const draftThingClassData_3 = dataBody.draftThingClassBody(`${prefix}_2`, 'device');
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_2`, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp', expressionType: 'direct' });
const createInstructionsData_3 = dataBody.createInstructionsBody(`${prefix}_2`, `${number}`, { name1: 'temp' });
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(`${prefix}_2`);
const createInstructionsRequestData_3 = dataBody.thingInstructionRequestsBody(`${prefix}_2`, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_直连设备_linear_下发成功
const draftThingClassData_2 = dataBody.draftThingClassBody(`${prefix}_3`, 'device');
const temp_option = { name: 'temp', expressionType: 'linear', scale: 1, base: 2 };
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}`, 'Number', `1*${prefix}+2`, 'temp', 'Number', temp_option);
const createInstructionsData_2 = dataBody.createInstructionsBody(`${prefix}_3`, `${number}`, { name1: 'temp' });
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(`${prefix}_3`);
const createInstructionsRequestData_2 = dataBody.thingInstructionRequestsBody(`${prefix}_3`, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_直连设备_constant_下发失败
const draftThingClassData_4 = dataBody.draftThingClassBody(`${prefix}_4`, 'device');
const draftThingClassModelPropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_4`, 'Number', '11', 'Ia', 'Number', { name: 'temp', expressionType: 'constant' });
const createInstructionsData_4 = dataBody.createInstructionsBody(`${prefix}_4`, `${number}`, { name1: 'temp' });
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(`${prefix}_4`);
const createInstructionsRequestData_4 = dataBody.thingInstructionRequestsBody(`${prefix}_4`, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_非直连设备_groovy_下发失败
const draftThingClassData_5 = dataBody.draftThingClassBody(`${prefix}_5`, 'gateway');
const draftThingClassModelPropertiesData_5 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_5`, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp' });
const thingInstanceData_5 = dataBody.thingClassModelInstanceBody(`${prefix}_5`);
const draftThingClassData_6 = dataBody.draftThingClassBody(`${prefix}_6`, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_6`, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp2', expressionType: 'groovy' });
const createInstructionsData_6 = dataBody.createInstructionsBody(`${prefix}_6`, `${number}`, { name1: 'temp2' });
const thingInstanceData_6 = dataBody.thingClassModelInstanceBody(`${prefix}_6`, { gatewayId: thingInstanceData_5.thingId });
const createInstructionsRequestData_6 = dataBody.thingInstructionRequestsBody(`${prefix}_6`, { 'temp': `${number}` }, createInstructionsData_6.instructionTemplateId, draftThingClassData_6.modelId, thingInstanceData_6.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_非直连设备_window_下发失败
const draftThingClassData_7 = dataBody.draftThingClassBody(`${prefix}_7`, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_7`, 'Number', 'a1', 'a1', 'Number', {
    expressionType: 'window',
    operator: 'sum',
    windowSizeMills: 2000,
    windowStepMills: 1000,
    windowAllowedLatenessMills: 0,
    name: 'a2'
});
const createInstructionsData_7 = dataBody.createInstructionsBody(`${prefix}_7`, `${number}`, { name1: 'a2' });
const thingInstanceData_7 = dataBody.thingClassModelInstanceBody(`${prefix}_7`, { gatewayId: thingInstanceData_5.thingId });
const createInstructionsRequestData_7 = dataBody.thingInstructionRequestsBody(`${prefix}_7`, { 'temp': `${number}` }, createInstructionsData_7.instructionTemplateId, draftThingClassData_7.modelId, thingInstanceData_7.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_非直连设备_Direct_下发成功
const draftThingClassData_8 = dataBody.draftThingClassBody(`${prefix}_8`, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_8 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_8`, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp', expressionType: 'direct' });
const createInstructionsData_8 = dataBody.createInstructionsBody(`${prefix}_8`, `${number}`, { name1: 'temp' });
const thingInstanceData_8 = dataBody.thingClassModelInstanceBody(`${prefix}_8`, { gatewayId: thingInstanceData_5.thingId });
const createInstructionsRequestData_8 = dataBody.thingInstructionRequestsBody(`${prefix}_8`, { 'temp': `${number}` }, createInstructionsData_8.instructionTemplateId, draftThingClassData_8.modelId, thingInstanceData_8.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_非直连设备_linear_下发成功
const draftThingClassData_9 = dataBody.draftThingClassBody(`${prefix}_9`, 'device', { directlyLinked: false });
const temp_option_1 = { name: 'temp', expressionType: 'linear', scale: 1, base: 2 };
const draftThingClassModelPropertiesData_9 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_9`, 'Number', `1*${prefix}+2`, 'temp', 'Number', temp_option_1);
const createInstructionsData_9 = dataBody.createInstructionsBody(`${prefix}_9`, `${number}`, { name1: 'temp' });
const thingInstanceData_9 = dataBody.thingClassModelInstanceBody(`${prefix}_9`, { gatewayId: thingInstanceData_5.thingId });
const createInstructionsRequestData_9 = dataBody.thingInstructionRequestsBody(`${prefix}_9`, { 'temp': `${number}` }, createInstructionsData_9.instructionTemplateId, draftThingClassData_9.modelId, thingInstanceData_9.thingId, { timeout: 60000 });

//指令下发根据ExpressionType判断是否可下发_非直连设备_constant_下发失败
const draftThingClassData_10 = dataBody.draftThingClassBody(`${prefix}_10`, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_10 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_10`, 'Number', '11', 'Ia', 'Number', { name: 'temp', expressionType: 'constant' });
const createInstructionsData_10 = dataBody.createInstructionsBody(`${prefix}_10`, `${number}`, { name1: 'temp' });
const thingInstanceData_10 = dataBody.thingClassModelInstanceBody(`${prefix}_10`, { gatewayId: thingInstanceData_5.thingId });
const createInstructionsRequestData_10 = dataBody.thingInstructionRequestsBody(`${prefix}_10`, { 'temp': `${number}` }, createInstructionsData_10.instructionTemplateId, draftThingClassData_10.modelId, thingInstanceData_10.thingId, { timeout: 60000 });

module.exports = {
    draftThingClassData,
    draftThingClassModelPropertiesData,
    createInstructionsData,
    thingInstanceData,
    createInstructionsRequestData,
    draftThingClassData_1,
    draftThingClassModelPropertiesData_1,
    createInstructionsData_1,
    thingInstanceData_1,
    createInstructionsRequestData_1,
    draftThingClassData_2,
    draftThingClassModelPropertiesData_2,
    createInstructionsData_2,
    thingInstanceData_2,
    createInstructionsRequestData_2,
    draftThingClassData_3,
    draftThingClassModelPropertiesData_3,
    createInstructionsData_3,
    thingInstanceData_3,
    createInstructionsRequestData_3,
    draftThingClassData_4,
    draftThingClassModelPropertiesData_4,
    createInstructionsData_4,
    thingInstanceData_4,
    createInstructionsRequestData_4,
    draftThingClassData_5,
    draftThingClassModelPropertiesData_5,
    thingInstanceData_5,
    draftThingClassData_6,
    draftThingClassModelPropertiesData_6,
    createInstructionsData_6,
    thingInstanceData_6,
    createInstructionsRequestData_6,
    draftThingClassData_7,
    draftThingClassModelPropertiesData_7,
    createInstructionsData_7,
    thingInstanceData_7,
    createInstructionsRequestData_7,
    draftThingClassData_8,
    draftThingClassModelPropertiesData_8,
    createInstructionsData_8,
    thingInstanceData_8,
    createInstructionsRequestData_8,
    draftThingClassData_9,
    draftThingClassModelPropertiesData_9,
    createInstructionsData_9,
    thingInstanceData_9,
    createInstructionsRequestData_9,
    draftThingClassData_10,
    draftThingClassModelPropertiesData_10,
    createInstructionsData_10,
    thingInstanceData_10,
    createInstructionsRequestData_10
};