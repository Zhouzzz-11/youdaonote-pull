'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

//创建device单条合法的StaticProperties
const prefix = 'GYPT13448';
//创建多条StaticProperties
const prefix_1 = 'GYPT13448_1';
const prefix_2 = 'GYPT13448_2';

//创建device多条合法的StaticProperties
const prefix_3 = 'GYPT13448_3';

//创建device多条合法的StaticProperties 无propertyValueJson
const prefix_4 = 'GYPT13448_4';

//创建device 无staticProperties
const prefix_5 = 'GYPT13448_5';

//创建device 无propertyName
const prefix_6 = 'GYPT13448_6';

//创建device 非法输入propertyValueJson
const prefix_7 = 'GYPT13448_7';

//创建device 非法输入propertyValueJson字符串
const prefix_8 = 'GYPT13448_8';

//创建device propertyValueJson缺失
const prefix_9 = 'GYPT13448_9';

//批量创建device 含staticProperties
const prefix_10 = 'GYPT13448_10';
const prefix_11 = 'GYPT13448_11';
const prefix_12 = 'GYPT13448_12';

//批量创建device 无staticProperties
const prefix_13 = 'GYPT13448_13';
const prefix_14 = 'GYPT13448_14';
const prefix_15 = 'GYPT13448_15';

//批量创建device propertyName缺失
const prefix_16 = 'GYPT13448_16';
const prefix_17 = 'GYPT13448_17';
const prefix_18 = 'GYPT13448_18';

//批量创建device propertyValueJson缺失
const prefix_19 = 'GYPT13448_19';
const prefix_20 = 'GYPT13448_20';
const prefix_21 = 'GYPT13448_21';

const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * (10 - 5) + 5).toFixed(2));
const random1 = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * (100 - 50) + 50).toFixed(2));
const random2 = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * (1000 - 500) + 500).toFixed(2));

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', '11', 'Ia', 'Number', { expressionType: 'constant' });
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', '22', 'Ia1', 'Number', { expressionType: 'constant' });
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', '33', 'Ia2', 'Number', { expressionType: 'constant' });

const thingClassModelStaticPropertiesData = dataBody.thingClassModelInstanceBody(prefix, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1 });
const updateClassModelStaticPropertiesData = dataBody.thingClassModelInstanceBody(prefix, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1, name: 'device' + random2 });

const thingClassModelManyStaticPropertiesData = dataBody.thingClassModelManyStaticPropertiesBody(prefix_3, draftThingClassModelPropertiesData.name, random, draftThingClassModelPropertiesData_1.name, random1, draftThingClassModelPropertiesData_2.name, random2);
const updateClassModelManyStaticPropertiesData = dataBody.thingClassModelManyStaticPropertiesBody(prefix_3, draftThingClassModelPropertiesData.name, random, draftThingClassModelPropertiesData_1.name, random1, draftThingClassModelPropertiesData_2.name, random2, { name: 'tjingname' + random2 });

const thingClassModelStaticPropertiesData_1 = dataBody.thingClassModelInstanceBody(prefix_4, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: '{}' });
const updateClassModelStaticPropertiesData_1 = dataBody.thingClassModelInstanceBody(prefix_4, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: '{}', name: 'instance' + random2 });

const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_5);
const updateClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_5, { name: 'thingclass' + random2 });

const thingClassModelStaticPropertiesData_2 = dataBody.thingClassModelInstanceBody(prefix_6, { propertyValueJson: random1 });
const updateClassModelStaticPropertiesData_2 = dataBody.thingClassModelInstanceBody(prefix_6, { propertyValueJson: random1, name: 'update1' + random2 });

const thingClassModelStaticPropertiesData_3 = dataBody.thingClassModelInstanceBody(prefix_7, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1 });
const updateClassModelStaticPropertiesData_3 = dataBody.thingClassModelInstanceBody(prefix_7, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1, name: 'update2' + random2 });

const thingClassModelStaticPropertiesData_4 = dataBody.thingClassModelInstanceBody(prefix_8, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: 'sdfsfjwkejrklwer' });
const updateClassModelStaticPropertiesData_4 = dataBody.thingClassModelInstanceBody(prefix_8, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: 'sdfsfjwkejrklwer', name: 'update3' + random2 });

const thingClassModelStaticPropertiesData_5 = dataBody.thingClassModelInstanceBody(prefix_9, { propertyName: draftThingClassModelPropertiesData.name });
const updateClassModelStaticPropertiesData_5 = dataBody.thingClassModelInstanceBody(prefix_9, { propertyName: draftThingClassModelPropertiesData.name, name: 'update4' + random2 });

const thingClassBulkInstanceBodyData_6 = dataBody.thingClassBulkInstanceBody(prefix_10, draftThingClassData.modelId, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1 });
const thingClassBulkInstanceBodyData_7 = dataBody.thingClassBulkInstanceBody(prefix_11, draftThingClassData.modelId, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1 });
const thingClassBulkInstanceBodyData_8 = dataBody.thingClassBulkInstanceBody(prefix_12, draftThingClassData.modelId, { propertyName: draftThingClassModelPropertiesData.name, propertyValueJson: random1 });

const thingClassBulkInstanceBodyData_9 = dataBody.thingClassBulkInstanceBody(prefix_13, draftThingClassData.modelId);
const thingClassBulkInstanceBodyData_10 = dataBody.thingClassBulkInstanceBody(prefix_14, draftThingClassData.modelId);
const thingClassBulkInstanceBodyData_11 = dataBody.thingClassBulkInstanceBody(prefix_15, draftThingClassData.modelId);

const thingClassBulkInstanceBodyData_12 = dataBody.thingClassBulkInstanceBody(prefix_16, draftThingClassData.modelId, { propertyValueJson: random1 });
const thingClassBulkInstanceBodyData_13 = dataBody.thingClassBulkInstanceBody(prefix_17, draftThingClassData.modelId, { propertyValueJson: random1 });
const thingClassBulkInstanceBodyData_14 = dataBody.thingClassBulkInstanceBody(prefix_18, draftThingClassData.modelId, { propertyValueJson: random1 });

const thingClassBulkInstanceBodyData_15 = dataBody.thingClassBulkInstanceBody(prefix_19, draftThingClassData.modelId, { propertyName: draftThingClassModelPropertiesData.name });
const thingClassBulkInstanceBodyData_16 = dataBody.thingClassBulkInstanceBody(prefix_20, draftThingClassData.modelId, { propertyName: draftThingClassModelPropertiesData.name });
const thingClassBulkInstanceBodyData_17 = dataBody.thingClassBulkInstanceBody(prefix_21, draftThingClassData.modelId, { propertyName: draftThingClassModelPropertiesData.name });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	draftThingClassModelPropertiesData_1,
	draftThingClassModelPropertiesData_2,
	thingClassModelStaticPropertiesData,
	updateClassModelStaticPropertiesData,
	thingClassModelStaticPropertiesData_1,
	updateClassModelStaticPropertiesData_1,
	thingClassModelManyStaticPropertiesData,
	updateClassModelManyStaticPropertiesData,
	thingClassModelInstanceData,
	updateClassModelInstanceData,
	thingClassModelStaticPropertiesData_2,
	updateClassModelStaticPropertiesData_2,
	thingClassModelStaticPropertiesData_3,
	updateClassModelStaticPropertiesData_3,
	thingClassModelStaticPropertiesData_4,
	updateClassModelStaticPropertiesData_4,
	thingClassModelStaticPropertiesData_5,
	updateClassModelStaticPropertiesData_5,
	thingClassBulkInstanceBodyData_6,
	thingClassBulkInstanceBodyData_7,
	thingClassBulkInstanceBodyData_8,
	thingClassBulkInstanceBodyData_9,
	thingClassBulkInstanceBodyData_10,
	thingClassBulkInstanceBodyData_11,
	thingClassBulkInstanceBodyData_12,
	thingClassBulkInstanceBodyData_13,
	thingClassBulkInstanceBodyData_14,
	thingClassBulkInstanceBodyData_15,
	thingClassBulkInstanceBodyData_16,
	thingClassBulkInstanceBodyData_17,
};