'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT21475';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });


module.exports = {
	draftThingClassData,
	thingInstanceData,
	draftThingClassModelPropertiesData
};
