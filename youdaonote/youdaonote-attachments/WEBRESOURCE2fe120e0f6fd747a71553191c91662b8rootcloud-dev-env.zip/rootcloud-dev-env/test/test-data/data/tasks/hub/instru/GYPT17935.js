'use strict';

const { dataBody } = require('../../../../comData');

//创建设备，指令
const prefix = 'GYPT17935';
const prefix_1 = 'GYPT17935_1';
const prefix_2 = 'GYPT17935_2';
const prefix_3 = 'GYPT17935_3';
const prefix_4 = 'GYPT17935_4';
const prefix_5 = 'GYPT17935_5';
const prefix_6 = 'GYPT17935_6';
const prefix_7 = 'GYPT17935_7';


const number = Math.round(Math.random() * (400));
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`, { type: 'LIVE' });
const updateInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`, { name: 'wit' });

const draftThingClassData1 = dataBody.draftThingClassBody(prefix_1, 'device');
const draftThingClassModelPropertiesData1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia', expressionType: 'direct' });
const createInstructionsData1 = dataBody.createInstructionsBody(prefix_1, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });

const createInstructionsData2 = dataBody.createInstructionsBody(prefix_1, `${number}`, { type: 'LIVE', name1: 'Ia' });
const createInstructionsData3 = dataBody.createInstructionsBody(prefix_2, `${number}`, { type: 'LIVE' });
const createInstructionsData4 = dataBody.createInstructionsBody(prefix_3, `${number}`, { type: 'LIVE' });
const createInstructionsData5 = dataBody.createInstructionsBody(prefix_4, `${number}`, { type: 'LIVE' });

const draftThingClassData2 = dataBody.draftThingClassBody(prefix_7, 'device');
const draftThingClassModelPropertiesData3 = dataBody.draftThingClassModelPropertiesBody(prefix_7, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia', expressionType: 'direct' });
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix_7);
const createInstructionsRequestData = dataBody.instructionRequestsBody({ 'Ia': '12' }, createInstructionsData2.instructionTemplateId, draftThingClassData2.modelId, thingInstanceData.thingId);

const draftGatewayClassData = dataBody.draftThingClassBody(prefix_5, 'gateway');
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_5);
const createInstructionsRequestData1 = dataBody.instructionRequestsBody({ 'Ia': '12' }, createInstructionsData2.instructionTemplateId, draftGatewayClassData.modelId, thingClassModelInstanceData.thingId);
const createInstructionsData6 = dataBody.createInstructionsBody(prefix_5, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const createInstructionsRequestData2 = dataBody.instructionRequestsBody({ 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData2.modelId, thingInstanceData.thingId, { type: 'CMD' });

//非直连模型
const draftThingClassData3 = dataBody.draftThingClassBody(prefix_6, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData2 = dataBody.draftThingClassModelPropertiesBody(prefix_6, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia', expressionType: 'direct' });
const thingInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_6, { gatewayId: thingClassModelInstanceData.thingId });
const createInstructionsRequestData3 = dataBody.instructionRequestsBody({ 'Ia': '12' }, createInstructionsData2.instructionTemplateId, draftThingClassData3.modelId, thingInstanceData2.thingId);

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	updateInstructionsData,
	draftThingClassData1,
	draftThingClassModelPropertiesData1,
	createInstructionsData1,
	createInstructionsData2,
	createInstructionsData3,
	createInstructionsData4,
	createInstructionsData5,
	createInstructionsData6,
	thingInstanceData,
	draftThingClassData2,
	createInstructionsRequestData,
	draftGatewayClassData,
	thingClassModelInstanceData,
	createInstructionsRequestData1,
	createInstructionsRequestData2,
	draftThingClassData3,
	draftThingClassModelPropertiesData2,
	thingInstanceData2,
	createInstructionsRequestData3,
	draftThingClassModelPropertiesData3
};
