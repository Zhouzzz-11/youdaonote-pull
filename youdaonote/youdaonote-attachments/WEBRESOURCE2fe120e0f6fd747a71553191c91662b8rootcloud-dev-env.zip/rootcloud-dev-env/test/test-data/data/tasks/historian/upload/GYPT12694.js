'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const num = 7;
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const prefix = 'GYPT12694';
const prefix_1 = 'GYPT12694_1';
const prefix_2 = 'GYPT12694_2';

//添加物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');  //直连设备
const draftThingClassData1 = dataBody.draftThingClassBody(prefix_1, 'device', { directlyLinked: false });  //非直连设备
//添加网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');

//添加设备
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_1, { connectId: 'connectId' + random, gatewayId: thingClassModelInstanceData2.thingId });

//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });
//mqtt
const locationData = dataBody.locationDataBody();
const locationData1 = dataBody.locationDataBody({ id: thingClassModelInstanceData1.connectId });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	locationData,
	draftThingClassData1,
	thingClassModelInstanceData1,
	draftGatewayClassData,
	thingClassModelInstanceData2,
	locationData1,
	num
};
