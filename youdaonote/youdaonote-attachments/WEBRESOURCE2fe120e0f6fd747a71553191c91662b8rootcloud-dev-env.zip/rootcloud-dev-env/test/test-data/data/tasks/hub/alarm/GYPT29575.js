'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const prefix = 'GYPT29575';
const prefix_1 = 'GYPT29575_1';
const prefix_2 = 'GYPT29575_2';
const prefix_3 = 'GYPT29575_3';
const prefix_4 = 'GYPT29575_4';
const prefix_5 = 'GYPT29575_5';
const prefix_6 = 'GYPT29575_6';
const prefix_c1 = 'GYPT29575_c1';
const prefix_T = 'GYPT29575_T';
const BulkType = 300;
const BulkTypeTest = 303;

const level = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 80)) - Math.round(Math.random() * 2000);

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_2, 'device');

const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia' });
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia' });

const postAlarmCategories = dataBody.alarmCategoriesBody(prefix);
const postAlarmSeverities = dataBody.alarmSeverities(prefix, parseInt(level));

const postAlarmType = dataBody.createBulkAlarmType(prefix, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');
const postAlarmType_1 = dataBody.createBulkAlarmType(prefix, [postAlarmCategories.cid], postAlarmSeverities.level, '', 'everyTime');
const postAlarmType_2 = dataBody.createBulkAlarmType(prefix_1, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');
const postAlarmType_3 = dataBody.createBulkAlarmType(prefix_2, [postAlarmCategories.cid, '12345'], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');
const postAlarmType_4 = dataBody.createBulkAlarmType(prefix_3, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime', { name: postAlarmType.name });
const postAlarmType_5 = dataBody.createBulkAlarmType(prefix_4, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime', { name: postAlarmType.name });
const postAlarmType_6 = dataBody.createBulkAlarmType(prefix_5, [postAlarmCategories.cid, '2345kk'], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');
const postAlarmType_7 = dataBody.createBulkAlarmType(prefix_6, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');

const ALarmBulkType_c1 = [];
for (let i = 0; i < BulkType; i++) {
	var BulkTypeData = dataBody.createBulkAlarmType(`${prefix_c1}_${i}`, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');
	ALarmBulkType_c1[i] = BulkTypeData.createBulkAlarmType[0];
}

const ALarmBulkType_T = [];
for (let i = 0; i < BulkTypeTest; i++) {
	var BulkTypeData_T = dataBody.createBulkAlarmType(`${prefix_T}_${i}`, [postAlarmCategories.cid], postAlarmSeverities.level, 'Ia >= 50', 'everyTime');
	ALarmBulkType_T[i] = BulkTypeData_T.createBulkAlarmType[0];
}

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	draftThingClassModelPropertiesData_1,
	postAlarmCategories,
	postAlarmSeverities,
	draftThingClassData_1,
	postAlarmType,
	postAlarmType_1,
	postAlarmType_2,
	postAlarmType_3,
	postAlarmType_4,
	postAlarmType_5,
	postAlarmType_6,
	postAlarmType_7,
	ALarmBulkType_c1,
	ALarmBulkType_T
};