'use strict';

const { dataBody } = require('../../../../comData');

//创建设备，指令
const prefix = 'GYPT17896';
// 验证模型不存在时创建失败，验证模型与tenantId不对应时创建失败
const prefix_1 = 'GYPT17896_1';
//验证关联属性不存在时创建失败
const prefix_2 = 'GYPT17896_2';
// 创建模板里的指令
const prefix_3 = 'GYPT17896_3';
//修改未发布的指令修改成功
const prefix_4 = 'GYPT17896_4';
//创建instruction
const prefix_5 = 'GYPT17896_5';
//修改已发布的指令草稿修改成功
const prefix_6 = 'GYPT17896_6';
//创建网关，指令
const prefix_9 = 'GYPT17896_9';
//验证组合条件查询的正确
const prefix_12 = 'GYPT17896_12';
//创建设备，指令LIVE
const prefix_13 = 'GYPT17896_13';
//验证增加指令后，发布设备模型
const prefix_14 = 'GYPT17896_14';
//验证更新指令后，发布设备模型
const prefix_15 = 'GYPT17896_15';
const prefix_16 = 'GYPT17896_16';
const prefix_17 = 'GYPT17896_17';

const number = Math.round(Math.random() * (200 - 10) + 10);
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });

const createInstructionsData_1 = dataBody.createInstructionsBody(prefix_1, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const createInstructionsData_2 = dataBody.createInstructionsBody(prefix_2, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: '' });
const createInstructionsData_3 = dataBody.createInstructionsBody(prefix_3, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP' });
const updateInstructionsData_4 = dataBody.createInstructionsBody(prefix_4, `${number}`, { instructionTemplateId: 'bum', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP', name2: 'sit' });
const updateInstructionsData_5 = dataBody.createInstructionsBody(prefix_5, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP' });
const updateInstructionsData_6 = dataBody.createInstructionsBody(prefix_6, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF', name: 'hit' });

const draftThingClassData_9 = dataBody.draftThingClassBody(prefix_9, 'gateway');
const draftThingClassModelPropertiesData_9 = dataBody.draftThingClassModelPropertiesBody(prefix_9, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData_9 = dataBody.createInstructionsBody(prefix_9, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const updateInstructionsData_9 = dataBody.createInstructionsBody(prefix_9, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF', name: 'bit' });

const createInstructionsData_12 = dataBody.createInstructionsBody(prefix_12, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP' });

const draftThingClassData_3 = dataBody.draftThingClassBody(prefix_13, 'device');
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(prefix_13, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp' });
const createInstructionsData_13 = dataBody.createInstructionsBody(prefix_13, `${number}`, { name1: 'temp' });
const createInstructionsData_14 = dataBody.createInstructionsBody(prefix_14, `${number}`, { name1: 'temp' });
const updateInstructionsData_15 = dataBody.createInstructionsBody(prefix_15, `${number}`, { name1: 'temp', name: 'bee' });
const createInstructionsData_16 = dataBody.createInstructionsBody(prefix_16, `${number}`, { name1: 'temp' });
const updateInstructionsData_17 = dataBody.createInstructionsBody(prefix_17, `${number}`, { name1: 'temp', name: 'bum' });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	createInstructionsData_1,
	createInstructionsData_2,
	createInstructionsData_3,
	updateInstructionsData_4,
	updateInstructionsData_5,
	updateInstructionsData_6,
	draftThingClassData_9,
	draftThingClassModelPropertiesData_9,
	createInstructionsData_9,
	updateInstructionsData_9,
	createInstructionsData_12,
	draftThingClassData_3,
	draftThingClassModelPropertiesData_3,
	createInstructionsData_13,
	createInstructionsData_14,
	updateInstructionsData_15,
	createInstructionsData_16,
	updateInstructionsData_17
};
