'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT23809';
const prefix_1 = 'GYPT23809_1';
const prefix_2 = 'GYPT23809_2';
const number = Math.round(Math.random() * (400));

//模型
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device'); //发布
const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device'); //未发布

//设备
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);   //设备1
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2);   //设备2

//属性
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', {name: 'Ia'});
//指令模板
//发布的模板
const createInstructionsData_1 = dataBody.createInstructionsBody(prefix_1, `${number}`, { instructionId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
//未发布的模板
const createInstructionsData_2 = dataBody.createInstructionsBody(prefix_2, `${number}`, { instructionId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
//设备权限集
const postDevicePermissionData_1 = dataBody.devicePermissionBody_withIns({ modelId: draftThingClassData_1.modelId, uuid: thingInstanceData_1.thingId, field1: 'name', access1: 0, field2: 'id', access2: 1 });
const postDevicePermissionData_2 = dataBody.devicePermissionBody_withIns({ modelId: draftThingClassData_1.modelId, uuid: thingInstanceData_1.thingId, field1: 'name', access1: 1, field2: 'id', access2: 0 });
const postDevicePermissionData_3 = dataBody.devicePermissionBody_withIns({ modelId: draftThingClassData_2.modelId, uuid: thingInstanceData_2.thingId, field1: 'name', access1: 1, field2: 'id', access2: 1 });


module.exports = {
	draftThingClassData_1,
	draftThingClassData_2,
	draftThingClassPropertiesData,
	thingInstanceData_1,
	thingInstanceData_2,
	createInstructionsData_1,
	createInstructionsData_2,
	postDevicePermissionData_1,
	postDevicePermissionData_2,
	postDevicePermissionData_3,

};