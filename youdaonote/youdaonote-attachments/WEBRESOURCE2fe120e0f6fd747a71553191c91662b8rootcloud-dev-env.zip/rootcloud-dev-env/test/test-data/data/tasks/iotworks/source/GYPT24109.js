// 'use strict';

// const { dataBody } = require('../../../../comData');
// const { iotworksMysqlDict,iotworksMongoDict } = require('../../../../requireData');

// const header = { 'Authorization': '' };
// const superUserToken = 'superUserToken';

// const prefix = 'GYPT24109';

// const externalDataSourceData = dataBody.externalDataSourceBody(prefix, 'MYSQL_JDBC_URL', { jdbcUrl: 'jdbc:mysql://' + iotworksMysqlDict.host + ':' + iotworksMysqlDict.port + '/' + iotworksMysqlDict.database, username: iotworksMysqlDict.username, password: iotworksMysqlDict.password });
// const externalDataSourceData1 = dataBody.externalDataSourceBody(prefix + '_1', 'MYSQL_HOST_PORT', { host: iotworksMysqlDict.host, port: iotworksMysqlDict.port, database: iotworksMysqlDict.database, username: iotworksMysqlDict.username, password: iotworksMysqlDict.password });
// const externalDataSourceData2 = dataBody.externalDataSourceBody(prefix + '_2', 'MONGO_JDBC_URL', { uri: 'mongo://' + iotworksMongoDict.username + ':' + iotworksMongoDict.password + '@' + iotworksMongoDict.host + ':' + iotworksMongoDict.port, database: iotworksMongoDict.database });
// const externalDataSourceData3 = dataBody.externalDataSourceBody(prefix + '_3', 'MONGO_HOST_PORT', { host: iotworksMongoDict.host, port: iotworksMongoDict.port, database: iotworksMongoDict.database, username: iotworksMongoDict.username, password: iotworksMongoDict.password });
// const externalDataSourceData4 = dataBody.externalDataSourceBody(prefix + '_4', 'MONGO_HOST', { host: iotworksMongoDict.host, port: iotworksMongoDict.port, database: iotworksMongoDict.database, username: iotworksMongoDict.username, password: iotworksMongoDict.password });
// const externalDataSourceData5 = dataBody.externalDataSourceBody(prefix + '_555555', 'MONGO_HOST_PORT', { host: iotworksMongoDict.host, port: iotworksMongoDict.port, database: iotworksMongoDict.database, username: iotworksMongoDict.username, password: iotworksMongoDict.password });
// const putExternalDataSourceData = dataBody.externalDataSourceBody(prefix + '6', 'MONGO_HOST_PORT', { host: iotworksMongoDict.host, port: iotworksMongoDict.port, database: iotworksMongoDict.database, username: iotworksMongoDict.username, password: iotworksMongoDict.password });
// const postValidationConnectionsData = dataBody.externalDataSourceBody(prefix + '7', 'MYSQL_JDBC_URL', { jdbcUrl: 'jdbc:mysql://' + iotworksMysqlDict.host + ':' + iotworksMysqlDict.port + '/' + iotworksMysqlDict.database, username: iotworksMysqlDict.username, password: iotworksMysqlDict.password });
// const putExternalDataSourceData_1 = dataBody.externalDataSourceBody(prefix, 'MYSQL_JDBC_URL', { jdbcUrl: 'jdbc:mysql://' + iotworksMysqlDict.host + ':' + iotworksMysqlDict.port + '/' + iotworksMysqlDict.database, username: iotworksMysqlDict.username, password: iotworksMysqlDict.password });

// module.exports = {
// 	externalDataSourceData,
// 	externalDataSourceData1,
// 	externalDataSourceData2,
// 	externalDataSourceData3,
// 	externalDataSourceData4,
// 	externalDataSourceData5,
// 	putExternalDataSourceData,
// 	postValidationConnectionsData,
// 	header,
// 	superUserToken,
// 	putExternalDataSourceData_1
// };
