'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT27260';
const num = 5;
const level = 27260;

const postAlarmSeverities = dataBody.alarmSeverities(prefix, level);

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'pro1', 'pro1', 'Number');

let postAlarmTypeDataList = [];
let alarmTypeIdList = [];
for (let i=0; i<num; i++) {
	const postAlarrmTypeData = dataBody.alarmTypeBody(prefix + '_' + i.toString(), null, level, draftThingClassData.modelId, 'pro1 >= 55', 'becomesTrue', 'PLATFORM');
	postAlarmTypeDataList.push(postAlarrmTypeData);
	alarmTypeIdList.push(postAlarrmTypeData.alarmTypeId);
}

module.exports = {
	num,
	postAlarmTypeDataList,
	alarmTypeIdList,
	postAlarmSeverities,
	draftThingClassData,
	draftThingClassPropertiesData
};
