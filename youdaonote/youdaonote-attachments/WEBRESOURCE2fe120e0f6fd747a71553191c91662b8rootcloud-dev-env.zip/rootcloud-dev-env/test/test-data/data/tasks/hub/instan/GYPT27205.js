'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const prefix = 'GYPT27205';
const prefix_1 = 'GYPT27025_1';
const prefix_2 = 'GYPT27025_2';
const prefix_3 = 'GYPT27025_3';
const prefix_4 = 'GYPT27025_4';
const prefix_5 = 'GYPT27025_5';
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
//创建thingInfo
const thingInfoData = dataBody.thingInfoBody({ serialNumber: '1001-ABC', manufacturer: '树根互联', model: 'AYX-2DF', deviceClass: '切割机', description: '这是设备描述信息', fwVersion: 'v1.0.1', hwVersion: 'v1.0.1-2', descriptiveLocation: '北京市海淀区西二旗', simImsi: random });
const thingInfoData_1 = dataBody.thingInfoBody({ serialNumber: '1001-ABCCD', manufacturer: '树根互联', model: 'AYX-2DF', deviceClass: '染布机', description: '这是设备描述信息', fwVersion: 'v1.0.1', hwVersion: 'v1.0.1-2', descriptiveLocation: '北京市朝阳区', simImsi: random });
//设备类型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//创建物实例_设备_请求参数不包含thingInfo
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
//创建物实例_设备_请求参数包含thingInfo
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1, { thingInfo: thingInfoData.thingInfoBody });
//修改物实例_设备_thingInfo修改参数value
const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2, { thingInfo: thingInfoData_1.thingInfoBody });
//复合物类型
const draftCompositeThingClassData_1 = dataBody.draftCompositeThingClassBody(prefix_3, 'compositeThing', draftThingClassData.modelId);
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_3, 'Number', 'Ia', 'Ia', 'Number');
//创建物实例_复合物类型_请求参数不包含thingInfo
const thingClassModelInstanceCompositeData_1 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_3, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId);
//创建物实例_复合物类型_请求参数包含thingInfo
const thingClassModelInstanceCompositeData_2 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_4, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { thingInfo: thingInfoData.thingInfoBody });
//修改物实例_复合物类型_thingInfo修改参数value
const updatethingClassModelInstanceCompositeData_1 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_5, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { thingInfo: thingInfoData_1.thingInfoBody });

module.exports = {
    thingInfoData,
    thingInfoData_1,
    draftThingClassData,
    draftThingClassModelPropertiesData,
    thingClassModelInstanceData,
    thingClassModelInstanceData_1,
    thingClassModelInstanceData_2,
    draftCompositeThingClassData_1,
    draftThingClassModelPropertiesData_1,
    thingClassModelInstanceCompositeData_1,
    thingClassModelInstanceCompositeData_2,
    updatethingClassModelInstanceCompositeData_1,
};