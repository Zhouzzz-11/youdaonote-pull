'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT25538';

//precondition
const ThingClassData = dataBody.draftThingClassBody(`${prefix}`, 'device');
const temp_option_1 = {'name':`${prefix}_1`, 'displayName':`${prefix}_1`,'expressionType':'linear', 'scale': 1, 'base': 2};
const PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number',`1*${prefix}+2` , 'temp' ,'Number' ,temp_option_1);
const compositeThing_1 = dataBody.draftCompositeThingClassBody(`${prefix}_c_1`, 'compositeThing', ThingClassData.modelId, {'nodeType': 'SingleDeviceNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const C_temp_option = {'name':`${prefix}_1`, 'displayName':`${prefix}_1`,'expressionType':'groovy'};
const C_PropertiesData = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', `$child("sum", "dt", "${prefix}_1")`, '' ,'Number' , C_temp_option);
const compositeThing_2 = dataBody.draftCompositeThingClassBody(`${prefix}_c_2`, 'compositeThing', compositeThing_1.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

//C2085535
const compositeThing_3 = dataBody.draftCompositeThingClassBody(`${prefix}_c_3`, 'compositeThing', compositeThing_2.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

//C2085537
const compositeThing_4 = dataBody.draftCompositeThingClassBody(`${prefix}_c_1`, 'compositeThing', compositeThing_2.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

//C2085548
const compositeThing_5 = dataBody.draftCompositeThingClassBody(`${prefix}_c_1`, 'compositeThing', compositeThing_1.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

module.exports = {ThingClassData, compositeThing_1, compositeThing_2, compositeThing_3, compositeThing_4, compositeThing_5, PropertiesData_1, C_PropertiesData};