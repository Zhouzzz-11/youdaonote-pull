'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const prefix = 'GYPT17931';
const prefix_1 = 'GYPT17931_1';
const prefix_2 = 'GYPT17931_2';
const prefix_3 = 'GYPT17931_3';
const prefix_4 = 'GYPT17931_4';

const postAlarmCategories = dataBody.alarmCategoriesBody(prefix);
const postAlarmCategories2 = dataBody.alarmCategoriesBody(prefix_1);
const postAlarmCategories3 = dataBody.alarmCategoriesBody(prefix_2);

const level = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 80)) - Math.round(Math.random() * 2000);
const postAlarmSeverities = dataBody.alarmSeverities(prefix, parseInt(level));

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'pro1', 'pro1', 'Number');

//创建初始的报警器
const postAlarmTypeData = dataBody.alarmTypeBody(prefix, null, postAlarmSeverities.level, draftThingClassData.modelId, 'pro1 >= 55', 'becomesTrue', 'PLATFORM');
//空数组的报警器分类
const postAlarmTypeData1 = dataBody.alarmTypeBody(prefix_1, [], postAlarmSeverities.level, draftThingClassData.modelId, 'pro1 >= 55', 'becomesTrue', 'PLATFORM');
//不存在的报警器分类
const postAlarmTypeData2 = dataBody.alarmTypeBody(prefix_2, ['123123'], postAlarmSeverities.level, draftThingClassData.modelId, 'pro1 >= 55', 'becomesTrue', 'PLATFORM');
//非数组的报警器分类
const postAlarmTypeData3 = dataBody.alarmTypeBody(prefix_3, 'no-array', postAlarmSeverities.level, draftThingClassData.modelId, 'pro1 >= 55', 'becomesTrue', 'PLATFORM');
//末尾多余逗号的报警器分类
const postAlarmTypeData4 = dataBody.alarmTypeBody(prefix_4, ['',], postAlarmSeverities.level, draftThingClassData.modelId, 'pro1 >= 55', 'becomesTrue', 'PLATFORM');

module.exports = {
	postAlarmTypeData,
	postAlarmCategories,
	postAlarmCategories2,
	postAlarmCategories3,
	postAlarmSeverities,
	postAlarmTypeData1,
	postAlarmTypeData2,
	postAlarmTypeData3,
	postAlarmTypeData4,
	draftThingClassData,
	draftThingClassPropertiesData
};
