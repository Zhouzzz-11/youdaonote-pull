'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const prefix = 'GYPT18340';
const prefix_1 = 'GYPT18340_1';
const prefix_2 = 'GYPT18340_2';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number');
const activeData = dataBody.patchActive();
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);

const draftThingClassData1 = dataBody.draftThingClassBody(prefix_1, 'device', { directlyLinked: false });  //非直连物模型
//添加网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');
//网关设备
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
//非直连设备
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_1, { connectId: 'connectId' + random, gatewayId: thingClassModelInstanceData2.thingId });

let timestamp = (new Date()).valueOf();
const msgData = dataBody.mesBody({ 'temp': 10 }, { 'ts': timestamp });
const msgData1 = dataBody.mesBody({ 'temp': 10 }, { id: thingClassModelInstanceData1.connectId });

let msgData2 = {
	header: {},
	body: {
		things: []
	}
};

for (let i = 0; i < 10; i++) {
	const things=dataBody.things({ 'temp': 10 }, { 'ts': timestamp++ });
	msgData2.body.things[i] = things.thing;
}

let msgData3 = {
	header: {},
	body: {
		things: []
	}
};
for (let i = 0; i < 1000; i++) {
	const things=dataBody.things({ 'temp': 10 }, { 'ts': timestamp++ });
	msgData3.body.things[i] = things.thing;
}

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	activeData,
	thingInstanceData,
	msgData,
	msgData1,
	draftThingClassData1,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2,
	msgData2,
	msgData3
};
