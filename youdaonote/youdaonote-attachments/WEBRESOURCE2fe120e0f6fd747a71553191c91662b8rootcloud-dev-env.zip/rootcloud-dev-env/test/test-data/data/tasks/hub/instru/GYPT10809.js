'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const prefix = 'GYPT10809';
const prefix_1 = 'GYPT10809_1';
const prefix_2 = 'GYPT10809_2';
const prefix_3 = 'GYPT10809_3';
const timestamp = Date.parse(new Date());
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
const prefix_10 = 'GYPT10809_10';
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_10);
const prefix_13 = 'GYPT10809_13';
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_13);
const prefix_14 = 'GYPT10809_14';
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_14);
const instructionRequestsData_1 = dataBody.configRequestsBody(prefix, thingInstanceData_1.thingId,{ timeout:126000 });
const responseData_1 = dataBody.instructionBody(instructionRequestsData_1.requestId, timestamp);
const instructionRequestsData_11 = dataBody.instructionConfigRequestBody(prefix_1, '34', draftThingClassData.modelId, thingInstanceData_2.thingId,{timeout:126000});
const responseData_11 = dataBody.instructionBody(instructionRequestsData_11.requestId, timestamp);
const prefix_6 = 'GYPT10809_6';
const instructionRequestsData_12 = dataBody.configRequestsBody(prefix_6, thingInstanceData.thingId,{ timeout:126000 });
const responseData_12 = dataBody.instructionBody(instructionRequestsData_12.requestId, timestamp);
const prefix_7 = 'GYPT10809_7';
const instructionRequestsData_13 = dataBody.configRequestsBody(prefix_7, thingInstanceData_3.thingId,{ timeout:126000 });
const responseData_13 = dataBody.instructionBody(instructionRequestsData_13.requestId, timestamp);
const prefix_8 = 'GYPT10809_8';
const instructionRequestsData_14 = dataBody.configRequestsBody(prefix_8, thingInstanceData_4.thingId,{ timeout:126000 });
const responseData_14 = dataBody.instructionBody(instructionRequestsData_14.requestId, timestamp,{isAck:false});

//网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
const prefix_9 = 'GYPT10809_9';
const thingClassModelInstanceData3 = dataBody.thingClassModelInstanceBody(prefix_9);
const prefix_11 = 'GYPT10809_11';
const thingClassModelInstanceData4 = dataBody.thingClassModelInstanceBody(prefix_11);
const prefix_12 = 'GYPT10809_12';
const thingClassModelInstanceData5 = dataBody.thingClassModelInstanceBody(prefix_12);
const instructionRequestsData_2 = dataBody.configRequestsBody(prefix_2, thingClassModelInstanceData2.thingId,{timeout:126000});
const responseData_2 = dataBody.instructionBody(instructionRequestsData_2.requestId, timestamp);
const prefix_4 = 'GYPT10809_4';
const instructionRequestsData_21 = dataBody.instructionConfigRequestBody(prefix_4, '34', draftGatewayClassData.modelId, thingClassModelInstanceData4.thingId,{ timeout:126000 });
const responseData_21 = dataBody.instructionBody(instructionRequestsData_21.requestId, timestamp);

//非直连物模型
const draftThingClassData1 = dataBody.draftThingClassBody(prefix_3, 'device', { directlyLinked: false });
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_3, { connectId: 'connectId' + random, gatewayId: thingClassModelInstanceData3.thingId });
const instructionRequestsData1 = dataBody.configRequestsBody(prefix_3, thingClassModelInstanceData1.thingId, { timeout: 126000 });
const responseData_3 = dataBody.instructionBody(instructionRequestsData1.requestId, timestamp, { id: thingClassModelInstanceData1.thingId, isAck: false });
const prefix_5 = 'GYPT10809_5';
const instructionRequestsData31 = dataBody.instructionConfigRequestBody(prefix_5, '34', draftGatewayClassData.modelId, thingClassModelInstanceData5.thingId,{ timeout:126000 });
const responseData_31 = dataBody.instructionBody(instructionRequestsData31.requestId, timestamp, { id: thingClassModelInstanceData1.connectId, isAck: false });

module.exports = {
	draftThingClassData,
	thingInstanceData_1,
	thingInstanceData_2,
	thingInstanceData_3,
	thingInstanceData_4,
	instructionRequestsData_1,
	responseData_2,
	draftThingClassPropertiesData,
	thingInstanceData,
	draftThingClassData1,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2,
	thingClassModelInstanceData3,
	thingClassModelInstanceData4,
	thingClassModelInstanceData5,
	responseData_1,
	instructionRequestsData_2,
	instructionRequestsData1,
	responseData_3,
	instructionRequestsData_11,
	responseData_11,
	instructionRequestsData_21,
	responseData_21,
	instructionRequestsData31,
	responseData_31,
	instructionRequestsData_12,
	responseData_12,
	instructionRequestsData_13,
	responseData_13,
	instructionRequestsData_14,
	responseData_14,
};