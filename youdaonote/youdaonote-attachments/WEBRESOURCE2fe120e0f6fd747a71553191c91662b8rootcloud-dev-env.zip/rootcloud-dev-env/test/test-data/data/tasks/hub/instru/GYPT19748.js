'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT19748';
const prefix_1 = 'GYPT19748_1';
const prefix_11 = 'GYPT19748_11';
const prefix_12 = 'GYPT19748_12';
const prefix_13 = 'GYPT19748_13';
const prefix_14 = 'GYPT19748_14';
const prefix_15 = 'GYPT19748_15';
const prefix_16 = 'GYPT19748_16';
const prefix_17 = 'GYPT19748_17';
const prefix_2 = 'GYPT19748_2';
const prefix_3 = 'GYPT19748_3';
const timestamp = Date.parse(new Date());

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//直连设备
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_11);
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_12);
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_13);
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_14);
const thingInstanceData_16 = dataBody.thingClassModelInstanceBody(prefix_16);
//添加网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');
//网关设备
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
//非直连物模型
const draftThingClassData1 = dataBody.draftThingClassBody(prefix_3, 'device', { directlyLinked: false });
//非直连设备
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_3, { connectId: 'connectId', gatewayId: thingClassModelInstanceData2.thingId });

let ota = { 'ota': { 'version': '1.0', 'url': '/url', 'force': true, 'type': '', 'size': 1024, 'needSize': 2048, 'signMethod': 'md5', 'sign': 'md5' } };

//直连设备指令下发
const instructionRequestsData = dataBody.thingInstructionRequestsBody(prefix, ota, undefined, undefined, thingInstanceData.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 10000 });
const instructionRequestsData_1 = dataBody.thingInstructionRequestsBody(prefix_11, ota, undefined, undefined, thingInstanceData_1.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 120000 });
const instructionRequestsData_2 = dataBody.thingInstructionRequestsBody(prefix_12, ota, undefined, undefined, thingInstanceData_2.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 30000 });
const instructionRequestsData_4 = dataBody.thingInstructionRequestsBody(prefix_14, ota, undefined, undefined, thingInstanceData_1.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 30000 });
const instructionRequestsData_5 = dataBody.thingInstructionRequestsBody(prefix_15, ota, undefined, undefined, thingInstanceData_3.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 30000 });
const instructionRequestsData_6 = dataBody.thingInstructionRequestsBody(prefix_16, ota, undefined, undefined, thingInstanceData_16.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 120000 });
const instructionRequestsData_7 = dataBody.thingInstructionRequestsBody(prefix_17, ota, undefined, undefined, thingInstanceData_4.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 50000 });

//网关设备指令下发
const instructionRequestsData2 = dataBody.thingInstructionRequestsBody(prefix_2, ota, undefined, undefined, thingClassModelInstanceData2.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 10000 });

//非直连设备指令下发
const instructionRequestsData1 = dataBody.thingInstructionRequestsBody(prefix_1, ota, undefined, undefined, thingClassModelInstanceData1.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 10000 });

//直连设备响应
const responseData = dataBody.otaInstructionBody(instructionRequestsData_1.requestId, timestamp, { isAck: false });
const responseData1 = dataBody.otaInstructionBody(instructionRequestsData_2.requestId, timestamp);
const responseData2 = dataBody.otaInstructionBody(instructionRequestsData_4.requestId, timestamp);
const responseData3 = dataBody.otaInstructionBody(instructionRequestsData_5.requestId, timestamp, { isCompleted: false, isAck: false });
const responseData4 = dataBody.otaInstructionBody(instructionRequestsData_6.requestId, timestamp, { isAck: false });
const responseData5 = dataBody.otaInstructionBody(instructionRequestsData_7.requestId, timestamp, { isCompleted: false, isAck: false });
const responseData6 = dataBody.otaInstructionBody(instructionRequestsData_7.requestId, timestamp, { isAck: false });
const responseData7 = dataBody.otaInstructionBody(instructionRequestsData_7.requestId, timestamp);

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	thingInstanceData,
	draftThingClassData1,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2,
	instructionRequestsData,
	instructionRequestsData_5,
	instructionRequestsData_6,
	thingInstanceData_4,
	instructionRequestsData_7,
	responseData7,
	responseData5,
	responseData6,
	responseData3,
	responseData4,
	thingInstanceData_3,
	thingInstanceData_16,
	responseData,
	thingInstanceData_2,
	responseData2,
	instructionRequestsData1,
	instructionRequestsData_2,
	instructionRequestsData_4,
	responseData1,
	instructionRequestsData2,
	thingInstanceData_1,
	instructionRequestsData_1,
};
