'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT25537';

//precondition
const ThingClassData = dataBody.draftThingClassBody(`${prefix}`, 'device');
const temp_option_1 = {'name':`${prefix}_1`, 'displayName':`${prefix}_1`,'expressionType':'linear', 'scale': 1, 'base': 2};
const PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number',`1*${prefix}+2` , 'temp' ,'Number' ,temp_option_1);
const InterfaceData = dataBody.draftThingInterfacesBody(`${prefix}_1`);
const temp_option_2 = {'name':`${prefix}_2`, 'displayName':`${prefix}_2`,'expressionType':'linear', 'scale': 1, 'base': 2, 'fromProperty': `${prefix}_1`};
const PropertiesData_2 = dataBody.draftThingInterfacesPropertiesBody(`${prefix}_1`, 'Number',`1*${prefix}+2` , '${prefix}_1' ,'Number' ,temp_option_2);

//schema modification
const DeviceData = dataBody.thingClassModelInstanceBody(`${prefix}`);

module.exports = {ThingClassData, PropertiesData_1, InterfaceData, PropertiesData_2, DeviceData};