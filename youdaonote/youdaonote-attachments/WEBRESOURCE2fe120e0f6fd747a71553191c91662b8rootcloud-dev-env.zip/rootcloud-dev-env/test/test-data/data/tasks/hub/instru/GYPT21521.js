'use strict';

const { dataBody } = require('../../../../comData');

//创建设备，增加设备属性创建指令模板_live
const prefix = 'GYPT21521';
const number = Math.round(Math.random() * (200 - 10) + 10);
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`);

//创建设备，增加设备属性创建指令模板_CMD
const prefix_1 = 'GYPT21521_1';
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData_1 = dataBody.createInstructionsBody(prefix_1, undefined, { type: 'CMD', name1: 'NTP', displayName: 'displayName_' + number, onOff: false });

//更新指令  指令模板_live
const updateInstructionsData = dataBody.createInstructionsBody(prefix, `${number}+'value'`, { name: 'tag' });

//更新指令  指令模板_CMD
const updateInstructionsData_1 = dataBody.createInstructionsBody(prefix_1, undefined, { type: 'CMD', name1: 'NTP', displayName: 'displayName_' + number, onOff: false, name: 'tager' });


module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsData,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	createInstructionsData_1,
	updateInstructionsData,
	updateInstructionsData_1
};