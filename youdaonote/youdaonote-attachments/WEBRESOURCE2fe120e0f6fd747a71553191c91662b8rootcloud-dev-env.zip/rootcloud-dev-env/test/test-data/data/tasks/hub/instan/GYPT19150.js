/* eslint-disable linebreak-style */
'use strict';

const { dataBody } = require('../../../../comData');

const Moment = require('moment');
//直连设备
const prefix = 'GYPT19150';
//直连设备 持续发送工况
const prefix_7 = 'GYPT19150_7';
//直连设备 发送一次工况
const prefix_3 = 'GYPT19150_3';
//网关设备
const prefix_1 = 'GYPT19150_1';
//网关设备 发送一次工况
const prefix_4 = 'GYPT19150_4';
//网关设备 持续发送工况
const prefix_8 = 'GYPT19150_8';
//非直连关联网关设备
const prefix_6 = 'GYPT19150_6';
//非直连设备
const prefix_2 = 'GYPT19150_2';
//非直连设备 发送一次工况
const prefix_5 = 'GYPT19150_5';
//非直连设备  持续发送工况
const prefix_9 = 'GYPT19150_9';

const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number');
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingClassModelInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_3);
const thingClassModelInstanceData_7 = dataBody.thingClassModelInstanceBody(prefix_7);

const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'gateway');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number');
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
const thingClassModelInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_4);
const thingClassModelInstanceData_6 = dataBody.thingClassModelInstanceBody(prefix_6);
const thingClassModelInstanceData_8 = dataBody.thingClassModelInstanceBody(prefix_8);

const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number');
const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2, { gatewayId: thingClassModelInstanceData_1.thingId });
const thingClassModelInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_5, { gatewayId: thingClassModelInstanceData_6.thingId, connectId: 'connectId_' + random });
const thingClassModelInstanceData_9 = dataBody.thingClassModelInstanceBody(prefix_9, { gatewayId: thingClassModelInstanceData_8.thingId, connectId: 'connectId_' + random });


const activeData = dataBody.patchActive();
const msgData = dataBody.mesBody({ 'temp': 20 });
const msgData1 = dataBody.mesBody({ 'temp': 20 }, { id: thingClassModelInstanceData_5.connectId });
const msgData2 = dataBody.mesBody({ 'temp': 20 }, { id: thingClassModelInstanceData_9.connectId });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	thingClassModelInstanceData_7,
	thingClassModelInstanceData_3,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceData_1,
	thingClassModelInstanceData_4,
	thingClassModelInstanceData_6,
	thingClassModelInstanceData_8,
	draftThingClassData_2,
	draftThingClassModelPropertiesData_2,
	thingClassModelInstanceData_2,
	thingClassModelInstanceData_5,
	thingClassModelInstanceData_9,
	activeData,
	msgData,
	msgData1,
	msgData2
};