'use strict';

const { dataBody } = require('../../../../comData');

//创建设备，指令
const prefix = 'GYPT18571';

const time = Math.round(new Date() / 1000);
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const activeData = dataBody.patchActive();
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const cloudTimeData = dataBody.cloudTimeBody(thingInstanceData.thingId, time);

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	activeData,
	thingInstanceData,
	cloudTimeData,
};