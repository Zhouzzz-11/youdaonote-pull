'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT20402';
const prefix_1 = 'GYPT20402_1';
const prefix_2 = 'GYPT20402_2';

//common data
const DeviceData = dataBody.thingClassModelInstanceBody(prefix);
const DeviceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
const DeviceData_2 = dataBody.thingClassModelInstanceBody(prefix_2);
const postdata = dataBody.mesBody({ 'temp': 1 });

//preconditions
const ThingClassData = dataBody.draftThingClassBody(`${prefix}`, 'device');
const ThingClassData_1 = dataBody.draftThingClassBody(`${prefix}_ff`, 'device');
const ThingClassData_2 = dataBody.draftThingClassBody(`${prefix}_gg`, 'device');

//C1880716
const temp_option_1 = { 'name': `${prefix}_aa`, 'displayName': `${prefix}_aa`, 'expressionType': 'linear', 'scale': 1, 'base': 2 };
const PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_aa`, 'Number', `1*${prefix}+2`, 'temp', 'Number', temp_option_1);

//C1880717&C1880718&C1880720
const temp_option_2 = { 'name': `${prefix}_bb`, 'displayName': `${prefix}_bb`, 'expressionType': 'groovy', 'priority': 2 };
const PropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_bb`, 'Number', `${prefix}_aa+1`, '', 'Number', temp_option_2);

const temp_option_3 = { 'name': `${prefix}_cc`, 'displayName': `${prefix}_cc`, 'expressionType': 'groovy', 'priority': 1 };
const PropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_cc`, 'Number', `${prefix}_bb+2`, '', 'Number', temp_option_3);

//C1880719
const temp_option_4 = { 'name': `${prefix}_ab`, 'displayName': `${prefix}_ab`, 'expressionType': 'groovy', 'priority': 2 };
const PropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_ab`, 'Number', `${prefix}_bb+1`, '', 'Number', temp_option_4);
const temp_option_7 = { 'name': `${prefix}_bc`, 'displayName': `${prefix}_bc`, 'expressionType': 'groovy', 'priority': 2 };
const PropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_ab`, 'Number', `${prefix}_bb+1`, '', 'Number', temp_option_7);

//C1880722
const temp_option_5 = { 'name': `${prefix}_dd`, 'displayName': `${prefix}_dd`, 'expressionType': 'window', 'priority': 1, 'operator': 'sum', 'windowSizeMills': 3000, 'windowStepMills': 1000, 'windowDefaultValueJson': '0' };
const PropertiesData_5 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_dd`, 'Number', `${prefix}_aa+1`, '', 'Number', temp_option_5);
const temp_option_6 = { 'name': `${prefix}_ee`, 'displayName': `${prefix}_ee`, 'expressionType': 'groovy', 'priority': 1 };
const PropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_ee`, 'Number', `${prefix}_dd+1`, '', 'Number', temp_option_6);

module.exports = {
    ThingClassData,
    ThingClassData_1,
    ThingClassData_2,
    PropertiesData_1,
    PropertiesData_2,
    PropertiesData_3,
    PropertiesData_4,
    PropertiesData_5,
    PropertiesData_6,
    PropertiesData_7,
    DeviceData,
    DeviceData_1,
    DeviceData_2,
    postdata
};