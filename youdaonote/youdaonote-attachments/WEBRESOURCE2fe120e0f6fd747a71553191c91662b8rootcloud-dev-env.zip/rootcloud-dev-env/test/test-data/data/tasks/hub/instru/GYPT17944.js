'use strict';

const { dataBody } = require('../../../../comData');

//创建设备，CMD指令
const prefix = 'GYPT17944';
//创建网关，CMD指令
const prefix_1 = 'GYPT17944_1';
//创建非直连，CMD指令
const prefix_2 = 'GYPT17944_2';
//直连设备再次下发指令
const prefix_3 = 'GYPT17944_3';
//直连设备_超时时间内不等设备就回应下发下一条指令
const prefix_4 = 'GYPT17944_4';
const prefix_5 = 'GYPT17944_5';
//直连设备_超时后再下发下一条指令
const prefix_6 = 'GYPT17944_6';
const prefix_7 = 'GYPT17944_7';
//网关设备再次下发指令
const prefix_8 = 'GYPT17944_8';
//网关设备_超时时间内不等设备就回应下发下一条指令
const prefix_9 = 'GYPT17944_9';
const prefix_10 = 'GYPT17944_10';
//网关设备_超时后再下发下一条指令
const prefix_11 = 'GYPT17944_11';
const prefix_12 = 'GYPT17944_12';
//非直连设备再次下发指令
const prefix_13 = 'GYPT17944_13';
//非直连设备_超时时间内不等设备就回应下发下一条指令
const prefix_14 = 'GYPT17944_14';
const prefix_15 = 'GYPT17944_15';
//非直连设备_超时后再下发下一条指令
const prefix_16 = 'GYPT17944_16';
const prefix_17 = 'GYPT17944_17';
//直连设备连续下发多条指令
const prefix_18 = 'GYPT17944_18';
const prefix_19 = 'GYPT17944_19';
const prefix_20 = 'GYPT17944_20';
//网关设备连续下发多条指令
const prefix_21 = 'GYPT17944_21';
const prefix_22 = 'GYPT17944_22';
const prefix_23 = 'GYPT17944_23';
//非直连设备连续下发多条指令
const prefix_24 = 'GYPT17944_24';
const prefix_25 = 'GYPT17944_25';
const prefix_26 = 'GYPT17944_26';
//创建设备，LIVE指令
const prefix_27 = 'GYPT17944_27';
//直连设备再次下发LIVE指令
const prefix_28 = 'GYPT17944_28';
//直连设备_超时时间内不等设备就回应下发下一条LIVE指令
const prefix_29 = 'GYPT17944_29';
const prefix_30 = 'GYPT17944_30';
//直连设备_超时后再下发下一条LIVE指令
const prefix_31 = 'GYPT17944_31';
const prefix_32 = 'GYPT17944_32';
//创建网关，LIVE指令
const prefix_33 = 'GYPT17944_33';
//网关设备再次下发LIVE指令
const prefix_34 = 'GYPT17944_34';
//网关设备_超时时间内不等设备就回应下发下一条LIVE指令
const prefix_35 = 'GYPT17944_35';
const prefix_36 = 'GYPT17944_36';
//网关设备_超时后再下发下一条LIVE指令
const prefix_37 = 'GYPT17944_37';
const prefix_38 = 'GYPT17944_38';
//非直连设备下发LIVE指令
const prefix_39 = 'GYPT17944_39';
//非直连设备再次下发LIVE指令
const prefix_40 = 'GYPT17944_40';
//非直连设备_超时时间内不等设备就回应下发下一条LIVE指令
const prefix_41 = 'GYPT17944_41';
const prefix_42 = 'GYPT17944_42';
//非直连设备_超时后再下发下一条LIVE指令
const prefix_43 = 'GYPT17944_43';
const prefix_44 = 'GYPT17944_44';
//直连设备连续下发多条指令
const prefix_45 = 'GYPT17944_45';
const prefix_46 = 'GYPT17944_46';
const prefix_47 = 'GYPT17944_47';
//网关设备连续下发多条指令
const prefix_48 = 'GYPT17944_48';
const prefix_49 = 'GYPT17944_49';
const prefix_50 = 'GYPT17944_50';
//非直连设备连续下发多条指令
const prefix_51 = 'GYPT17944_51';
const prefix_52 = 'GYPT17944_52';
const prefix_53 = 'GYPT17944_53';
//创建设备，CONFIG_GET指令
const prefix_54 = 'GYPT17944_54';
//直连设备再次下发CONFIG_GET指令
const prefix_55 = 'GYPT17944_55';
//直连设备_超时时间内不等设备就回应下发下一条CONFIG_GET指令
const prefix_56 = 'GYPT17944_56';
const prefix_57 = 'GYPT17944_57';
//直连设备_超时后再下发下一条CONFIG_GET指令
const prefix_58 = 'GYPT17944_58';
const prefix_59 = 'GYPT17944_59';
//创建网关，CONFIG_GET指令
const prefix_60 = 'GYPT17944_60';
//网关设备再次下发CONFIG_GET指令
const prefix_61 = 'GYPT17944_61';
//网关设备_超时时间内不等设备就回应下发下一条CONFIG_GET指令
const prefix_62 = 'GYPT17944_62';
const prefix_63 = 'GYPT17944_63';
//网关设备_超时后再下发下一条CONFIG_GET指令
const prefix_64 = 'GYPT17944_64';
const prefix_65 = 'GYPT17944_65';
//非直连设备下发CONFIG_GET指令
const prefix_66 = 'GYPT17944_66';
//非直连设备再次下发CONFIG_GET指令
const prefix_67 = 'GYPT17944_67';
//非直连设备_超时时间内不等设备就回应下发下一条CONFIG_GET指令
const prefix_68 = 'GYPT17944_68';
const prefix_69 = 'GYPT17944_69';
//非直连设备_超时后再下发下一条CONFIG_GET指令
const prefix_70 = 'GYPT17944_70';
const prefix_71 = 'GYPT17944_71';
//直连设备连续下发多条指令
const prefix_72 = 'GYPT17944_72';
const prefix_73 = 'GYPT17944_73';
const prefix_74 = 'GYPT17944_74';
//网关设备连续下发多条指令
const prefix_75 = 'GYPT17944_75';
const prefix_76 = 'GYPT17944_76';
const prefix_77 = 'GYPT17944_77';
//非直连设备连续下发多条指令
const prefix_78 = 'GYPT17944_78';
const prefix_79 = 'GYPT17944_79';
const prefix_80 = 'GYPT17944_80';


const number = Math.round(Math.random() * (400));
const time = Math.round(new Date() / 1000);
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const activeData = dataBody.patchActive();
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const draftThingClassData_9 = dataBody.draftThingClassBody(`${prefix}_81`, 'device');
const createInstructionsData_9 = dataBody.createInstructionsBody(`${prefix}_81`, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const thingInstanceData_9 = dataBody.thingClassModelInstanceBody(`${prefix}_81`);
const createInstructionsRequestData = dataBody.thingInstructionRequestsBody(prefix, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD', timeout: 60000 });
const instructionData = dataBody.instructionBody(createInstructionsRequestData.requestId, time);
const createInstructionsRequestData_3 = dataBody.thingInstructionRequestsBody(prefix_3, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_4 = dataBody.thingInstructionRequestsBody(prefix_4, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_5 = dataBody.thingInstructionRequestsBody(prefix_5, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_6 = dataBody.thingInstructionRequestsBody(prefix_6, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_9.modelId, thingInstanceData_9.thingId, { type: 'CMD', timeout: 3000 });
const createInstructionsRequestData_7 = dataBody.thingInstructionRequestsBody(prefix_7, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_9.modelId, thingInstanceData_9.thingId, { type: 'CMD', timeout:3000 });
const createInstructionsRequestData_18 = dataBody.thingInstructionRequestsBody(prefix_18, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD' });
const createInstructionsRequestData_19 = dataBody.thingInstructionRequestsBody(prefix_19, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD' });
const createInstructionsRequestData_20 = dataBody.thingInstructionRequestsBody(prefix_20, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD' });

const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'gateway');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData_1 = dataBody.createInstructionsBody(prefix_1, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP' });
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
const thingInstanceData_10 = dataBody.thingClassModelInstanceBody(`${prefix}_82`);
const createInstructionsRequestData_1 = dataBody.thingInstructionRequestsBody(prefix_1, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD', timeout: 120000 });
const instructionData_1 = dataBody.instructionBody(createInstructionsRequestData_1.requestId, time);
const createInstructionsRequestData_8 = dataBody.thingInstructionRequestsBody(prefix_8, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_9 = dataBody.thingInstructionRequestsBody(prefix_9, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_10 = dataBody.thingInstructionRequestsBody(prefix_10, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_11 = dataBody.thingInstructionRequestsBody(prefix_11, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_10.thingId, { type: 'CMD', timeout: 3000 });
const createInstructionsRequestData_12 = dataBody.thingInstructionRequestsBody(prefix_12, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_10.thingId, { type: 'CMD', timeout: 3000 });
const createInstructionsRequestData_21 = dataBody.thingInstructionRequestsBody(prefix_21, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD' });
const createInstructionsRequestData_22 = dataBody.thingInstructionRequestsBody(prefix_22, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD' });
const createInstructionsRequestData_23 = dataBody.thingInstructionRequestsBody(prefix_23, { 'cmds': [{ 'name': 'WAKEUP' }] }, '_Turnoff_', draftThingClassData_1.modelId, thingInstanceData_1.thingId, { type: 'CMD' });

const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'Ia', 'Ia', 'Number');
const createInstructionsData_2 = dataBody.createInstructionsBody(prefix_2, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2, { gatewayId: thingInstanceData_1.thingId });
const thingInstanceData_11 = dataBody.thingClassModelInstanceBody(`${prefix}_83`, { gatewayId: thingInstanceData_10.thingId });
const createInstructionsRequestData_2 = dataBody.thingInstructionRequestsBody(prefix_2, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD', timeout: 120000 });
const instructionData_2 = dataBody.instructionBody(createInstructionsRequestData_2.requestId, time, { id: thingInstanceData_2.thingId, isAck: false });
const createInstructionsRequestData_13 = dataBody.thingInstructionRequestsBody(prefix_13, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_14 = dataBody.thingInstructionRequestsBody(prefix_14, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_15 = dataBody.thingInstructionRequestsBody(prefix_15, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD', timeout: 60000 });
const createInstructionsRequestData_16 = dataBody.thingInstructionRequestsBody(prefix_16, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_11.thingId, { type: 'CMD', timeout: 3000 });
const createInstructionsRequestData_17 = dataBody.thingInstructionRequestsBody(prefix_17, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_11.thingId, { type: 'CMD', timeout: 3000 });
const createInstructionsRequestData_24 = dataBody.thingInstructionRequestsBody(prefix_24, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD' });
const createInstructionsRequestData_25 = dataBody.thingInstructionRequestsBody(prefix_25, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD' });
const createInstructionsRequestData_26 = dataBody.thingInstructionRequestsBody(prefix_26, { 'cmds': [{ 'name': 'POWEROFF' }] }, '_Rouse_', draftThingClassData_2.modelId, thingInstanceData_2.thingId, { type: 'CMD' });

const draftThingClassData_3 = dataBody.draftThingClassBody(prefix_27, 'device');
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(prefix_27, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp', expressionType: 'direct' });
const createInstructionsData_3 = dataBody.createInstructionsBody(prefix_27, `${number}`, { name1: 'temp' });
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_27);
const thingInstanceData_16 = dataBody.thingClassModelInstanceBody(`${prefix}_88`);
const createInstructionsRequestData_27 = dataBody.thingInstructionRequestsBody(prefix_27, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId, { timeout: 120000 });
const instructionData_3 = dataBody.instructionBody(createInstructionsRequestData_27.requestId, time);
const createInstructionsRequestData_28 = dataBody.thingInstructionRequestsBody(prefix_28, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId, { timeout: 60000 });
const createInstructionsRequestData_29 = dataBody.thingInstructionRequestsBody(prefix_29, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId, { timeout: 60000 });
const createInstructionsRequestData_30 = dataBody.thingInstructionRequestsBody(prefix_30, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId, { timeout: 60000 });
const createInstructionsRequestData_31 = dataBody.thingInstructionRequestsBody(prefix_31, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_16.thingId, { timeout: 3000 });
const createInstructionsRequestData_32 = dataBody.thingInstructionRequestsBody(prefix_32, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_16.thingId, { timeout: 3000 });
const createInstructionsRequestData_45 = dataBody.thingInstructionRequestsBody(prefix_45, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId);
const createInstructionsRequestData_46 = dataBody.thingInstructionRequestsBody(prefix_46, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId);
const createInstructionsRequestData_47 = dataBody.thingInstructionRequestsBody(prefix_47, { 'temp': `${number}` }, createInstructionsData_3.instructionTemplateId, draftThingClassData_3.modelId, thingInstanceData_3.thingId);

const draftThingClassData_4 = dataBody.draftThingClassBody(prefix_33, 'gateway');
const draftThingClassModelPropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(prefix_33, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp1',expressionType:'direct' });
const createInstructionsData_4 = dataBody.createInstructionsBody(prefix_33, `${number}`, { name1: 'temp1' });
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_33);
const thingInstanceData_17 = dataBody.thingClassModelInstanceBody(`${prefix}_90`);
const createInstructionsRequestData_33 = dataBody.thingInstructionRequestsBody(prefix_33, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId, { timeout: 120000 });
const instructionData_4 = dataBody.instructionBody(createInstructionsRequestData_33.requestId, time);
const createInstructionsRequestData_34 = dataBody.thingInstructionRequestsBody(prefix_34, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId, { timeout: 60000 });
const createInstructionsRequestData_35 = dataBody.thingInstructionRequestsBody(prefix_35, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId, { timeout: 60000 });
const createInstructionsRequestData_36 = dataBody.thingInstructionRequestsBody(prefix_36, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId, { timeout: 60000 });
const createInstructionsRequestData_37 = dataBody.thingInstructionRequestsBody(prefix_37, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_17.thingId, { timeout: 3000 });
const createInstructionsRequestData_38 = dataBody.thingInstructionRequestsBody(prefix_38, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_17.thingId, { timeout: 3000 });
const createInstructionsRequestData_48 = dataBody.thingInstructionRequestsBody(prefix_48, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId,);
const createInstructionsRequestData_49 = dataBody.thingInstructionRequestsBody(prefix_49, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId);
const createInstructionsRequestData_50 = dataBody.thingInstructionRequestsBody(prefix_50, { 'temp': `${number}` }, createInstructionsData_4.instructionTemplateId, draftThingClassData_4.modelId, thingInstanceData_4.thingId);

const draftThingClassData_5 = dataBody.draftThingClassBody(prefix_39, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_5 = dataBody.draftThingClassModelPropertiesBody(prefix_39, 'Number', 'Ia', 'Ia', 'Number', { name: 'temp2',expressionType:'direct' });
const createInstructionsData_5 = dataBody.createInstructionsBody(prefix_39, `${number}`, { name1: 'temp2' });
const thingInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_39, { gatewayId: thingInstanceData_4.thingId });
const thingInstanceData_18 = dataBody.thingClassModelInstanceBody(`${prefix}_91`, { gatewayId: thingInstanceData_17.thingId });
const createInstructionsRequestData_39 = dataBody.thingInstructionRequestsBody(prefix_39, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId, { timeout: 120000 });
const instructionData_5 = dataBody.instructionBody(createInstructionsRequestData_39.requestId, time, { id: thingInstanceData_5.thingId, isAck: false });
const createInstructionsRequestData_40 = dataBody.thingInstructionRequestsBody(prefix_40, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId, { timeout: 60000 });
const createInstructionsRequestData_41 = dataBody.thingInstructionRequestsBody(prefix_41, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId, { timeout: 60000 });
const createInstructionsRequestData_42 = dataBody.thingInstructionRequestsBody(prefix_42, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId, { timeout: 60000 });
const createInstructionsRequestData_43 = dataBody.thingInstructionRequestsBody(prefix_43, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_18.thingId, { timeout: 3000 });
const createInstructionsRequestData_44 = dataBody.thingInstructionRequestsBody(prefix_44, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_18.thingId, { timeout: 3000 });
const createInstructionsRequestData_51 = dataBody.thingInstructionRequestsBody(prefix_51, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId);
const createInstructionsRequestData_52 = dataBody.thingInstructionRequestsBody(prefix_52, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId);
const createInstructionsRequestData_53 = dataBody.thingInstructionRequestsBody(prefix_53, { 'temp': `${number}` }, createInstructionsData_5.instructionTemplateId, draftThingClassData_5.modelId, thingInstanceData_5.thingId);

const draftThingClassData_6 = dataBody.draftThingClassBody(prefix_54, 'device');
const draftThingClassModelPropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(prefix_54, 'Number', 'Ia', 'Ia', 'Number');
const thingInstanceData_6 = dataBody.thingClassModelInstanceBody(prefix_54);
const thingInstanceData_12 = dataBody.thingClassModelInstanceBody(`${prefix}_84`);
const createInstructionsRequestData_54 = dataBody.instructionConfigRequestBody(prefix_54, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId, { timeout: 120000 });
const instructionData_6 = dataBody.instructionBody(createInstructionsRequestData_54.requestId, time);
const createInstructionsRequestData_55 = dataBody.instructionConfigRequestBody(prefix_55, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId, { timeout: 60000 });
const createInstructionsRequestData_56 = dataBody.instructionConfigRequestBody(prefix_56, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId, { timeout: 60000 });
const createInstructionsRequestData_57 = dataBody.instructionConfigRequestBody(prefix_57, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId, { timeout: 60000 });
const createInstructionsRequestData_58 = dataBody.instructionConfigRequestBody(prefix_58, `${number}`, draftThingClassData_6.modelId, thingInstanceData_12.thingId, { timeout: 3000 });
const createInstructionsRequestData_59 = dataBody.instructionConfigRequestBody(prefix_59, `${number}`, draftThingClassData_6.modelId, thingInstanceData_12.thingId, { timeout: 3000 });
const createInstructionsRequestData_72 = dataBody.instructionConfigRequestBody(prefix_72, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId);
const createInstructionsRequestData_73 = dataBody.instructionConfigRequestBody(prefix_73, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId);
const createInstructionsRequestData_74 = dataBody.instructionConfigRequestBody(prefix_74, `${number}`, draftThingClassData_6.modelId, thingInstanceData_6.thingId);

const draftThingClassData_7 = dataBody.draftThingClassBody(prefix_60, 'gateway');
const draftThingClassModelPropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(prefix_60, 'Number', 'Ia', 'Ia', 'Number');
const thingInstanceData_7 = dataBody.thingClassModelInstanceBody(prefix_60);
const thingInstanceData_13 = dataBody.thingClassModelInstanceBody(`${prefix}_85`);
const thingInstanceData_15 = dataBody.thingClassModelInstanceBody(`${prefix}_89`);
const createInstructionsRequestData_60 = dataBody.instructionConfigRequestBody(prefix_60, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId, { timeout: 120000 });
const instructionData_7 = dataBody.instructionBody(createInstructionsRequestData_60.requestId, time);
const createInstructionsRequestData_61 = dataBody.instructionConfigRequestBody(prefix_61, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId, { timeout: 60000 });
const createInstructionsRequestData_62 = dataBody.instructionConfigRequestBody(prefix_62, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId, { timeout: 60000 });
const createInstructionsRequestData_63 = dataBody.instructionConfigRequestBody(prefix_63, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId, { timeout: 60000 });
const createInstructionsRequestData_64 = dataBody.instructionConfigRequestBody(prefix_64, `${number}`, draftThingClassData_7.modelId, thingInstanceData_13.thingId, { timeout: 3000 });
const createInstructionsRequestData_65 = dataBody.instructionConfigRequestBody(prefix_65, `${number}`, draftThingClassData_7.modelId, thingInstanceData_13.thingId, { timeout: 3000 });
const createInstructionsRequestData_75 = dataBody.instructionConfigRequestBody(prefix_75, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId);
const createInstructionsRequestData_76 = dataBody.instructionConfigRequestBody(prefix_76, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId);
const createInstructionsRequestData_77 = dataBody.instructionConfigRequestBody(prefix_77, `${number}`, draftThingClassData_7.modelId, thingInstanceData_7.thingId);

const draftThingClassData_8 = dataBody.draftThingClassBody(prefix_66, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_8 = dataBody.draftThingClassModelPropertiesBody(prefix_66, 'Number', 'Ia', 'Ia', 'Number');
const thingInstanceData_8 = dataBody.thingClassModelInstanceBody(prefix_66, { gatewayId: thingInstanceData_7.thingId });
const thingInstanceData_14 = dataBody.thingClassModelInstanceBody(`${prefix}_86`, { gatewayId: thingInstanceData_15.thingId });
const createInstructionsRequestData_66 = dataBody.instructionConfigRequestBody(prefix_66, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId, { timeout: 120000 });
const instructionData_8 = dataBody.instructionBody(createInstructionsRequestData_66.requestId, time, { id: thingInstanceData_8.thingId, isAck: false });
const createInstructionsRequestData_67 = dataBody.instructionConfigRequestBody(prefix_67, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId, { timeout: 60000 });
const createInstructionsRequestData_68 = dataBody.instructionConfigRequestBody(prefix_68, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId, { timeout: 60000 });
const createInstructionsRequestData_69 = dataBody.instructionConfigRequestBody(prefix_69, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId, { timeout: 60000 });
const createInstructionsRequestData_70 = dataBody.instructionConfigRequestBody(prefix_70, `${number}`, draftThingClassData_8.modelId, thingInstanceData_14.thingId, { timeout: 3000 });
const createInstructionsRequestData_71 = dataBody.instructionConfigRequestBody(prefix_71, `${number}`, draftThingClassData_8.modelId, thingInstanceData_14.thingId, { timeout: 3000 });
const createInstructionsRequestData_78 = dataBody.instructionConfigRequestBody(prefix_78, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId);
const createInstructionsRequestData_79 = dataBody.instructionConfigRequestBody(prefix_79, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId);
const createInstructionsRequestData_80 = dataBody.instructionConfigRequestBody(prefix_80, `${number}`, draftThingClassData_8.modelId, thingInstanceData_8.thingId);

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	activeData,
	createInstructionsData,
	thingInstanceData,
	draftThingClassData_9,
	createInstructionsData_9,
	thingInstanceData_9,
	createInstructionsRequestData,
	instructionData,
	createInstructionsRequestData_3,
	createInstructionsRequestData_4,
	createInstructionsRequestData_5,
	createInstructionsRequestData_6,
	createInstructionsRequestData_7,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	createInstructionsData_1,
	thingInstanceData_1,
	createInstructionsRequestData_1,
	instructionData_1,
	thingInstanceData_10,
	createInstructionsRequestData_8,
	createInstructionsRequestData_9,
	createInstructionsRequestData_10,
	createInstructionsRequestData_11,
	createInstructionsRequestData_12,
	draftThingClassData_2,
	draftThingClassModelPropertiesData_2,
	createInstructionsData_2,
	thingInstanceData_2,
	thingInstanceData_11,
	createInstructionsRequestData_2,
	instructionData_2,
	createInstructionsRequestData_13,
	createInstructionsRequestData_14,
	createInstructionsRequestData_15,
	createInstructionsRequestData_16,
	createInstructionsRequestData_17,
	createInstructionsRequestData_18,
	createInstructionsRequestData_19,
	createInstructionsRequestData_20,
	createInstructionsRequestData_21,
	createInstructionsRequestData_22,
	createInstructionsRequestData_23,
	createInstructionsRequestData_24,
	createInstructionsRequestData_25,
	createInstructionsRequestData_26,
	draftThingClassData_3,
	draftThingClassModelPropertiesData_3,
	createInstructionsData_3,
	thingInstanceData_3,
	createInstructionsRequestData_27,
	instructionData_3,
	thingInstanceData_16,
	createInstructionsRequestData_28,
	createInstructionsRequestData_29,
	createInstructionsRequestData_30,
	createInstructionsRequestData_31,
	createInstructionsRequestData_32,
	createInstructionsRequestData_45,
	createInstructionsRequestData_46,
	createInstructionsRequestData_47,
	draftThingClassData_4,
	draftThingClassModelPropertiesData_4,
	createInstructionsData_4,
	thingInstanceData_4,
	thingInstanceData_17,
	createInstructionsRequestData_33,
	instructionData_4,
	createInstructionsRequestData_34,
	createInstructionsRequestData_35,
	createInstructionsRequestData_36,
	createInstructionsRequestData_37,
	createInstructionsRequestData_38,
	createInstructionsRequestData_48,
	createInstructionsRequestData_49,
	createInstructionsRequestData_50,
	draftThingClassData_5,
	draftThingClassModelPropertiesData_5,
	createInstructionsData_5,
	thingInstanceData_5,
	thingInstanceData_18,
	createInstructionsRequestData_39,
	instructionData_5,
	createInstructionsRequestData_40,
	createInstructionsRequestData_41,
	createInstructionsRequestData_42,
	createInstructionsRequestData_43,
	createInstructionsRequestData_44,
	createInstructionsRequestData_51,
	createInstructionsRequestData_52,
	createInstructionsRequestData_53,
	draftThingClassData_6,
	draftThingClassModelPropertiesData_6,
	thingInstanceData_6,
	createInstructionsRequestData_54,
	instructionData_6,
	thingInstanceData_12,
	createInstructionsRequestData_55,
	createInstructionsRequestData_56,
	createInstructionsRequestData_57,
	createInstructionsRequestData_58,
	createInstructionsRequestData_59,
	draftThingClassData_7,
	draftThingClassModelPropertiesData_7,
	thingInstanceData_7,
	createInstructionsRequestData_60,
	instructionData_7,
	thingInstanceData_13,
	thingInstanceData_15,
	createInstructionsRequestData_61,
	createInstructionsRequestData_62,
	createInstructionsRequestData_63,
	createInstructionsRequestData_64,
	createInstructionsRequestData_65,
	draftThingClassData_8,
	draftThingClassModelPropertiesData_8,
	thingInstanceData_8,
	createInstructionsRequestData_66,
	instructionData_8,
	thingInstanceData_14,
	createInstructionsRequestData_67,
	createInstructionsRequestData_68,
	createInstructionsRequestData_69,
	createInstructionsRequestData_70,
	createInstructionsRequestData_71,
	createInstructionsRequestData_72,
	createInstructionsRequestData_73,
	createInstructionsRequestData_74,
	createInstructionsRequestData_75,
	createInstructionsRequestData_76,
	createInstructionsRequestData_77,
	createInstructionsRequestData_78,
	createInstructionsRequestData_79,
	createInstructionsRequestData_80
};