'use strict';
const { dataBody } = require('../../../../comData');
const prefix = 'GYPT19428';

const string_lenth256 = 'd25645672201245679123456789012345678912345678901234567891234567890123456789123456d12341234567890123456789123456789012345678912345678901234567891234567890123456789123456789012345678912345678912345678901233256';
const string_lenth258 = 'd258124567200123456789201234678901234567892012346789023456789012345678912345678901234567891234567890123456789123456d12341234567890123456789123456789012345678912345678901234567891234567890123456789123456789012345678912345678912345678901233258';
const string_lenth512 = 'd5124374567220124578912345678901234567891234567890123456789123456sdfd123456789012345678912345678907890123456789123456d1234123456789012345789123456789012345678912345678901234567891234567890123456789123456d1234123456789012345678912345678901234890123456789123456789012345678912345678901234456789012345678912345678901234567891234567890123456789123456789123456789012332566789123456789012345678912345678901234567891234567890123456789123456789012345678912345678912345678901233512';
const string_lenth514 = 'd5144374567220123456789201234678900124sd5678912345678901234567891234567890123456789123456sdfd123456789012345678912345678907890123456789123456d1234123456789012345789123456789012345678912345678901234567891234567890123456789123456d1234123456789012345678912345678901234890123456789123456789012345678912345678901234456789012345678912345678901234567891234567890123456789123456789123456789012332566789123456789012345678912345678901234567891234567890123456789123456789012345678912345678912345678901233514';
const string_dollar = 'd12326$';

const string_ConnectIdCorrect = 'abcdedfhijklmnopqrstuvwxyxABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_#:-@';
const string_ConnectIdError = 'dedfhijklmnod*^';

const draftDirectDeviceClassData = dataBody.draftThingClassBody(`${prefix}_1`, 'device');
const draftGatewayClassData = dataBody.draftThingClassBody(`${prefix}_2`, 'gateway');
const draftNonDirectDeviceClassData = dataBody.draftThingClassBody(`${prefix}_3`, 'device', { directlyLinked: false });
const gwInstanceData = dataBody.thingClassModelInstanceBody(prefix);

const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number');
const activeData = dataBody.patchActive();
const msgData = dataBody.mesBody({ 'temp': 10 });

//direct linked device
const directDeviceInstanceDataC1721893_1 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721893_1`, { userName: dataBody.returnName(string_lenth256, `${prefix}_C1721893_1`) });
const directDeviceInstanceDataC1721893_2 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721893_2`, { userName: dataBody.returnName(string_lenth258, `${prefix}_C1721893_2`) });
const directDeviceInstanceDataC1721893_3 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721893_3`, { userName: dataBody.returnName(string_dollar, `${prefix}_C1721893_3`) });
const directDeviceInstanceDataC1721894_1 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721894_1`, { authToken: dataBody.returnName(string_lenth512, `${prefix}_C1721894_1`) });
const directDeviceInstanceDataC1721894_2 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721894_2`, { authToken: dataBody.returnName(string_lenth514, `${prefix}_C1721894_2`) });

//gateway
const gatewayInstanceDataC1721896_1 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721896_1`, { userName: dataBody.returnName(string_lenth256, `${prefix}_C1721896_1`) });
const gatewayInstanceDataC1721896_2 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721896_2`, { userName: dataBody.returnName(string_lenth258, `${prefix}_C1721896_2`) });
const gatewayInstanceDataC1721896_3 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721896_3`, { userName: dataBody.returnName(string_dollar, `${prefix}_C1721896_3`) });
const gatewayInstanceDataC1721897_1 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721897_1`, { authToken: dataBody.returnName(string_lenth512, `${prefix}_C1721897_1`) });
const gatewayInstanceDataC1721897_2 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721897_2`, { authToken: dataBody.returnName(string_lenth514, `${prefix}_C1721897_2`) });

//non direct linked device
const nonDirectDeviceInstanceDataC1721901_1 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721901_1`, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth256, `${prefix}_C1721901_1`) });
const nonDirectDeviceInstanceDataC1721901_2 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721901_2`, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdCorrect, `${prefix}_C1721901_2`) });
const nonDirectDeviceInstanceDataC1721901_3 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721901_3`, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth258, `${prefix}_C1721901_3`) });
const nonDirectDeviceInstanceDataC1721901_4 = dataBody.thingClassModelInstanceBody(`${prefix}_C1721901_4`, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdError, `${prefix}_C1721901_4`) });

//bulk device
// const bulkDeviceInstanceDataC1721902_1 = dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_1`, draftNonDirectDeviceClassData.modelId, {userName:dataBody.returnName(string_lenth256, `${prefix}_C1721902_1`)});
const bulkDeviceInstanceDataC1721902_1 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_11`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_lenth256, `${prefix}_C1721902_11`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_12`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_lenth256, `${prefix}_C1721902_12`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_13`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_lenth256, `${prefix}_C1721902_13`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721902_2 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_21`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_lenth258, `${prefix}_C1721902_21`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_22`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_lenth258, `${prefix}_C1721902_22`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_23`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_lenth258, `${prefix}_C1721902_23`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721902_3 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_31`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_dollar, `${prefix}_C1721902_31`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_32`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_dollar, `${prefix}_C1721902_32`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721902_33`, draftDirectDeviceClassData.modelId, { userName: dataBody.returnName(string_dollar, `${prefix}_C1721902_33`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721903_1 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721903_11`, draftDirectDeviceClassData.modelId, { authToken: dataBody.returnName(string_lenth512, `${prefix}_C1721903_11`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721903_12`, draftDirectDeviceClassData.modelId, { authToken: dataBody.returnName(string_lenth512, `${prefix}_C1721903_12`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721903_13`, draftDirectDeviceClassData.modelId, { authToken: dataBody.returnName(string_lenth512, `${prefix}_C1721903_13`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721903_2 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721903_21`, draftDirectDeviceClassData.modelId, { authToken: dataBody.returnName(string_lenth514, `${prefix}_C1721903_21`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721903_22`, draftDirectDeviceClassData.modelId, { authToken: dataBody.returnName(string_lenth514, `${prefix}_C1721903_22`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721903_23`, draftDirectDeviceClassData.modelId, { authToken: dataBody.returnName(string_lenth514, `${prefix}_C1721903_23`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721904_1 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_11`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth256, `${prefix}_C1721904_11`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_12`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth256, `${prefix}_C1721904_12`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_13`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth256, `${prefix}_C1721904_13`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721904_2 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_21`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdCorrect, `${prefix}_C1721904_21`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_22`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdCorrect, `${prefix}_C1721904_22`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_23`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdCorrect, `${prefix}_C1721904_23`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721904_3 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_31`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth258, `${prefix}_C1721904_31`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_32`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth258, `${prefix}_C1721904_32`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_33`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_lenth258, `${prefix}_C1721904_33`) }).thingBulkInstanceBody,
];
const bulkDeviceInstanceDataC1721904_4 = [
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_41`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdError, `${prefix}_C1721904_41`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_42`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdError, `${prefix}_C1721904_42`) }).thingBulkInstanceBody,
	dataBody.thingClassBulkInstanceBody(`${prefix}_C1721904_43`, draftNonDirectDeviceClassData.modelId, { gatewayId: gwInstanceData.thingId, connectId: dataBody.returnName(string_ConnectIdError, `${prefix}_C1721904_43`) }).thingBulkInstanceBody,
];

module.exports = {
	draftDirectDeviceClassData,
	draftGatewayClassData,
	draftNonDirectDeviceClassData,
	draftThingClassPropertiesData,
	activeData,
	msgData,
	gwInstanceData,
	directDeviceInstanceDataC1721893_1,
	directDeviceInstanceDataC1721893_2,
	directDeviceInstanceDataC1721893_3,
	directDeviceInstanceDataC1721894_1,
	directDeviceInstanceDataC1721894_2,
	gatewayInstanceDataC1721896_1,
	gatewayInstanceDataC1721896_2,
	gatewayInstanceDataC1721896_3,
	gatewayInstanceDataC1721897_1,
	gatewayInstanceDataC1721897_2,
	nonDirectDeviceInstanceDataC1721901_1,
	nonDirectDeviceInstanceDataC1721901_2,
	nonDirectDeviceInstanceDataC1721901_3,
	nonDirectDeviceInstanceDataC1721901_4,
	bulkDeviceInstanceDataC1721902_1,
	bulkDeviceInstanceDataC1721902_2,
	bulkDeviceInstanceDataC1721902_3,
	bulkDeviceInstanceDataC1721903_1,
	bulkDeviceInstanceDataC1721903_2,
	bulkDeviceInstanceDataC1721904_1,
	bulkDeviceInstanceDataC1721904_2,
	bulkDeviceInstanceDataC1721904_3,
	bulkDeviceInstanceDataC1721904_4,
};
