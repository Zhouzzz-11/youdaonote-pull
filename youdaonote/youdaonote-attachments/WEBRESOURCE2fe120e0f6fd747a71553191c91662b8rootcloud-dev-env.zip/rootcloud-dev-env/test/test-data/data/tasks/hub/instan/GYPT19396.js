'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

//create device, Add 
const prefix = 'GYPT19396device';
//create compositeThing, Add  and update
const prefix_1 = 'GYPT19396compositeThing_1';
//update compositeThing
const prefix_2 = 'GYPT19396_2';
//create compositeThing, When assertId already exists
const prefix_3 = 'GYPT19396_3';
//update compositeThing
const prefix_4 = 'GYPT19396_4';
//create compositeThing, When assertId is correct and does not exist under this tenant
const prefix_5 = 'GYPT19396_5';
//update compositeThing
const prefix_6 = 'GYPT19396_6';
//create compositeThing, When assertId exists under other tenants
const prefix_7 = 'GYPT19396_7';
//update compositeThing
const prefix_8 = 'GYPT19396_8';

const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const draftCompositeThingClassData_1 = dataBody.draftCompositeThingClassBody(prefix_1, 'compositeThing', draftThingClassData.modelId);
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number');
const thingClassModelInstanceCompositeData_1 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_1, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId);
const updatethingClassModelInstanceCompositeData_1 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_2, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { name: 'name' + random });

const thingClassModelInstanceCompositeData_2 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_3, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { assetId: thingClassModelInstanceCompositeData_1.thingId });
const updatethingClassModelInstanceCompositeData_3 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_4, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { name: 'name1' + random });

const thingClassModelInstanceCompositeData_4 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_5, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { assetId: 'sxcss' });
const updatethingClassModelInstanceCompositeData_5 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_6, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { name: 'name2' + random });

const thingClassModelInstanceCompositeData_6 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_7, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { assetId: 'demo2' });
const updatethingClassModelInstanceCompositeData_7 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_8, draftCompositeThingClassData_1.nodeId, thingClassModelInstanceData.thingId, draftThingClassData.modelId, { name: 'name3' + random });


module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	draftCompositeThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceCompositeData_1,
	updatethingClassModelInstanceCompositeData_1,
	thingClassModelInstanceCompositeData_2,
	updatethingClassModelInstanceCompositeData_3,
	thingClassModelInstanceCompositeData_4,
	updatethingClassModelInstanceCompositeData_5,
	thingClassModelInstanceCompositeData_6,
	updatethingClassModelInstanceCompositeData_7,
};