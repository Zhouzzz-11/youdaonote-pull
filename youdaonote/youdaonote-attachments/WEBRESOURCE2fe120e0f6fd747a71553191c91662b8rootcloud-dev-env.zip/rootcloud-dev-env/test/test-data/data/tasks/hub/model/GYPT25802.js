'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT25802';

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia12', 'Ia', 'Number', { expressionType: 'linear', scale: 0, name: 'Ia12' });
const updatedraftThingClassPropertiesData = dataBody.updateDraftThingClassModelPropertiesBody(prefix, 'Number', 'Ia12', 'Ia', 'Number', draftThingClassPropertiesData.name, { expressionType: 'linear', scale: 0, name: 'Ia12' });
const draftExpressionData = dataBody.postExpressionBody(prefix, { type: 'linear' });
const draftExpressionData_1 = dataBody.postExpressionBody(prefix,);

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	updatedraftThingClassPropertiesData,
	draftExpressionData,
	draftExpressionData_1
};
