'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT23812';
const prefix_1 = 'GYPT23812_1';
const prefix_2 = 'GYPT23812_2';
const prefix_3 = 'GYPT23812_3';
const prefix_4 = 'GYPT23812_4';
const prefix_5 = 'GYPT23812_5';
const prefix_6 = 'GYPT23812_6';
const prefix_7 = 'GYPT23812_7';
const prefix_8 = 'GYPT23812_8';
const prefix_9 = 'GYPT23812_9';
const prefix_10 = 'GYPT23812_10';
const prefix_11 = 'GYPT23812_11';
//thingInfoExtensions
const thingInfoExtensionsData_1 = dataBody.thingInfoExtensions({ name1: 'name1', displayName: 'displayName', type: 'String', value: '"2000W"' });
const thingInfoExtensionsData_2 = dataBody.thingInfoExtensions({ name1: 'name2', displayName: 'displayName', type: 'Number', value: '130' });
const thingInfoExtensionsData_3 = dataBody.thingInfoExtensions({ name1: 'name3', displayName: 'displayName', type: 'Integer', value: '10' });
const thingInfoExtensionsData_4 = dataBody.thingInfoExtensions({ name1: 'name1', displayName: 'displayInteger', type: 'Integer', value: '100' });
//创建物模型_设备_thingInfoExtensions包含多个参数
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device', { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody] });
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix, 'device', { thingInfoExtensions: [thingInfoExtensionsData_3.thingInfoExtensionsBody] });
//修改物模型_未发布状态_thingInfoExtensions增加参数
const draftThingClassData_4 = dataBody.draftThingClassBody(prefix_7, 'device', { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody, thingInfoExtensionsData_3.thingInfoExtensionsBody, thingInfoExtensionsData_2.thingInfoExtensionsBody] });
//修改物模型_未发布状态_thingInfoExtensions删除参数
const draftThingClassData_5 = dataBody.draftThingClassBody(prefix_8, 'device', { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody, thingInfoExtensionsData_3.thingInfoExtensionsBody] });
//添加属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number');
//修改物模型_修改前模型处于已发布状态_thingInfoExtensions修改参数内容
const ThingClassData_2 = dataBody.draftThingClassBody(prefix, 'device', { thingInfoExtensions: [thingInfoExtensionsData_2.thingInfoExtensionsBody] });
//修改物模型_修改前模型处于已发布状态_thingInfoExtensions增加参数
const ThingClassData_6 = dataBody.draftThingClassBody(prefix_9, 'device', { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody, thingInfoExtensionsData_3.thingInfoExtensionsBody, thingInfoExtensionsData_2.thingInfoExtensionsBody] });
//修改物模型_修改前模型处于已发布状态_thingInfoExtensions删除参数
const ThingClassData_7 = dataBody.draftThingClassBody(prefix_10, 'device', { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody] });
//创建物实例_直连设备_thingInfoExtensions包含多个参数
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_4, { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody] });
//修改物实例_thingInfoExtensions修改参数内容（displayName、type和value
const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_11, { thingInfoExtensions: [thingInfoExtensionsData_4.thingInfoExtensionsBody] });
//创建网关模型
const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_1, 'gateway', { thingInfoExtensions: [thingInfoExtensionsData_3.thingInfoExtensionsBody] });
//添加属性
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'temp+1', 'temp', 'Number');
//创建物实例_网关_thingInfoExtensions包含多个参数
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_3, { thingInfoExtensions: [thingInfoExtensionsData_3.thingInfoExtensionsBody] });
//创建复合物模型
const draftcompositeThingClassData = dataBody.draftCompositeThingClassBody(prefix_2, 'compositeThing', draftThingClassData.modelId, { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody] });
//添加属性
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'temp+1', 'temp', 'Number');
//创建物实例_复合物_thingInfoExtensions包含多个参数
const compositeThingInstancesData = dataBody.thingClassModelInstanceCompositeThingBody(prefix_5, draftcompositeThingClassData.nodeId, thingClassModelInstanceData_1.thingId, draftThingClassData.modelId, { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody] });
//创建非直连模型
const draftThingClassData_3 = dataBody.draftThingClassBody(prefix_6, 'device', { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody], directlyLinked: false });
//添加属性
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(prefix_6, 'Number', 'temp+1', 'temp', 'Number');
//创建物实例_非直连_thingInfoExtensions包含多个参数
const thingClassModelInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_6, { thingInfoExtensions: [thingInfoExtensionsData_1.thingInfoExtensionsBody], gatewayId: thingClassModelInstanceData.thingId });

module.exports = {
    thingInfoExtensionsData_1,
    thingInfoExtensionsData_2,
    thingInfoExtensionsData_3,
    thingInfoExtensionsData_4,
    draftThingClassData,
    draftThingClassData_1,
    ThingClassData_2,
    draftThingClassModelPropertiesData,
    thingClassModelInstanceData_1,
    thingClassModelInstanceData_2,
    draftThingClassData_2,
    draftThingClassModelPropertiesData_1,
    draftcompositeThingClassData,
    thingClassModelInstanceData,
    draftThingClassModelPropertiesData_2,
    compositeThingInstancesData,
    draftThingClassData_3,
    draftThingClassModelPropertiesData_3,
    thingClassModelInstanceData_3,
    draftThingClassData_4,
    draftThingClassData_5,
    ThingClassData_6,
    ThingClassData_7
};