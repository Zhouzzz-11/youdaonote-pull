'use strict';

// const Moment = require('moment');
const { dataBody } = require('../../../../comData');

const prefix = 'GYPT28262';
const time = new Date();
const currentTs = parseInt(Date.parse(time)/60000)*60000 + 60000;

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');


// latency less than 0
const draftThingClassPropertiesData1 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'min',
	windowSizeMills: 5000,
	windowStepMills: 1000,
	windowAllowedLatenessMills: -1000,
});

// latency greate than window size
const draftThingClassPropertiesData2 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'min',
	windowSizeMills: 5000,
	windowStepMills: 1000,
	windowAllowedLatenessMills: 8000,
});

// latency window size less than window step
const draftThingClassPropertiesData3 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'min',
	windowSizeMills: 5000,
	windowStepMills: 10000,
	windowAllowedLatenessMills: 1000,
});

// latency window size 8 multiples of window step
const draftThingClassPropertiesData4 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'min',
	windowSizeMills: 8000,
	windowStepMills: 1000,
	windowAllowedLatenessMills: 1000,
});

// window allow latency eq 0 and window size 5 multiples of window step
const draftThingClassPropertiesData5 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'min',
	windowSizeMills: 5000,
	windowStepMills: 1000,
	windowAllowedLatenessMills: 0,
});

const activeData = dataBody.patchActive();
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const msgData1 = dataBody.mesBody({ 'temp': 10 }, { ts: currentTs + 501});
const msgData2 = dataBody.mesBody({ 'temp': 12 }, { ts: currentTs + 3001 });
const msgData3 = dataBody.mesBody({ 'temp': 14 }, { ts: currentTs + 6001 });
const msgList1 = [
	msgData1, msgData2, msgData3
];

// window allow latency eq window size and window step
const prefix6 = 'GYPT28262_6';
const draftThingClassData6 = dataBody.draftThingClassBody(prefix6, 'device');
const draftThingClassPropertiesData6 = dataBody.draftThingClassModelPropertiesBody(prefix6, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'min',
	windowSizeMills: 5000,
	windowStepMills: 5000,
	windowAllowedLatenessMills: 5000,
});
const thingInstanceData6 = dataBody.thingClassModelInstanceBody(prefix6);
const msgData21 = dataBody.mesBody({ 'temp': 10 }, { ts: currentTs + 501});
const msgData22 = dataBody.mesBody({ 'temp': 12 }, { ts: currentTs + 3001 });
const msgData23 = dataBody.mesBody({ 'temp': 16 }, { ts: currentTs + 11001 });
const msgList2 = [
	msgData21, msgData22, msgData23
];

// window allow latency between 0 and window size, window size is 5 and window step is 2
const prefix7 = 'GYPT28262_7';
const draftThingClassData7 = dataBody.draftThingClassBody(prefix7, 'device');
const draftThingClassPropertiesData7 = dataBody.draftThingClassModelPropertiesBody(prefix7, 'Number', 'temp + 1', 'temp', 'Number', {
	expressionType: 'window',
	operator: 'sum',
	windowSizeMills: 5000,
	windowStepMills: 2000,
	windowAllowedLatenessMills: 3000,
});
const thingInstanceData7 = dataBody.thingClassModelInstanceBody(prefix7);
const msgData31 = dataBody.mesBody({ 'temp': 0 }, { ts: currentTs + 501 });
const msgData32 = dataBody.mesBody({ 'temp': 1 }, { ts: currentTs + 3001 });
const msgData33 = dataBody.mesBody({ 'temp': 3 }, { ts: currentTs + 1001 });
const msgData34 = dataBody.mesBody({ 'temp': 16 }, { ts: currentTs + 9000 });
const msgData35 = dataBody.mesBody({ 'temp': 7 }, { ts: currentTs + 2001 });
const msgList3 = [
	msgData31, msgData32, msgData33, msgData34, msgData35
];

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData1,
	draftThingClassPropertiesData2,
	draftThingClassPropertiesData3,
	draftThingClassPropertiesData4,
	draftThingClassPropertiesData5,
	activeData,
	thingInstanceData,
	draftThingClassData6,
	draftThingClassPropertiesData6,
	thingInstanceData6,
	draftThingClassData7,
	draftThingClassPropertiesData7,
	thingInstanceData7,
	msgList1,
	msgList2,
	msgList3
};
