'use strict';
const { dataBody } = require('../../../../comData');

const prefix = 'GYPT30961';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp1+1', 'temp1', 'Number');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', 'temp2+1', 'temp2', 'Number');

const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(`${prefix}_2`);
const msgData = dataBody.mesBody({ 'temp1': 10 });
const msgData_1 = dataBody.mesBody({ 'temp2': 20 });

module.exports = {
    draftThingClassData,
    draftThingClassModelPropertiesData,
    draftThingClassModelPropertiesData_1,
    thingClassModelInstanceData,
    msgData,
    msgData_1
};
