'use strict';

const { dataBody } = require('../../../../comData');

const prefix_1 = 'GYPT21527_1';
const prefix_2 = 'GYPT21527_2';
const prefix_3 = 'GYPT21527_3';
//创建3个设备类型
//发布，tag不为空
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');
//发布, tag为空
const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device');
//未发布, tag不为空
const draftThingClassData_3 = dataBody.draftThingClassBody(prefix_3, 'device');
//属性添加编号与物模型一一对应
const draftThingClassPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'temp + 1', 'temp', 'Number', {displayName: '温度', unit: '摄氏度', tags: ['电表温度', '表盘温度']});
const draftThingClassPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'temp + 1', 'temp', 'Number');
const draftThingClassPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(prefix_3, 'Number', 'temp + 1', 'temp', 'Number', {displayName: '温度', unit: '摄氏度', tags: ['电表温度', '表盘温度']});

module.exports = {
	draftThingClassData_1,
	draftThingClassData_2,
	draftThingClassData_3,
	draftThingClassPropertiesData_1,
	draftThingClassPropertiesData_2,
	draftThingClassPropertiesData_3,
};