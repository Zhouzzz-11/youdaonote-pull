'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const header = { 'Authorization': '' };
let saveToken = { superUserToken: '', userToken: '', commonUserToken: '' };
const userToken = 'userToken';
const superUserToken = 'superUserToken';
const commonUserToken = 'commonUserToken';

const prefix = 'GYPT13473';
const prefix_1 = 'GYPT13473_1';

//添加
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');     //物模型
const thingInstanceData1 = dataBody.thingClassModelInstanceBody( prefix );         //设备1
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });

//设备权限集
const postDevicePermissionData1 = dataBody.devicePermissionBody({ modelId: draftThingClassData.modelId, uuid: thingInstanceData1.thingId, field1: 'assetId', access1: 1, field2: 'name', access2: 2, field3: 'userName', access3: 3, field4: 'classId', access4: 4 });    //可读 可写 读写 不可读写

//更新
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const updateThingInstanceData = dataBody.thingClassModelInstanceBody(prefix_1, { name: 'deviceName' + random });      //设备
const updateThingInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_1, { username: 'deviceUserName' + random });      //设备

module.exports = {
	draftThingClassData,
	thingInstanceData1,
	userToken,
	saveToken,
	header,
	superUserToken,
	postDevicePermissionData1,
	updateThingInstanceData,
	updateThingInstanceData1,
	commonUserToken,
	draftThingClassModelPropertiesData
};