'use strict';

const { dataBody } = require('../../../../comData');

const Moment = require('moment');
const prefix = 'GYPT29585';

const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'gateway');
const draftThingClassModelPropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number', { name: 'temp' });
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$connect("__online__", false)', '__online__', 'Json', { name: '__online__', displayName: '在线状态' });
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
//创建模型，模型已有预置属性__online__，且是启用状态
const draftThingClassData_1 = dataBody.draftThingClassBody(`${prefix}_1`, 'device', { directlyLinked: false });
//非直连模型__online__属性的表达式中，值默认是true
const draftThingClassData_2 = dataBody.draftThingClassBody(`${prefix}_2`, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Json', '$connect("__online__", true)', '__online__', 'Json', { name: '__online__', displayName: '在线状态' });
//从未上数的设备，则__online__没有值，firstDataTime没有值。设备状态是未激活
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}_1`, { gatewayId: thingClassModelInstanceData.thingId, connectId: 'connectId_' + random });
const activeData = dataBody.patchActive();
//const properties = { updated: true, connected: true }
//const msgData = dataBody.mesBody({ '__online__': properties }, { id: thingClassModelInstanceData_1.connectId });
const msgData = dataBody.mesBody({ 'temp': 23 }, { id: thingClassModelInstanceData_1.connectId });
//__online__参与报警，正确触发报警
const draftThingClassData_3 = dataBody.draftThingClassBody(`${prefix}_3`, 'device', { directlyLinked: false });
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_5`, 'Number', 'Ia1', 'Ia1', 'Number', { name: 'Ia1' });
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_3`, 'Json', '$connect("__online__", true)', '__online__', 'Json', { name: '__online__', displayName: '在线状态' });
const postAlarmCategories = dataBody.alarmCategoriesBody(prefix);
const level = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 80)) - Math.round(Math.random() * 2000);
const postAlarmSeverities = dataBody.alarmSeverities(prefix, parseInt(level));
const postAlarmTypeData = dataBody.alarmTypeBody(`${prefix}_4`, [postAlarmCategories.cid], postAlarmSeverities.level, draftThingClassData_3.modelId, 'Ia1 >= 50', 'everyTime', 'PLATFORM');
const thingClassModelInstanceData_3 = dataBody.thingClassModelInstanceBody(`${prefix}_3`, { gatewayId: thingClassModelInstanceData.thingId, connectId: 'connectId_1' + random });
const msgData_1 = dataBody.mesBody({ 'Ia1': 56 }, { id: thingClassModelInstanceData_3.connectId });
//离线检测周期默认是60s
const draftThingClassData_4 = dataBody.draftThingClassBody(`${prefix}_2`, 'device', { directlyLinked: false, offlineCheckPeriod: 60000 });
//离线检测周期小于60s，给出错误提示
const draftThingClassData_5 = dataBody.draftThingClassBody(`${prefix}_2`, 'device', { directlyLinked: false, offlineCheckPeriod: 30000 });

module.exports = {
    draftThingClassData,
    draftThingClassModelPropertiesData,
    draftThingClassModelPropertiesData_4,
    thingClassModelInstanceData,
    draftThingClassData_1,
    thingClassModelInstanceData_1,
    draftThingClassData_2,
    draftThingClassModelPropertiesData_1,
    activeData,
    msgData,
    draftThingClassData_3,
    postAlarmCategories,
    postAlarmSeverities,
    draftThingClassModelPropertiesData_2,
    draftThingClassModelPropertiesData_3,
    postAlarmTypeData,
    thingClassModelInstanceData_3,
    msgData_1,
    draftThingClassData_4,
    draftThingClassData_5
};