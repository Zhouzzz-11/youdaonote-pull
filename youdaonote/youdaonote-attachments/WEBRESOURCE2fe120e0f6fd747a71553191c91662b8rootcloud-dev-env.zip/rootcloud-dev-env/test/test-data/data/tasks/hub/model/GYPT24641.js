'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT24641';

//precondition
const ThingClassData_1 = dataBody.draftThingClassBody(`${prefix}_1`, 'device');
const CompositeThingData = dataBody.draftCompositeThingClassBody(`${prefix}_c_1`, 'compositeThing',ThingClassData_1.modelId, {'nodeType': 'MultipleDeviceNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const temp_option = {'name':`${prefix}`, 'displayName':`${prefix}`,'expressionType':'linear', 'scale': 1, 'base': 2};
const PropertiesData = dataBody.draftThingClassModelPropertiesBody(`${prefix}`, 'Number',`1*${prefix}+2` , 'temp' ,'Number' ,temp_option);
const deviceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}_1`);
const deviceData_2 = dataBody.thingClassModelInstanceBody(`${prefix}_2`);
const deviceData_3 = dataBody.thingClassModelInstanceBody(`${prefix}_3`);
const multi_device = [{'thingId': deviceData_2.thingId, 'modelId': ThingClassData_1.modelId}, {'thingId': deviceData_3.thingId, 'modelId': ThingClassData_1.modelId}];
const compositeDeviceData = dataBody.thingClassModelInstanceCompositeThingBody(`${prefix}_c_1`, 'dt', deviceData_1.thingId, ThingClassData_1.modelId, multi_device);

//data
const postdata = dataBody.mesBody({'temp': 1 });

//C2076446
const C_temp_option = {'name':`${prefix}_c`, 'displayName':`${prefix}_c`,'expressionType':'groovy'};
const C_PropertiesData = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c`, 'Number', `$child("sum", "dt", "${prefix}")`, '' ,'Number' , C_temp_option);

//C2076447
const C_temp_option_1 = {'name':`${prefix}_c_1`, 'displayName':`${prefix}_c_1`,'expressionType':'groovy'};
const C_PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_1`, 'Number', `$child("count", "dt", "${prefix}")`, '' ,'Number' , C_temp_option_1);

//C2076448
const C_temp_option_2 = {'name':`${prefix}_c_2`, 'displayName':`${prefix}_c_2`,'expressionType':'groovy'};
const C_PropertiesData_2= dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_2`, 'Number', `$child("avg", "dt", "${prefix}")`, '' ,'Number' , C_temp_option_2);

//C2076449
const C_temp_option_3 = {'name':`${prefix}_c_3`, 'displayName':`${prefix}_c_3`,'expressionType':'groovy'};
const C_PropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_3`, 'Number', `$child("min", "dt", "${prefix}")`, '' ,'Number' , C_temp_option_3);

//C2076450
const C_temp_option_4 = {'name':`${prefix}_c_4`, 'displayName':`${prefix}_c_4`,'expressionType':'groovy'};
const C_PropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_4`, 'Number', `$child("max", "dt", "${prefix}")`, '' ,'Number' , C_temp_option_4);

//C2076451
const C_temp_option_5 = {'name':`${prefix}_c_5`, 'displayName':`${prefix}_c_5`,'expressionType':'groovy'};
const C_PropertiesData_5 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_5`, 'Number', `$child("dev", "dt", "${prefix}")`, '' ,'Number' , C_temp_option_5);

//C2076452
const C_temp_option_6 = {'name':`${prefix}_c_6`, 'displayName':`${prefix}_c_6`,'expressionType':'groovy'};
const C_PropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_6`, 'Number', `$child("range", "dt", "${prefix}")`, '' ,'Number' , C_temp_option_6);

//C2074774
const C_temp_option_7 = {'name':`${prefix}_c_7`, 'displayName':`${prefix}_c_7`,'expressionType':'groovy'};
const C_PropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_c_7`, 'String', `$child("sum", "dt", "${prefix}")`, '' ,'String' , C_temp_option_7);

module.exports = {
	ThingClassData_1,
	CompositeThingData,
	C_PropertiesData,
	C_PropertiesData_1,
	C_PropertiesData_2,
	C_PropertiesData_3,
	C_PropertiesData_4,
	C_PropertiesData_5,
	C_PropertiesData_6,
	C_PropertiesData_7,
	compositeDeviceData,
	PropertiesData,
	postdata,
	deviceData_1,
	deviceData_2,
	deviceData_3,
};