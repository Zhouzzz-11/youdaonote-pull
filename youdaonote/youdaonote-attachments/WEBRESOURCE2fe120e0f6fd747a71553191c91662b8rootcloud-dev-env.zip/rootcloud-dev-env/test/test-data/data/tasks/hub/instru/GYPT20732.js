'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT20732';
const prefix_1 = 'GYPT20732_1';
const prefix_11 = 'GYPT20732_11';
const prefix_12 = 'GYPT20732_12';
const prefix_13 = 'GYPT20732_13';
const prefix_14 = 'GYPT20732_14';
const prefix_15 = 'GYPT20732_15';
const prefix_16 = 'GYPT20732_16';
const prefix_2 = 'GYPT20732_2';
const prefix_3 = 'GYPT20732_3';
const timestamp = Date.parse(new Date());

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//直连设备
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_11);
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_12);
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_13);
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_14);
const thingInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_15);
const thingInstanceData_6 = dataBody.thingClassModelInstanceBody(prefix_15);
//添加网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');
//网关设备
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
//非直连物模型
const draftThingClassData1 = dataBody.draftThingClassBody(prefix_3, 'device', { directlyLinked: false });
//非直连设备
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_3, { connectId: 'connectId', gatewayId: thingClassModelInstanceData2.thingId });

let files = { 'files': [{'key': '<string>', name: '<string>', 'source': '<string>', 'encode': 'dd', 'zip': '', 'size': 1024, 'md5': '<string>'}] };

//直连设备指令下发
const instructionRequestsData = dataBody.thingInstructionRequestsBody(prefix, files, undefined, undefined, thingInstanceData.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_1 = dataBody.thingInstructionRequestsBody(prefix_11, files, undefined, undefined, thingInstanceData_1.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_2 = dataBody.thingInstructionRequestsBody(prefix_12, files, undefined, undefined, thingInstanceData_2.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_3 = dataBody.thingInstructionRequestsBody(prefix_14, files, undefined, undefined, thingInstanceData_3.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_4 = dataBody.thingInstructionRequestsBody(prefix_15, files, undefined, undefined, thingInstanceData_4.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_5 = dataBody.thingInstructionRequestsBody(prefix_3, files, undefined, undefined, thingInstanceData_5.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });
const instructionRequestsData_6 = dataBody.thingInstructionRequestsBody(prefix_16, files, undefined, undefined, thingInstanceData_6.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 60000 });

//网关设备指令下发
const instructionRequestsData2 = dataBody.thingInstructionRequestsBody(prefix_2, files, undefined, undefined, thingClassModelInstanceData2.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 10000 });

//非直连设备指令下发
const instructionRequestsData1 = dataBody.thingInstructionRequestsBody(prefix_1, files, undefined, undefined, thingClassModelInstanceData1.thingId, { type: 'FILE_SET', trigger: 'realTime', timeout: 10000 });

//直连设备响应
const responseData = dataBody.filesInstructionBody(instructionRequestsData_1.requestId, timestamp, { isAck: false, isCompleted: false });
const responseData1 = dataBody.filesInstructionBody(instructionRequestsData_2.requestId, timestamp);
const responseData2 = dataBody.filesInstructionBody(instructionRequestsData_3.requestId, timestamp, { isAck: false });
const responseData3 = dataBody.filesInstructionBody(instructionRequestsData_4.requestId, timestamp, { isCompleted: false, isAck: false });
const responseData4 = dataBody.filesInstructionBody(instructionRequestsData_5.requestId, timestamp, { isAck: false });
const responseData5 = dataBody.filesInstructionBody(instructionRequestsData_6.requestId, timestamp, { isAck: false, isCompleted: false });
const responseData6 = dataBody.filesInstructionBody(instructionRequestsData_6.requestId, timestamp, { isAck: false });

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	thingInstanceData,
	draftThingClassData1,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2,
	instructionRequestsData_5,
	thingInstanceData_5,
	thingInstanceData_6,
	instructionRequestsData,
	thingInstanceData_3,
	thingInstanceData_4,
	responseData5,
	responseData6,
	responseData,
	responseData1,
	responseData2,
	responseData3,
	responseData4,
	thingInstanceData_2,
	instructionRequestsData1,
	instructionRequestsData_2,
	instructionRequestsData_4,
	instructionRequestsData_3,
	instructionRequestsData_6,
	instructionRequestsData2,
	thingInstanceData_1,
	instructionRequestsData_1,
};
