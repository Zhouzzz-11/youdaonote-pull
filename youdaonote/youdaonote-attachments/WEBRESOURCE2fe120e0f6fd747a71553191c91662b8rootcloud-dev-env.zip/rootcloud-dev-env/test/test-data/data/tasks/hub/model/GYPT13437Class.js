'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

//添加设备
const prefix = 'GYPT13437';         //设备1
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassWrongThingTypeData = dataBody.draftThingClassBody(prefix, 'devi');
const draftThingClassNoThingTypeData = dataBody.draftThingClassBody(prefix, '');
const prefix_4 = 'GYPT13437_4';     //设备2
const draftThingClassData2 = dataBody.draftThingClassBody(prefix_4, 'device');
const prefix_3 = 'GYPT13437_3';     //未发布设备1
const unpublishDraftThingClassData = dataBody.draftThingClassBody(prefix_3, 'device');
const prefix_10 = 'GYPT13437_10';     //未发布设备2
const unpublishDraftThingClassData1 = dataBody.draftThingClassBody(prefix_10, 'device');
const prefix_18 = 'GYPT13437_18';     //未发布设备3
const unpublishDraftThingClassData2 = dataBody.draftThingClassBody(prefix_18, 'device');

//添加网关
const prefix_1 = 'GYPT13437_1';     //网关1
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_1, 'gateway');
const prefix_11 = 'GYPT13437_11';     //未发布网关1
const unpublishDraftGatewayClassData = dataBody.draftThingClassBody(prefix_11, 'gateway');
const prefix_5 = 'GYPT13437_5';     //网关2
const draftGatewayClassData2 = dataBody.draftThingClassBody(prefix_5, 'gateway');
const prefix_19 = 'GYPT13437_19';     //网关3
const draftGatewayClassData3 = dataBody.draftThingClassBody(prefix_19, 'gateway');

//添加复合物
const prefix_2 = 'GYPT13437_2';     //复合物1
const draftCompositeThingClassData = dataBody.draftCompositeThingClassBody(prefix_2, 'compositeThing', draftThingClassData.modelId);
const prefix_6 = 'GYPT13437_6';     //复合物2
const draftCompositeThingClassData2 = dataBody.draftCompositeThingClassBody(prefix_6, 'compositeThing', draftThingClassData.modelId);
const prefix_12 = 'GYPT13437_12';     //未发布复合物2
const draftCompositeThingClassData3 = dataBody.draftCompositeThingClassBody(prefix_12, 'compositeThing', draftThingClassData.modelId);
const prefix_14 = 'GYPT13437_14';     //复合物2
const draftCompositeThingClassData4 = dataBody.draftCompositeThingClassBody(prefix_14, 'compositeThing', draftThingClassData.modelId);
const prefix_16 = 'GYPT13437_16';     //复合物3
const draftCompositeThingClassData5 = dataBody.draftCompositeThingClassBody(prefix_16, 'compositeThing', draftThingClassData.modelId);
const prefix_20 = 'GYPT13437_20';     //复合物3
const draftCompositeThingClassData6 = dataBody.draftCompositeThingClassBody(prefix_20, 'compositeThing', draftThingClassData.modelId);

//更新
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const prefix_7 = 'GYPT13437_7';     //更新设备
const updateDraftThingClassData = dataBody.draftThingClassBody(prefix_7, 'device', { name: 'testdevice' + random });
const prefix_8 = 'GYPT13437_8';     //更新网关
const updateDraftGatewayClassData = dataBody.draftThingClassBody(prefix_8, 'gateway', { name: 'testgateway' + random });
const prefix_9 = 'GYPT13437_9';     //更新复合物
const updateDraftCompositeThingClassData = dataBody.draftCompositeThingClassBody(prefix_9, 'compositeThing', draftThingClassData.modelId, { name: 'testcompositeThing' + random });

//添加设备
const prefix_13 = 'GYPT13437_13';
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_13);

//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const prefix_17 = 'GYPT13437_17';
const draftThingClassModelPropertiesData2 = dataBody.draftThingClassModelPropertiesBody(prefix_17, 'Number', 'Iq', 'Iq', 'Number');
const prefix_15 = 'GYPT13437_15';
const draftThingClassModelPropertiesData1 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_15, 'Number', 'Io', 'Io', 'Number', draftThingClassModelPropertiesData.name, { name: 'testupdateproperties' });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	draftGatewayClassData,
	draftCompositeThingClassData,
	draftThingClassNoThingTypeData,
	draftThingClassWrongThingTypeData,
	unpublishDraftThingClassData,
	draftThingClassData2,
	draftGatewayClassData2,
	draftCompositeThingClassData2,
	updateDraftThingClassData,
	updateDraftGatewayClassData,
	updateDraftCompositeThingClassData,
	unpublishDraftThingClassData1,
	unpublishDraftGatewayClassData,
	draftCompositeThingClassData3,
	thingClassModelInstanceData,
	draftCompositeThingClassData4,
	draftThingClassModelPropertiesData1,
	draftCompositeThingClassData5,
	draftThingClassModelPropertiesData2,
	unpublishDraftThingClassData2,
	draftGatewayClassData3,
	draftCompositeThingClassData6
};
