'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const number = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));


const prefix = 'GYPT28261';
const prefix_2 = 'GYPT28261_2';
const prefix_10 = 'GYPT28261_10';
const prefix_11 = 'GYPT28261_11';
const prefix_12 = 'GYPT28261_12';
const prefix_14 = 'GYPT28261_14';
const prefix_15 = 'GYPT28261_15';
const prefix_16 = 'GYPT28261_16';
const prefix_19 = 'GYPT28261_19';
const prefix_26 = 'GYPT28261_26';
const prefix_27 = 'GYPT28261_27';
const prefix_28 = 'GYPT28261_28';
const prefix_29 = 'GYPT28261_29';
const prefix_30 = 'GYPT28261_30';
const prefix_31 = 'GYPT28261_31';
const prefix_32 = 'GYPT28261_32';


const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const postDraftThingInterfacesData = dataBody.draftThingInterfacesBody(prefix);
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);


const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', `Ia_${number}`, 'Number', { expressionType: 'direct' });
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'Ia', `Ia_${number}1`, 'Number', { expressionType: 'direct', fromProperty: ' '});
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_10, 'Number', 'Ia', `Ia_${number}2`, 'Number', { expressionType: 'linear',scale: 1,base: 1});
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(prefix_11, 'Number', 'Ia', `Ia_${number}10`, 'Number', { expressionType: 'linear'});
const draftThingClassModelPropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(prefix_12, 'Number', 'Ia', `Ia_${number}11`, 'Number', { expressionType: 'linear',scale: 1,base: 1});
const draftThingClassModelPropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(prefix_14, 'Array', 'Ia', `Ia_${number}13`, 'Array', { expressionType: 'linear',scale: 1,base: 1});
const draftThingClassModelPropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', `temp`, 'Number', { expressionType: 'direct',displayName:'displayname'});
const draftThingClassModelPropertiesData_8 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', `temp`, 'Number', { expressionType: 'linear',scale: 1,base: 1});


const updatedraftThingClassModelPropertiesData = dataBody.updateDraftThingClassModelPropertiesBody(prefix, 'Integer', 'Ia', `Ia_${number}14`, 'Number', draftThingClassModelPropertiesData.thingPropertiesBody[0].name, { expressionType: 'direct' });
const updatedraftThingClassModelPropertiesData_1 = dataBody.updateDraftThingClassModelPropertiesBody(prefix, 'Integer', 'Ia', `Ia_${number}15`, 'Number', draftThingClassModelPropertiesData.thingPropertiesBody[0].name, { expressionType: 'direct', fromProperty: ' ' });
const updatedraftThingClassModelPropertiesData_2 = dataBody.updateDraftThingClassModelPropertiesBody(prefix, 'String', 'Ia', `Ia_${number}16`, 'String', draftThingClassModelPropertiesData.thingPropertiesBody[0].name, { expressionType: 'direct'});
const updatedraftThingClassModelPropertiesData_3 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Number', 'Ia', `Ia_${number}17`, 'Number', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});
const updatedraftThingClassModelPropertiesData_4 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Number', 'Ia', `Ia_${number}18`, 'Number', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear'});
const updatedraftThingClassModelPropertiesData_5 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'String', 'Ia', `Ia_${number}19`, 'String', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});
const updatedraftThingClassModelPropertiesData_6 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Array', 'Ia', `Ia_${number}20`, 'Array', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});
const updatedraftThingClassModelPropertiesData_7 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Boolean', 'Ia', `Ia_${number}21`, 'Boolean', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});
const updatedraftThingClassModelPropertiesData_8 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Json', 'Ia', `Ia_${number}22`, 'Json', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});
const updatedraftThingClassModelPropertiesData_9 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Binary', 'Ia', `Ia_${number}23`, 'Binary', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});
const updatedraftThingClassModelPropertiesData_10 = dataBody.updateDraftThingClassModelPropertiesBody(prefix_10, 'Number', 'Ia', `Ia_${number}24`, 'Number', draftThingClassModelPropertiesData_2.thingPropertiesBody[0].name, { expressionType: 'linear',scale: 1,base: 1});

const postDraftThingInterfacesPropertiesData = dataBody.draftThingInterfacesPropertiesBody(prefix_15, 'Number', 'Ia', `Ia_${number}25`, 'Number', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}1`});
const postDraftThingInterfacesPropertiesData_1 = dataBody.draftThingInterfacesPropertiesBody(prefix_16, 'Number', 'Ia', `Ia_${number}26`, 'Number', { expressionType: 'direct',fromProperty: `Ia_${number}1`});
const postDraftThingInterfacesPropertiesData_2 = dataBody.draftThingInterfacesPropertiesBody(prefix_19, 'Number', 'Ia', `Ia_${number}27`, 'Number', { expressionType: 'direct',fromProperty: ''});
const postDraftThingInterfacesPropertiesData_3 = dataBody.draftThingInterfacesPropertiesBody(prefix_26, 'Number', 'Ia', `Ia_${number}28`, 'Number', { expressionType: 'linear',fromProperty: `Ia_${number}2`});
const postDraftThingInterfacesPropertiesData_4 = dataBody.draftThingInterfacesPropertiesBody(prefix_27, 'Number', 'Ia', `Ia_${number}29`, 'Number', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}3`});
const postDraftThingInterfacesPropertiesData_5 = dataBody.draftThingInterfacesPropertiesBody(prefix_28, 'String', 'Ia', `Ia_${number}30`, 'String', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}4`});
const postDraftThingInterfacesPropertiesData_6 = dataBody.draftThingInterfacesPropertiesBody(prefix_29, 'Array', 'Ia', `Ia_${number}31`, 'Array', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}5`});
const postDraftThingInterfacesPropertiesData_7 = dataBody.draftThingInterfacesPropertiesBody(prefix_30, 'Boolean', 'Ia', `Ia_${number}32`, 'Boolean', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}6`});
const postDraftThingInterfacesPropertiesData_8 = dataBody.draftThingInterfacesPropertiesBody(prefix_31, 'Json', 'Ia', `Ia_${number}33`, 'Json', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}7`});
const postDraftThingInterfacesPropertiesData_9 = dataBody.draftThingInterfacesPropertiesBody(prefix_32, 'Binary', 'Ia', `Ia_${number}34`, 'Binary', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}8`});

const updatedDraftThingInterfacesPropertiesData = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData_1.name, dataBody.draftThingInterfacesPropertiesBody(prefix_16, 'Integer', 'Ia', `Ia_${number}26`, 'Integer', { expressionType: 'direct',fromProperty: `Ia_${number}1`}).thingInterfaceProperitesBody);
const updatedDraftThingInterfacesPropertiesData_1 = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData_1.name, dataBody.draftThingInterfacesPropertiesBody(prefix_16, 'Number', 'Ia', `Ia_${number}27`, 'Number', { expressionType: 'direct',fromProperty: ''}).thingInterfaceProperitesBody);
const updatedDraftThingInterfacesPropertiesData_2 = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData_1.name, dataBody.draftThingInterfacesPropertiesBody(prefix_16, 'Array', 'Ia', `Ia_${number}27`, 'Array', { expressionType: 'direct',fromProperty: `Ia_${number}1`}).thingInterfaceProperitesBody);
const updatedDraftThingInterfacesPropertiesData_3 = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData.name, dataBody.draftThingInterfacesPropertiesBody(prefix_15, 'Number', 'Ia', `Ia_${number}228`, 'Number', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}1`}).thingInterfaceProperitesBody);
const updatedDraftThingInterfacesPropertiesData_4 = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData.name, dataBody.draftThingInterfacesPropertiesBody(prefix_15, 'Number', 'Ia', `Ia_${number}29`, 'Number', { expressionType: 'linear',fromProperty: `Ia_${number}1`}).thingInterfaceProperitesBody);
const updatedDraftThingInterfacesPropertiesData_5 = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData.name, dataBody.draftThingInterfacesPropertiesBody(prefix_15, 'Array', 'Ia', `Ia_${number}29`, 'Array', { expressionType: 'linear',scale: 1,base: 1,fromProperty: `Ia_${number}1`}).thingInterfaceProperitesBody);


const propertyTypeList = ['Number', 'Integer', 'Boolean', 'String', 'Json', 'Array', 'Binary'];

const multipleDirectTypeProperties = [];
const directTypeAllDataType = [];
const interfaceMultipleDirectTypeProperties = [];
const interfaceDirectTypeAllDataType = [];

for (let i = 0; i < 2; i++) {
	multipleDirectTypeProperties.push((dataBody.draftThingClassModelPropertiesBody(`GYPT28261_${i}`, 'Number', 'Ia', `Ia_${number}${i}`, 'Number', { expressionType: 'direct' })).thingPropertiesBody[0]);
}

for (let i = 3; i < 10; i++){
	directTypeAllDataType.push((dataBody.draftThingClassModelPropertiesBody(`GYPT28261_${i}`, propertyTypeList[i-3], 'Ia', `Ia_${number}${i}`, propertyTypeList[i-3], { expressionType: 'direct' })).thingPropertiesBody[0]);
}

for (let i = 17; i < 19; i++) {
	interfaceMultipleDirectTypeProperties.push((dataBody.draftThingInterfacesPropertiesBody(`GYPT28261_${i}`, 'Number', 'Ia', `Ia_${number}${i}`, 'Number', { expressionType: 'direct',fromProperty: `Ia_${number}${i}`})).thingInterfaceProperitesBody[0]);
}

for (let i = 20; i < 26; i++){
	interfaceDirectTypeAllDataType.push((dataBody.draftThingInterfacesPropertiesBody(`GYPT28261_${i}`, propertyTypeList[i-20], 'Ia', `Ia_${number}${i}`, propertyTypeList[i-20], { expressionType: 'direct',fromProperty: `Ia_1${number}${i}`})).thingInterfaceProperitesBody[0]);
}

const msgData = dataBody.mesBody({'temp': 20});

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	multipleDirectTypeProperties,
	draftThingClassModelPropertiesData_1,
	directTypeAllDataType,
	draftThingClassModelPropertiesData_2,
	draftThingClassModelPropertiesData_3,
	draftThingClassModelPropertiesData_4,
	draftThingClassModelPropertiesData_6,
	updatedraftThingClassModelPropertiesData,
	updatedraftThingClassModelPropertiesData_1,
	updatedraftThingClassModelPropertiesData_2,
	updatedraftThingClassModelPropertiesData_3,
	updatedraftThingClassModelPropertiesData_4,
	updatedraftThingClassModelPropertiesData_5,
	updatedraftThingClassModelPropertiesData_6,
	updatedraftThingClassModelPropertiesData_7,
	updatedraftThingClassModelPropertiesData_8,
	updatedraftThingClassModelPropertiesData_9,
	updatedraftThingClassModelPropertiesData_10,
	postDraftThingInterfacesData,
	postDraftThingInterfacesPropertiesData,
	postDraftThingInterfacesPropertiesData_1,
	interfaceMultipleDirectTypeProperties,
	postDraftThingInterfacesPropertiesData_2,
	interfaceDirectTypeAllDataType,
	postDraftThingInterfacesPropertiesData_3,
	postDraftThingInterfacesPropertiesData_4,
	postDraftThingInterfacesPropertiesData_5,
	postDraftThingInterfacesPropertiesData_6,
	postDraftThingInterfacesPropertiesData_7,
	postDraftThingInterfacesPropertiesData_8,
	postDraftThingInterfacesPropertiesData_9,
	updatedDraftThingInterfacesPropertiesData,
	updatedDraftThingInterfacesPropertiesData_1,
	updatedDraftThingInterfacesPropertiesData_2,
	updatedDraftThingInterfacesPropertiesData_3,
	updatedDraftThingInterfacesPropertiesData_4,
	updatedDraftThingInterfacesPropertiesData_5,
	thingClassModelInstanceData,
	msgData,
	draftThingClassModelPropertiesData_7,
	draftThingClassModelPropertiesData_8,

};