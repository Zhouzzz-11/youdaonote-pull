'use strict';

const { dataBody } = require('../../../../comData');
const { getDeployerBody } = require('../../../adeployer/deployer');
const { bp } = require('../../../../blueprint');

const prefix = 'GYPT19700';
const prefix_1 = 'GYPT19700_1';
const prefix_2 = 'GYPT19700_2';
const prefix_3 = 'GYPT19700_3';
const prefix_4 = 'GYPT19700_4';
const prefix_5 = 'GYPT19700_5';
const prefix_6 = 'GYPT19700_6';
const prefix_7 = 'GYPT19700_7';
const prefix_8 = 'GYPT19700_8';
const prefix_9 = 'GYPT19700_9';
const prefix_10 = 'GYPT19700_10';
const prefix_11 = 'GYPT19700_11';
const prefix_12 = 'GYPT19700_12';
const prefix_13 = 'GYPT19700_13';


const draftDeviceThingClassData_1 = dataBody.draftThingClassBody(prefix, 'device');
const draftDeviceThingClassData_2 = dataBody.draftThingClassBody(prefix_1, 'device', {name: draftDeviceThingClassData_1.name});

const draftGatewayThingClassData_1 = dataBody.draftThingClassBody(prefix_2, 'gateway');
const draftGatewayThingClassData_2 = dataBody.draftThingClassBody(prefix_3, 'gateway', {name: draftGatewayThingClassData_1.name});

const draftGatewayThingClassData_3 = dataBody.draftThingClassBody(prefix_4, 'gateway', {name: draftDeviceThingClassData_1.name});

const draftThingInterfaceData_1 = dataBody.draftThingInterfacesBody(prefix_5);
const draftThingInterfaceData_2 = dataBody.draftThingInterfacesBody(prefix_6, {name: draftThingInterfaceData_1.name});
const draftThingInterfaceData_3 = dataBody.draftThingInterfacesBody(prefix_7,{name: draftDeviceThingClassData_1.name});
const draftThingInterfaceData_4 = dataBody.draftThingInterfacesBody(prefix_8,{name:draftGatewayThingClassData_1.name});
//create another tenant
const deployerBody = getDeployerBody({tenantId: 'qwe1'});
const deleteDeployerBody = {'tenantId': 'qwe1'};
const headers = { 'X-RCD-Tenant-Id': 'qwe1', 'Authorization': bp.userToken };
const draftDeviceThingClassData_3 = dataBody.draftThingClassBody(prefix_9, 'device',{name: draftDeviceThingClassData_1.name});
const draftThingInterfaceData_5 = dataBody.draftThingInterfacesBody(prefix_10,{name: draftThingInterfaceData_1.name});
const draftDeviceThingClassData_4 = dataBody.draftThingClassBody(prefix_13, 'device');
const draftThingInterfaceData_6 = dataBody.draftThingInterfacesBody(prefix_11,{name: draftDeviceThingClassData_4.name});
const draftThingInterfaceData_7 = dataBody.draftThingInterfacesBody(prefix_12,{name: draftGatewayThingClassData_1.name});



module.exports = {
	draftDeviceThingClassData_1,
	draftDeviceThingClassData_2,
	draftGatewayThingClassData_1,
	draftGatewayThingClassData_2,
	draftGatewayThingClassData_3,
	draftThingInterfaceData_1,
	draftThingInterfaceData_2,
	draftThingInterfaceData_3,
	draftThingInterfaceData_4,
	headers,
	draftDeviceThingClassData_3,
	draftThingInterfaceData_5,
	draftThingInterfaceData_6,
	draftThingInterfaceData_7,
	draftDeviceThingClassData_4,
	deployerBody,
	deleteDeployerBody
};
