'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));

const prefix_1 = 'GYPT27218_1';
const prefix_2 = 'GYPT27218_2';
const prefix_3 = 'GYPT27218_3';
//const prefix_4 = 'GYPT27218_4';

//添加物模型
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');  //直连设备
const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device', { directlyLinked: false });  //非直连设备
//添加网关模型
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_3, 'gateway');

//添加设备
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);//直连
const thingGatewayModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_3);//网关
const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2, { connectId: 'connectId' + random, gatewayId: thingGatewayModelInstanceData.thingId });//非直连

//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });
const msgData_1 = dataBody.mesBody({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'}});
const msgData_2 = dataBody.mesBody({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'}}, { id: thingClassModelInstanceData_2.connectId });
const msgData_3 = dataBody.mesBody({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49', cells:[
	'$CELL,092927.000,460,00,FFAC,620412,,,50,60,151216,M',
	'$CELL,092928.000,460,00,FFAC,620412,,,50,60,151216,S',
	'$CELL,092929.000,460,00,FFAC,620412,,,50,60,151216,S'
]}
});
const msgData_4 = dataBody.mesBody({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49', cells:[
	'$CELL,092927.000,460,00,FFAC,620412,,,50,60,151216,M',
	'$CELL,092928.000,460,00,FFAC,620412,,,50,60,151216,S',
	'$CELL,092929.000,460,00,FFAC,620412,,,50,60,151216,S'
]}
}, { id: thingClassModelInstanceData_2.connectId });
const msgData_5 = dataBody.mesBody_old({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'}});
const msgData_6 = dataBody.mesBody_old({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'}}, { id: thingClassModelInstanceData_2.connectId });
const msgData_7 = dataBody.mesBody_old({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49', cells:[
	'$CELL,092927.000,460,00,FFAC,620412,,,50,60,151216,M',
	'$CELL,092928.000,460,00,FFAC,620412,,,50,60,151216,S',
	'$CELL,092929.000,460,00,FFAC,620412,,,50,60,151216,S'
]}
});
const msgData_8 = dataBody.mesBody_old({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49', cells:[
	'$CELL,092927.000,460,00,FFAC,620412,,,50,60,151216,M',
	'$CELL,092928.000,460,00,FFAC,620412,,,50,60,151216,S',
	'$CELL,092929.000,460,00,FFAC,620412,,,50,60,151216,S'
]}
}, { id: thingClassModelInstanceData_2.connectId });


module.exports = {
	draftThingClassData_1,
	draftThingClassData_2,
	draftGatewayClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData_1,
	thingGatewayModelInstanceData,
	thingClassModelInstanceData_2,
	msgData_1,
	msgData_2,
	msgData_3,
	msgData_4,
	msgData_5,
	msgData_6,
	msgData_7,
	msgData_8
};
