'use strict';

const { dataBody } = require('../../../../comData');
const { valDict } = require('../../../../requireData');

const prefix = 'GYPT15212';
const prefix_1 = 'GYPT15212_1';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'String', '[0:\'失败\',1:\'正常\'][ONOFF]', 'ONOFF', 'Integer', {name: '__workingStatus__', displayName: '设备工作状态', persisStrategy: valDict.onChange, privilege: valDict.privilegeReadOnly, deviceStatus: true});
const activeData = dataBody.patchActive();
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_1);
//状态为正常
const msgData = dataBody.mesBody({'ONOFF':1});
//状态为失败
const msgData1 = dataBody.mesBody({'ONOFF':0});


module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	activeData,
	thingInstanceData,
	thingInstanceData1,
	msgData,
	msgData1
};
