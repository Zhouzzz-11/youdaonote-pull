'use strict';

const { dataBody } = require('../../../../comData');
const { valDict } = require('../../../../requireData');

const prefix = 'GYPT13437Interfaces'; //未发布
const prefix_1 = 'GYPT13437Interfaces_1';  //发布的


const postDraftThingInterfacesData = dataBody.draftThingInterfacesBody(prefix);
//发布的物应用
const postDraftThingInterfacesData1 = dataBody.draftThingInterfacesBody(prefix_1);
//创建物模型
const postDraftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
//给物模型添加属性
const postDraftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const postDraftThingInterfacesPropertiesData = dataBody.draftThingInterfacesPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//添加属性2
const postDraftThingInterfacesPropertiesData2 = dataBody.draftThingInterfacesPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number');
const putDraftThingInterfacesData = dataBody.draftThingInterfacesBody(prefix, { name: prefix + 'updateName' + valDict.randStr, description: 'updateDescription' });
//更新发布的物应用
const putDraftThingInterfacesData1 = dataBody.draftThingInterfacesBody(prefix_1, { name: prefix_1 + 'updateName' + valDict.randStr, description: 'updateDescription' });
//更新物接口的属性
const putDraftThingInterfacesPropertiesData = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData.name, dataBody.draftThingInterfacesPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: prefix_1 + 'updateName' + valDict.randStr, displayName: 'updateDisplayName' }).thingInterfaceProperitesBody);
//不存的属性name
const putDraftThingInterfacesPropertiesData1 = dataBody.putDraftThingInterfacesPropertiesBody(valDict.randStr, dataBody.draftThingInterfacesPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: prefix_1 + 'updateName' + valDict.randStr, displayName: 'updateDisplayName' }).thingInterfaceProperitesBody);
//创建的属性和更新的属性值相同
const putDraftThingInterfacesPropertiesData2 = dataBody.putDraftThingInterfacesPropertiesBody(postDraftThingInterfacesPropertiesData.name, dataBody.draftThingInterfacesPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: postDraftThingInterfacesPropertiesData.name }).thingInterfaceProperitesBody);


module.exports = {
	postDraftThingInterfacesData,
	postDraftThingInterfacesData1,
	postDraftThingClassData,
	postDraftThingClassModelPropertiesData,
	postDraftThingInterfacesPropertiesData,
	putDraftThingInterfacesData,
	putDraftThingInterfacesData1,
	postDraftThingInterfacesPropertiesData2,
	putDraftThingInterfacesPropertiesData,
	putDraftThingInterfacesPropertiesData1,
	putDraftThingInterfacesPropertiesData2
};
