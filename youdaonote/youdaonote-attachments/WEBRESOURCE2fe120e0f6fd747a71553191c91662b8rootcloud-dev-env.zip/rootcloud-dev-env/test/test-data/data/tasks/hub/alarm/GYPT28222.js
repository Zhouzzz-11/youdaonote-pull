'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const msgData = dataBody.mesBody({'Ia': 20000});

const prefix = 'GYPT28222';
const prefix_1 = 'GYPT28222_1';
const prefix_2 = 'GYPT28222_2';
const prefix_3 = 'GYPT28222_3';
const level = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 80)) - Math.round(Math.random() * 2000);

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_2, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia' });
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia' });
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_2);
const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_3);

const alarmDeviceList = [thingClassModelInstanceData_1.thingId];
const alarmDeviceList1 = [thingClassModelInstanceData.thingId];

const createDraftAlarmRulesData = dataBody.draftAlarmRulesBody(prefix_2,draftThingClassData_1.modelId,'Ia',{acceptedThings:alarmDeviceList});
const createDraftAlarmRulesData_1 = dataBody.draftAlarmRulesBody(prefix,draftThingClassData_1.modelId,'Ia',{acceptedThings:[]});
const postAlarmCategories = dataBody.alarmCategoriesBody(prefix);
const postAlarmSeverities = dataBody.alarmSeverities(prefix, parseInt(level));

const postAlarmTypeData = dataBody.alarmTypeBody(prefix, [postAlarmCategories.cid], postAlarmSeverities.level, draftThingClassData.modelId, 'Ia >= 50', 'everyTime', 'PLATFORM',{acceptedThings:alarmDeviceList1});
const postAlarmTypeData_1 = dataBody.alarmTypeBody(prefix_1, [postAlarmCategories.cid], postAlarmSeverities.level, draftThingClassData.modelId, 'Ia >= 50', 'everyTime', 'PLATFORM',{acceptedThings:[]});


const updateDraftAlarmRulesData = dataBody.draftAlarmRulesBody(prefix,draftThingClassData_1.modelId,'Ia',{acceptedThings:alarmDeviceList,ruleMode:'becomeTrue'});
const updatepostAlarmTypeData = dataBody.alarmTypeBody(prefix, [postAlarmCategories.cid], postAlarmSeverities.level, draftThingClassData.modelId, 'Ia >= 60', 'everyTime', 'PLATFORM',{acceptedThings:alarmDeviceList1});



module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceData,
	createDraftAlarmRulesData,
	updateDraftAlarmRulesData,
	createDraftAlarmRulesData_1,
	postAlarmCategories,
	postAlarmSeverities,
	postAlarmTypeData,
	postAlarmTypeData_1,
	updatepostAlarmTypeData,
	draftThingClassData_1,
	thingClassModelInstanceData_1,
	msgData,
	thingClassModelInstanceData_2
};