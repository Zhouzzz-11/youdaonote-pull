'use strict';

//const { valDict } = require('../../../../requireData');
const { dataBody } = require('../../../../comData');
const uuid = require('uuid');

const prefix = 'GYPT21117';
const bookmarkId = uuid.v1();

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number');
const activeData = dataBody.patchActive();
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const msgData = dataBody.mesBody({ 'temp': 10 });


module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	activeData,
	thingInstanceData,
	msgData,
	bookmarkId
};
