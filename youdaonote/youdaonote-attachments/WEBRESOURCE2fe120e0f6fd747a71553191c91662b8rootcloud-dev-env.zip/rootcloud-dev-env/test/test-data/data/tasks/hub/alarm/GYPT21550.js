'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const prefix = 'GYPT21550';

const postAlarmCategories = dataBody.alarmCategoriesBody(prefix);

const level = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 80)) - Math.round(Math.random() * 2000);
const postAlarmSeverities = dataBody.alarmSeverities(prefix, parseInt(level));

//create thing model class
const postDraftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const PostDraftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia' });
//create alarm type
const postAlarmTypeData = dataBody.alarmTypeBody(prefix, [postAlarmCategories.cid], postAlarmSeverities.level, postDraftThingClassData.modelId, 'Ia >= 50', 'everyTime', 'PLATFORM');
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const msgData = dataBody.mesBody({'Ia': 66});
const msgData1 = dataBody.mesBody({'Ia': 88});
const msgData7 = dataBody.mesBody({'Ia': 90});
const prefix_1 = 'GYPT21550_1';
const PostDraftThingClassModelPropertiesData1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia1', 'Ia1', 'Number', { name: 'Ia1' });
const postAlarmTypeData1 = dataBody.alarmTypeBody(prefix_1, [postAlarmCategories.cid], postAlarmSeverities.level, postDraftThingClassData.modelId, 'Ia1 >= 80', 'everyTime', 'PLATFORM', { everyTimeInterval: 0 });
const msgData2 = dataBody.mesBody({'Ia1': 85});
const msgData3 = dataBody.mesBody({'Ia1': 95});
const msgData8 = dataBody.mesBody({'Ia1': 90});

const prefix_2 = 'GYPT21550_2';
const postDraftThingClassData1 = dataBody.draftThingClassBody(prefix_2, 'device');
const PostDraftThingClassModelPropertiesData2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'Ia2', 'Ia2', 'Number', { name: 'Ia2' });
const postAlarmTypeData2 = dataBody.alarmTypeBody(prefix_2, [postAlarmCategories.cid], postAlarmSeverities.level, postDraftThingClassData1.modelId, 'Ia2 > 60', 'everyTime', 'PLATFORM', { everyTimeInterval: 3000 });
const thingInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_2);
const msgData4 = dataBody.mesBody({'Ia2': 77});
const msgData5 = dataBody.mesBody({'Ia2': 88});
const msgData6 = dataBody.mesBody({'Ia2': 12});
const msgData9 = dataBody.mesBody({'Ia2': 62});
const msgData10 = dataBody.mesBody({'Ia2': 63});
const msgData11 = dataBody.mesBody({'Ia2': 34});
const prefix_3 = 'GYPT21550_3';
const postAlarmTypeData3 = dataBody.alarmTypeBody(prefix_3, [postAlarmCategories.cid], postAlarmSeverities.level, 'postDraftThingClassData1.modelId', 'Ia2 > 40', 'becomesTrue', 'PLATFORM', { everyTimeInterval: 5000 });
const prefix_4 = 'GYPT21550_4';
const postAlarmTypeData4 = dataBody.alarmTypeBody(prefix_4, [postAlarmCategories.cid], postAlarmSeverities.level, postDraftThingClassData1.modelId, 'Ia>50', 'everyTime', 'PLATFORM', { everyTimeInterval: 3000, delayPeriod: 50 });
const postDraftThingClassData2 = dataBody.draftThingClassBody(prefix_3, 'device');
const PostDraftThingClassModelPropertiesData3 = dataBody.draftThingClassModelPropertiesBody(prefix_4, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia' });
const thingInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_4);
const prefix_5 = 'GYPT21550_5';
const postAlarmTypeData5 = dataBody.alarmTypeBody(prefix_5, [postAlarmCategories.cid], postAlarmSeverities.level, postDraftThingClassData2.modelId, 'Ia>50', 'everyTime', 'PLATFORM', { everyTimeInterval: 3000, delayPeriod: 50 });

module.exports = {
	postAlarmCategories,
	postAlarmSeverities,
	postAlarmTypeData,
	postDraftThingClassData,
	PostDraftThingClassModelPropertiesData,
	thingInstanceData,
	msgData,
	msgData1,
	PostDraftThingClassModelPropertiesData1,
	postAlarmTypeData1,
	msgData2,
	msgData3,
	msgData4,
	postDraftThingClassData1,
	PostDraftThingClassModelPropertiesData2,
	PostDraftThingClassModelPropertiesData3,
	postAlarmTypeData2,
	thingInstanceData1,
	postDraftThingClassData2,
	msgData5,
	msgData6,
	msgData7,
	msgData8,
	msgData9,
	msgData10,
	msgData11,
	postAlarmTypeData3,
	thingInstanceData2,
	postAlarmTypeData4,
	postAlarmTypeData5
};
