'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT_23523';

const timestamp = Date.parse(new Date());

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//直连设备
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
let ota = { 'ota': { 'version': '1.0', 'url': '/url', 'force': true, 'type': '', 'size': 1024, 'needSize': 2048, 'signMethod': 'md5', 'sign': 'md5' } };

//直连设备指令下发
const createInstructionsRequestData = dataBody.thingInstructionRequestsBody(prefix, ota, undefined, undefined, thingInstanceData.thingId, { type: 'OTA_SET', trigger: 'realTime', timeout: 300000 });

//直连设备响应
const responseData = dataBody.otaInstructionBody(createInstructionsRequestData.requestId, timestamp, { isAck: false });


module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingInstanceData,
	createInstructionsRequestData,
	responseData
};