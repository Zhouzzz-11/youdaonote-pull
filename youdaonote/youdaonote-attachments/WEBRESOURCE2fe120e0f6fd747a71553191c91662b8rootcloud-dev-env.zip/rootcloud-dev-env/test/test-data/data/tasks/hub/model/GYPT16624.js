'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT16624';
const prefix_1 = 'GYPT16624_1';
const prefix_2 = 'GYPT16624_2';
//物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
//设备
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_1);
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
//网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_1, 'gateway');
//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');


module.exports = {
	thingClassModelInstanceData,
	draftThingClassData,
	draftGatewayClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2
};