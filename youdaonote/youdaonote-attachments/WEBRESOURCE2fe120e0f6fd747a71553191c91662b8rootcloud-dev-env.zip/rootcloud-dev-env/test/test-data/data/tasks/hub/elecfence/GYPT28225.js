'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const prefix = 'GYPT28225';

const current_time = new Date();

const validFrom = Moment(current_time.getTime() - 10000000).format('YYYY-MM-DDTHH:mm:ss') + 'Z';
const validThru = Moment(current_time.getTime() + 10000000).format('YYYY-MM-DDTHH:mm:ss') + 'Z';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
//创建圆形电子围栏
const elecfenceData = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validThru, { radius: 100 });
const elecfenceData_1 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validThru, { radius: 200 });
//修改物接口的属性
const properties = dataBody.propertiesBody({ name: '__location__', displayName: '更改位置', propertyType: 'Json' });
const properties_1 = dataBody.propertiesBody({ name: '__location__', displayName: '当前位置', propertyType: 'Json' });
const draftThingInterfaces = dataBody.updateThingInterfacesBody(prefix, { name: 'saas_elec_fence_interface', properties: [properties] })
//添加物接口的属性
const draftThingInterfaces_1 = dataBody.updateThingInterfacesBody(prefix, { name: 'saas_elec_fence_interface', properties: [properties,properties_1] })
//修改物接口
const draftThingInterfaces_2 = dataBody.updateThingInterfacesBody(prefix, { name: 'saas_elec_fence_interface',description:'修改物接口', properties: [properties_1] })
//创建依赖环境
const draftThingClassData_1 = dataBody.draftThingClassBody(`${prefix}_1`, 'device');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', 'Ia', 'Ia', 'Number');
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}_1`);
//创建圆形电子围栏
const elecfenceData_2 = dataBody.createElecfenceBody('circle', thingInstanceData_1.thingId, validFrom, validThru, { radius: 100 });
module.exports = {
    draftThingClassData,
    thingInstanceData,
    draftThingClassModelPropertiesData,
    elecfenceData,
    elecfenceData_1,
    draftThingInterfaces,
    draftThingInterfaces_1,
    draftThingInterfaces_2,
    draftThingClassData_1,
    draftThingClassModelPropertiesData_1,
    thingInstanceData_1,
    elecfenceData_2
}