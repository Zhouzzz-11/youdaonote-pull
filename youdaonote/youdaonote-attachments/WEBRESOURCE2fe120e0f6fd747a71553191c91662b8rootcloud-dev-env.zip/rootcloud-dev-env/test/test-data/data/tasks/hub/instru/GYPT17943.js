'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const prefix = 'GYPT17943';
const prefix_1 = 'GYPT17943_1';
const prefix_11 = 'GYPT17943_11';
const prefix_12 = 'GYPT17943_12';
const prefix_2 = 'GYPT17943_2';
const prefix_3 = 'GYPT17943_3';

const number = Math.round(Math.random() * (400));
const timestamp = Date.parse(new Date());

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const activeData = dataBody.patchActive();
const createInstructionsData = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_11);
const instructionRequestsData_1 = dataBody.thingInstructionRequestsBody(prefix_11, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_1.thingId, { type: 'CMD', timeout: 60000 });
const responseData_1 = dataBody.instructionBody(instructionRequestsData_1.requestId, timestamp);

const thingInstanceData_11 = dataBody.thingClassModelInstanceBody(prefix_12);
const instructionRequestsData_11 = dataBody.thingInstructionRequestsBody(prefix_12, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_11.thingId, { type: 'CMD', timeout: 60000 });
const responseData11 = dataBody.instructionBody(instructionRequestsData_11.requestId, timestamp);
const prefix_13 = 'GYPT17943_13';
const thingInstanceData_13 = dataBody.thingClassModelInstanceBody(prefix_13);
const instructionRequestsData_13 = dataBody.thingInstructionRequestsBody(prefix_13, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_13.thingId, { type: 'CMD' });
const responseData13 = dataBody.instructionBody(instructionRequestsData_13.requestId, timestamp);
const prefix_14 = 'GYPT17943_14';
const thingInstanceData_14 = dataBody.thingClassModelInstanceBody(prefix_14);
const instructionRequestsData_14 = dataBody.thingInstructionRequestsBody(prefix_14, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_14.thingId, { type: 'CMD', timeout: 60000 });
const responseData14 = dataBody.instructionBody(instructionRequestsData_14.requestId, timestamp);
const prefix_15 = 'GYPT17943_15';
const thingInstanceData_15 = dataBody.thingClassModelInstanceBody(prefix_15);
const instructionRequestsData_15 = dataBody.thingInstructionRequestsBody(prefix_15, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_15.thingId, { type: 'CMD', timeout: 60000 });
const responseData15 = dataBody.instructionBody(instructionRequestsData_15.requestId, timestamp);
const prefix_16 = 'GYPT17943_16';
const thingInstanceData_16 = dataBody.thingClassModelInstanceBody(prefix_16);
const instructionRequestsData_16 = dataBody.thingInstructionRequestsBody(prefix_16, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_16.thingId, { type: 'CMD', timeout: 3000 });
const prefix_17 = 'GYPT17943_17';
const thingInstanceData_17 = dataBody.thingClassModelInstanceBody(prefix_17);
const instructionRequestsData_17 = dataBody.thingInstructionRequestsBody(prefix_17, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_17.thingId, { type: 'CMD', timeout: 60000 });
const prefix_18 = 'GYPT17943_18';
const thingInstanceData_18 = dataBody.thingClassModelInstanceBody(prefix_18);
const instructionRequestsData_18 = dataBody.thingInstructionRequestsBody(prefix_18, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_18.thingId, { type: 'CMD', timeout: 3000 });
const responseData18 = dataBody.instructionBody(instructionRequestsData_18.requestId, timestamp);
const prefix_30 = 'GYPT17943_30';
const thingInstanceData_30 = dataBody.thingClassModelInstanceBody(prefix_30);
const instructionRequestsData1 = dataBody.thingInstructionRequestsBody(prefix_30, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_30.thingId, { type: 'CMD', timeout: 3000 });
const instructionRequestsData = dataBody.thingInstructionRequestsBody(prefix, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData.thingId, { type: 'CMD' });
const responseData = dataBody.instructionBody(instructionRequestsData.requestId, timestamp);
const responseData1 = dataBody.instructionBody(instructionRequestsData1.requestId, timestamp);
const prefix_19 = 'GYPT17943_19';
const thingInstanceData_19 = dataBody.thingClassModelInstanceBody(prefix_19);
const instructionRequestsData_19 = dataBody.thingInstructionRequestsBody(prefix_19, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData.instructionTemplateId, draftThingClassData.modelId, thingInstanceData_19.thingId, { type: 'CMD', timeout: 3000 });

//直连物模型2
const prefix_22 = 'GYPT17943_22';
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');
const draftThingClassModelPropertiesData1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia', 'Ia', 'Number', { name: 'Ia', expressionType: 'direct' });
const thingInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_1);
const createInstructionsData2 = dataBody.createInstructionsBody(prefix_1, `${number}`, { type: 'LIVE', name1: 'Ia', timeout: 0 });
const createInstructionsRequestData2 = dataBody.thingInstructionRequestsBody(prefix_22, { 'Ia': '12' }, createInstructionsData2.instructionTemplateId, draftThingClassData_1.modelId, thingInstanceData2.thingId, { timeout: 60000 });
const prefix_20 = 'GYPT17943_20';
const thingInstanceData20 = dataBody.thingClassModelInstanceBody(prefix_20);
const createInstructionsRequestData20 = dataBody.configRequestsBody(prefix_20, thingInstanceData20.thingId, { timeout: 3000 });
const prefix_21 = 'GYPT17943_21';
const thingInstanceData21 = dataBody.thingClassModelInstanceBody(prefix_21);
const createInstructionsRequestData21 = dataBody.thingInstructionRequestsBody(prefix_21, { 'Ia': '12' }, createInstructionsData2.instructionTemplateId, draftThingClassData_1.modelId, thingInstanceData21.thingId);
const thingInstanceData22 = dataBody.thingClassModelInstanceBody(prefix_22);
const createInstructionsRequestData22 = dataBody.thingInstructionRequestsBody(prefix_22, { 'Ia': '12' }, createInstructionsData2.instructionTemplateId, draftThingClassData_1.modelId, thingInstanceData22.thingId);

//网关
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_2, 'gateway');
const thingClassModelInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_2);
const createInstructionsData_2 = dataBody.createInstructionsBody(prefix_2, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const instructionRequestsData_2 = dataBody.thingInstructionRequestsBody(
	prefix_2, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData_2.instructionTemplateId, draftGatewayClassData.modelId, thingClassModelInstanceData2.thingId, { type: 'CMD', timeout: 3000 });
const responseData_2 = dataBody.instructionBody(instructionRequestsData_2.requestId, timestamp);
//非直连物模型
const draftThingClassData1 = dataBody.draftThingClassBody(prefix_3, 'device', { directlyLinked: false });
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_3, { connectId: 'connectId' + random, gatewayId: thingClassModelInstanceData2.thingId });
const createInstructionsData_3 = dataBody.createInstructionsBody(prefix_3, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const instructionRequestsData_3 = dataBody.thingInstructionRequestsBody(
	prefix_3, { 'cmds': [{ 'name': 'POWEROFF' }] }, createInstructionsData_3.instructionTemplateId, draftThingClassData1.modelId, thingClassModelInstanceData1.thingId, { type: 'CMD', timeout: 3000 });
const responseData_3 = dataBody.instructionBody(instructionRequestsData_3.requestId, timestamp, { id: thingClassModelInstanceData1.connectId, isAck: false });



module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	activeData, thingInstanceData,
	draftThingClassData1,
	draftGatewayClassData,
	thingClassModelInstanceData1,
	thingClassModelInstanceData2,
	createInstructionsData,
	instructionRequestsData,
	responseData,
	instructionRequestsData1,
	responseData1,
	responseData_1,
	createInstructionsData_2,
	instructionRequestsData_2,
	responseData_2,
	createInstructionsData_3,
	instructionRequestsData_3,
	responseData_3,
	thingInstanceData_1,
	instructionRequestsData_1,
	thingInstanceData_11,
	instructionRequestsData_11,
	responseData11,
	thingInstanceData_13,
	instructionRequestsData_13,
	responseData13,
	thingInstanceData_14,
	instructionRequestsData_14,
	responseData14,
	thingInstanceData_15,
	instructionRequestsData_15,
	responseData15,
	thingInstanceData_16,
	instructionRequestsData_16,
	thingInstanceData_17,
	instructionRequestsData_17,
	thingInstanceData_18,
	instructionRequestsData_18,
	responseData18,
	thingInstanceData_19,
	instructionRequestsData_19,
	thingInstanceData_30,
	thingInstanceData20,
	createInstructionsRequestData20,
	thingInstanceData21,
	createInstructionsRequestData21,
	thingInstanceData22,
	createInstructionsRequestData22,
	createInstructionsData2,
	createInstructionsRequestData2,
	draftThingClassData_1,
	draftThingClassModelPropertiesData1,
	thingInstanceData2


};
