'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT17465';

//common data
const postdata = dataBody.mesBody({ 'temp': 1 });

//precondition
const ThingClassData = dataBody.draftThingClassBody(`${prefix}`, 'device');
const temp_option_1 = { 'name': `${prefix}_1`, 'displayName': `${prefix}_1`, 'expressionType': 'linear', 'scale': 1, 'base': 2 };
const PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', `1*${prefix}+2`, 'temp', 'Number', temp_option_1);

//C2074521
const temp_option_2 = { 'name': `${prefix}_2`, 'displayName': `${prefix}_2`, 'expressionType': 'constant' };
const PropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_2`, 'Number', '10', '', 'Number', temp_option_2);
const postdata_3 = dataBody.mesBody({ '10': 10 });

//C2074522
const d_option_1 = { 'propertyName': `${prefix}_2`, 'propertyValueJson': '10' };
const DeviceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}_1`, d_option_1);

const d_option_8 = { 'propertyName': `${prefix}_9`, 'propertyValueJson': '15' };
const DeviceData_8 = dataBody.thingClassModelInstanceBody(`${prefix}_9`, d_option_8);

const d_option_9 = { 'propertyName': `${prefix}_10`, 'propertyValueJson': '20' };
const DeviceData_9 = dataBody.thingClassModelInstanceBody(`${prefix}_10`, d_option_9);

//C2074523
const d_option_2 = { 'propertyName': `${prefix}_2`, 'propertyValueJson': ' ' };
const DeviceData_2 = dataBody.thingClassModelInstanceBody(`${prefix}_2`, d_option_2);

//C2074524
const DeviceData_3 = dataBody.thingClassModelInstanceBody(`${prefix}_3`);

//C2074525
const temp_option_4 = { 'name': `${prefix}_4`, 'displayName': `${prefix}_3`, 'expressionType': 'groovy', 'priority': 1 };
const PropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_4`, 'Number', 'temp2+1', 'temp2', 'Number', temp_option_4);
const postdata_2 = dataBody.mesBody({ 'temp2': 5 });
//C2074526
const temp_option_3 = { 'name': `${prefix}_3`, 'displayName': `${prefix}_3`, 'expressionType': 'groovy', 'priority': 2 };
const PropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_3`, 'Number', 'temp1+1', 'temp1', 'Number', temp_option_3);
const postdata_1 = dataBody.mesBody({ 'temp1': 1 });

//C2074527
const temp_option_5 = { 'name': `${prefix}_5`, 'displayName': `${prefix}_5`, 'expressionType': 'constant' };
const PropertiesData_5 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_5`, 'Number', 'hhh', '', 'Number', temp_option_5);

//C2074528
const d_option_4 = { 'propertyName': `${prefix}_2`, 'propertyValueJson': 'hhh' };
const DeviceData_4 = dataBody.thingClassModelInstanceBody(`${prefix}_4`, d_option_4);
const d_option_5 = { 'propertyName': `${prefix}_10`, 'propertyValueJson': '10' };
const DeviceData_5 = dataBody.thingClassModelInstanceBody(`${prefix}_5`, d_option_5);

//C2074534&C2074536&C2074535

//C2078397
const d_option_6 = { 'propertyName': `${prefix}_6`, 'propertyValueJson': '66' };
const DeviceData_6 = dataBody.thingClassModelInstanceBody(`${prefix}_6`, d_option_6);

//C2078412
const temp_option_6 = { 'name': `${prefix}_6`, 'displayName': `${prefix}_6`, 'expressionType': 'constant' };
const PropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_6`, 'Number', '6', '', 'Number', temp_option_6);

//C2082803
const d_option_7 = { 'propertyName': `${prefix}_7`, 'propertyValueJson': '77' };
const DeviceData_7 = dataBody.thingClassModelInstanceBody(`${prefix}_7`, d_option_7);
const temp_option_7 = { 'name': `${prefix}_7`, 'displayName': `${prefix}_7`, 'expressionType': 'constant' };
const PropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_7`, 'String', '"7"', '', 'String', temp_option_7);

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(`${prefix}_8`, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(`${prefix}_8`, 'Number', '6', 'Ia', 'Number', { expressionType: 'constant' });
const draftThingClassPropertiesData1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_88`, 'Number', 'pro', 'pro', 'Number', { name: 'GYPT17465_realData', expressionType: 'linear', base: 1, scale: 1, persisStrategy: 'onReport' });
const draftThingClassPropertiesData2 = dataBody.updateDraftThingClassModelPropertiesBody(`${prefix}_8`, 'String', '"Ia1"', 'Ia1', 'String', draftThingClassPropertiesData.name, { name: `${draftThingClassPropertiesData.name}`, expressionType: 'constant' });

//直连设备
const thingInstanceData = dataBody.thingClassModelInstanceBody(`${prefix}_8`);
const msgData = dataBody.mesBody({ 'pro': 6 });
const msgData1 = dataBody.mesBody({ 'pro': 10 });
const msgData2 = dataBody.mesBody({ 'pro': 22 });


module.exports = { postdata_1, postdata_2, postdata_3, ThingClassData, d_option_8, DeviceData_8, DeviceData_9, msgData, msgData2, draftThingClassPropertiesData1, msgData1, draftThingClassData, draftThingClassPropertiesData2, draftThingClassPropertiesData, thingInstanceData, PropertiesData_1, PropertiesData_2, PropertiesData_3, PropertiesData_4, PropertiesData_5, PropertiesData_6, PropertiesData_7, DeviceData_1, DeviceData_2, DeviceData_3, DeviceData_4, DeviceData_5, DeviceData_6, DeviceData_7, postdata };