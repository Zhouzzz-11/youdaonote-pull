'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const prefix = 'GYPT28077';
const prefix_1 = 'GYPT28077_1';
const prefix_2 = 'GYPT28077_2';
const prefix_3 = 'GYPT28077_3';

const number = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', { 'name': `attribute_name${number}` });
const createInstructionsTemplateData = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const createInstructionsTemplateData_1 = dataBody.createInstructionsBody(prefix_1, `${number}`, { instructionTemplateId: `instructionID${number}`, type: 'LIVE', displayName: '自定义指令1', name1: `attribute_name${number}` });
const createInstructionsTemplateData_2 = dataBody.createInstructionsBody(prefix_2, `${number}`, { instructionTemplateId: `instructionID1${number}`, type: 'LIVE', displayName: '自定义指令2', name1: `attribute_name${number}` });
const createInstructionsTemplateData_3 = dataBody.createInstructionsBody(prefix_3, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP' });

const ListInstructionTemplateId_1 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId];
const ListInstructionTemplateId_2 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId, createInstructionsTemplateData_2.instructionsBody.instructionTemplateId];
const ListInstructionTemplateId_3 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId, createInstructionsTemplateData_1.instructionsBody.instructionTemplateId, createInstructionsTemplateData_2.instructionsBody.instructionTemplateId, createInstructionsTemplateData_3.instructionsBody.instructionTemplateId];
const ListInstructionTemplateId_4 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId, createInstructionsTemplateData_3.instructionsBody.instructionTemplateId];

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsTemplateData,
	createInstructionsTemplateData_1,
	createInstructionsTemplateData_2,
	createInstructionsTemplateData_3,
	ListInstructionTemplateId_1,
	ListInstructionTemplateId_2,
	ListInstructionTemplateId_3,
	ListInstructionTemplateId_4
};