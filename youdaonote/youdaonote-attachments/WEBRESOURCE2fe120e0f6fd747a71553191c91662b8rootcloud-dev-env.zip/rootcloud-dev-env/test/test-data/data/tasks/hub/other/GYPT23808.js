'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT23808';
const prefix_1 = 'GYPT23808_1';

//创建6个非直连设备模型
const multipleDraftDeviceData = [];
for(let i = 0 ; i < 6; i++){
	multipleDraftDeviceData[i] = dataBody.draftThingClassBody(`${prefix}_${i}`,'device', {directlyLinked: false});
}
//创建6个网关设备模型
const multipleDraftGatewayData = [];
for(let i = 0 ; i < 6; i++){
	multipleDraftGatewayData[i] = dataBody.draftThingClassBody(`${prefix_1}_${i}`,'gateway');
}
//12个设备属性相同 for convenience
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//创建6个网关模型的物实例
const multipleGatewayInstanceData = [];
for(let i = 0 ; i < 6; i++){
	multipleGatewayInstanceData[i] = dataBody.thingClassModelInstanceBody(`${prefix_1}_${i}`);
}
//创建6个设备模型的物实例
const multipleDeviceInstanceData = [];
for(let i = 0 ; i < 6; i++){
	multipleDeviceInstanceData[i] = dataBody.thingClassModelInstanceBody(`${prefix}_${i}`, {gatewayId: multipleGatewayInstanceData[i].thingId, connectId: multipleGatewayInstanceData[i].thingId});
}


module.exports = {
	multipleDraftDeviceData,
	multipleDraftGatewayData,
	draftThingClassModelPropertiesData,
	multipleGatewayInstanceData,
	multipleDeviceInstanceData
};



