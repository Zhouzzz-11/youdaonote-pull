'use strict';

const { dataBody } = require('../../../../comData');

const prefix_c1 = 'GYPT22260_c1';
const prefix_c2 = 'GYPT22260_c2';
const prefix_c3 = 'GYPT22260_c3';
const prefix_c4 = 'GYPT22260_c4';
const prefix_c5 = 'GYPT22260_c5';
const prefix_c6 = 'GYPT22260_c6';
const prefix_c7 = 'GYPT22260_c7';

//case1数据: 10个属性全部合法且不重复
const draftThingClassData_c1 = dataBody.draftThingClassBody(prefix_c1, 'device');
//批量创建属性10个
const multipleProperties_c1 = [];
for (let i = 0; i < 10; i++) {
	var draftThingClassModelPropertiesData_c1 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c1}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c1[i] = draftThingClassModelPropertiesData_c1.thingPropertiesBody[0];
}

//case2数据：10个属性全部合法但第10个属性连接变量与第9个重复
const draftThingClassData_c2 = dataBody.draftThingClassBody(prefix_c2, 'device');
//批量创建属性10个
const multipleProperties_c2 = [];
for (let i = 0; i < 9; i++) {
	var draftThingClassModelPropertiesData_c2 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c2}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c2[i] = draftThingClassModelPropertiesData_c2.thingPropertiesBody[0];
}
multipleProperties_c2[9] = dataBody.draftThingClassModelPropertiesBody(`${prefix_c2}_${9}`,'Number', `Ia_${9}+1`,`Ia_${8}`, 'Number' ).thingPropertiesBody[0];

//case3数据: 10个属性均不重复但最后一个属性表达式值不合法
const draftThingClassData_c3 = dataBody.draftThingClassBody(prefix_c3, 'device');
//批量创建属性10个
const multipleProperties_c3 = [];
for (let i = 0; i < 9; i++) {
	var draftThingClassModelPropertiesData_c3 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c3}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c3[i] = draftThingClassModelPropertiesData_c3.thingPropertiesBody[0];
}
multipleProperties_c3[9] = dataBody.draftThingClassModelPropertiesBody(`${prefix_c3}_${9}`,'Number', '*illegal*',`Ia_${9}`, 'Number' ).thingPropertiesBody[0];

//case4数据：10个属性全部合法但第10个属性连接变量与第9个重复但是支持partialAdd
const draftThingClassData_c4 = dataBody.draftThingClassBody(prefix_c4, 'device');
//批量创建属性10个
const multipleProperties_c4 = [];
for (let i = 0; i < 9; i++) {
	var draftThingClassModelPropertiesData_c4 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c4}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c4[i] = draftThingClassModelPropertiesData_c4.thingPropertiesBody[0];
}
multipleProperties_c4[9] = dataBody.draftThingClassModelPropertiesBody(`${prefix_c4}_${9}`,'Number', `Ia_${9}+1`,`Ia_${8}`, 'Number' ).thingPropertiesBody[0];

//case5数据: 10个属性全部合法且不重复 支持forceUpdate
const draftThingClassData_c5 = dataBody.draftThingClassBody(prefix_c5, 'device');
//批量创建属性10个
const multipleProperties_c5 = [];
for (let i = 0; i < 10; i++) {
	var draftThingClassModelPropertiesData_c5 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c5}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c5[i] = draftThingClassModelPropertiesData_c5.thingPropertiesBody[0];
}

//case6数据: 10个属性全部合法但第10个属性连接变量与第9个重复但是支持forceUpdate
const draftThingClassData_c6 = dataBody.draftThingClassBody(prefix_c6, 'device');
//批量创建属性10个
const multipleProperties_c6 = [];
for (let i = 0; i < 9; i++) {
	var draftThingClassModelPropertiesData_c6 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c6}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c6[i] = draftThingClassModelPropertiesData_c6.thingPropertiesBody[0];
}
multipleProperties_c6[9] = dataBody.draftThingClassModelPropertiesBody(`${prefix_c6}_${9}`,'Number', `Ia_${9}+1`,`Ia_${8}`, 'Number' ).thingPropertiesBody[0];

//case7数据: 10个属性均不重复但最后一个属性表达式值不合法, 支持partialAdd && forceUpdate
const draftThingClassData_c7 = dataBody.draftThingClassBody(prefix_c7, 'device');
//批量创建属性10个
const multipleProperties_c7 = [];
for (let i = 0; i < 9; i++) {
	var draftThingClassModelPropertiesData_c7 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c7}_${i}`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c7[i] = draftThingClassModelPropertiesData_c7.thingPropertiesBody[0];
}
multipleProperties_c7[9] = dataBody.draftThingClassModelPropertiesBody(`${prefix_c7}_${9}`,'Number', '*illegal*',`Ia_${9}`, 'Number' ).thingPropertiesBody[0];

//case8数据: 10个属性全部合法但第10个属性连接变量与第9个重复, deviceType与case1相同, 支持forceUpdate && partialAdd
//批量创建属性10个
const multipleProperties_c8 = [];
for (let i = 0; i < 9; i++) {
	var draftThingClassModelPropertiesData_c8 = dataBody.draftThingClassModelPropertiesBody(`${prefix_c1}_${i}_new`,'Number', `Ia_${i}+1`,`Ia_${i}`, 'Number' );
	multipleProperties_c8[i] = draftThingClassModelPropertiesData_c8.thingPropertiesBody[0];
}
multipleProperties_c8[9] = dataBody.draftThingClassModelPropertiesBody(`${prefix_c1}_${1}`,'Number', `Ia_${9}_new+1`,`Ia_${9}_new`, 'Number' ).thingPropertiesBody[0];



module.exports = {
	draftThingClassData_c1,
	multipleProperties_c1,
	draftThingClassData_c2,
	multipleProperties_c2,
	draftThingClassData_c3,
	multipleProperties_c3,
	draftThingClassData_c4,
	multipleProperties_c4,
	draftThingClassData_c5,
	multipleProperties_c5,
	draftThingClassData_c6,
	multipleProperties_c6,
	draftThingClassData_c7,
	multipleProperties_c7,
	multipleProperties_c8,
};