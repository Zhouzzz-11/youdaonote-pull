'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');

const prefix = 'GYPT29581';
const prefix_1 = 'GYPT29581_1';
const prefix_2 = 'GYPT29581_2';
const prefix_3 = 'GYPT29581_3';

const number = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number', { 'name': `attribute_name${number}` });
const createInstructionsTemplateData = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: '_Rouse_', type: 'CMD', displayName: '关机', name1: 'POWEROFF' });
const createInstructionsTemplateData_1 = dataBody.createInstructionsBody(prefix_1, `${number}`, { instructionTemplateId: `instructionID${number}`, type: 'LIVE', displayName: '自定义指令1', name1: `attribute_name${number}` });
const createInstructionsTemplateData_2 = dataBody.createInstructionsBody(prefix_2, `${number}`, { instructionTemplateId: `instructionID1${number}`, type: 'LIVE', displayName: '自定义指令2', name1: `attribute_name${number}` });
const createInstructionsTemplateData_3 = dataBody.createInstructionsBody(prefix_3, `${number}`, { instructionTemplateId: '_Turnoff_', type: 'CMD', displayName: '唤醒', name1: 'WAKEUP' });
const createInstructionsTemplateData_4 = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: `instructionID2${number}`, type: 'LIVE', displayName: 22, name1: `attribute_name${number}` });
const createInstructionsTemplateData_5 = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: `instructionID2${number}`, type: 'LIVE', displayName: '自定义指令3', name1: `attribute_name${number}`, timeout:1 });
const createInstructionsTemplateData_6 = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: `instructionID2${number}`, type: 'LIVE', displayName: 'Invalid data type', name1: `attribute_name${number}`, timeout:'abc' });
const createInstructionsTemplateData_7 = dataBody.createInstructionsBody(prefix, `${number}`, { instructionTemplateId: `instructionID2${number}`, type: 'LIVE', displayName: 'Invalid data type', name1: `attribute_name${number}`, timeout:'3000' });

const createInstructionsTemplateData_8 = prepareHugeData(8, 2000);
const createInstructionsTemplateData_9 = prepareHugeData(9, 2000);

const ListInstructionTemplateId_1 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId];
const ListInstructionTemplateId_2 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId, createInstructionsTemplateData_2.instructionsBody.instructionTemplateId];
const ListInstructionTemplateId_3 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId, createInstructionsTemplateData_1.instructionsBody.instructionTemplateId, createInstructionsTemplateData_2.instructionsBody.instructionTemplateId, createInstructionsTemplateData_3.instructionsBody.instructionTemplateId];
const ListInstructionTemplateId_4 = [createInstructionsTemplateData.instructionsBody.instructionTemplateId, createInstructionsTemplateData_3.instructionsBody.instructionTemplateId];

function preparePayload(...args){
	
	let payloads = [];
	for(let i = 0; i < args.length; ++i){
		let l = args[i].name.split('_');
		let s = [l[0],'draft_thing_class_id', l[l.length-2], l[l.length - 1]].join('_') + ':'+args[i].instructionTemplateId + ':' + 'draft';
		payloads.push(s);
	}
	return payloads;
}

function prepareHugeData(prefix, num ){
	let data_body = [];

	for (let i = 0; i < num; i++){
		let pre = `GYPT29581_${prefix}` + i;
		let body = dataBody.createInstructionsBody(pre, `${prefix}${i}`, { instructionTemplateId: `instructionID${prefix}${i}`, type: 'LIVE', displayName: `自定义指令${prefix}` + i, name1: `attribute_name${number}` });
		data_body.push(body.instructionsBody);
		
	}
	return data_body;
}

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	createInstructionsTemplateData,
	createInstructionsTemplateData_1,
	createInstructionsTemplateData_2,
	createInstructionsTemplateData_3,
	createInstructionsTemplateData_4,
	createInstructionsTemplateData_5,
	createInstructionsTemplateData_6,
	createInstructionsTemplateData_7,
	createInstructionsTemplateData_8,
	createInstructionsTemplateData_9,
	ListInstructionTemplateId_1,
	ListInstructionTemplateId_2,
	ListInstructionTemplateId_3,
	ListInstructionTemplateId_4,
	preparePayload,
};