'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT29796';
const prefix_1 = 'GYPT29796_1';
const prefix_2 = 'GYPT29796_2';
const time = new Date();
const currentTs = parseInt(Date.parse(time)/60000)*60000 + 60000;

//添加物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');  //直连设备

//添加设备
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);

//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });

const temp_option = {'name':'a1', 'displayName':'a1','expressionType':'linear', 'scale': 1, 'base': 1};
const draftThingClassModelPropertiesData1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number','1*temp+1' , 'temp' ,'Number' ,temp_option);

let draftThingClassModelPropertiesData2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'a1', 'a1', 'Number', {
	expressionType: 'window',
	operator: 'sum',
	windowSizeMills: 2000,
	windowStepMills: 1000,
	windowAllowedLatenessMills: 0,
	'name': 'a2'
});

delete draftThingClassModelPropertiesData2.thingPropertiesBody[0]['sourceFromConnection'];
const draftThingClassModelPropertiesBody = [draftThingClassModelPropertiesData.thingPropertiesBody[0], draftThingClassModelPropertiesData1.thingPropertiesBody[0], draftThingClassModelPropertiesData2.thingPropertiesBody[0]]
//mqtt
const locationData = dataBody.locationDataBody({ts: currentTs + 3001});

const msgData1 = dataBody.mesBody({ 'temp': 1 }, { ts: currentTs + 501});
const msgData2 = dataBody.mesBody({ 'temp': 2 }, { ts: currentTs + 1001 });
const msgData3 = dataBody.mesBody({ 'temp': 4 }, { ts: currentTs + 2001 });
const msgData4 = dataBody.mesBody({ 'temp': 8 }, { ts: currentTs + 6501 });
const msgData5 = dataBody.mesBody({ 'temp': 16 }, { ts: currentTs + 7001 });
const msgData6 = dataBody.mesBody({ 'temp': 32 }, { ts: currentTs + 8001 });
const msgList1 = [
	msgData1, msgData2, msgData3, msgData4, msgData5, msgData6
];


module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesBody,
	thingClassModelInstanceData,
    locationData,
    msgList1,
};
