'use strict';

const { dataBody } = require('../../../../comData');
//直连设备
const prefix_thingclass_device= 'GYPT32442_device';
const thingclassDeviceData = dataBody.draftThingClassBody(prefix_thingclass_device,'device');
const thingPropertyData = dataBody.draftThingClassModelPropertiesBody(prefix_thingclass_device,'Number', 'test_str_pro', 'test_str_pro','Number',{name: 'test_str_pro'});
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix_thingclass_device,{description:thingclassDeviceData.modelId});
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_thingclass_device,{description:thingclassDeviceData.modelId+'testd4d75a4d153c3f0e27c4df14c2053434'});

//直连设备2
const prefix_thingclass_device2= 'GYPT32442_device2';
const thingclassDeviceData2 = dataBody.draftThingClassBody(prefix_thingclass_device2,'device');
const thingPropertyData22 = dataBody.draftThingClassModelPropertiesBody(prefix_thingclass_device2,'Number', 'test_str_pro', 'test_str_pro','Number',{name: 'test_str_pro'});
const thingInstanceData2 = dataBody.thingClassModelInstanceBody(prefix_thingclass_device2,{description:thingclassDeviceData2.modelId+'~!@#$%^&*()_+'});



const thingDevicemsg = dataBody.mesBody({'test_str_pro':1});
//复合物
const prefix_thingclass_composite='GYPT32442_composite';

const thingClassCompositeData = dataBody.draftCompositeThingClassBody(prefix_thingclass_composite,'compositeThing',thingclassDeviceData.modelId,{nodeId:'test1',nodeName:'test1'});
const thingPropertyData2 = dataBody.draftThingClassModelPropertiesBody(prefix_thingclass_composite,'Number','test1.test_str_pro');
const thingCompositeInstanceData = dataBody.thingClassModelInstanceCompositeThingBody(prefix_thingclass_composite,'test1',thingInstanceData.thingId,thingclassDeviceData.modelId,{description:thingclassDeviceData.modelId});

//网关设备
const prefix_thingclass_gateway = 'GYPT32442_gateway';
const thingclassGatewayData = dataBody.draftThingClassBody(prefix_thingclass_gateway,'gateway');
const thingPropertyDataGateway= dataBody.draftThingClassModelPropertiesBody(prefix_thingclass_gateway,'Number','test_num_pro','test_num_pro','Number',{name:'test_num_pro'});
const thingInstanceGateway = dataBody.thingClassModelInstanceBody(prefix_thingclass_gateway,{description:thingclassDeviceData.modelId});

//非直连设备

const prefix_thingclass_ndevice ='GYPT32442_ndevice'; 
const thingclassNDeviceData =dataBody.draftThingClassBody(prefix_thingclass_ndevice,'device', { directlyLinked: false });
const thingPropertyDataNDevice = dataBody.draftThingClassModelPropertiesBody(prefix_thingclass_ndevice,'Number','test_num_pro','test_num_pro','Number',{name:'test_num_pro'});
const thingInstanceNDevice = dataBody.thingClassModelInstanceBody(prefix_thingclass_ndevice, { connectId: thingclassNDeviceData.modelId, gatewayId: thingInstanceGateway.thingId,description:thingclassDeviceData.modelId });
module.exports = {
	thingClassCompositeData,
	prefix_thingclass_device,
	thingclassDeviceData,
	thingPropertyData,
	thingInstanceData,
	thingPropertyData2,
	thingCompositeInstanceData,
	thingDevicemsg,
	thingclassGatewayData,
	thingPropertyDataGateway,
	thingInstanceGateway,
	thingclassNDeviceData,
	thingPropertyDataNDevice,
	thingInstanceNDevice,
	thingclassDeviceData2,
	thingPropertyData22,
	thingInstanceData2,
	thingInstanceData_1
};
