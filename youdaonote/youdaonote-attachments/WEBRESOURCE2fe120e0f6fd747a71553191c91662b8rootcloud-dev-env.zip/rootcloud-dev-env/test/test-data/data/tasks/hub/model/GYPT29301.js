'use strict';
const { dataBody } = require('../../../../comData');

const prefix = 'GYPT29301';
const prefix_w1 = 'GYPT29301_w1';
const prefix_s = 'GYPT29301_s';
const prefix_s1 = 'GYPT29301_s1';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_w1, 'device');

const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Integer', 'temp1', 'temp1', 'Integer');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Integer', 'temp2', 'temp2', 'Integer');
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_2`, 'Number', 'temp3', 'temp3', 'Number');
const draftThingClassModelPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_3`, 'Number', 'temp4', 'temp4', 'Number');
const draftThingClassModelPropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_4`, 'String', 'temp5', 'temp5', 'String');
const draftThingClassModelPropertiesData_5 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_5`, 'String', 'temp6', 'temp6', 'String');
const draftThingClassModelPropertiesData_6 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_6`, 'String', 'temp7', 'temp7', 'String');
const draftThingClassModelPropertiesData_7 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_7`, 'String', 'temp8', 'temp8', 'String');
const draftThingClassModelPropertiesData_8 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_8`, 'String', 'temp9', 'temp9', 'String');
const draftThingClassModelPropertiesData_9 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_9`, 'Boolean', 'temp10', 'temp10', 'Boolean');
const draftThingClassModelPropertiesData_9_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_9_1`, 'Boolean', 'temp10_1', 'temp10_1', 'Boolean');
const draftThingClassModelPropertiesData_10 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_10`, 'Boolean', 'temp11', 'temp11', 'Boolean');
const draftThingClassModelPropertiesData_10_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_10_1`, 'Boolean', 'temp11_1', 'temp11_1', 'Boolean');
const draftThingClassModelPropertiesData_11 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_11`, 'Boolean', 'temp12', 'temp12', 'Boolean');
const draftThingClassModelPropertiesData_12 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_12`, 'Json', 'temp13', 'temp13', 'Json');
const draftThingClassModelPropertiesData_13 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_13`, 'Array', 'temp14', 'temp14', 'Array');
const draftThingClassModelPropertiesData_14 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_14`, 'Binary', 'temp15', 'temp15', 'Binary');
const draftThingClassModelPropertiesData_15 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_15`, 'Binary', 'temp16', 'temp16', 'Binary');

//window属性创建
const draftThingClassPropertiesData_w = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w`, 'Number', 'Ia', 'Ia', 'Number', {
    expressionType: 'window',
    operator: 'min',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w_f = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w_f`, 'String', 'Ia', 'Ia', 'String', {
    expressionType: 'window',
    operator: 'min',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w1`, 'Integer', 'Ia1', 'Ia1', 'Integer', {
    expressionType: 'window',
    operator: 'count',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w1_f = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w1_f`, 'Number', 'Ia1', 'Ia1', 'Number', {
    expressionType: 'window',
    operator: 'count',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w2`, 'Number', 'Ia2', 'Ia2', 'Number', {
    expressionType: 'window',
    operator: 'avg',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w2_f = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w2_f`, 'Integer', 'Ia2', 'Ia2', 'Integer', {
    expressionType: 'window',
    operator: 'dev',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w3`, 'Boolean', 'Ia3', 'Ia3', 'Boolean', {
    expressionType: 'window',
    operator: 'first',
    windowSizeMills: 5000,
    windowStepMills: 1000
});
const draftThingClassPropertiesData_w4 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w4`, 'Number', 'Ia4', 'Ia4', 'Number', {
    expressionType: 'window',
    operator: 'sum',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '12345'
});
const draftThingClassPropertiesData_w4_f = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w4_f`, 'Number', 'Ia4_f', 'Ia4_f', 'Number', {
    expressionType: 'window',
    operator: 'sum',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '123abc'
});
const draftThingClassPropertiesData_w5 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w5`, 'Integer', 'Ia5', 'Ia5', 'Integer', {
    expressionType: 'window',
    operator: 'count',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '9876'
});
const draftThingClassPropertiesData_w5_f = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w5_f`, 'Integer', 'Ia5_f', 'Ia5_f', 'Integer', {
    expressionType: 'window',
    operator: 'count',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '57.87'
});
const draftThingClassPropertiesData_w6 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w6`, 'Number', 'Ia6', 'Ia6', 'Number', {
    expressionType: 'window',
    operator: 'avg',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '10.57'
});
const draftThingClassPropertiesData_w6_f = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w6_f`, 'Number', 'Ia6_f', 'Ia6_f', 'Number', {
    expressionType: 'window',
    operator: 'avg',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '10a'
});
const draftThingClassPropertiesData_w7 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_w7`, 'Number', 'Ia7', 'Ia7', 'Number', {
    expressionType: 'window',
    operator: 'majority',
    windowSizeMills: 5000,
    windowStepMills: 1000,
    windowDefaultValueJson: '123456'
});

const draftThingClassPropertiesData_ws1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_ws1`, 'Integer', 'Ia_ws1', 'Ia_ws1', 'Integer');
const draftThingClassPropertiesData_ws2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_ws2`, 'Boolean', 'Ia_ws2', 'Ia_ws2', 'Boolean');
const draftThingClassPropertiesData_ws3 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_ws3`, 'Boolean', 'Ia_ws2+3', 'Ia_ws3', 'Boolean');

const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_s);
const thingClassModelInstanceData1 = dataBody.thingClassModelInstanceBody(prefix_s1);

const msgData = dataBody.mesBody({ 'temp1': 20 });
const msgData_1 = dataBody.mesBody({ 'temp2': 10.75 });
const msgData_2 = dataBody.mesBody({ 'temp3': 10 });
const msgData_3 = dataBody.mesBody({ 'temp4': 12.31 });
const msgData_4 = dataBody.mesBody({ 'temp5': 51 });
const msgData_5 = dataBody.mesBody({ 'temp6': 23.83 });
const msgData_6 = dataBody.mesBody({ 'temp7': 'asdf' });
const msgData_7 = dataBody.mesBody({ 'temp8': true });
const msgData_8 = dataBody.mesBody({ 'temp9': 0b100011 });
const msgData_9 = dataBody.mesBody({ 'temp10': 1 });
const msgData_9_1 = dataBody.mesBody({ 'temp10_1': 3 });
const msgData_10 = dataBody.mesBody({ 'temp11': 1.0 });
const msgData_10_1 = dataBody.mesBody({ 'temp11_1': 5.0 });
const msgData_11 = dataBody.mesBody({ 'temp12': false });
const msgData_12 = dataBody.mesBody({ 'temp13': { "age": 30 } });
const msgData_13 = dataBody.mesBody({ 'temp14': [1, 2, 3] });
const msgData_14 = dataBody.mesBody({ 'temp15': '12asdf' });
const msgData_15 = dataBody.mesBody({ 'temp16': '100011' });
//创建window数据
const msgData_ws1 = dataBody.mesBody({ 'Ia_ws1': 'asdf' });
const msgData_ws2 = dataBody.mesBody({ 'Ia_ws2': 1 });
const msgData_ws3 = dataBody.mesBody({ 'Ia_ws3': 1 });

module.exports = {
    draftThingClassData,
    draftThingClassData_1,
    draftThingClassModelPropertiesData,
    draftThingClassModelPropertiesData_1,
    draftThingClassModelPropertiesData_2,
    draftThingClassModelPropertiesData_3,
    draftThingClassModelPropertiesData_4,
    draftThingClassModelPropertiesData_5,
    draftThingClassModelPropertiesData_6,
    draftThingClassModelPropertiesData_7,
    draftThingClassModelPropertiesData_8,
    draftThingClassModelPropertiesData_9,
    draftThingClassModelPropertiesData_9_1,
    draftThingClassModelPropertiesData_10,
    draftThingClassModelPropertiesData_10_1,
    draftThingClassModelPropertiesData_11,
    draftThingClassModelPropertiesData_12,
    draftThingClassModelPropertiesData_13,
    draftThingClassModelPropertiesData_14,
    draftThingClassModelPropertiesData_15,
    thingClassModelInstanceData,
    thingClassModelInstanceData1,
    draftThingClassPropertiesData_w,
    draftThingClassPropertiesData_w_f,
    draftThingClassPropertiesData_w1,
    draftThingClassPropertiesData_w1_f,
    draftThingClassPropertiesData_w2,
    draftThingClassPropertiesData_w2_f,
    draftThingClassPropertiesData_w3,
    draftThingClassPropertiesData_w4,
    draftThingClassPropertiesData_w4_f,
    draftThingClassPropertiesData_w5,
    draftThingClassPropertiesData_w5_f,
    draftThingClassPropertiesData_w6,
    draftThingClassPropertiesData_w6_f,
    draftThingClassPropertiesData_w7,
    draftThingClassPropertiesData_ws1,
    draftThingClassPropertiesData_ws2,
    draftThingClassPropertiesData_ws3,
    msgData,
    msgData_1,
    msgData_2,
    msgData_3,
    msgData_4,
    msgData_5,
    msgData_6,
    msgData_7,
    msgData_8,
    msgData_9,
    msgData_9_1,
    msgData_10,
    msgData_10_1,
    msgData_11,
    msgData_12,
    msgData_13,
    msgData_14,
    msgData_15,
    msgData_ws1,
    msgData_ws2,
    msgData_ws3
};
