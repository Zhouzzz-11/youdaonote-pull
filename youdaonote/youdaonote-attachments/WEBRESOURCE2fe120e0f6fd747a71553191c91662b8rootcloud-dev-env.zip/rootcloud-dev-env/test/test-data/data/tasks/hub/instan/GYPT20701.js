'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT20701';
const lessDevice = 200;
const addLessDeviceTime = 20;
const moreDevice = 500;
const addMoreDeviceTime = 80;

//物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
//设备
const multipleDevice = [];
const deleteMulDevice = [];
for (let i = 0; i < lessDevice; i++) {
	var thingClassModelInstanceData = dataBody.thingClassBulkInstanceBody(`${prefix}_${i}`, draftThingClassData.modelId);
	multipleDevice[i] = thingClassModelInstanceData.thingBulkInstanceBody;
	deleteMulDevice[i] = {
		'thingId': `${thingClassModelInstanceData.thingId}`,
		'modelId': `${draftThingClassData.modelId}`
	};
}

const multipleDevice1 = [];
const deleteMulDevice1 = [];
for (let i = 0; i < moreDevice; i++) {
	var thingClassModelInstanceData1 = dataBody.thingClassBulkInstanceBody(`${prefix}_${i}`, draftThingClassData.modelId);
	multipleDevice1[i] = thingClassModelInstanceData1.thingBulkInstanceBody;
	deleteMulDevice1[i] = {
		'thingId': `${thingClassModelInstanceData1.thingId}`,
		'modelId': `${draftThingClassData.modelId}`
	};
}

module.exports = {
	draftThingClassModelPropertiesData,
	draftThingClassData,
	multipleDevice,
	deleteMulDevice,
	multipleDevice1,
	deleteMulDevice1,
	addLessDeviceTime,
	addMoreDeviceTime,
	lessDevice,
	moreDevice
};