'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT15596';

//precondition
const ThingClassData = dataBody.draftThingClassBody(`${prefix}`, 'device');
const ThingClassData_2 = dataBody.draftThingClassBody(`${prefix}_3`, 'device');

//C2126122
const temp_option_1 = { 'name': '__workingStatus__', 'displayName': '设备工作状态', 'expressionType': 'groovy' };
const PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'String', '[0:"失败",1:"正常"][ONOFF]', 'ONOFF', 'Integer', temp_option_1);
const DeviceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}`);
const DeviceData_3 = dataBody.thingClassModelInstanceBody(`${prefix}_3`);

const postdata_1 = dataBody.mesBody({ 'ONOFF': 1 });

//C2126150
const postdata_2 = dataBody.mesBody({ 'ONOFF': 2 });

//C2126123
const temp_option_2 = { 'name': `${prefix}`, 'displayName': `${prefix}`, 'expressionType': 'linear', 'scale': 1, 'base': 2 };
const PropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(`${prefix}`, 'Number', `1*${prefix}+2`, 'temp', 'Number', temp_option_2);
const PropertiesData_3 = dataBody.updateDraftThingClassModelPropertiesBody(`${prefix}_1`, 'String', `if (${prefix}>0) "作业";else "离线"`, '', 'Integer', '__workingStatus__', temp_option_1);
const postdata_3 = dataBody.mesBody({ 'temp': 1 });

module.exports = {
    ThingClassData,
    ThingClassData_2,
    PropertiesData_1,
    PropertiesData_2,
    PropertiesData_3,
    DeviceData_1,
    DeviceData_3,
    postdata_1,
    postdata_2,
    postdata_3
};