'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const random = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 100));

const prefix_1 = 'GYPT28765_1';
const prefix_2 = 'GYPT28765_2';
const prefix_3 = 'GYPT28765_3';
const prefix_4 = 'GYPT28765_4';
const prefix_5 = 'GYPT28765_5';
const prefix_6 = 'GYPT28765_6';
const prefix_7 = 'GYPT28765_7';
const prefix_8 = 'GYPT28765_8';

//添加物模型
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');  //直连设备1
const draftThingClassData_4 = dataBody.draftThingClassBody(prefix_4, 'device');  //直连设备2
const draftThingClassData_5 = dataBody.draftThingClassBody(prefix_5, 'device');  //直连设备3
const draftThingClassData_6 = dataBody.draftThingClassBody(prefix_6, 'device');  //直连设备4
const draftThingClassData_7 = dataBody.draftThingClassBody(prefix_7, 'device');  //直连设备5
const draftThingClassData_8 = dataBody.draftThingClassBody(prefix_8, 'device');  //直连设备6
const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device', { directlyLinked: false });  //非直连设备
//添加网关模型
const draftGatewayClassData = dataBody.draftThingClassBody(prefix_3, 'gateway');

//添加设备
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);//直连
const thingClassModelInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_4);//直连
const thingClassModelInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_5);//直连
const thingClassModelInstanceData_6 = dataBody.thingClassModelInstanceBody(prefix_6);//直连
const thingClassModelInstanceData_7 = dataBody.thingClassModelInstanceBody(prefix_7);//直连
const thingClassModelInstanceData_8 = dataBody.thingClassModelInstanceBody(prefix_8);//直连
const thingGatewayModelInstanceData = dataBody.thingClassModelInstanceBody(prefix_3);//网关
const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2, { connectId: 'connectId' + random, gatewayId: thingGatewayModelInstanceData.thingId });//非直连

//属性
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });
const msgData_1 = dataBody.mesBody({ __raw_loc__: {cells:['$CELL,065000.000,460,1,10C6,7671427,,,50,60,200826,M']}});
const msgData_2 = dataBody.mesBody({ __raw_loc__: {cells:['$CELL,065000.000,460,1,10C6,7671427,,,50,60,200826,M']}}, { id: thingClassModelInstanceData_2.connectId });
const msgData_3 = dataBody.mesBody({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49', cells:['$CELL,065000.000,460,1,10C6,7671427,,,50,60,200826,M']}});
const msgData_4 = dataBody.mesBody({ __raw_loc__: {gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'}});
const msgData_5 = dataBody.mesBody({ __raw_loc__: {cells:['$CELL,065000.000,460,1,10C6,7671427,,,50,60,200826,M'], gps:'$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'}});
module.exports = {
	draftThingClassData_1,
	draftThingClassData_2,
	draftGatewayClassData,
	draftThingClassData_4,
	draftThingClassData_5,
	draftThingClassData_6,
	draftThingClassData_7,
	draftThingClassData_8,
	thingClassModelInstanceData_4,
	thingClassModelInstanceData_5,
	thingClassModelInstanceData_6,
	thingClassModelInstanceData_7,
	thingClassModelInstanceData_8,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData_1,
	thingGatewayModelInstanceData,
	thingClassModelInstanceData_2,
	msgData_1,
	msgData_2,
	msgData_3,
	msgData_4,
	msgData_5
};
