'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT25564';

const { valDict } = require('../../../../requireData');
const { processObject } = require('../../../../util');

class MultiNode {
	returnName(prefix, str) {
		return `${prefix}_${str}_${valDict.randStr}`;
	}
    
	MultiNodeCompositeThingClassBody(prefix, thingType, deviceTypeId, options = {}) {

		const modelId = this.returnName(prefix, 'draft_thing_class_id');
		const nodeId = this.returnName(prefix + '_composite_thing', 'draft_thing_class_nodeId');
		let CompositeThingClassBody = {
			name: options.name || this.returnName(prefix, 'draft_thing_class_name'),
			modelId: modelId,
			thingType: thingType,
			childThingNodes: [
				{
					childInterfaceId: deviceTypeId,
					thingType: 'device',
					nodeId: options.nodeId || nodeId,
					nodeName: options.nodeName,
					nodeType: options.nodeType || 'SingleDeviceNode'
				},
				options.anothernode
			],
			description: options.description || undefined
		};
		processObject(CompositeThingClassBody);
		return { CompositeThingClassBody, modelId, nodeId };
	}
}

//precondition
const ThingClassData = dataBody.draftThingClassBody(`${prefix}`, 'device');
const temp_option_1 = {'name':`${prefix}_1`, 'displayName':`${prefix}_1`,'expressionType':'linear', 'scale': 1, 'base': 2};
const PropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number',`1*${prefix}+2` , 'temp' ,'Number' ,temp_option_1);
const compositeThing_1 = dataBody.draftCompositeThingClassBody(`${prefix}_c_1`, 'compositeThing', ThingClassData.modelId, {'nodeType': 'SingleDeviceNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const C_temp_option = {'name':`${prefix}_1`, 'displayName':`${prefix}_1`,'expressionType':'groovy'};
const C_PropertiesData = dataBody.draftThingClassModelPropertiesBody(`${prefix}_1`, 'Number', `$child("sum", "dt", "${prefix}_1")`, '' ,'Number' , C_temp_option);
const compositeThing_2 = dataBody.draftCompositeThingClassBody(`${prefix}_c_2`, 'compositeThing', compositeThing_1.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const compositeThing_3 = dataBody.draftCompositeThingClassBody(`${prefix}_c_3`, 'compositeThing', compositeThing_2.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

//C2078392
const compositeThing_4 = dataBody.draftCompositeThingClassBody(`${prefix}_c_4`, 'compositeThing', compositeThing_3.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

//C2078393
const compositeThing_5 = dataBody.draftCompositeThingClassBody(`${prefix}_c_5`, 'compositeThing', compositeThing_4.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});

//C2085616
const anothernode = {'childInterfaceId': compositeThing_2.modelId, 'thingType': 'compositeThing', 'nodeId': 'dr', 'nodeName': 'dr', 'nodeType': 'ThingNode'};
const multinode = new MultiNode();
const compositeThing_6 = multinode.MultiNodeCompositeThingClassBody(`${prefix}_c_6`, 'compositeThing', compositeThing_3.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt', 'anothernode': anothernode});

//C2125961
const compositeThing_1_1 = dataBody.draftCompositeThingClassBody(`${prefix}_c_1_1`, 'compositeThing', ThingClassData.modelId, {'nodeType': 'SingleDeviceNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const compositeThing_2_1 = dataBody.draftCompositeThingClassBody(`${prefix}_c_2_1`, 'compositeThing', compositeThing_1_1.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const compositeThing_3_1 = dataBody.draftCompositeThingClassBody(`${prefix}_c_3_1`, 'compositeThing', compositeThing_2_1.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});
const compositeThing_7 = dataBody.draftCompositeThingClassBody(`${prefix}_c_3`, 'compositeThing', compositeThing_3_1.modelId, {'nodeType': 'ThingNode', 'nodeId': 'dt', 'nodeName': 'dt'});


module.exports = {ThingClassData, compositeThing_1, compositeThing_2, compositeThing_3, compositeThing_4, compositeThing_5, compositeThing_6, compositeThing_7, compositeThing_1_1, compositeThing_2_1, compositeThing_3_1, PropertiesData_1, C_PropertiesData};