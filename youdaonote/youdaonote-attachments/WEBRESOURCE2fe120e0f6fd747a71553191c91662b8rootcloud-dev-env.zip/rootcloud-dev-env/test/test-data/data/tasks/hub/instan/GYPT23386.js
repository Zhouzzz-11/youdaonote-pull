'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT23386';
const prefix_1 = 'GYPT23386_1';
const prefix_2 = 'GYPT23386_2';
const prefix_3 = 'GYPT23386_3';
const prefix_4 = 'GYPT23386_4';
const prefix_5 = 'GYPT23386_5';
//创建一个设备类型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number');
//使用同一个设备类型创建5个不同的设备
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2);
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_3);
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_4);
const thingInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_5);
//给5个设备分别设置位置信息
const locationData_1 = dataBody.putLocationBody('中国', '湖北省', '武汉市');
const locationData_2 = dataBody.putLocationBody('中国', '湖北省', '武汉市');
const locationData_3 = dataBody.putLocationBody('中国', '湖北省', '宜昌市');
const locationData_4 = dataBody.putLocationBody('中国', '湖北省', '孝感市');
const locationData_5 = dataBody.putLocationBody('中国', '山西省', '太原市');
//根据设置的位置信息按省份查询结果
const deviceIdList = [thingInstanceData_1.thingId, thingInstanceData_2.thingId, thingInstanceData_3.thingId, thingInstanceData_4.thingId, thingInstanceData_5.thingId];
const countByStateData = dataBody.postCountDeviceByStateBody('中国', deviceIdList);
const countByCityData = dataBody.postCountDeviceByCityBody(deviceIdList);

module.exports = {
	draftThingClassData,
	draftThingClassPropertiesData,
	thingInstanceData_1,
	thingInstanceData_2,
	thingInstanceData_3,
	thingInstanceData_4,
	thingInstanceData_5,
	locationData_1,
	locationData_2,
	locationData_3,
	locationData_4,
	locationData_5,
	countByStateData,
	countByCityData
};