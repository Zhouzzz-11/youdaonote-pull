'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT22362';
const Moment = require('moment');

const level = Moment.utc().format('YYYYMMDD').concat(Math.round(Math.random() * 80)) - Math.round(Math.random() * 2000);
const postAlarmSeverities = dataBody.alarmSeverities(prefix, parseInt(level));
//common data
const temp_option = {'name':`${prefix}`, 'displayName':`${prefix}`,'expressionType':'linear', 'scale': 1, 'base': 2};
const PropertiesData = dataBody.draftThingClassModelPropertiesBody(`${prefix}`, 'Number',`1*${prefix}+2` , 'temp' ,'Number' ,temp_option);
const postdata = dataBody.mesBody({'temp': 1 });

//C1880451
const c_option_1 = {'baseTime': 'CLOUD_TIME'};
const ThingClassData_1 = dataBody.draftThingClassBody(`${prefix}_1`, 'device', c_option_1);
const DeviceData_1 = dataBody.thingClassModelInstanceBody(`${prefix}_1`);

//C1880452
const c_option_2 = {'baseTime': 'CREATE_TIME'};
const ThingClassData_2 = dataBody.draftThingClassBody(`${prefix}_2`, 'device', c_option_2);
const DeviceData_2 = dataBody.thingClassModelInstanceBody(`${prefix}_2`);
const current_time = new Date();
const current_UTCtime = Moment(current_time.getTime()-28800000).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
const postdata_1 = dataBody.mesBody({'temp': 1}, {'ts': current_time.getTime()});

//C1880453 上数复用postdata
const DeviceData_3 = dataBody.thingClassModelInstanceBody(`${prefix}_3`);

//C1880454 上数复用postdata_1
const DeviceData_4 = dataBody.thingClassModelInstanceBody(`${prefix}_4`);

//C1880457
const alarmTypeData_1 = dataBody.alarmTypeBody(`${prefix}_1`, [], postAlarmSeverities.level, ThingClassData_1.modelId, `${prefix}>1`, 'becomesTrue', 'PLATFORM');

//C1880458
const alarmTypeData_2 = dataBody.alarmTypeBody(`${prefix}_2`, [], postAlarmSeverities.level, ThingClassData_2.modelId, `${prefix}>1`, 'becomesTrue', 'PLATFORM');

module.exports = {PropertiesData, postAlarmSeverities, ThingClassData_1, ThingClassData_2, DeviceData_1, DeviceData_2, DeviceData_3, DeviceData_4, postdata, postdata_1, alarmTypeData_1, alarmTypeData_2, current_UTCtime};
