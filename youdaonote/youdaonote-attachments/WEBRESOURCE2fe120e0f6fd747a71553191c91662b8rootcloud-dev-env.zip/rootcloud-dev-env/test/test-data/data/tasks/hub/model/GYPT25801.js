'use strict';

const { dataBody } = require('../../../../comData');
const prefix = 'GYPT25801';

//直连物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp + 1', 'temp', 'Number');
const updateDraftThingClassPropertiesData = dataBody.updateDraftThingClassModelPropertiesBody(`${prefix}_new`, 'Number', 'temp_new + 1', 'temp_new', 'Number', draftThingClassPropertiesData.name);


module.exports = {
    draftThingClassData,
    draftThingClassPropertiesData,
    updateDraftThingClassPropertiesData,
};
