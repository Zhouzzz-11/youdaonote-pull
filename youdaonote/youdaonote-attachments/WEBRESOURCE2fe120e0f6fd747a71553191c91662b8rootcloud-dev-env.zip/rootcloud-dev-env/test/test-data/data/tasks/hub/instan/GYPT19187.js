'use strict';
const { valDict } = require('../../../../requireData');
const { dataBody } = require('../../../../comData');

//create  device The manufacturer name can be filled
const prefix = 'GYPT19187';
//create device The manufacturer name and manufacturerId can be filled
const prefix_1 = 'GYPT19187_1';
const thingInfoData = dataBody.thingInfoBody({ manufacturer: valDict.manufacturer});
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix, { thingInfo: thingInfoData.thingInfoBody  });
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1, {thingInfo: thingInfoData.thingInfoBody , manufacturerId: valDict.manufacturerId });

module.exports = {
	thingInfoData,
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	thingClassModelInstanceData_1
};