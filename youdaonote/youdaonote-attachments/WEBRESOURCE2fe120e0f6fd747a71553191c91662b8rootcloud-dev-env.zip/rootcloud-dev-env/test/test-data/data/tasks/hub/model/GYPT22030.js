'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT22030';
const prefix_1 = 'GYPT22030_1';
const lessProperties = 200;
const addLessPropertiesTime = 15;
const moreProperties = 500;
const addMorePropertiesTime = 80;

//物模型
const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');

//批量创建属性200个
const multipleProperties = [];
const deleteMulProperties = [];
for (let i = 0; i < lessProperties; i++) {
	var draftThingClassModelPropertiesData = dataBody.bulkAddPropertiesBody(`${prefix}_${i}`,'Number', 'Ia',`Ia_${i}`, 'Number' );
	multipleProperties[i] = draftThingClassModelPropertiesData.bulkPropertiesBody;
	deleteMulProperties[i] = {
		'name': `${draftThingClassModelPropertiesData.name}`
	};
}


//批量创建属性500个
const multipleProperties1 = [];
const deleteMulProperties1 = [];
for (let i = 0; i < moreProperties; i++) {
	var draftThingClassModelPropertiesData1 = dataBody.bulkAddPropertiesBody(`${prefix}_${i}`,'Number', 'Ia',`Ia_${i}`, 'Number' );
	multipleProperties1[i] = draftThingClassModelPropertiesData1.bulkPropertiesBody;
	deleteMulProperties1[i] = {
		'name': `${draftThingClassModelPropertiesData1.name}`
	};
}

module.exports = {
	draftThingClassData,
	draftThingClassData_1,
	multipleProperties1,
	deleteMulProperties1,
	multipleProperties,
	deleteMulProperties,
	addLessPropertiesTime,
	addMorePropertiesTime,
	lessProperties,
	moreProperties
};