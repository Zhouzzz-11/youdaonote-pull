'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT29577';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Integer', 'Ia', `Ia`, 'Integer', { expressionType: 'linear',scale: 1,base: 1});
const draftThingClassModelPropertiesData2 = dataBody.draftThingClassModelPropertiesBody(prefix, 'String', 'Ia', `Ia`, 'String', { expressionType: 'linear',scale: 1,base: 1});


module.exports = {
    draftThingClassData,
    draftThingClassModelPropertiesData,
    draftThingClassModelPropertiesData2
};