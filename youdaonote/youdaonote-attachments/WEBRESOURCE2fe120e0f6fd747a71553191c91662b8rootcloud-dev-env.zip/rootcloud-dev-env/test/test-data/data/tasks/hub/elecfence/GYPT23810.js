'use strict';

const { dataBody } = require('../../../../comData');
const Moment = require('moment');
const prefix = 'GYPT23810';

const current_time = new Date();

const validFrom = Moment(current_time.getTime() - 10000000).format('YYYY-MM-DDTHH:mm:ss') + 'Z';
const validThru = Moment(current_time.getTime() + 10000000).format('YYYY-MM-DDTHH:mm:ss') + 'Z';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Json', '$position(__raw_loc__)', '__raw_loc__', 'Json', { name: '__location__', displayName: '当前位置' });
const thingInstanceData = dataBody.thingClassModelInstanceBody(prefix);
//创建圆形电子围栏
const elecfenceData = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validThru, { radius: 100 });
const elecfenceData_3 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validThru);
//创建多边形电子围栏
const locationData = dataBody.locationBody({ longitude: '116.299381', latitude: '39.970871' });
const locationData_1 = dataBody.locationBody({ longitude: '120.299381', latitude: '67.970871' });
const locationData_2 = dataBody.locationBody({ longitude: '139.299381', latitude: '45.970871' });
const locationData_3 = dataBody.locationBody({ longitude: '150.299381', latitude: '52.970871' });
const elecfenceData_1 = dataBody.createElecfenceBody('polygon', thingInstanceData.thingId, validFrom, validThru, { polygon: [locationData, locationData_1, locationData_2] });
const elecfenceData_2 = dataBody.createElecfenceBody('polygon', thingInstanceData.thingId, validFrom, validThru, { polygon: [locationData, locationData_1] });
//创建路径的电子围栏
const elecfenceData_4 = dataBody.createElecfenceBody('route', thingInstanceData.thingId, validFrom, validThru, { route: [[locationData, locationData_1, locationData_2, locationData_3]], paramPoints: [locationData, locationData_1] });
const elecfenceData_5 = dataBody.createElecfenceBody('route', thingInstanceData.thingId, validFrom, validThru, { route: [[locationData, locationData_1, locationData_2, locationData_3]] });
//创建行政区的电子围栏
const elecfenceData_6 = dataBody.createElecfenceBody('region', thingInstanceData.thingId, validFrom, validThru, { regionName: '西安市', regionCode: '610100' });
const elecfenceData_7 = dataBody.createElecfenceBody('region', thingInstanceData.thingId, validFrom, validThru, { regionName: '西安市' });
//创建电子围栏时没有设备，创建失败 
const elecfenceData_8 = dataBody.createElecfenceBody('region', undefined, validFrom, validThru, { regionName: '西安市', regionCode: '610100' });
//创建围栏时fenceType错误时，创建失败 
const elecfenceData_9 = dataBody.createElecfenceBody('circgf', thingInstanceData.thingId, validFrom, validThru, { radius: 100 });
//创建围栏时起始时间等于停止时间，创建失败 
const elecfenceData_10 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validThru, validFrom, { radius: 100 });
//创建围栏时起始时间晚于停止时间，创建失败 
const elecfenceData_11 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validFrom, { radius: 100 });
//围栏创建成功后既是发布状态 
const elecfenceData_12 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validThru, { radius: 200 });
//当围栏不存在时，更新失败
const elecfenceData_13 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validThru, { radius: 300 });
//更新围栏时没有设备，更新失败
const elecfenceData_14 = dataBody.createElecfenceBody('circle', '', validFrom, validThru, { radius: 300 });
//更新围栏时起始时间晚于停止时间，更新失败
const elecfenceData_15 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validThru, validFrom, { radius: 200 });
//更新围栏时起始时间等于停止时间，更新失败
const elecfenceData_16 = dataBody.createElecfenceBody('circle', thingInstanceData.thingId, validFrom, validFrom, { radius: 300 });
//修改围栏状态为关闭，修改成功
const patchelecfence = dataBody.patchElecfenceBody('closed');
//修改围栏状态为失效，修改成功
const patchelecfence_1 = dataBody.patchElecfenceBody('expired');

module.exports = {
	draftThingClassData,
	thingInstanceData,
	draftThingClassModelPropertiesData,
	elecfenceData,
	elecfenceData_1,
	locationData,
	locationData_1,
	locationData_2,
	locationData_3,
	elecfenceData_2,
	elecfenceData_3,
	elecfenceData_4,
	elecfenceData_5,
	elecfenceData_6,
	elecfenceData_7,
	elecfenceData_8,
	elecfenceData_9,
	elecfenceData_10,
	elecfenceData_11,
	elecfenceData_12,
	elecfenceData_13,
	elecfenceData_14,
	elecfenceData_15,
	elecfenceData_16,
	patchelecfence,
	patchelecfence_1
};
