'use strict';
const { valDict } = require('../../../../requireData');
const { dataBody } = require('../../../../comData');

//create  device The manufacturer name can be filled
const prefix = 'GYPT17249';
//create device The manufacturer name and manufacturerId can be filled
const prefix_1 = 'GYPT17249_1';

const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number');
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix, { manufacturerId: valDict.manufacturerId});

const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'gateway');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'temp+1', 'temp', 'Number');
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1, { manufacturerId: valDict.manufacturerId });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceData_1
};