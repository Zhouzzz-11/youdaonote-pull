/* eslint-disable linebreak-style */
'use strict';

const { dataBody } = require('../../../../comData');

//create model device, Add and  update 
const prefix = 'GYPT13437Instances';
//create gateway, Add  and update
const prefix_1 = 'GYPT13437Instances_1';
//crate compositeThing, Add  and update
const prefix_2 = 'GYPT13437Instances_2';
//create device, Add, update
const prefix_3 = 'GYPT13437Instances_3';
//create device, Add, update  ID is inconsistent with tenantid
const prefix_4 = 'GYPT13437Instances_4';
//create device, Add, update  ID does not exist
const prefix_5 = 'GYPT13437Instances_5';


const draftThingClassData = dataBody.draftThingClassBody(prefix, 'device');
const draftThingClassModelPropertiesData = dataBody.draftThingClassModelPropertiesBody(prefix, 'Number', 'Ia', 'Ia', 'Number');
const thingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix);
const updatethingClassModelInstanceData = dataBody.thingClassModelInstanceBody(prefix, { name: 'test' });

const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'gateway');
const draftThingClassModelPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'Ia1', 'Ia1', 'Number');
const thingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
const updatethingClassModelInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1, { name: 'test1' });

const draftThingClassData_2 = dataBody.draftCompositeThingClassBody(prefix_2, 'compositeThing', draftThingClassData.modelId);
const draftThingClassModelPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'Ia3', 'Ia3', 'Number');

const thingClassModelInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_3);

const thingClassModelInstanceData_2 = dataBody.thingClassModelInstanceCompositeThingBody(prefix_2, draftThingClassData_2.nodeId, thingClassModelInstanceData_3.thingId, draftThingClassData.modelId);
const updatethingClassModelInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2, { name: 'test2' });


const updatethingClassModelInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_3, { name: 'test3' });

const thingClassModelInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_4);
const updatethingClassModelInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_4, { name: 'test4' });

const thingClassModelInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_5);
const updatethingClassModelInstanceData_5 = dataBody.thingClassModelInstanceBody(prefix_5, { name: 'test5' });

module.exports = {
	draftThingClassData,
	draftThingClassModelPropertiesData,
	thingClassModelInstanceData,
	updatethingClassModelInstanceData,

	draftThingClassData_1,
	draftThingClassModelPropertiesData_1,
	thingClassModelInstanceData_1,
	updatethingClassModelInstanceData_1,

	draftThingClassData_2,
	draftThingClassModelPropertiesData_2,
	thingClassModelInstanceData_2,
	updatethingClassModelInstanceData_2,

	thingClassModelInstanceData_3,
	updatethingClassModelInstanceData_3,

	thingClassModelInstanceData_4,
	updatethingClassModelInstanceData_4,

	thingClassModelInstanceData_5,
	updatethingClassModelInstanceData_5


};
