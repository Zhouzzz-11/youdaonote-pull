'use strict';

const { dataBody } = require('../../../../comData');

const prefix = 'GYPT20509';
const prefix_1 = 'GYPT20509_1';
const prefix_2 = 'GYPT20509_2';
const prefix_3 = 'GYPT20509_3';
const prefix_4 = 'GYPT20509_4';

//创建物模型
const draftThingClassData_1 = dataBody.draftThingClassBody(prefix_1, 'device');
//添加属性
const draftThingClassPropertiesData_1 = dataBody.draftThingClassModelPropertiesBody(prefix_1, 'Number', 'temp + 1', 'temp', 'Number');
//创建设备实例
const thingInstanceData_1 = dataBody.thingClassModelInstanceBody(prefix_1);
//创建复合物模型
const draftCompositeThingClassData_1 = dataBody.draftCompositeThingClassBody(prefix_1+'composite', 'compositeThing', draftThingClassData_1.modelId);

const draftThingClassData_2 = dataBody.draftThingClassBody(prefix_2, 'device');
const draftThingClassPropertiesData_2 = dataBody.draftThingClassModelPropertiesBody(prefix_2, 'Number', 'temp + 1', 'temp', 'Number');
const thingInstanceData_2 = dataBody.thingClassModelInstanceBody(prefix_2);
const draftCompositeThingClassData_2 = dataBody.draftCompositeThingClassBody(prefix_2+'composite', 'compositeThing', draftThingClassData_2.modelId);

const draftThingClassData_3 = dataBody.draftThingClassBody(prefix_3, 'device');
const draftThingClassPropertiesData_3 = dataBody.draftThingClassModelPropertiesBody(prefix_3, 'Number', 'temp + 1', 'temp', 'Number');
const thingInstanceData_3 = dataBody.thingClassModelInstanceBody(prefix_3);
const draftCompositeThingClassData_3 = dataBody.draftCompositeThingClassBody(prefix_3+'composite', 'compositeThing', draftThingClassData_3.modelId);

const draftThingClassData_4 = dataBody.draftThingClassBody(prefix_4, 'device');
const draftThingClassPropertiesData_4 = dataBody.draftThingClassModelPropertiesBody(prefix_4, 'Number', 'temp + 1', 'temp', 'Number');
const thingInstanceData_4 = dataBody.thingClassModelInstanceBody(prefix_4);
const draftCompositeThingClassData_4 = dataBody.draftCompositeThingClassBody(prefix_4+'composite', 'compositeThing', draftThingClassData_4.modelId);

//批量创建物实例
const thingClassModelInstanceCompositeThingBulkData_1 = dataBody.thingClassModelInstanceCompositeThingBulkBody(prefix + '_1', draftCompositeThingClassData_1.modelId, draftCompositeThingClassData_1.nodeId, thingInstanceData_1.thingId, draftThingClassData_1.modelId, draftCompositeThingClassData_2.modelId, draftCompositeThingClassData_2.nodeId, thingInstanceData_2.thingId, draftThingClassData_2.modelId);
const thingClassModelInstanceCompositeThingBulkData_2 = dataBody.thingClassModelInstanceCompositeThingBulkBody(prefix + '_2', draftCompositeThingClassData_3.modelId, draftCompositeThingClassData_3.nodeId, thingInstanceData_3.thingId, draftThingClassData_3.modelId, draftCompositeThingClassData_4.modelId, draftCompositeThingClassData_4.nodeId, thingInstanceData_4.thingId, draftThingClassData_4.modelId);


module.exports = {
	draftThingClassData_1,
	draftThingClassPropertiesData_1,
	thingInstanceData_1,
	draftCompositeThingClassData_1,
	draftThingClassData_2,
	draftThingClassPropertiesData_2,
	thingInstanceData_2,
	draftCompositeThingClassData_2,
	draftThingClassData_3,
	draftThingClassPropertiesData_3,
	thingInstanceData_3,
	draftCompositeThingClassData_3,
	draftThingClassData_4,
	draftThingClassPropertiesData_4,
	thingInstanceData_4,
	draftCompositeThingClassData_4,
	thingClassModelInstanceCompositeThingBulkData_1,
	thingClassModelInstanceCompositeThingBulkData_2
};

