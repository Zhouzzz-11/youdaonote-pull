'use strict';

const { valDict } = require('./requireData');
const { processObject } = require('./util');
const Moment = require('moment');

class DataBody {
	returnName(prefix, str) {
		return `${prefix}_${str}_${valDict.randStr}`;
	}

	//files instruction body
	filesInstructionBody(msgId, ts, options = {}) {
		const instructionBody = {
			header: {
				msgId: msgId,
				ts: ts
			},
			body: {
				hasError: 0,
				isAck: Object.prototype.hasOwnProperty.call(options, 'isAck') ? options.isAck : true,
				results: Object.prototype.hasOwnProperty.call(options, 'isAck') ? {
					id: options.id || '',
					thingType: options.thingType || 'Device',
					file: {
						key: 'pass',
						name: '<string>',
						code: 0,
						isCompleted: Object.prototype.hasOwnProperty.call(options, 'isCompleted') ? options.isCompleted : true,
						progress: 100,
						type: 'txt',
						zip: null,
						encode: 'utf8',
						size: 1024,
						md5: '<string>'
					}
				} : undefined
			}
		};
		processObject(instructionBody);
		return { instructionBody };
	}

	//issued by the OTA body
	otaInstructionBody(msgId, ts, options = {}) {
		const instructionBody = {
			header: {
				msgId: msgId,
				ts: ts
			},
			body: {
				hasError: 0,
				isAck: Object.prototype.hasOwnProperty.call(options, 'isAck') ? options.isAck : true,
				results: {
					code: 0,
					desc: '',
					tips: '',
					status: options.status || 'UNZIP',
					isCompleted: Object.prototype.hasOwnProperty.call(options, 'isCompleted') ? options.isCompleted : true,
					progress: 100,
					lastModifyTime: ts,
					version: '1.0'
				}
			}
		};
		processObject(instructionBody);
		return { instructionBody };
	}

	//POST /external-data-sources
	externalDataSourceBody(prefix, dbType, options = {}) {
		let externalDataSourceBody = {
			dataSourceName: prefix + valDict.randStr,
			dbType: dbType,
			jdbcUrl: options.jdbcUrl || undefined,
			host: options.host || undefined,
			port: options.port || undefined,
			dbVersion: '8.0.2' || options.dbVersion,
			database: options.database || undefined,
			uri: options.uri || undefined,
			username: options.username || undefined,
			password: options.password || undefined,
		};
		processObject(externalDataSourceBody);
		return { externalDataSourceBody };
	}

	//POST  /thing/instruction-requests
	instructionRequestsBody(instructionProperties, instructionTemplateId, modelId, thingId, options = {}) {
		let instructionRequestsBody = {
			instructionProperties: instructionProperties,
			timeout: options.timeout || 3000,
			type: options.type || 'LIVE',
			instructionTemplateId: instructionTemplateId,
			modelId: modelId,
			thingId: thingId
		};
		return { instructionRequestsBody };
	}

	//PUT   /thing/draft/thing-interfaces/{modelId}/implementations/{destModelId}/properties
	putDraftThingInterfacesPropertiesBody(name, draftThingInterfacesPropertiesBody) {
		let putThingInterfacesPropertiesBody = {
			change: {
				name: name
			},
			to: draftThingInterfacesPropertiesBody[0]
		};
		processObject(putThingInterfacesPropertiesBody);
		return putThingInterfacesPropertiesBody;
	}

	//Post /device/device-instances/bulk-add
	thingClassBulkInstanceBody(prefix, modelId, options = {}) {
		const thingId = this.returnName(prefix, 'thing_id');
		//const staticPropertiesData = this.staticPropertiesData(options.propertyName, options.propertyValueJson);
		let thingBulkInstanceBody = {
			thingId: thingId,
			modelId: modelId,
			assetId: options.assetId || undefined,
			name: this.returnName(prefix, 'thing_name'),
			description: options.description || undefined,
			userName: options.userName || undefined,
			authToken: options.authToken || 'demoToken',
			gatewayId: options.gatewayId || undefined,
			connectId: options.connectId || undefined,
			metadata: {
				color: options.color || undefined,
			},
			protocol: options.protocol || valDict.protocolV4,
			manufacturerId: options.manufacturerId || valDict.manufacturerId,
			phase: options.phase || undefined,
			staticProperties: options.propertyName === undefined ? undefined : [{
				propertyName: options.propertyName || undefined,
				propertyValueJson: options.propertyValueJson || undefined,
			}],
			fromModel3: options.fromModel3 || undefined
		};

		processObject(thingBulkInstanceBody);
		return { thingBulkInstanceBody, thingId };
	}

	//POST  /thing/draft/thing-interfaces/{modelId}/implementations/{destModelId}/properties
	draftThingInterfacesPropertiesBody(prefix, propertyType, expression, mappingName, mappingPropertyType, options = {}) {
		const name = this.returnName(prefix, 'draft_thing_class_properties_name');
		let thingInterfaceProperitesBody = [{
			name: options.name || name,
			displayName: options.displayName || undefined,
			unit: options.unit || undefined,
			propertyType: propertyType,
			scale: options.scale || undefined,
			base: options.base || undefined,
			fromProperty: options.fromProperty || undefined,
			persisStrategy: options.persisStrategy || valDict.strategyAlways,
			privilege: options.privilege || valDict.privilegeReadWrite,
			expressionType: options.expressionType || valDict.expressionTypeGroovy,
			expression: expression,
			sourceFromConnection: {
				mappingName: mappingName,
				mappingPropertyType: mappingPropertyType
			}
		}];
		processObject(thingInterfaceProperitesBody);
		return { thingInterfaceProperitesBody, name };
	}

	//POST /thing/draft/thing-interfaces
	draftThingInterfacesBody(prefix, options = {}) {
		const modelId = this.returnName(prefix, 'draft_thing_interfaces');
		const name = options.name || prefix + 'draft_thing_interfaces' + valDict.randStr;
		let draftThingInterfacesBody = {
			modelId: modelId,
			name: name,
			description: options.description || valDict.desStr
		};
		return { draftThingInterfacesBody, modelId, name };
	}

	propertiesBody(options = {}) {
		let propertiesBody = {
			name: options.name || undefined,
			displayName: options.displayName || undefined,
			propertyType: options.propertyType || undefined
		};
		processObject(propertiesBody);
		return { propertiesBody };
	}

	//put /thing/draft/thing-interfaces/modelId
	updateThingInterfacesBody(prefix, options = {}) {
		const name = options.name || prefix + 'draft_thing_interfaces' + valDict.randStr;
		const properties = options.properties || undefined;
		let updateThingInterfacesBody = {
			name: name,
			description: options.description || valDict.desStr,
			properties: properties
		};
		return { updateThingInterfacesBody, name };
	}

	//POST /alarm/categories
	alarmCategoriesBody(prefix) {
		const cid = prefix + '_alarm_categories_id_' + valDict.randStr;
		let alarmCategoriesBody = {
			cid: cid,
			term: prefix + '_alarm_categories_term_' + valDict.randStr,
			description: valDict.desStr
		};
		processObject(alarmCategoriesBody);
		return { alarmCategoriesBody, cid };
	}

	//POST /alarm/severities
	alarmSeverities(prefix, level) {
		let alarmSeverities = {
			level: level,
			term: prefix + '_term_' + valDict.randStr,
			description: valDict.desStr
		};
		return alarmSeverities;
	}

	//POST /draft/alarm/types
	alarmTypeBody(prefix, categoryIds, severityLevel, logicalInterfaceId, condition, when, source, options = {}) {
		const alarmTypeId = prefix + '_alarm_type_id_' + valDict.randStr;
		let alarmTypeBody = {
			description: valDict.desStr,
			subject: valDict.randStr,
			alarmTypeId: alarmTypeId,
			categoryIds: categoryIds,
			severityLevel: severityLevel,
			logicalInterfaceId: logicalInterfaceId,
			condition: condition,
			when: when,
			name: prefix + '_alarm_type_name_' + valDict.randStr,
			source: source,
			everyTimeInterval: options.everyTimeInterval ? options.everyTimeInterval : undefined,
			delayPeriod: options.delayPeriod ? options.delayPeriod : undefined,
			acceptedThings: options.acceptedThings || undefined,
		};
		processObject(alarmTypeBody);
		return { alarmTypeBody, alarmTypeId };
	}

	//POST /draft/alarm/models/{modelId}  /按模型ID批量增加报警定义
	createBulkAlarmType(prefix, categoryIds, severityLevel, condition, when, options = {}) {
		const name = options.name || prefix + '_alarm_type_name_' + valDict.randStr;
		let createBulkAlarmType = [{
			description: options.description || valDict.desStr,
			subject: options.subject || valDict.randStr,
			categoryIds: categoryIds,
			severityLevel: severityLevel,
			remark: options.remark || "备注",
			errorCode: options.errorCode || "01001",
			metadata: {
				location: options.location || "sever room"
			},
			variables: [
				"Ia"
			],
			condition: condition,
			when: when,
			recoverCondition: options.recoverCondition || 'Ia < 12',
			delayPeriod: options.delayPeriod ? options.delayPeriod : undefined,
			requiredAck: options.requiredAck || false,
			notificationLimit: {
				limitEnum: options.limitEnum || 'onlyOne',
				timePeriod: options.timePeriod || 300000
			},
			notificationModes: [
				'SMS'
			],
			name: name,
			source: options.source || 'PLATFORM',
		}];
		processObject(createBulkAlarmType);
		return { createBulkAlarmType, name };
	};

	loginBody(username, password, options = {}) {
		const loginBody = {
			grant_type: options.grant_type || 'password',
			username: username,
			password: password,
			client_id: options.client_id || 'web_app',
			client_secret: options.client_secret || 'changeit'
		};
		return loginBody;
	}

	companyBody(prefix, id, options = {}) {
		const userId = options.username || this.returnName(prefix, 'super_user_id');
		const username = options.username || this.returnName(prefix, 'super_user_name');
		const password = options.password || valDict.password;
		const companyBody = {
			id: id,
			name: this.returnName(prefix, 'company_name'),
			isOperator: Object.prototype.hasOwnProperty.call(options, 'isOperator') ? options.isOperator : true,
			superAdmin: {
				id: userId,
				username: username,
				password: password
			}
		};
		return { companyBody, companyId: id, username, password };
	}

	serviceLicenseBody(tenantId, options = {}) {
		const serviceBody = {
			service: 'RC_SERVICE_001',
			grantTo: tenantId,
			startAt: options.startAt || 1577836800000
		};
		return { serviceBody };
	}

	userBody(prefix, options = {}) {
		const userId = this.returnName(prefix, 'uid');
		const username = this.returnName(prefix, 'user_name');
		const password = options.password || valDict.password;
		const userBody = {
			id: userId,
			username: username,
			password: password
		};
		return { userBody, username, password, userId };
	}

	devicePermissionBody(options = {}) {
		const devicePermissionBody = {
			name: 'only-see-userName',
			modelAclDefinitions: [
				{
					resourceClazzId: 'com.rootcloud.platform.Device',
					modelId: options.modelId || '*',
					modelAcl: {
						modelFilter: [
							{
								expression: options.uuid === undefined ? '{}' : '{"_id":{"$in":["' + options.uuid + '"]}}',
								type: 'MONGO'
							}],
						accessDefinition: {
							modelId: options.modelId || '*',
							accessRight: {
								ModelSeriesData: [
									{
										field: '*',
										access: 15
									}],
								ModelMetaData: [
									{
										field: options.field1 || 'userName',
										access: options.access1 || 15,
									},
									{
										field: options.field2 || undefined,
										access: options.access2 || undefined,
									},
									{
										field: options.field3 || undefined,
										access: options.access3 || undefined,
									},
									{
										field: options.field4 || undefined,
										access: options.access4 || undefined,
									}
								],
								DeviceDownstream: [
									{
										field: 'DeviceFileDownstream',
										access: 3
									},
									{
										field: 'DeviceHardWareUpgrade',
										access: 3
									}]
							}
						},
						modelId: options.modelId || '*'
					}
				}
			]
		};
		return devicePermissionBody;
	}

	devicePermissionBody_withIns(options = {}) {
		const devicePermissionBody = {
			name: 'only-see-userName',
			modelAclDefinitions: [
				{
					resourceClazzId: 'com.rootcloud.platform.Device',
					modelId: options.modelId || '*',
					modelAcl: {
						modelFilter: [
							{
								expression: options.uuid === undefined ? '{}' : '{"_id":{"$in":["' + options.uuid + '"]}}',
								type: 'MONGO'
							}],
						accessDefinition: {
							modelId: options.modelId || '*',
							accessRight: {
								ModelSeriesData: [
									{
										field: '__online__',
										access: 1
									}],
								ModelMetaData: [
									{
										field: '*',
										access: 3,
									}
								],
								DeviceDownstream: [
									{
										field: undefined,
										access: 32
									}]
							}
						},
						modelId: options.modelId || '*',
						modelType: 'DEVICE'
					}
				}, {
					resourceClazzId: 'com.rootcloud.platform.InstructionTemplate',
					modelId: '*',
					modelAcl: {
						modelFilter: [
							{
								expression: '',
								type: 'MONGO'
							}],
						accessDefinition: {
							modelId: '*',
							accessRight: {
								ModelMetaData: [
									{
										field: options.field1,
										access: options.access1,
									},
									{
										field: options.field2,
										access: options.access2,
									},
									{
										field: 'type',
										access: 3
									}
								]
							}
						},
						modelId: '*',
						modelType: 'DEVICE'
					},
					modelType: 'LOGICALINTERFACE'
				}
			]
		};
		return devicePermissionBody;
	}

	putAclGroups(options = {}) {
		const groupId = options.groupId || undefined;
		const putAclGroupsBody = {
			groupId: groupId,
			targetModelType: 'DEVICE',
			modelExpression: options.modelExpressionModelId === undefined ? undefined : [
				{
					resourceClassId: 'com.rootcloud.platform.Device',
					modelId: options.modelExpressionModelId || undefined,
					expression: {
						expression: options.uuid === undefined ? '{}' : '{"_id":{"$in":["' + options.uuid + '"]}}',
						type: 'MONGO',
					}
				}
			],
			grantedAccessPrivilege: options.grantedAccessPrivilegeModelId === undefined ? undefined : [
				{
					actionType: 0,
					resourceClazzId: 'com.rootcloud.platform.Device',
					attribute: {
						deviceModelId: options.grantedAccessPrivilegeModelId || undefined,
						attributeType: options.attributeType || undefined,
						attributeName: options.attributeName || undefined
					}
				}
			],
			revokedAccessPrivilege: options.revokedAccessPrivilegeModelId === undefined ? undefined : [
				{
					actionType: 0,
					resourceClazzId: 'com.rootcloud.platform.Device',
					attribute: {
						deviceModelId: options.revokedAccessPrivilegeModelId || undefined,
						attributeType: options.attributeType || undefined,
						attributeName: options.attributeName || undefined
					}
				}
			]
		};
		processObject(putAclGroupsBody);
		return { putAclGroupsBody };
	}

	draftSchemaBody(prefix, schmeaProperties) {
		const schemaName = this.returnName(prefix, 'schema_name');
		let schemaBody = {
			name: schemaName,
			describe: valDict.desStr,
			properties: schmeaProperties,
		};
		processObject(schemaBody);
		return { schemaBody, schemaName };
	}

	schemaPropertyBody(name, propertyType, displayName, unit, strategy) {
		let properityBody = {
			name: name,
			type: propertyType,
			displayName: displayName,
			unit: unit,
			persistStrategy: strategy
		};
		return properityBody;
	}

	//被创建网关设备的body所引用
	thingInfoExtensions(options = {}) {
		let thingInfoExtensionsBody = {
			name: options.name1 || undefined,
			displayName: options.displayName || undefined,
			type: options.type || undefined,
			value: options.value || undefined
		};
		processObject(thingInfoExtensionsBody);
		return { thingInfoExtensionsBody };
	}

	/*
	 Post/put  /thing/draft/thing-classes   网关/设备
	*/
	draftThingClassBody(prefix, thingType, options = {}) {
		const modelId = this.returnName(prefix, 'draft_thing_class_id');
		const name = options.name || this.returnName(prefix, 'draft_thing_class_name');
		const thingInfoExtensions = options.thingInfoExtensions || undefined;
		let thingClassBody = {
			name: name,
			modelId: modelId,
			thingType: thingType,
			offlineCheckPeriod: options.offlineCheckPeriod || 120000,
			connectionConfig: {
				directlyLinked: Object.prototype.hasOwnProperty.call(options, 'directlyLinked') ? options.directlyLinked : true,
				manufacturerId: options.manufacturerId || undefined,
				baseTime: options.baseTime || undefined,
				fromModel3: options.fromModel3 || false,
			},
			thingInfoExtensions: thingInfoExtensions,
			description: options.description || undefined
		};
		processObject(thingClassBody);
		return { thingClassBody, modelId, name, thingInfoExtensions };
	}

	/*
	  Post/put  /thing/draft/thing-classes   复合物
	*/
	draftCompositeThingClassBody(prefix, thingType, deviceTypeId, options = {}) {

		const modelId = this.returnName(prefix, 'draft_thing_class_id');
		const nodeId = this.returnName(prefix + '_composite_thing', 'draft_thing_class_nodeId');
		const thingInfoExtensions = options.thingInfoExtensions || undefined;
		let CompositeThingClassBody = {
			name: options.name || this.returnName(prefix, 'draft_thing_class_name'),
			modelId: modelId,
			thingType: thingType,
			connectionConfig: {
				directlyLinked: Object.prototype.hasOwnProperty.call(options, 'directlyLinked') ? options.directlyLinked : true,
				manufacturerId: options.manufacturerId || valDict.manufacturerId,
				baseTime: options.baseTime || undefined,
				fromModel3: options.fromModel3 || undefined
			},
			thingInfoExtensions: thingInfoExtensions,
			childThingNodes: [
				{
					childInterfaceId: deviceTypeId,
					thingType: 'device',
					nodeId: options.nodeId || nodeId,
					nodeName: options.nodeName || this.returnName(prefix + '_composite_thing', 'draft_thing_class_name'),
					nodeType: options.nodeType || 'SingleDeviceNode'
				}
			],
			description: options.description || undefined
		};
		processObject(CompositeThingClassBody);
		return { CompositeThingClassBody, modelId, nodeId, thingInfoExtensions };
	}

	/*
	  Post  /thing/draft/thing-classes/{modelId}/properties
   */
	draftThingClassModelPropertiesBody(prefix, propertyType, expression, mappingName, mappingPropertyType, options = { 'tags': null }) {
		const name = options.name || this.returnName(prefix, 'draft_thing_class_properties_name');
		let thingPropertiesBody = [{
			name: name,
			displayName: options.displayName || undefined,
			unit: options.unit || undefined,
			propertyType: propertyType,
			persisStrategy: options.persisStrategy || 'onReport',
			privilege: options.privilege || valDict.privilegeReadWrite,
			fixed: options.fixed || 2,
			tags: options.tags || undefined,
			expressionType: options.expressionType || valDict.expressionTypeGroovy,
			expression: expression,
			sourceFromConnection: {
				mappingName: mappingName,
				mappingPropertyType: mappingPropertyType
			},
			priority: options.priority || undefined,
			operator: options.operator || undefined,
			windowSizeMills: options.windowSizeMills || undefined,
			windowStepMills: options.windowStepMills || undefined,
			windowAllowedLatenessMills: options.windowAllowedLatenessMills || undefined,
			windowDefaultValueJson: options.windowDefaultValueJson || undefined,
			scale: options.scale || undefined,
			base: options.base || undefined,
			fromProperty: options.fromProperty || undefined,
		}];
		processObject(thingPropertiesBody);
		return { thingPropertiesBody, name };
	}

	/*
	  Put  /thing/draft/thing-classes/{modelId}/properties
	*/
	updateDraftThingClassModelPropertiesBody(prefix, propertyType, expression, mappingName, mappingPropertyType, oldname, options = {}) {
		let UpdatethingPropertiesBody = {
			change: {
				name: oldname
			},
			to: {
				name: options.name || this.returnName(prefix, 'draft_thing_class_properties_name'),
				displayName: options.displayName || undefined,
				unit: options.unit || undefined,
				propertyType: propertyType,
				persisStrategy: options.persisStrategy || valDict.strategyAlways,
				privilege: options.privilege || valDict.privilegeReadWrite,
				expressionType: options.expressionType || valDict.expressionTypeGroovy,
				expression: expression,
				scale: options.scale || undefined,
				base: options.base || undefined,
				fromProperty: options.fromProperty || undefined,
				sourceFromConnection: {
					mappingName: mappingName,
					mappingPropertyType: mappingPropertyType
				}
			}
		};
		processObject(UpdatethingPropertiesBody);
		return { UpdatethingPropertiesBody };
	}

	thingInfoBody(options = {}) {
		let thingInfoBody = {
			serialNumber: options.serialNumber || undefined,
			manufacturer: options.manufacturer || undefined,
			model: options.model || undefined,
			deviceClass: options.deviceClass || undefined,
			description: options.description || undefined,
			fwVersion: options.fwVersion || undefined,
			hwVersion: options.hwVersion || undefined,
			descriptiveLocation: options.descriptiveLocation || undefined,
			simImsi: options.simImsi || undefined,
			hasSim: options.hasSim || undefined,
			imei: options.imei || undefined
		};
		processObject(thingInfoBody);
		return { thingInfoBody };
	}

	/*
	   Post  /thing/thing-classes/{modelId}/instances  创建物实例
	 */
	thingClassModelInstanceBody(prefix, options = {}) {
		const thingId = this.returnName(prefix, 'thing_id');
		const connectId = options.connectId || undefined;
		const thingInfo = options.thingInfo || undefined;
		const thingInfoExtensions = options.thingInfoExtensions || undefined;
		let thingInstanceBody = {
			thingId: thingId,
			name: this.returnName(prefix, 'thing_name'),
			assetId: options.assetId || undefined,
			description: options.description || undefined,
			connectionConfig: {
				userName: options.userName || undefined,
				authToken: options.authToken || 'demoToken',
				gatewayId: options.gatewayId || undefined,
				connectId: connectId,
				protocol: options.protocol || valDict.protocolV4
			},
			staticProperties: options.propertyName === undefined && options.propertyValueJson === undefined
				? undefined : [{
					propertyName: options.propertyName || undefined,
					propertyValueJson: options.propertyValueJson || undefined,
				}],
			thingInfo: thingInfo,
			thingInfoExtensions: thingInfoExtensions,
			manufacturerId: options.manufacturerId || valDict.manufacturerId,
			fromModel3: options.fromModel3 || undefined,
		};
		processObject(thingInstanceBody);
		return { thingInstanceBody, thingId, connectId, thingInfo, thingInfoExtensions };
	}

	/*
put  /thing/thing-classes/{modelId}/instances/{thingId}  更新物实例
*/
	PutThingClassModelInstanceBody(prefix, options = {}) {
		const thingInfo = options.thingInfo || undefined;
		const thingInfoExtensions = options.thingInfoExtensions || undefined;
		let PutThingInstanceBody = {
			name: this.returnName(prefix, 'thing_name'),
			assetId: options.assetId || undefined,
			description: options.description || undefined,
			connectionConfig: {
				userName: options.userName || undefined,
				authToken: options.authToken || 'demoToken',
				gatewayId: options.gatewayId || undefined,
				connectId: options.connectId || undefined,
				protocol: options.protocol || valDict.protocolV4
			},
			staticProperties: options.propertyName === undefined && options.propertyValueJson === undefined
				? undefined : [{
					propertyName: options.propertyName || undefined,
					propertyValueJson: options.propertyValueJson || undefined,
				}],
			thingInfo: thingInfo,
			thingInfoExtensions: thingInfoExtensions,
			manufacturerId: options.manufacturerId || valDict.manufacturerId,
		};
		processObject(PutThingInstanceBody);
		return { PutThingInstanceBody, thingInfo, thingInfoExtensions };
	}

	/*
	  Post  /thing/thing-classes/{modelId}/instances  创建物实例  复合物
	*/
	thingClassModelInstanceCompositeThingBody(prefix, nodeId, deviceId, deviceTypeId, options = {}) {
		const thingId = this.returnName(prefix, 'thing_id');
		const thingInfo = options.thingInfo || undefined;
		const thingInfoExtensions = options.thingInfoExtensions || undefined;
		const instances = [{
			thingId: deviceId,
			modelId: deviceTypeId,
		}];
		if (options != {}) { instances.push.apply(instances, options); }
		let CompositeThingBody = {
			thingId: thingId,
			assetId: options.assetId || undefined,
			name: this.returnName(prefix, 'thing_name'),
			description: options.description || undefined,
			metadata: {
				range: options.range || undefined,
			},
			thingInfo: thingInfo,
			thingInfoExtensions: thingInfoExtensions,
			childThingNodes: [
				{
					nodeId: nodeId,
					instances: instances,
				}]
		};
		processObject(CompositeThingBody);
		return { CompositeThingBody, thingId, thingInfo, thingInfoExtensions };
	}

	/*
	  Post  /thing/thing-instances/bulk-add  批量创建物实例  复合物
	*/
	thingClassModelInstanceCompositeThingBulkBody(prefix, modelId1, nodeId1, deviceId1, deviceTypeId1, modelId2, nodeId2, deviceId2, deviceTypeId2, options = {}) {
		const thingId1 = this.returnName(prefix + '_composite_thing', 'thing_id_1');
		const thingId2 = this.returnName(prefix + '_composite_thing', 'thing_id_2');
		let CompositeThingBulkBody = [
			{
				thingId: thingId1,
				modelId: modelId1,
				assetId: options.assetId || undefined,
				name: this.returnName(prefix + '_composite_thing', 'thing_name_1'),
				description: options.description || undefined,
				metadata: {
					range: options.range || undefined,
				},
				childThingNodes: [
					{
						nodeId: nodeId1,
						instances: [
							{
								thingId: deviceId1,
								modelId: deviceTypeId1,
							}]
					}]
			},
			{
				thingId: thingId2,
				modelId: modelId2,
				assetId: options.assetId || undefined,
				name: this.returnName(prefix + '_composite_thing', 'thing_name_2'),
				description: options.description || undefined,
				metadata: {
					range: options.range || undefined,
				},
				childThingNodes: [
					{
						nodeId: nodeId2,
						instances: [
							{
								thingId: deviceId2,
								modelId: deviceTypeId2,
							}]
					}]
			}
		];
		processObject(CompositeThingBulkBody);
		return { CompositeThingBulkBody, thingId1, thingId2 };
	}

	/*
	  Post  /thing/thing-classes/{modelId}/instances  创建物实例包含多条静态属性
	*/
	thingClassModelManyStaticPropertiesBody(prefix, propertyName, propertyValueJson, propertyName1, propertyValueJson1, propertyName2, propertyValueJson2, options = {}) {
		const thingId = this.returnName(prefix, 'thing_id');
		let thingManyStaticPropertiesBody = {
			thingId: thingId,
			name: this.returnName(prefix, 'thing_name'),
			assetId: options.assetId || undefined,
			description: options.description || undefined,
			connectionConfig: {
				username: options.username || undefined,
				authToken: options.authToken || 'demoToken',
				gatewayId: options.gatewayId || undefined,
				connectionId: options.connectionId || undefined,
				protocol: options.protocol || valDict.protocolV4
			},
			staticProperties: [
				{
					propertyName: propertyName,
					propertyValueJson: propertyValueJson,
				},
				{
					propertyName: propertyName1,
					propertyValueJson: propertyValueJson1,
				},
				{
					propertyName: propertyName2,
					propertyValueJson: propertyValueJson2,
				}
			],
			manufacturerId: options.manufacturerId || valDict.manufacturerId,
			fromModel3: options.fromModel3 || undefined
		};
		processObject(thingManyStaticPropertiesBody);
		return { thingManyStaticPropertiesBody, thingId };
	}

	//被创建电子围栏所引用
	locationBody(options = {}) {
		let locationBody = {
			longitude: options.longitude || undefined,
			latitude: options.latitude || undefined
		};
		processObject(locationBody);
		return { locationBody };
	}

	/*
		Post  /elecfence​/saas  创建电子围栏
	*/
	createElecfenceBody(fenceType, deviceId, validFrom, validThru, options = {}) {
		const polygon = options.polygon || undefined;
		const route = options.route || undefined;
		const paramPoints = options.paramPoints || undefined;
		const interfaceId = options.interfaceId || undefined;
		let elecfenceBody = {
			fenceType: fenceType,
			deviceList: [
				{
					deviceId: deviceId,
					location: {
						longitude: options.longitude || 116.299381,
						latitude: options.latitude || 39.970871
					}
				}
			],
			validFrom: validFrom,
			validThru: validThru,
			disabled: options.disabled || false,
			extendFields: [],
			mapType: options.mapType || 'WGS84',
			polygon: polygon,
			radius: options.radius || undefined,
			regionName: options.regionName || undefined,
			regionCode: options.regionCode || undefined,
			route: route,
			paramPoints: paramPoints,
			fenceRuleId: options.fenceRuleId || undefined,
			interfaceId: interfaceId
		};
		processObject(elecfenceBody);
		return { elecfenceBody };
	}

	/*
		patch  /elecfence​/saas​/{elecFenceRuleId}  按id修改电子围栏状态
	 */
	patchElecfenceBody(fenceStatus) {
		let patchElecfenceBody = {
			fenceStatus: fenceStatus
		};
		processObject(patchElecfenceBody);
		return { patchElecfenceBody };
	}

	/*
		POST /draft​/thing​/thing-models​/{modelId}​/instruction-templates 创建指令
	*/
	createInstructionsBody(prefix, value, options = {}) {
		const instructionTemplateId = options.instructionTemplateId || this.returnName(prefix, 'instruction_id');

		let instructionsBody = {
			instructionTemplateId: instructionTemplateId,
			type: options.type || 'LIVE',
			timeout: options.timeout || 3000,
			definition: [{
				name: options.name1 || this.returnName(prefix, 'definition_name'),
				value: value,
				displayName: options.displayName || undefined,
				onOff: Object.prototype.hasOwnProperty.call(options, 'onOff') ? options.onOff : undefined
			}],
			name: options.name || this.returnName(prefix, 'instruction_name'),
			description: options.description || undefined,
		};
		processObject(instructionsBody);
		return { instructionsBody, instructionTemplateId };
	}

	//POST  /thing/instruction-requests
	thingInstructionRequestsBody(prefix, instructionProperties, instructionTemplateId, modelId, thingId, options = {}) {
		const requestId = options.requestId || this.returnName(prefix, 'instruction_requests');
		let thingInstructionRequestsBody = {
			instructionProperties: instructionProperties,
			timeout: options.timeout || 60000,
			type: options.type || 'LIVE',
			instructionTemplateId: instructionTemplateId,
			trigger: options.trigger || undefined,
			modelId: modelId,
			thingId: thingId,
			requestId: requestId
		};
		processObject(thingInstructionRequestsBody);
		return { thingInstructionRequestsBody, requestId };
	}
	//POST  /thing/instruction-requests   配置 SET 下发
	configRequestsBody(prefix, thingId, options = {}) {
		const requestId = options.requestId || this.returnName(prefix, 'instruction_requests');
		let configRequestsBody = {
			instructionProperties: {
				info: {
					content: options.content || 'ss',
					encode: options.encode || 'base64',
					version: options.version || '1.0'
				},
				param: options.version || '12'
			},
			timeout: options.timeout || 3000,
			trigger: options.trigger || 'realTime',
			type: options.type || 'CONFIG_SET',
			thingId: thingId,
			requestId: requestId
		};
		return { configRequestsBody, requestId };
	}
	//POST  /thing/instruction-requests  配置config_get下发
	instructionConfigRequestBody(prefix, param, modelId, thingId, options = {}) {
		const requestId = options.requestId || this.returnName(prefix, 'instruction_requests');
		let instructionConfigRequestBody = {
			instructionProperties: {
				encode: options.encode || 'base64',
				param: param
			},
			timeout: options.timeout || 3000,
			trigger: options.trigger || 'realTime',
			type: options.type || 'CONFIG_GET',
			modelId: modelId,
			thingId: thingId,
			requestId: requestId
		};
		processObject(instructionConfigRequestBody);
		return { instructionConfigRequestBody, requestId };
	}

	instructionBody(msgId, ts, options = {}) {
		const instructionBody = {
			header: {
				msgId: msgId,
				ts: ts
			},
			body: {
				hasError: 0,
				isAck: Object.prototype.hasOwnProperty.call(options, 'isAck') ? options.isAck : true,
				results: Object.prototype.hasOwnProperty.call(options, 'isAck') ? {
					id: options.id || undefined,
					cmds: [{
						name: 'OTA',
						code: 0,
						output: '',
						desc: 'success',
						tips: ''
					}]
				} : undefined,
			}
		};
		processObject(instructionBody);
		return { instructionBody };
	}

	patchActive() {
		const activeBody = {
			operation: 'activate'
		};
		return activeBody;
	}

	getQueryString(options = {}) {
		let tsQueryStr = '';
		let startTime = '';
		let endTime = '';
		if (options.ts) {
			startTime = Moment(options.ts - 100000000).format('YYYY-MM-DDTHH:mm:ss') + 'Z';
			endTime = Moment(options.ts + 100000000).format('YYYY-MM-DDTHH:mm:ss') + 'Z';
		} else {
			startTime = Moment().subtract(1, 'd').utc().toISOString();
			endTime = Moment().add(1, 'days').utc().toISOString();
		}
		tsQueryStr = `?startTime=${startTime}&endTime=${endTime}`;
		return tsQueryStr;
	}

	things(properties, options = {}) {
		const thing = {
			id: options.id ? options.id : undefined,
			eventType: options.eventType ? options.eventType : 'DEFAULT_EVENT',
			thingType: options.thingType || 'Device',
			items: [
				{
					qBad: ['level'],
					ts: options.ts || undefined,
					properties: properties
				}
			]
		};
		const tsQueryStr = this.getQueryString();
		processObject(thing);
		return { thing, tsQueryStr };
	}

	mesBody(properties, options = {}) {
		const mesBody = {
			header: {},
			body: {
				things: [
					{
						id: options.id ? options.id : undefined,
						eventType: options.eventType ? options.eventType : 'DEFAULT_EVENT',
						thingType: options.thingType || 'Device',
						items: [
							{
								qBad: ['level'],
								ts: options.ts || undefined,
								properties: properties
							}
						]
					}
				]
			}
		};
		const tsQueryStr = this.getQueryString();
		processObject(mesBody);
		return { mesBody, tsQueryStr };
	}

	mesBody_old(properties, options = {}) {
		const mesBody = {
			header: {},
			body: {
				id: options.id ? options.id : undefined,
				eventType: options.eventType ? options.eventType : 'DEFAULT_EVENT',
				thingType: options.thingType || 'Device',
				items: [
					{
						qBad: ['level'],
						ts: options.ts || undefined,
						properties: properties
					}]
			}
		};
		const tsQueryStr = this.getQueryString();
		processObject(mesBody);
		return { mesBody, tsQueryStr };
	}

	cloudTimeBody(msgId, ts) {
		const cloudTimeBody = {
			header: {
				msgId: msgId,
				ts: ts
			},
		};
		processObject(cloudTimeBody);
		return { cloudTimeBody };
	}

	locationDataBody(options = {}) {
		const locationDataBody = {
			header: {
				ts: options.ts || undefined,
			},
			body: {
				id: options.id || undefined,
				__raw_loc__:
				{
					gps: '$GPRMC,092927.000,A,2235.9058,N,11400.0518,E,0.000,74.11,151216,,,D*49'
				}
			}
		};
		const tsQueryStr = this.getQueryString();
		processObject(locationDataBody);
		return { locationDataBody, tsQueryStr };
	}

	/*
	Put /device/types/{deviceTypeId}/devices/{deviceId}/locations
	  */
	putLocationBody(country, state, city, options = {}) {
		let locationBody = {
			country: country,
			state: state,
			city: city,
			district: options.district || undefined,
			street: options.street || undefined,
			longitude: options.longitude || undefined,
			latitude: options.latitude || undefined,
			elevation: options.elevation || undefined,
			accuracy: options.accuracy || undefined,
		};
		processObject(locationBody);
		return { locationBody };
	}

	/*
	Post /devices/countByState
	  */
	postCountDeviceByStateBody(country, deviceIdList = []) {
		let countDeviceByStateBody = {
			country: country,
			deviceIdList: deviceIdList,
		};
		processObject(countDeviceByStateBody);
		return { countDeviceByStateBody };
	}

	/*
	Post /devices/{state}/countByCity
	*/
	postCountDeviceByCityBody(deviceIdList = []) {
		let countDeviceByCityBody = {
			deviceIdList: deviceIdList,
		};
		processObject(countDeviceByCityBody);
		return { countDeviceByCityBody };
	}

	/*
	Post /draft/device/types/{deviceTypeId}/properties
	  */
	bulkAddPropertiesBody(prefix, propertyType, expression, mappingName, mappingPropertyType, options = {}) {
		const name = options.name || this.returnName(prefix, 'draft_thing_class_properties_name');
		let bulkPropertiesBody = {
			name: name,
			displayName: options.displayName || undefined,
			unit: options.unit || undefined,
			propertyType: propertyType,
			persisStrategy: options.persisStrategy || valDict.strategyAlways,
			privilege: options.privilege || valDict.privilegeReadWrite,
			expressionType: options.expressionType || valDict.expressionTypeGroovy,
			expression: expression,
			mappingName: mappingName,
			mappingPropertyType: mappingPropertyType
		};
		processObject(bulkPropertiesBody);
		return { bulkPropertiesBody, name };
	}

	/*
	  POST  /draft/expressions
	  */
	postExpressionBody(prefix, options = {}) {
		const name = options.name || this.returnName(prefix, 'draft_thing_class_properties_name');
		let postExpressionBody = {
			name: name,
			description: options.description || 'string',
			type: options.type || 'groovy',
			expression: options.expression || 'string',
			scale: options.scale || 0,
			base: options.base || 0,
			operator: options.operator || 'min',
			windowStepMills: options.windowStepMills || 0,
			windowSizeMills: options.windowSizeMills || 0,
			windowDefaultValueJson: options.windowDefaultValueJson || 'string',
			windowAllowedLatenessMills: options.windowAllowedLatenessMills || 0,
			fromProperty: options.fromProperty || 'string',
			fromEventTypeName: options.fromEventTypeName || 'string',
			propertyType: options.propertyType || 'Integer'
		};
		processObject(postExpressionBody);
		return { postExpressionBody };
	}

	/*
	Post /draft/rule
	  */
	draftAlarmRulesBody(prefix, logicalInterfaceId, expressionId, options = {}) {
		const name = options.name || this.returnName(prefix, 'draft_alarm_rules_name');
		let draftAlarmRulesBody = {
			name: name,
			logicalInterfaceId: logicalInterfaceId,
			expressionId: expressionId,
			ruleMode: options.ruleMode || 'onHit',
			acceptedThings: options.acceptedThings || undefined,
		};
		processObject(draftAlarmRulesBody);
		return { draftAlarmRulesBody, name };
	}

	/*
Delete tenant with callback
  */
	deleteTenantBody(tenantId) {
		let tenantBody = {
			tenantId: tenantId,
		};
		return { tenantBody };
	}

}

const dataBody = new DataBody();

module.exports = {
	dataBody
};
