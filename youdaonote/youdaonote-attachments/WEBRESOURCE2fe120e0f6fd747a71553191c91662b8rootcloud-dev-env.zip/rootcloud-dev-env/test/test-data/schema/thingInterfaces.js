'use strict';

const Joi = require('@hapi/joi');
const { sourceFromConnection } = require('./common');

const thingInterfacesPostSchema = Joi.object({
	name: Joi.string().required(),
	modelId: Joi.string().required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	description: Joi.string(),
	isPublished: Joi.boolean().required(),
	updated: Joi.string(),
	updatedBy: Joi.string(),
	metadata: Joi.object(),
	properties:Joi.array().items({
		name:Joi.string().allow(null),
		displayName:Joi.string().allow(null),
		propertyType:Joi.string().allow(null)
	})
}).unknown(false);

const thingInterfacesGetByModelIdSchema = Joi.array().items(
	thingInterfacesPostSchema
);

const draftThingInterfacesModelPropertiesSchema = Joi.array().items(
	Joi.object({
		name: Joi.string().required(),
		propertyType: Joi.string().required(),
		persistStrategy: Joi.string().required(),
		period: Joi.number().integer(),
		privilege: Joi.string().required(),
		fixed: Joi.number(),
		expressionType: Joi.string().required(),
		expression: Joi.string().required(),
		priority: Joi.number().required(),
		fromProperty: Joi.string(),
		windowSizeMills: Joi.number().required(),
		windowStepMills: Joi.number().required(),
		windowAllowedLatenessMills: Joi.number().required(),
		sourceFromConnection: sourceFromConnection,
		createdAt: Joi.date().required(),
	}).required(),
);

module.exports = {
	thingInterfacesPostSchema,
	thingInterfacesGetByModelIdSchema,
	draftThingInterfacesModelPropertiesSchema
};