'use strict';

const Joi = require('@hapi/joi');
const { instance, model, staticProperty, thingInfo, thingInfoExtensions, connectionConfigInstance } = require('./common');

//创建设备实例
const thingInstancePostSchema = Joi.object({
	thingId: Joi.string().required(),
	assetId: Joi.string().required(),
	name: Joi.string().required(),
	modelId: Joi.string().required(),
	thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
	description: Joi.string(),
	metadata: ({
		range: Joi.string(),
	}),
	phase: Joi.string().required(),
	connectionConfig: Joi.object({
		userName: Joi.string(),
		gatewayId: Joi.string(),
		connectId: Joi.string(),
		authToken: Joi.string(),
		protocol: Joi.string().valid('ROOTCLOUD_V4').required(),
	}).required(),
	staticProperties: Joi.array().items(
		staticProperty
	),
	thingInfo: thingInfo,
	thingInfoExtensions: Joi.array().items(
		thingInfoExtensions
	),
	manufacturerId: Joi.string().required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	updated: Joi.string(),
	updatedBy: Joi.string(),
});

const thingInstancePutSchema = Joi.object({
	thingId: Joi.string().required(),
	assetId: Joi.string().required(),
	name: Joi.string().required(),
	modelId: Joi.string().required(),
	thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
	phase: Joi.string().required(),
	connectionConfig:
		connectionConfigInstance,
	manufacturerId: Joi.string().required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	updated: Joi.string().required(),
	updatedBy: Joi.string().required(),
});

const thingInstanceGetByModelIdSchema = Joi.array().items(
	thingInstancePostSchema
);

const thingInstanceGetSchema = Joi.array().items(
	Joi.object(
		{
			thingId: Joi.string().required(),
			userName: Joi.string().required(),
			authToken: Joi.string().required(),
			assetId: Joi.string().required(),
			name: Joi.string().required(),
			classId: Joi.string().valid('DEVICE', 'GATEWAY').required(),
			protocol: Joi.string().valid('ROOTCLOUD_V4').required(),
			manufacturerId: Joi.string().required(),
			phase: Joi.string().required(),
			model: model.required(),
			created: Joi.date().required(),
			createdBy: Joi.string().required()
		}
	)
);

//复合物
const thingInstanceCompositeSchema = Joi.object({
	thingId: Joi.string().required(),
	assetId: Joi.string().required(),
	name: Joi.string().required(),
	modelId: Joi.string().required(),
	thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
	description: Joi.string(),
	metadata: ({
		range: Joi.string(),
	}),
	thingInfo: thingInfo,
	thingInfoExtensions: Joi.array().items(
		thingInfoExtensions
	),
	childThingNodes: Joi.array().items(
		Joi.object({
			nodeId: Joi.string(),
			instances: Joi.array().items(
				instance
			)
		})
	).required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	updated: Joi.string(),
	updatedBy: Joi.string(),
});

//批量创建设备实例
const thingInstanceBulkSchema = Joi.object({
	thingId: Joi.string().required(),
	modelId: Joi.string().required(),
	assetId: Joi.string(),
	name: Joi.string().required(),
	userName: Joi.string(),
	authToken: Joi.string(),
	protocol: Joi.string().valid('ROOTCLOUD_V4'),
	staticProperties: Joi.array().items(
		staticProperty
	),
	success: Joi.boolean().required(),
	message: Joi.string().required(),
});

//批量创建复合物
const thingInstanceCompositeBulkSchema = Joi.array().items(
	Joi.object(
		{
			thingId: Joi.string().required(),
			modelId: Joi.string().required(),
			assetId: Joi.string(),
			name: Joi.string().required(),
			userName: Joi.string(),
			authToken: Joi.string(),
			protocol: Joi.string().valid('ROOTCLOUD_V4'),
			staticProperties: Joi.array().items(
				staticProperty
			),
			success: Joi.boolean().required(),
			message: Joi.string().required(),
		}
	)
);

//设备列表
const thingInstanceListSchema = Joi.array().items(
	Joi.object(
		{
			thingId: Joi.string().required(),
			assetId: Joi.string().required(),
			name: Joi.string().required(),
			modelId: Joi.string().required(),
			thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
			description:Joi.string(),
			childThingNodes: Joi.array().items(
				Joi.object({
					nodeId: Joi.string(),
					instances: Joi.array().items(
						instance
					)
				})
			).required(),
			created: Joi.date().required(),
			createdBy: Joi.string().required(),
			updated: Joi.date(),
			updatedBy: Joi.string()
		}
	)
);

module.exports = {
	thingInstancePostSchema,
	thingInstancePutSchema,
	thingInstanceGetSchema,
	thingInstanceGetByModelIdSchema,
	thingInstanceCompositeSchema,
	thingInstanceBulkSchema,
	thingInstanceCompositeBulkSchema,
	thingInstanceListSchema
};