'use strict';

const Joi = require('@hapi/joi');
const { childThingNode, connectionConfigClass, thingInfoExtensions, sourceFromConnection } = require('./common');

const draftThingClassSchema = Joi.object({
	modelId: Joi.string().required(),
	thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
	name: Joi.string().required(),
	offlineCheckPeriod: Joi.number().integer(),
	connectionConfig: connectionConfigClass.required(),
	thingInfoExtensions: Joi.array().items(
		thingInfoExtensions
	),
	isPublished: Joi.boolean().required(),
	description: Joi.string(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	updated: Joi.string(),
	updatedBy: Joi.string(),
});

const draftCompositeThingClassSchema = Joi.object({
	modelId: Joi.string().required(),
	thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
	name: Joi.string().required(),
	description: Joi.string(),
	childThingNodes: Joi.array().items(
		childThingNode
	).required(),
	downSamplingWindowSizeMillis: Joi.number().integer().required(),
	thingInfoExtensions: Joi.array().items(
		thingInfoExtensions
	),
	isPublished: Joi.boolean().required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	updated: Joi.string(),
	updatedBy: Joi.string(),
});

const draftThingClassModelPropertiesSchema = Joi.array().items(
	Joi.object({
		name: Joi.string().required(),
		propertyType: Joi.string().required(),
		persistStrategy: Joi.string().required(),
		period: Joi.number().integer(),
		privilege: Joi.string().required(),
		fixed: Joi.number().required(),
		expressionType: Joi.string().required(),
		priority: Joi.number().required(),
		expression: Joi.string().required(),
		fromProperty: Joi.string(),
		windowSizeMills: Joi.number().required(),
		windowStepMills: Joi.number().required(),
		windowAllowedLatenessMills: Joi.number().required(),
		sourceFromConnection: sourceFromConnection,
		createdAt: Joi.date().required(),
	}).required(),
);

const draftThingClassBasicSchema = Joi.object({
	modelId: Joi.string().required(),
	thingType: Joi.string().valid('device', 'gateway', 'compositeThing').required(),
	name: Joi.string().required(),
	offlineCheckPeriod: Joi.number().integer().required(),
	connectionConfig: connectionConfigClass.required(),
	isPublished: Joi.boolean().required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required()
}).unknown(true);

module.exports = {
	draftThingClassSchema,
	draftThingClassBasicSchema,
	draftCompositeThingClassSchema,
	draftThingClassModelPropertiesSchema
};
