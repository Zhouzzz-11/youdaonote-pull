'use strict';

const Joi = require('@hapi/joi');

const responseAlarmCategories = Joi.object({
	id: Joi.string(),
	description: Joi.string().required(),
	created: Joi.string(),
	createdBy: Joi.string(),
	tenantId: Joi.string(),
	cid: Joi.string().required(),
	term: Joi.string().required(),
}).unknown(false);

const responseAlarmSeverities = Joi.object({
	id: Joi.string(),
	description: Joi.string().required(),
	created: Joi.string(),
	createdBy: Joi.string(),
	tenantId: Joi.string(),
	term: Joi.string().required(),
	level: Joi.number().required(),
}).unknown(false);

const responseAlarmType = Joi.object({
	id: Joi.string(),
	name: Joi.string(),
	description: Joi.string().required(),
	created: Joi.string(),
	createdBy: Joi.string(),
	tenantId: Joi.string(),
	alarmInfo: Joi.object({
		source: Joi.string(),
		subject: Joi.string(),
	}).unknown(true),
	level: Joi.string(),
	alarmTypeId: Joi.string(),
	logicalInterface: Joi.object({
		interfaceId: Joi.string(),
	}),
	when: Joi.string()
}).unknown(true);

const responseBulkAlarmType = Joi.array().items(
	Joi.object({
		imodelId: Joi.string(),
		alarmTypeId: Joi.string(),
		name: Joi.string(),
		success: Joi.boolean(),
	}).unknown(true)
);

const responseAlarmHistory = Joi.object({
	id: Joi.string().required(),
	alarmTopicId: Joi.string().required(),
	alarmTopicName: Joi.string().required(),
	description: Joi.string(),
	tenantId: Joi.string().required(),
	modelId: Joi.string().required(),
	thingId: Joi.string().required(),
	fromDevice: Joi.boolean(),
	subject: Joi.string(),
	categories: Joi.array(),
	severityLevel: Joi.number(),
	severityName: Joi.string(),
	rule: Joi.string(),
	createdTime: Joi.string(),
	cloudTime: Joi.string(),
	activeTime: Joi.string(),
	active: Joi.boolean(),
	inActiveTime: Joi.string(),
	closed: Joi.boolean(),
	closedTime: Joi.string(),
	ackedState: Joi.string(),
}).unknown(false);

module.exports = {
	responseAlarmCategories,
	responseAlarmSeverities,
	responseAlarmType,
	responseAlarmHistory,
	responseBulkAlarmType
};
