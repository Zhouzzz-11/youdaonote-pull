'use strict';

const Joi = require('@hapi/joi');

const historianDevicesetSchema = Joi.array().items(
	Joi.object({
		columns: Joi.array().items(Joi.string()).required(),
		rows: Joi.array().items(
			Joi.array().items(
				Joi.any()
			).length(Joi.ref('...columns.length'))
		).required(),
		deviceId: Joi.string().required(),
		logicalTypeId: Joi.string().required(),
	}).unknown(false)
);

const getHistorianSchema = Joi.array().items(
	Joi.object({
		thingId: Joi.string().required(),
		modelId: Joi.string().required(),
		columns: Joi.array().items(Joi.string()).required(),
		rows: Joi.array().items(
			Joi.array().items(
				Joi.any()
			).length(Joi.ref('...columns.length'))
		).required()
	}).unknown(false)
);


module.exports = {
	historianDevicesetSchema,
	getHistorianSchema
};
