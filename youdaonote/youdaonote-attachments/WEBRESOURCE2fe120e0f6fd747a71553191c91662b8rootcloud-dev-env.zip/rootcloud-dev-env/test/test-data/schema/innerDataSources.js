'use strict';

const Joi = require('@hapi/joi');

const dataSource = Joi.object({
	type: Joi.string().valid('flink', 'influx', 'emq', 'mongo', 'redis', 'kafka', 'hive', 'hdfs').required(),
	resourceLevel: Joi.string().valid('statics', 'shared', 'dedicated').required(),
	version: Joi.string().required(),
	kafkaBroadcastAddress: Joi.string(),
	nodeNum: Joi.number(),
	eachNodeCores: Joi.number(),
	eachNodeMemory: Joi.number(),
	eachNodeDisk: Joi.number(),
	initScriptUri: Joi.allow(null, String),
	accessUrl: Joi.string(),
	mode: Joi.string(),
	accessKey: Joi.string(),
}).unknown(false);

const innerDataSourcesSchema = Joi.object({
	code: Joi.number().required(),
	message: Joi.string().required(),
	page: Joi.object({
		pageNo: Joi.number(),
		pageSize: Joi.number(),
		totalNum: Joi.number(),
		totalPage: Joi.number(),
		direction: Joi.string(),
		orderBy: Joi.string(),
		result: Joi.array().items(
			dataSource
		).required()
	}),
}).unknown(false);

module.exports = {
	innerDataSourcesSchema,
	dataSource,
};
