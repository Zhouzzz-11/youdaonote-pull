'use strict';

const Joi = require('@hapi/joi');

const deviceStatusSchema = Joi.array().items(
	Joi.object({
		thingId: Joi.string().required(),
		assetId: Joi.string(),
		modelId: Joi.string().required(),
		classId: Joi.string(),
		online: Joi.boolean(),
		workingStatus: Joi.string(),
		lastActivityTime: Joi.string(),
		offlineCheckPeriod: Joi.number(),
		firstDataTime: Joi.number(),
		created: Joi.string(),
		createdBy: Joi.string(),
		updated: Joi.string(),
		updatedBy: Joi.string(),
		country: Joi.string(),
		state: Joi.string(),
		city: Joi.string(),
		district: Joi.string(),
		street: Joi.string(),
		longitude: Joi.number(),
		latitude: Joi.number(),
		elevation: Joi.number(),
		accuracy: Joi.number(),
		locationSource: Joi.string(),
	}).unknown(false)
);

const findDeviceStatusSchema = Joi.array().items(
	Joi.object({
		id: Joi.string().required(),
		name: Joi.string(),
		tenantId: Joi.string().required(),
		deviceId: Joi.string().required(),
		assetId: Joi.string(),
		deviceTypeId: Joi.string().required(),
		classId: Joi.string(),
		gatewayId: Joi.allow(null, String),
		online: Joi.boolean(),
		lastActivityTime: Joi.string(),
		directlyLinked: Joi.boolean(),
		workingStatus: Joi.string(),
		offlineCheckPeriod: Joi.number(),
		created: Joi.string(),
		createdBy: Joi.string(),
		updated: Joi.string(),
		firstDataTime: Joi.number(),
		expectedOfflineTime: Joi.string(),
		country: Joi.string(),
		state: Joi.string(),
		city: Joi.string(),
		district: Joi.string(),
		street: Joi.string(),
		longitude: Joi.number(),
		latitude: Joi.number(),
		elevation: Joi.number(),
		accuracy: Joi.number(),
		locationSource: Joi.string(),
		updatedBy: Joi.string(),
	})
);

const putSingleDeviceLocationSchema = Joi.object({
	deviceId: Joi.string().required(),
	assetId: Joi.string(),
	deviceTypeId: Joi.string().required(),
	country: Joi.string(),
	state: Joi.string(),
	city: Joi.string(),
	district: Joi.string(),
	street: Joi.string(),
	longitude: Joi.number(),
	latitude: Joi.number(),
	elevation: Joi.number(),
	accuracy: Joi.number(),
	locationSource: Joi.string(),
});

module.exports = {
	deviceStatusSchema,
	findDeviceStatusSchema,
	putSingleDeviceLocationSchema
};