'use strict';

const Joi = require('@hapi/joi');

const errorResponseSchema = Joi.object({
	message: Joi.string().required(),
	code: Joi.string().required(),
}).unknown(false);

const childThingNode = Joi.object({
	childInterfaceId: Joi.string().required(),
	nodeId: Joi.string().required(),
	nodeName: Joi.string().required(),
	nodeType: Joi.string().required()
});

const connectionConfigClass = Joi.object({
	directlyLinked: Joi.boolean().required(),
	manufacturerId: Joi.string(),
	fromModel3: Joi.boolean(),
	baseTime: Joi.string(),
});

const thingInfo = Joi.object({
	serialNumber: Joi.string(),
	manufacturer: Joi.string(),
	model: Joi.string(),
	deviceClass: Joi.string(),
	description: Joi.string(),
	fwVersion: Joi.string(),
	hwVersion: Joi.string(),
	descriptiveLocation: Joi.string(),
	simImsi: Joi.string()
}).unknown(true);

const thingInfoExtensions = Joi.object({
	name: Joi.string(),
	displayName: Joi.string(),
	type: Joi.string(),
	value: Joi.string(),
});

const connectionConfigInstance = Joi.object({
	userName: Joi.string().required(),
	authToken: Joi.string().required(),
	protocol: Joi.string().valid('ROOTCLOUD_V4').required(),
});

const instance = Joi.object({
	thingId: Joi.string().required(),
	modelId: Joi.string().required(),
});

const model = Joi.object({
	modelId: Joi.string().required(),
	connectionConfig: Joi.object({}),
});

const sourceFromConnection = Joi.object({
	mappingName: Joi.string().required(),
	mappingPropertyType: Joi.string().required(),
	alignStrategy: Joi.string().required(),
});

const staticProperty = Joi.object({
	propertyName: Joi.string(),
	propertyValueJson: Joi.string(),
});

module.exports = {
	childThingNode,
	connectionConfigClass,
	connectionConfigInstance,
	thingInfo,
	thingInfoExtensions,
	instance,
	model,
	sourceFromConnection,
	staticProperty,
	errorResponseSchema
};
