'use strict';

const Joi = require('@hapi/joi');

const instructionSchema = Joi.object({
	id: Joi.string().required(),
	name: Joi.string().required(),
	created: Joi.date().required(),
	createdBy: Joi.string().required(),
	status: Joi.string().required(),
	tenantId: Joi.string().required(),
	instructionTemplateId: Joi.string().required(),
	deviceTypeId: Joi.string().required(),
	type: Joi.string().required(),
	definition: Joi.array().items(
		Joi.any().when('type', {is: 'LIVE', then: Joi.object({
			name: Joi.string().required(),
			value: Joi.string().required(),
		})})
		.when('type', {is: 'CMD', then: Joi.object({
			name: Joi.string().required(),
			displayName: Joi.string().required(),
			onOff: Joi.boolean().required(),
		})})
	),
	timeout: Joi.number().integer().required(),
	updated: Joi.string(),
	updatedBy: Joi.string(),
	isPublished:Joi.boolean(),
	hasActiveVersion:Joi.boolean(),
});

const batchInstructionSchema = Joi.array().items(Joi.string().required()); 

module.exports = {
	instructionSchema,
	batchInstructionSchema,
};