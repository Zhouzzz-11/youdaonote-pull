'use strict';

const Joi = require('@hapi/joi');

const instructionRequestSchema = Joi.object({
	msgId: Joi.string().required(),
	groupId: Joi.string().required(),
}).unknown(false);

const getInstructionRequestSchema = Joi.object({
	msgId: Joi.string().required(),
	groupId: Joi.string().required(),
	directId: Joi.string(),
	deviceId: Joi.string(),
	payload: Joi.string(),
	deviceTypeId: Joi.string(),
	progress: Joi.number(),
	phase: Joi.string(),
	priority: Joi.string(),
	deviceUserName: Joi.string(),
	instructionType: Joi.string(),
	ts: Joi.number(),
	expired: Joi.boolean(),
	sentTime: Joi.number(),
	created: Joi.string(),
	createdBy: Joi.string(),
	tenantId: Joi.string(),
	instructionTemplateId: Joi.string().required(),
}).unknown(false);

module.exports = {
	instructionRequestSchema,
	getInstructionRequestSchema,
};