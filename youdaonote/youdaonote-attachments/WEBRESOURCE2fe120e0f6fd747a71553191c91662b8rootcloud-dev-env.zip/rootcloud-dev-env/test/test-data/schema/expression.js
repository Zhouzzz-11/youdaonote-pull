'use strict';

const Joi = require('@hapi/joi');

const expressionSchema = Joi.object({
	id: Joi.string().required(),
	name: Joi.string().required(),
	description: Joi.string().required(),
	created: Joi.string().required(),
	createdBy: Joi.string().required(),
	status: Joi.string().required(),
	tenantId: Joi.string().required(),
	isPublished: Joi.boolean().required(),
	hasActiveVersion: Joi.boolean().required(),
	expressionId: Joi.string().required(),
	type: Joi.string().required(),
	expression: Joi.string().required(),
	scale: Joi.number().required(),
	base: Joi.number().required(),
	fromProperty: Joi.string().required(),
	fromEventTypeName: Joi.string().required(),
	operator: Joi.string().required(),
	windowStepMills: Joi.number().required(),
	windowSizeMills: Joi.number().required(),
	windowAllowedLatenessMills: Joi.number().required(),
	windowDefaultValueJson: Joi.string().required()
});

module.exports = {
	expressionSchema
};
