'use strict';

const Joi = require('@hapi/joi');

const dataSource = Joi.object({
	id: Joi.string(),
	createTime: Joi.string(),
	updateTime: Joi.string(),
	params: Joi.object({
		dbType: Joi.string().valid('MYSQL_JDBC_URL', 'MYSQL_HOST_PORT', 'MONGO_JDBC_URL', 'MONGO_HOST_PORT').required(),
		dataSourceName: Joi.string(),
		jdbcUrl: Joi.string(),
		username: Joi.string(),
		password: Joi.string(),
		host: Joi.string(),
		port: Joi.number(),
		dbVersion: Joi.string(),
		uri: Joi.string(),
		database: Joi.string(),
	}),
	tenantId: Joi.string(),
}).unknown(false);

const postExternalDataSourcesSchema = Joi.object({
	code: Joi.number().required(),
	message: Joi.string().required(),
	body: dataSource,
}).unknown(false);

const getExternalDataSourcesSchema = Joi.object({
	code: Joi.number().required(),
	message: Joi.string().required(),
	page: Joi.object({
		pageNo: Joi.number(),
		pageSize: Joi.number(),
		totalNum: Joi.number(),
		totalPage: Joi.number(),
		orderBy: Joi.string(),
		direction: Joi.string(),
		result: Joi.array().items({
			id: Joi.string(),
			createTime: Joi.string(),
			updateTime: Joi.string(),
			params: Joi.object({
				dbType: Joi.string().valid('MYSQL_JDBC_URL', 'MYSQL_HOST_PORT', 'MONGO_JDBC_URL', 'MONGO_HOST_PORT').required(),
				dataSourceName: Joi.string(),
				jdbcUrl: Joi.string(),
				username: Joi.string(),
				password: Joi.string(),
				host: Joi.string(),
				port: Joi.number(),
				dbVersion: Joi.string(),
				uri: Joi.string(),
				database: Joi.string(),
			}),
			tenantId: Joi.string(),
		})
	})
}).unknown(false);

const deleteExternalDataSourcesSchema = Joi.object({
	message: Joi.string().required(),
	code: Joi.number().required(),
}).unknown(false);

module.exports = {
	postExternalDataSourcesSchema,
	dataSource,
	getExternalDataSourcesSchema,
	deleteExternalDataSourcesSchema,
};
