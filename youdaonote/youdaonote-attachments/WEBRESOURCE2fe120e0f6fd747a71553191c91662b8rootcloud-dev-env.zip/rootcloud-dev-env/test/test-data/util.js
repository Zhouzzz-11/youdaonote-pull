'use strict';

// const Moment = require('moment');
const Mqtt = require('mqtt');
const promiseRetry = require('promise-retry');
const zlib = require('zlib');
const { valDict } = require('./requireData');
const { log4js } = require('./../test-lib/logger');
const logger = log4js.getLogger('util');

function processObject(obj) {
	for ( let attr in obj) {
		if (obj[attr] === undefined) delete obj[attr];
		else if (typeof obj[attr]=='object'){
			processObject(obj[attr]);
		}
	}
}

function itWait(delayMs) {
	it(`Wait ${delayMs}ms`, function (done) {
		this.timeout = delayMs + 1000;
		setTimeout(function () {
			done();
		}, delayMs);
	});
}

function postData(topic, clientId, message, gz = false, options = {}) {

	it('Send device data to MQTT', function (done) {
		const client = Mqtt.connect({
			host: valDict.mqttHost,
			port: 1883,
			username: clientId,
			password: options.password || 'demoToken',
			clientId: clientId,
			protocol: 'mqtt'
		});

		client.on('error', (err) => {
			logger.info(err);
			client.end(true, () => {
				return done(err);
			});
		});

		client.on('offline', () => {
			throw Error('MQTT is offline');
		});

		client.on('connect', () => {
			const msgToPublish = gz ? zlib.gzipSync(Buffer.from(JSON.stringify(message), 'utf8')) : JSON.stringify(message);
			client.publish(topic, msgToPublish, {}, (err) => {
				if (!err) {
					logger.info('MQTT message sent');
					client.end(done);
				}
				else {
					logger.info('err: ' + err);
				}
			});
			
		});
	});
}


function saveData(sData, key1, pData, key2) {

	it('Save data', async() => {
		sData[key1] = pData.getData(key2);
	});
}

function getHeadersWithBearer( token ) {
	return {
		Authorization: `Bearer ${token}`
	};
}

class MaxRetriesExceededError extends Error {
	constructor(message) {
		super(message);
		Object.setPrototypeOf(this, MaxRetriesExceededError.prototype);
	}
}

async function retryRequest(options, action, shouldRetry) {
	return await promiseRetry(options, async (retry) => {
		const response = await action();
		if (shouldRetry(response)) {
			return retry(new MaxRetriesExceededError('shouldRetry returned true'));
		}
		return response;
	});
}


module.exports = {
	processObject,
	postData,
	saveData,
	getHeadersWithBearer,
	retryRequest,
	itWait
};