const dotenv = require('dotenv');
const os = require('os');
const { resolve } = require('path');
const { loggerCommon } = require('./../test-lib/logger');

class Blueprint {
	constructor() {
		this.tenantId = 't2';
		this.tenantS1Id = 's_t1_a';
		this.tenantS2Id = 's_t1_b';
		this.tenantS3Id = 's_t1_c';
		this.dotenvPath = resolve(__dirname, '.env');
		this.envPath = resolve(__dirname, '../env.txt');
		const res = dotenv.config({ path: this.dotenvPath });
		if (res.error) {
			const res1 = dotenv.config({ path: this.envPath });
			if (res1.error) {
				throw res1.error;
			}
		}
		this.env = process.env;
		this.runEnv = this.env.RUN_ENV ? this.env.RUN_ENV : 'local';
		this.superUser = {};
		this.urlDict = this.getUrls(this.runEnv);
		this.hubUrl = this.urlDict['HUB_URL'];
		this.historianUrl = this.urlDict['HISTORIAN_URL'];
		this.deployerUrl = this.urlDict['DEPLOYER_URL'];
		this.metricsUrl = this.urlDict['METRICS_URL'];
		this.identityUrl = this.urlDict['IDENTITY_URL'] || '';
		this.iotWorksUrl = this.env.IOTWORKS_HOST;
		this.mqttHost = this.env.EMQX_HOST ? this.env.EMQX_HOST : 'localhost';
		this.hubDict = {};
		this.openApiDict = {};
		this.identityDict = {};
		this.iotWorksDict = {};
		this.userToken = this.getAuth();
		this.getHubUrl();
		this.getOpenApiUrl();
		this.getIdentityUrl();
		this.getIotWorksUrl();
	}

	getAuth() {
		if (this.runEnv === 'local' || this.runEnv === 'ci' || this.runEnv === 'ci1') {
			return 'hub-super-user';
		}
		else {
			return 'aHViLXN1cGVyLXVzZXI';
		}
	}

	getHubUrl() {
		this.hubDict['alarmUrl'] = `${this.hubUrl}/alarm`;
		this.hubDict['callbackUrl'] = `${this.hubUrl}/resource/tenant/callback`;
		this.hubDict['deployerUrl'] = `${this.hubUrl}/deployer`;
		this.hubDict['deviceUrl'] = `${this.hubUrl}/device/types`;
		this.hubDict['deviceTypesUrl'] = `${this.hubUrl}/device/types`;
		this.hubDict['draftDeviceTypesUrl'] = `${this.hubUrl}/draft/device/types`;
		this.hubDict['draftSchemasUrl'] = `${this.hubUrl}/draft/schemas`;
		this.hubDict['alarmModelUrl'] = `${this.hubUrl}/draft/alarm/models`;
		this.hubDict['alarmTypeUrl'] = `${this.hubUrl}/draft/alarm/types`;
		this.hubDict['bulkDevicesUrl'] = `${this.hubUrl}/bulk/devices`;
		this.hubDict['instructionUrl'] = `${this.hubUrl}/thing/thing-models`;
		this.hubDict['draftInstructionUrl'] = `${this.hubUrl}/draft/thing/thing-models`;
		this.hubDict['richFindUrl'] = `${this.hubUrl}/find`;
		this.hubDict['instructionRequests'] = `${this.hubUrl}/thing/instruction-requests`;
		this.hubDict['draftExpression'] = `${this.hubUrl}/draft/expressions`;
		this.hubDict['draftRule'] = `${this.hubUrl}/draft/rules`;
		this.hubDict['elecfence'] = `${this.hubUrl}/elecfence/saas`;
		this.hubDict['draftElecfence'] = `${this.hubUrl}/draft/elecfence/types`;
		this.hubDict['deviceAggregate'] = `${this.hubUrl}/devices/status/aggregate`;
	}

	getOpenApiUrl() {
		this.openApiDict['thingClasses'] = `${this.hubUrl}/thing/thing-classes`;
		this.openApiDict['draftThingClasses'] = `${this.hubUrl}/thing/draft/thing-classes`;
		this.openApiDict['thingInstances'] = `${this.hubUrl}/thing/thing-instances`;
		this.openApiDict['thingInterfaces'] = `${this.hubUrl}/thing/thing-interfaces`;
		this.openApiDict['draftThingInterfaces'] = `${this.hubUrl}/thing/draft/thing-interfaces`;
		this.openApiDict['alarmTypes'] = `${this.hubUrl}/alarm/alarm-types`;
		this.openApiDict['alarmSeverities'] = `${this.hubUrl}/alarm/severities`;
		this.openApiDict['alarmCategories'] = `${this.hubUrl}/alarm/categories`;
		this.openApiDict['deviceTypes'] = `${this.hubUrl}/device/device-types`;
		this.openApiDict['deviceBulkAdd'] = `${this.hubUrl}/device/device-instances/bulk-add`;
		this.openApiDict['deviceBulkRemove'] = `${this.hubUrl}/device/device-instances/bulk-remove`;
		this.openApiDict['deviceStatus'] = `${this.hubUrl}/device/device-instances/status`;
		this.openApiDict['deviceStatusCount'] = `${this.hubUrl}/device/device-instances/status/count`;
		this.openApiDict['deviceInstances'] = `${this.hubUrl}/device/device-instances`;
		this.openApiDict['aclGroups'] = `${this.hubUrl}/acl-groups`;
		this.openApiDict['files'] = `${this.hubUrl}/files`;
		this.openApiDict['file'] = `${this.hubUrl}/file`;
		this.openApiDict['historianAlarm'] = `${this.historianUrl}/historian/alarms`;
		this.openApiDict['historian'] = `${this.historianUrl}/historian`;
		this.openApiDict['realtime'] = `${this.historianUrl}/realtime/models`;
		this.openApiDict['devicesUrl'] = `${this.hubUrl}/devices`;
		this.openApiDict['deviceTags'] = `${this.hubUrl}/device-type`;
	}

	getIdentityUrl() {
		this.identityDict['login'] = `${this.identityUrl}/api/v1/auth/login`;
		this.identityDict['company'] = `${this.identityUrl}/api/v1/company`;
		this.identityDict['user'] = `${this.identityUrl}/api/v1/user`;
		this.identityDict['servcieLicense'] = `${this.identityUrl}/api/v1/service/license`;
	}

	getIotWorksUrl() {
		this.iotWorksDict['innerDataSource'] = `${this.iotWorksUrl}/inner-data-sources`;
		this.iotWorksDict['externalDataSource'] = `${this.iotWorksUrl}/external-data-sources`;
	}

	getUrls(run_env) {
		switch (run_env) {
			case 'local':
				this.urlDict = {
					HUB_URL: 'http://localhost:8444',
					HISTORIAN_URL: 'http://localhost:8443',
					DEPLOYER_URL: 'http://localhost:8445',
					METRICS_URL: 'http://localhost:8446'
				};
				break;
			case 'ci': {
				const host = Object.values(os.networkInterfaces())
					.reduce((a, c) => c.forEach((x) => a.push(x)) || a, [])
					.filter(ni => ni.family === 'IPv4' && ni.internal === false)
					.map(ni => ni.address)[0];
				this.urlDict = {
					HUB_URL: `http://${host}:8444`,
					HISTORIAN_URL: `http://${host}:8443`,
					DEPLOYER_URL: `http://${host}:8445`,
					METRICS_URL: `http://${host}:8446`
				};
				break;
			}
			case 'ci1': {
				const host = '10.66.0.153';
				this.urlDict = {
					HUB_URL: `http://${host}:8444`,
					HISTORIAN_URL: `http://${host}:8443`,
					DEPLOYER_URL: `http://${host}:8445`,
					METRICS_URL: `http://${host}:8446`
				};
				break;
			}
			case 'qa':
				this.urlDict = {
					HUB_URL: 'http://hub.iot-qa.rootcloudapp.com',
					HISTORIAN_URL: 'http://historian.iot-qa.rootcloudapp.com',
					DEPLOYER_URL: 'http://eca-deployer.iot-qa.rootcloudapp.com',
					METRICS_URL: 'http://platform-metrics.iot-qa.rootcloudapp.com',
					IDENTITY_URL: 'http://rootcloud-identity.iot-qa.rootcloudapp.com'
				};
				this.superUser = {
					username: 'rc_admin',
					password: 'admin'
				};
				this.env.EMQX_HOST = '10.70.40.124';
				this.env.IOTWORKS_HOST = 'http://analysis-api.iot-qa.rootcloudapp.com';
				break;
			case 'dev':
				this.urlDict = {
					HUB_URL: 'http://hub.iot-dev.rootcloudapp.com',
					HISTORIAN_URL: 'http://historian.iot-dev.rootcloudapp.com',
					DEPLOYER_URL: 'http://eca-deployer.iot-dev.rootcloudapp.com',
					METRICS_URL: 'http://platform-metrics.iot-dev.rootcloudapp.com',
					IDENTITY_URL: 'http://rootcloud-identity.iot-dev.rootcloudapp.com'
				};
				this.superUser = {
					username: 'rc_admin',
					password: 'admin'
				};
				this.env.EMQX_HOST = '10.70.31.95';
				this.env.IOTWORKS_HOST = 'http://10.70.40.144:8880';
				break;
			case 'pre':
				this.urlDict = {
					HUB_URL: 'http://hub.iot-pre.rootcloudapp.com',
					HISTORIAN_URL: 'http://historian.iot-pre.rootcloudapp.com',
					DEPLOYER_URL: 'http://eca-deployer.iot-pre.rootcloudapp.com',
					METRICS_URL: 'http://platform-metrics.iot-pre.rootcloudapp.com',
					IDENTITY_URL: 'http://rootcloud-identity.iot-pre.rootcloudapp.com'
				};
				this.superUser = {
					username: 'rc_admin',
					password: '123qweasd'
				};
				this.env.EMQX_HOST = '10.70.43.30';
				this.env.IOTWORKS_HOST = 'http://analysis-api.iot-pre.rootcloudapp.com';
				break;
			default:
				loggerCommon.error("Don't support this run env now");
		}
		return this.urlDict;
	}
}


const bp = new Blueprint();
module.exports = {
	bp
};
