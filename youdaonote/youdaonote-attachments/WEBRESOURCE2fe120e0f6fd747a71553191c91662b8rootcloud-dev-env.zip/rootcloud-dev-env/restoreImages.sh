#!/bin/bash

if [ -f images-cache.tar ]; then
  echo "images-cache.tar found";
  docker load -i images-cache.tar;
  echo "images-cache.tar loaded"
else
  echo "images-cache.tar not found"
fi

