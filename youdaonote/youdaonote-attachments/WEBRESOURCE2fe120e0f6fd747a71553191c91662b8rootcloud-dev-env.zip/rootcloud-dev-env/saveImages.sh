#!/bin/bash
set -ex

source "$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"/env.sh

dockerComposeFiles=""
while IFS=  read -r -d $'\0'; do
    dockerComposeFiles+="-f $REPLY "
done < <(find . -name "docker-compose*" -print0)

docker save -o images-cache.tar \
  $(sh -c "docker-compose ${dockerComposeFiles} config"  | awk '{if ($1 == "image:") print $2;}')

echo "Saving Development Environment Images Finished!"
