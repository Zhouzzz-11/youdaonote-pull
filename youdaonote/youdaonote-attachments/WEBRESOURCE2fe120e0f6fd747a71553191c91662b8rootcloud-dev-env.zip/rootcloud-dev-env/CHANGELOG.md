## [1.16.177](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.176...v1.16.177) (2020-10-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.56.3 ([71e0696](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/71e0696756ad959e54d4dc9f4eb56219c0cd50fb))

## [1.16.176](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.175...v1.16.176) (2020-10-21)


### Bug Fixes

* 🐛 change default logging mode to prod ([cbb30e2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cbb30e23ffc5950342ecf7ad874d6b6c9efe5a4e))

## [1.16.175](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.174...v1.16.175) (2020-10-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.38.5 ([e31ed95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e31ed95355e2e9c2f99a6cd4181e9a4f58761091))

## [1.16.174](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.173...v1.16.174) (2020-10-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.17.3 ([642455d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/642455d5642edc8e9438a710ce58a2f5c243c628))

## [1.16.173](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.172...v1.16.173) (2020-10-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.56.1 ([a098379](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a09837971024ef2ea45997407a8fb037fc92dbba))

## [1.16.172](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.171...v1.16.172) (2020-10-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.38.4 ([472d156](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/472d156f1e5ed49d09ece5601cbf758c5402bb8a))

## [1.16.171](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.170...v1.16.171) (2020-10-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.56.0 ([27ec271](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/27ec27109b91de8a3c883741ec88c6ad78fdd702))

## [1.16.170](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.169...v1.16.170) (2020-10-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.5.1 ([16d2eaf](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/16d2eaf17d70f01d314b74b00773bbab3dc3c7be))

## [1.16.169](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.168...v1.16.169) (2020-10-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.48.10 ([4fc9a0f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4fc9a0fc6782b47469c7c0fabc10777e70df9e97))

## [1.16.168](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.167...v1.16.168) (2020-10-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.55.1 ([03bc16a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/03bc16a808c805374b4b4f0d76494410c33fce30))

## [1.16.167](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.166...v1.16.167) (2020-10-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.5.0 ([8223796](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8223796cf90ae9a39354654738bd2a0738df3d55))

## [1.16.166](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.165...v1.16.166) (2020-10-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.12.4 ([7e0fb69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e0fb695965adc6ae7252237910aa51b780e5fba))

## [1.16.165](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.164...v1.16.165) (2020-10-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.55.0 ([7193cd3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7193cd37363a22ba54fa7c7db8faf6867f0edeb9))

## [1.16.164](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.163...v1.16.164) (2020-10-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.54.1 ([3eb382b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3eb382bbdd6cb32c5ba12c0f0c53d9b66d1a8729))

## [1.16.163](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.162...v1.16.163) (2020-10-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.55.0 ([678793b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/678793b1d0f446c4a4fa4b8c6b780e6c9f1fb82d))

## [1.16.162](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.161...v1.16.162) (2020-10-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.54.0 ([71359c9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/71359c9eecf7a506af472ea9ba3e60301a0acc06))

## [1.16.161](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.160...v1.16.161) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.20 ([989b7a5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/989b7a5ca33fba85197d39afd7e7df6a74dd177f))

## [1.16.160](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.159...v1.16.160) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.53.11 ([331ec21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/331ec2157d6fecd5c96221a722256e6c6d837b6a))

## [1.16.159](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.158...v1.16.159) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.53.10 ([16a7fc1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/16a7fc1b638da7468f54d7d82392ee74d32ced3b))

## [1.16.158](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.157...v1.16.158) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.53.9 ([c499a8f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c499a8fe799d83d17249f1c5ca95e2eb6c5a4a6a))

## [1.16.157](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.156...v1.16.157) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.53.8 ([dfaed98](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dfaed98e4dd748cf2533bec8c80ae767e988fa26))

## [1.16.156](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.155...v1.16.156) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.54.1 ([5b16fa7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5b16fa7430d67e1c4ec96aac812a020eaed56281))

## [1.16.155](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.154...v1.16.155) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.17.2 ([5e6c4bd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5e6c4bdefad9bdcf94fa403b161014a9274b2909))

## [1.16.154](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.153...v1.16.154) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.48.9 ([0e2d5b0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0e2d5b081426e79660045c1bd525fb4914450b5b))

## [1.16.153](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.152...v1.16.153) (2020-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.9 ([8e08d74](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8e08d74eb439c2441fd6fd63ce63f7eace10ee86))

## [1.16.152](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.151...v1.16.152) (2020-10-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.54.0 ([0bf07a9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0bf07a9b925ba54cf0ac4ce741bd88fba9e379b5))

## [1.16.151](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.150...v1.16.151) (2020-10-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.38.3 ([f898597](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f898597b8ea3b7472d199c7fe477979a7e1da8a1))

## [1.16.150](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.149...v1.16.150) (2020-10-14)


### Bug Fixes

* 🐛 upgrade hub to 2.48.7 manually ([978dc67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/978dc67bd78129b7ba39d9c48588e56164901715))

## [1.16.149](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.148...v1.16.149) (2020-10-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.15 ([9a4bfa8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9a4bfa8e7143bb36d43cc6e7e68a680840ebcbb1))

## [1.16.148](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.147...v1.16.148) (2020-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.38.2 ([10d3435](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/10d34359ec474dda35d0215abfc2af71fdb6b791))

## [1.16.147](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.146...v1.16.147) (2020-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.37.5 ([ecf37b6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ecf37b6509b3100fa7071d3c3430f6deb401a244))

## [1.16.146](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.145...v1.16.146) (2020-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.48.4 ([4b4194b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4b4194bb094618ed1df0e7316afd85faa7517693))

## [1.16.145](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.144...v1.16.145) (2020-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.48.0 ([2a81658](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2a816582c8eab55c81654ab07cd1cef43fafc67e))

## [1.16.144](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.143...v1.16.144) (2020-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.37.6 ([474a6a8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/474a6a8f274a4257554f94f0f7f9bad717da0a16))

## [1.16.143](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.142...v1.16.143) (2020-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.47.1 ([b7b5c2d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b7b5c2d85c035bed835aeae377fe70dda5a6d92f))

## [1.16.142](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.141...v1.16.142) (2020-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.47.0 ([34bc6d4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/34bc6d4e917aae49c5dc0164e43d13437c2f39c2))

## [1.16.141](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.140...v1.16.141) (2020-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.51.3 ([aaa4644](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/aaa4644eb40ef5d5478ca4d2922311c9ce8e422b))

## [1.16.140](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.139...v1.16.140) (2020-10-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.51.2 ([f9d398a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f9d398ab4206a7e3d8dad61ca2f8993c255e79e2))

## [1.16.139](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.138...v1.16.139) (2020-10-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.51.1 ([f1f608b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f1f608b4f393ff1fc99b35386ebb7a487fa6883a))

## [1.16.138](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.137...v1.16.138) (2020-10-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.46.0 ([96a9686](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/96a96860328ab4cc775b08ff8422226467406bcd))

## [1.16.137](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.136...v1.16.137) (2020-10-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.51.0 ([65327d0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/65327d07c4bd3ecde95953c89799d62e917a956a))

## [1.16.136](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.135...v1.16.136) (2020-10-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.12 ([edad8ba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/edad8bac72c7fa50fc032d7085a72769fcc8b76d))

## [1.16.135](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.134...v1.16.135) (2020-10-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.17.1 ([d0d962f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d0d962f0c792c8de3c24743b8b6953c7f994a7bf))

## [1.16.134](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.133...v1.16.134) (2020-10-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.12.3 ([fe6c9c0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fe6c9c02bcc18c676d833e62eb5bc59467cb712d))

## [1.16.133](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.132...v1.16.133) (2020-10-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.7.1 ([b2fce46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b2fce46cc1959502802cda90dce577fbd183414d))

## [1.16.132](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.131...v1.16.132) (2020-10-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.37.3 ([3006e3a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3006e3a97458b7cca3e5c322f5b7bd3fe3ae7de9))

## [1.16.131](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.130...v1.16.131) (2020-10-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.37.2 ([84be4e6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/84be4e6ede62359db9fc596baf6f74a7fa03fc9d))

## [1.16.130](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.129...v1.16.130) (2020-09-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.11 ([bffaaec](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bffaaec0d3a89b17c92cded9bd0103b6fc968a9e))

## [1.16.129](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.128...v1.16.129) (2020-09-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.10 ([97cd7e0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/97cd7e019cb5bbaf3fbe1ba61be3f82d36f90047))

## [1.16.128](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.127...v1.16.128) (2020-09-29)


### Bug Fixes

* 🐛 set REDIS_URI for hub ([a3e64e4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a3e64e47097c2a9f928731d059a8e6f008b8f2f7))

## [1.16.127](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.126...v1.16.127) (2020-09-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.36.0 ([96767b3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/96767b3dc5a5adc8078f8169fc872b2ee4d3961b))

## [1.16.126](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.125...v1.16.126) (2020-09-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.50.0 ([afac624](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/afac6248ec07d771c5ef3d5cdae57d02d04dd83e))

## [1.16.125](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.124...v1.16.125) (2020-09-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.49.14 ([26d36bb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/26d36bbab5f856b5038baf370dd63a1633692edd))

## [1.16.124](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.123...v1.16.124) (2020-09-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.26 ([8e97a0e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8e97a0e62c95c7a03b30bcb3e35f9cd7bbf0fb33))

## [1.16.123](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.122...v1.16.123) (2020-09-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.49.13 ([2bd506b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2bd506bfdb6dbfb24b5c33a0d1349121ae002d06))

## [1.16.122](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.121...v1.16.122) (2020-09-27)


### Bug Fixes

* upgrade hub ([0fe664d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0fe664d063698572b3f7e3e144a7fd164bc6c800))

## [1.16.121](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.120...v1.16.121) (2020-09-27)


### Bug Fixes

*  update dependency @rootcloud/rootcloud-hub to v2.44.24 ([57f5c1d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/57f5c1d6dbfc82d1091196cadeb56199a43423bf))

## [1.16.120](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.119...v1.16.120) (2020-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.9 ([3fb51ba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3fb51bae2de6bb11b45391a11a72c42d5291df75))

## [1.16.119](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.118...v1.16.119) (2020-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.8 ([bcf3d45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bcf3d45f401964e2fe29a1c1da1c0ae846cdebd1))

## [1.16.118](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.117...v1.16.118) (2020-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.8 ([0d5e4de](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0d5e4de51e42f1cd189b4757e3f293cd89072ada))

## [1.16.117](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.116...v1.16.117) (2020-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.7 ([d03a840](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d03a8407da618e83170d28aaeb437dc5e94d6050))

## [1.16.116](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.115...v1.16.116) (2020-09-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.22 ([b1fbd4e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b1fbd4eafb08735ea2dd8258fa1f638c611253d8))

## [1.16.115](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.114...v1.16.115) (2020-09-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.10 ([6f07cab](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6f07cab962485a885738e740979772cc3373d9a3))

## [1.16.114](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.113...v1.16.114) (2020-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.9 ([d462f2f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d462f2f91bd4b0e35e2098ff3463a37ce28eb3f1))

## [1.16.113](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.112...v1.16.113) (2020-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.21 ([099c5e8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/099c5e83896f02037343bbb29c95542a0e434996))

## [1.16.112](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.111...v1.16.112) (2020-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.8 ([2221f33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2221f339528267c9d78e97788c7f66414381ccd9))

## [1.16.111](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.110...v1.16.111) (2020-09-25)


### Bug Fixes

* 🐛 env for less kafka rebalence ([eb969f0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/eb969f0363fc2b0f519c0163a28cb9c46c559fe9))

## [1.16.110](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.109...v1.16.110) (2020-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.49.12 ([eb846e3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/eb846e3c44b1d045f9fcb44812a2ca1d00805563))

## [1.16.109](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.108...v1.16.109) (2020-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.7 ([b233a73](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b233a73dba25568351e1b2d3c8634aad8e87d578))

## [1.16.108](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.107...v1.16.108) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.7 ([4de95f8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4de95f85e4d187fbd8cf9fce6e390091c682d17f))

## [1.16.107](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.106...v1.16.107) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.2 ([f18fc95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f18fc959518b361f4955b561555be947a3d109e2))

## [1.16.106](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.105...v1.16.106) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.12.1 ([b1602b5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b1602b57d8f3c4fe8a2275ffb9aea183c84558dd))

## [1.16.105](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.104...v1.16.105) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.53.0 ([c541928](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c541928a441c1515d7f6da1b15af9ac79c2c8bd2))

## [1.16.104](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.103...v1.16.104) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.6 ([f3c09ce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f3c09ce974544532ac7c0a7fb19c5e5dd3378b08))

## [1.16.103](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.102...v1.16.103) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.20 ([fe77f23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fe77f237147d8e095f4a61b04298d5bca0659289))

## [1.16.102](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.101...v1.16.102) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.19 ([a296948](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a296948f0823b971cb03ddd410cc2550fba1dcb0))

## [1.16.101](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.100...v1.16.101) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.52.0 ([cc2d99c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cc2d99ca027ccd029cf532a3b9b04bb756d2ffb2))

## [1.16.100](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.99...v1.16.100) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.18 ([9940899](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9940899b8fa72cf4187f1083f5640a612939dcac))

## [1.16.99](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.98...v1.16.99) (2020-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.51.3 ([949b078](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/949b07879ec09574503bb5a0857ce0d6acf3a6fd))

## [1.16.98](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.97...v1.16.98) (2020-09-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.7.0 ([4446491](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4446491e7e37854829558fa80ad5ed9644d29e43))

## [1.16.97](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.96...v1.16.97) (2020-09-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.2 ([1bd5354](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1bd53540e0386a58e3f6f384b97e211953f27e07))

## [1.16.96](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.95...v1.16.96) (2020-09-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.51.1 ([f22b57d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f22b57d3b9ae9fec297f71ab0eca3dd717a04e67))

## [1.16.95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.94...v1.16.95) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.12.0 ([ee232f3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ee232f335add0e64337ae0ec3db816d70b637b70))

## [1.16.94](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.93...v1.16.94) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.11 ([a3a6551](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a3a6551e5431d7ca87fbd9d3d98b753be7af662f))

## [1.16.93](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.92...v1.16.93) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.17.0 ([2bd5d13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2bd5d130bd2dbc602dcc748fe6a40a2b31dafc7e))

## [1.16.92](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.91...v1.16.92) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.35.1 ([6abea08](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6abea083b75f645579717e61da3ec7042d721897))

## [1.16.91](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.90...v1.16.91) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.51.0 ([1427564](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/142756405d88fa0deac46ab28c68d47339e0524f))

## [1.16.90](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.89...v1.16.90) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.49.6 ([507ee90](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/507ee9006f5f6176a4bbe30d9b15d0f6d128d1b7))

## [1.16.89](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.88...v1.16.89) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.10 ([cfa7fc2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cfa7fc286d8b3583b8b9f70f74967207957421b1))

## [1.16.88](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.87...v1.16.88) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.9 ([9f61d37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9f61d37e8dea46fe2a1bc199e4794b75b13e8946))

## [1.16.87](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.86...v1.16.87) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.49.3 ([8f00e78](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8f00e78ab0fd5a4e41425a66f299d0aef831abea))

## [1.16.86](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.85...v1.16.86) (2020-09-22)


### Bug Fixes

* 🐛 set instructionproxy log level to INFO ([7a1fe65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7a1fe6564327fd3bef67cc97fe1461cedb14d2d6))

## [1.16.85](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.84...v1.16.85) (2020-09-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.49.2 ([e2fa581](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e2fa5812ecfdf7ca9e683a5bf8cf74b9d7626468))

## [1.16.84](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.83...v1.16.84) (2020-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.21 ([309d31a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/309d31ab73b7d80f96004b0a5337b1af58be21fb))

## [1.16.83](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.82...v1.16.83) (2020-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.16.5 ([0a45a7c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0a45a7c7027feef99d3e17ad4a6c2f35c16c913d))

## [1.16.82](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.81...v1.16.82) (2020-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.44.8 ([b69e294](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b69e2945aaf1bbbfa4b4b63403d9524d93b9387f))

## [1.16.81](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.80...v1.16.81) (2020-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.11 ([0c71990](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0c7199080d83bf5b61b5785bc1b12801092c3414))

## [1.16.80](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.79...v1.16.80) (2020-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.20 ([7603a65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7603a653dcbd44d6a9e3ab37a83a0e1bcea854ed))

## [1.16.79](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.78...v1.16.79) (2020-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.19 ([53f49cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/53f49cd6142efd0b1ab6d1196c95ce89858dd95a))

## [1.16.78](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.77...v1.16.78) (2020-09-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.6.0 ([99808e7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/99808e7dbf711c4bf2a4077aee00db2f4560b234))

## [1.16.77](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.76...v1.16.77) (2020-09-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.18 ([c93c9c5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c93c9c5c3a1b3cd2eda898c7f6662e903fbb1fae))

## [1.16.76](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.75...v1.16.76) (2020-09-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.5 ([2fc1c6d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2fc1c6d61a048397746c0e8ac946d73f2dd4fc2c))

## [1.16.75](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.74...v1.16.75) (2020-09-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.17 ([be95d18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/be95d183d7a5dbad07e2c5ddd9b444c39987c651))

## [1.16.74](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.73...v1.16.74) (2020-09-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.10 ([bbe509b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bbe509b0e23ce68fcbc4a8b51b6fd75771a0afc9))

## [1.16.73](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.72...v1.16.73) (2020-09-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.16 ([1c1eea3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1c1eea3c1245aae8f73f4da5076c3e1af240c9b9))

## [1.16.72](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.71...v1.16.72) (2020-09-18)


### Bug Fixes

*  update dependency @rootcloud/rootcloud-hub to v2.44.3 ([0d28a61](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0d28a61af63cf6d0852e0a53f7df5d0cb545f84d))

## [1.16.71](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.70...v1.16.71) (2020-09-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.15 ([482127d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/482127dd0d7a69d82ddcb5f36193a2e242b20e91))

## [1.16.70](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.69...v1.16.70) (2020-09-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.14 ([2d9036e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2d9036e5dfb6b98e56de015ab67a7a758d849123))

## [1.16.69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.68...v1.16.69) (2020-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.9 ([0c220e3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0c220e317e1c0365e4f3833eca4d67679893d74e))

## [1.16.68](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.67...v1.16.68) (2020-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.8 ([b3a6d55](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b3a6d55541da318aff5644ec88405dbc7f2a8fbc))

## [1.16.67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.66...v1.16.67) (2020-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.43.3 ([9c57d77](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9c57d7791305727ba13bb07027aa2ae9b0cb10fd))

## [1.16.66](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.65...v1.16.66) (2020-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.11 ([d263787](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d263787005f6c16f4261668948c8cd15e8c93c61))

## [1.16.65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.64...v1.16.65) (2020-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.43.2 ([d848a49](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d848a497854cde3ee0f80bcdb4020a911fd00fb8))

## [1.16.64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.63...v1.16.64) (2020-09-17)


### Bug Fixes

* 🐛 upgrade rootcloud-platform-metrics to 0.4.4 ([2e68ec8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2e68ec826428e9978169c5a64d9598c12e6e6f17))

## [1.16.63](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.62...v1.16.63) (2020-09-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.19 ([6c85d51](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6c85d51336e66da19bf235e02699ee298f5dbfe7))

## [1.16.62](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.61...v1.16.62) (2020-09-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.10 ([572242a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/572242a7973fc32e3875aa4e9cc2ebb5255f6fbb))

## [1.16.61](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.60...v1.16.61) (2020-09-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.7 ([ceead43](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ceead43c044a4b283d4378bb161ac8b98f6a55e5))

## [1.16.60](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.59...v1.16.60) (2020-09-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.9 ([729abee](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/729abeecad13a008cefa109779bc8d6d18d1a4e0))

## [1.16.59](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.58...v1.16.59) (2020-09-16)


### Bug Fixes

* repair fail of online verify ([b264ba9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b264ba9ec755a4b821d41a56a0c072171438e3e8))

## [1.16.58](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.57...v1.16.58) (2020-09-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.8 ([530583c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/530583c0893f4be79835c177a099b6e5fa532046))

## [1.16.57](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.56...v1.16.57) (2020-09-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.43.0 ([19bef48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/19bef48e9342e9c39307d4b28f4e5e036a0f421c))

## [1.16.56](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.55...v1.16.56) (2020-09-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.7 ([dcdd66e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dcdd66ef153607d3167e30708a1a3cb8cf68e459))

## [1.16.55](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.54...v1.16.55) (2020-09-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.50.6 ([acff876](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/acff876585c16a5c316d3c0289026648deb5b67c))

## [1.16.54](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.53...v1.16.54) (2020-09-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.3 ([35cab98](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/35cab9800b59bbadbb7f7bbd0068e4e869f7ff57))

## [1.16.53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.52...v1.16.53) (2020-09-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.22 ([5438a8b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5438a8b7ca0f73c64ec929a59394371020929a32))

## [1.16.52](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.51...v1.16.52) (2020-09-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.2 ([4156b84](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4156b84c5b2731d6151875b24203d339eb9d68bc))
* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.21 ([596f9f7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/596f9f7a7b34c1229857f4776ff1adca45cdab0c))

## [1.16.51](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.50...v1.16.51) (2020-09-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.15 ([bf113b5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bf113b575d7135076b6990b5496149a653d7778d))

## [1.16.50](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.49...v1.16.50) (2020-09-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.16.3 ([06bb69f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/06bb69fc8ea7cf368d5caa83ec9bc86a0820e12d))

## [1.16.49](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.48...v1.16.49) (2020-09-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.47.0 ([4206544](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4206544d5d5244ff7e2c809627a9ae556abeb31d))

## [1.16.48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.47...v1.16.48) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.14 ([9ce8d9a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9ce8d9a41cd4ca762e21bd0f715b3d41b5305a8f))

## [1.16.47](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.46...v1.16.47) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.16.2 ([32d8b70](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/32d8b70273152f17bd6284b204648e22e6310bdb))

## [1.16.46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.45...v1.16.46) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.34.0 ([e6a3076](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e6a3076ac72d2366228b33fc0ccc6fa095699e44))

## [1.16.45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.44...v1.16.45) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.13 ([b8da1fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b8da1fbd74e99e782ca9c797933f6ffa7dc8b075))

## [1.16.44](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.43...v1.16.44) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.46.3 ([42a1feb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/42a1feb40a34121a868a962f2b80ee51705d23e2))

## [1.16.43](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.42...v1.16.43) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.46.2 ([1256d48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1256d48e4c8f18a5974e0d8ac166d6e3eb87a21f))

## [1.16.42](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.41...v1.16.42) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.12 ([107d575](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/107d5758eadc2c7b7a7ff89583199bc9b15abc32))

## [1.16.41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.40...v1.16.41) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.33.3 ([8332fba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8332fbaf73f0e73e8b006b69669e375d7b5e2a42))

## [1.16.40](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.39...v1.16.40) (2020-09-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.45.0 ([6818afa](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6818afa3f876343520e6b834548e3f5e5ea07e9e))

## [1.16.39](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.38...v1.16.39) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.11 ([cc843f1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cc843f105190949e1f7b3df9f9fd794bb683c867))

## [1.16.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.37...v1.16.38) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.18 ([3031fb7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3031fb7d6ecba5050b5316ba91be974a68aa9e8a))

## [1.16.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.36...v1.16.37) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.49.11 ([0a01c02](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0a01c02d20ad595ee002dae27d0073c5d4b8bf33))

## [1.16.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.35...v1.16.36) (2020-09-09)


### Bug Fixes

* repair GYPT-13448 ([7927419](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/79274192515236fd84759987cbc442d3dc1db7c1))

## [1.16.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.34...v1.16.35) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.49.10 ([2436c2b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2436c2b9f2f9fbe2f22a2b298212ebd2f7d7f0d8))

## [1.16.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.33...v1.16.34) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.49.9 ([3271896](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3271896bc59311bd19075aee917a3ce2198055a5))

## [1.16.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.32...v1.16.33) (2020-09-09)


### Bug Fixes

* historian 0.33.2 ([0e01a9b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0e01a9b438806fac4768c5df5709ba086fbb3a47))

## [1.16.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.31...v1.16.32) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.44.5 ([daa7034](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/daa7034f81a0216c84f7925e9a10229118066adb))

## [1.16.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.30...v1.16.31) (2020-09-09)


### Bug Fixes

* eca 1.49.6 ([b7c2fea](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b7c2fea437dec1eca2f2f3e3f3cd6bb495cbd047))

## [1.16.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.29...v1.16.30) (2020-09-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.3 ([4cdcdab](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4cdcdabee4660e269e989abab0be5a1d4cf0c3e6))

## [1.16.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.28...v1.16.29) (2020-09-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.33.0 ([c3377a1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c3377a13b59a43beb1c6ad972e1e8718ae4379b9))

## [1.16.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.27...v1.16.28) (2020-09-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.4 ([2909a8a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2909a8a042bd52082d7a0eefca80a402ee4b0868))

## [1.16.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.26...v1.16.27) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.2 ([d5f1dfe](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d5f1dfe238ed30f8c5d152b92b6dc444a716feac))

## [1.16.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.25...v1.16.26) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.49.5 ([06b707d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/06b707d19d312963ed32349fdaa241d770d87315))

## [1.16.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.24...v1.16.25) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.32.0 ([31999b2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/31999b2408818b3f5cdab4344513a55f4dd2b1b1))

## [1.16.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.23...v1.16.24) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.3 ([c5570af](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c5570afa93a39c1a74d7e13c8d4f77f76a336e77))

## [1.16.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.22...v1.16.23) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.31.9 ([236cc5b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/236cc5b1b685734b391a11f4812dd1cae2d01d67))

## [1.16.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.21...v1.16.22) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.42.1 ([acd45e9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/acd45e982bb5e113f781a30cbd97804a855f1b8b))

## [1.16.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.20...v1.16.21) (2020-09-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.49.4 ([9190953](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/91909536614749cd2074f124053fad41ea88b50d))

## [1.16.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.19...v1.16.20) (2020-09-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.43.0 ([36f8689](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/36f8689db77750e40a0e5a60d1a100e34b16c845))

## [1.16.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.18...v1.16.19) (2020-09-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.41.1 ([ac89ba0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ac89ba0e018f48fe17e178b031c33c672063e219))

## [1.16.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.17...v1.16.18) (2020-09-03)


### Bug Fixes

* historian 0.31.4 ([6032150](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/60321507dd561838786760be7384488d2ff866f6))

## [1.16.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.16...v1.16.17) (2020-09-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.40.4 ([87ba45e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/87ba45e9c27e5e6643ea3fa94f204e0b5b26ff03))

## [1.16.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.15...v1.16.16) (2020-09-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.40.3 ([01f7d94](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/01f7d942b008f4c70a0dade095967f9ac6ca2471))

## [1.16.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.14...v1.16.15) (2020-09-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.40.2 ([b0470a2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b0470a2852f74abdb6b7c19944f8760feb462abc))

## [1.16.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.13...v1.16.14) (2020-09-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.40.1 ([8689074](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8689074f92a020433abb8f18b9c3ff514641a5ca))

## [1.16.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.12...v1.16.13) (2020-09-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.40.0 ([a58c7b7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a58c7b736b0e7d340b188d2d671f6dd7f6c4c850))

## [1.16.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.11...v1.16.12) (2020-09-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.1 ([062cd64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/062cd64a4c9698711ed101293700dd083bac3bed))

## [1.16.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.10...v1.16.11) (2020-09-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.39.3 ([cea36a7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cea36a740826513c74db4a475d1df7e0729fa95f))

## [1.16.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.9...v1.16.10) (2020-09-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.16.1 ([409c051](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/409c0512a1932bcd4461488e38c6675bddb1d3f1))
* 🐛 env ([7e0a760](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e0a7608c7cb90ef644a0601eca27c401728b9db))

## [1.16.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.8...v1.16.9) (2020-09-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.39.2 ([a6b9d09](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a6b9d09b9d560404819c03742186a2fdcd8757d6))

## [1.16.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.7...v1.16.8) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.31.2 ([6d4f253](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d4f25385f4638590f1c728be7eeaaf850127459))

## [1.16.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.6...v1.16.7) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.31.1 ([c203e9a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c203e9ac451a6508a0c7721b8aa9e8c4b2bb33ae))

## [1.16.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.5...v1.16.6) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.20 ([8367495](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8367495b1c764d3183767b656c0182f154b7d827))

## [1.16.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.4...v1.16.5) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.48.6 ([bf75e62](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bf75e626fb830a131ec9f5669277c0c71300a78e))

## [1.16.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.3...v1.16.4) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.31.0 ([856b45e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/856b45ec0d42c00aac292ce9b2373e9a62350672))

## [1.16.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.2...v1.16.3) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.4.0 ([70786bd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/70786bde03c19dd013efd25d95ca997d69a3feec))

## [1.16.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.1...v1.16.2) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.38.3 ([96ab3a4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/96ab3a4cd188a0e1dec046b03cb46209b70f69d0))

## [1.16.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.16.0...v1.16.1) (2020-08-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.48.4 ([6e05b33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6e05b3326186effa35c37deb61ae9a1d9096cd79))

# [1.16.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.15...v1.16.0) (2020-08-28)


### Features

* 🎸 add hbase into dev-env resource when starting env ([254352b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/254352be56eb774067e6f2582b28c3700c67be51))

## [1.15.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.14...v1.15.15) (2020-08-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.48.3 ([d0668b0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d0668b047b284b07a06d941642308be52532cd80))

## [1.15.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.13...v1.15.14) (2020-08-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.48.2 ([8e23758](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8e23758b9a183f6a235c64c6e1c96f9b779b1dd7))

## [1.15.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.12...v1.15.13) (2020-08-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.48.1 ([b57f75c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b57f75c5e1abaf634598bb59d79664a88ac195b8))

## [1.15.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.11...v1.15.12) (2020-08-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.15 ([699bab8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/699bab8cfc93dc53249da3ad5ade206f8d2736d5))

## [1.15.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.10...v1.15.11) (2020-08-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.5.0 ([bb2c0b0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bb2c0b08a073739d541f8ae9080d241646ab131b))

## [1.15.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.9...v1.15.10) (2020-08-26)


### Bug Fixes

* update dev-env version ([9633ba0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9633ba0725f2c696a4ee3d31593c477e0e75a84e))

## [1.15.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.8...v1.15.9) (2020-08-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.14 ([0ed94a0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0ed94a0a3f1f537bd0dc273e284ffa2c06580191))

## [1.15.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.7...v1.15.8) (2020-08-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.12 ([eecbc83](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/eecbc83563725c1ecccb6eb2b15a923887a94637))

## [1.15.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.6...v1.15.7) (2020-08-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.11 ([53c1d2b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/53c1d2b753ee189c72bd81a8b05d783608da74b5))

## [1.15.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.5...v1.15.6) (2020-08-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.30.2 ([0881359](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0881359f4b0c34fc8b562732b6e23c89e4509ce1))

## [1.15.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.4...v1.15.5) (2020-08-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.10 ([aa12c97](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/aa12c97521fe2d1b2ecc8bd372dbb58dc6c4f987))

## [1.15.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.3...v1.15.4) (2020-08-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.48.0 ([a9be280](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a9be280539f83dd57a8b4e32ad51fedfcab5da80))

## [1.15.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.2...v1.15.3) (2020-08-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.40.6 ([c245251](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c24525104510097723423fc10c69b94f24ba144b))

## [1.15.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.1...v1.15.2) (2020-08-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.36.0 ([8b9df23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8b9df23e405eb2f9b483eb218d8b947fbf6fd12c))

## [1.15.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.15.0...v1.15.1) (2020-08-24)


### Bug Fixes

* eca 1.47.3 ([5f74474](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5f74474af1063769148012b33e02dcf884b0dc69))

# [1.15.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.224...v1.15.0) (2020-08-24)


### Features

* bump eca & hub ([dec3ba7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dec3ba769edc10c81e5e4facc5c4a54b8d33ef2c))

## [1.14.224](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.223...v1.14.224) (2020-08-21)


### Bug Fixes

* hub 2.39.22 ([c882186](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c88218683546edf0dc14a911ab43323d12bc3f36))

## [1.14.223](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.222...v1.14.223) (2020-08-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.47.0 ([47a1761](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/47a17610d9b5c1cce5bf7b1f84c96444cf71d4bd))

## [1.14.222](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.111...v1.14.222) (2020-08-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.46.9 ([5cd06c7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5cd06c7d77176be318f77cabc3f9034decd486ee))

## [1.14.221](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.220...v1.14.221) (2020-08-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.46.8 ([22f7c3d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/22f7c3d730a7c81eec70fd135c8f3b2c24656605))

## [1.14.220](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.219...v1.14.220) (2020-08-19)


### Bug Fixes

* update dev-env version ([d2a3e0f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d2a3e0f16024c662f36f5bf8b8732d8ba2c9028c))

## [1.14.219](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.218...v1.14.219) (2020-08-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.39.10 ([6e84bb2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6e84bb2902ce11ccc58916cd666239203ea96dad))

## [1.14.218](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.217...v1.14.218) (2020-08-17)


### Bug Fixes

* hub 2.39.3 ([03fe6a4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/03fe6a41ad49c84472069c84f690f917e754d0b6))

## [1.14.217](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.216...v1.14.217) (2020-08-14)


### Bug Fixes

* 🐛 preset tenant t2 ([778e738](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/778e738d61d59c7801cc53269069bf6e0809e26b))

## [1.14.216](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.215...v1.14.216) (2020-08-14)


### Bug Fixes

* hub 2.39.0 ([3942352](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/39423520ba626c561d6b3d35f9e8966b18e2d7ef))

## [1.14.215](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.214...v1.14.215) (2020-08-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.4.0 ([10bced2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/10bced2d681a2424578e41ebb7bf3c9de9ad7d9e))

## [1.14.214](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.213...v1.14.214) (2020-08-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.38.14 ([8455c7f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8455c7f277a41340214daf0f6bbe4401f9b7f6b1))

## [1.14.213](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.212...v1.14.213) (2020-08-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.46.4 ([6e64c4a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6e64c4ae5dbcb765406f1180fef38afd3be882c9))

## [1.14.212](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.211...v1.14.212) (2020-08-13)


### Bug Fixes

* eca 1.46.3 ([06234bc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/06234bca16b4b22f76ae3abd0dcd76acd20f6c9e))

## [1.14.211](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.210...v1.14.211) (2020-08-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.38.13 ([e323f34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e323f34efe0835be0a5d6fe66bed4dce112187e7))

## [1.14.210](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.209...v1.14.210) (2020-08-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.32.8 ([08b5671](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/08b56715fa0de5d324f74e0fd2edcf042a0d6009))

## [1.14.209](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.208...v1.14.209) (2020-08-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.38.12 ([4e6d04a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4e6d04a75377be790f744cc8fd59f7b81048207c))

## [1.14.208](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.207...v1.14.208) (2020-08-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-data-analysis to v3.32.7 ([e841d5b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e841d5bf2ee243e9504d8a925d61f9bbfe060093))

## [1.14.207](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.206...v1.14.207) (2020-08-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.30.0 ([5390d69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5390d694e8c8c293ee9cecf19ea30fe578f4ba1e))

## [1.14.206](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.205...v1.14.206) (2020-08-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.46.2 ([40dfc3a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/40dfc3acda9e4c32e40fe1c739841652f11c5547))

## [1.14.205](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.204...v1.14.205) (2020-08-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.46.1 ([0ddd04f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0ddd04f08ec27ca6460b9b284c4516d2b462c0ca))

## [1.14.204](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.203...v1.14.204) (2020-08-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.46.0 ([11abd54](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/11abd54b9b1c62c490c7af4c2660e792dd02b3aa))

## [1.14.203](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.202...v1.14.203) (2020-08-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.23 ([a96b5d9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a96b5d9d1dce8ee093e147f04eedb1efeb8fa6f7))

## [1.14.202](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.201...v1.14.202) (2020-08-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.22 ([a7accb3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a7accb3a578662b2e5af53fec6b36b759dd8af9b))

## [1.14.201](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.200...v1.14.201) (2020-08-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.38.1 ([19b0c4d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/19b0c4deee70580a35915899a45de47c95966556))

## [1.14.200](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.199...v1.14.200) (2020-08-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.38.0 ([33622fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/33622fb347924f25e67a51e3ef7eb08991335f42))

## [1.14.199](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.198...v1.14.199) (2020-08-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.20 ([a1a6be8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a1a6be8c4f0e27de26a13bc4017a85b1acac20a3))

## [1.14.198](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.197...v1.14.198) (2020-08-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.8 ([9dd35db](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9dd35db599dc3ef31d1dfd4441875ea23918f86c))

## [1.14.197](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.196...v1.14.197) (2020-08-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.7 ([4d56d73](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4d56d73c6fe3913b65c77c3f3b787942fecfabf0))

## [1.14.196](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.195...v1.14.196) (2020-08-04)


### Bug Fixes

* gypt-23808 is subject to environment changes ([31e2eb5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/31e2eb5b03dc382ffb3bb0eef67d6d3e74c020a7))

## [1.14.195](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.194...v1.14.195) (2020-08-04)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.19 ([d8b3991](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d8b39917b75a678ced7781586baa4b9f2f9e315f))

## [1.14.194](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.193...v1.14.194) (2020-08-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.5 ([c76dbce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c76dbce96edca72ec7869d280ddad7813c6980f0))

## [1.14.193](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.192...v1.14.193) (2020-08-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.18 ([3a56532](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3a56532a68eeb303d414216f2c65d3196651a1d4))

## [1.14.192](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.191...v1.14.192) (2020-07-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.4 ([f304c25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f304c250a4ec04306d5363dbff8c8ecaffc1ab53))

## [1.14.191](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.190...v1.14.191) (2020-07-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.3 ([f79446f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f79446fde7be137b9da66c875f6071926cc635c8))

## [1.14.190](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.189...v1.14.190) (2020-07-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.17 ([21069f6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/21069f664d59d3000f466f47b4caab9313973901))

## [1.14.189](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.188...v1.14.189) (2020-07-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.16 ([90dc4bc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/90dc4bc3debb6b18f028fcb3cb87735f790340a0))

## [1.14.188](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.187...v1.14.188) (2020-07-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.15 ([dbe80f3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dbe80f31d25335017504b8237d1777d2fe2d09be))

## [1.14.187](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.186...v1.14.187) (2020-07-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.2 ([cc84c6a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cc84c6a53e21b7b595e5ae376ae3339463de14f5))

## [1.14.186](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.185...v1.14.186) (2020-07-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.14 ([baab936](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/baab93699334039f977556c08a24186d65d7ca67))

## [1.14.185](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.184...v1.14.185) (2020-07-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.13 ([2d810e6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2d810e68258f340eb402f7a227a2f43f8fcaf8c4))

## [1.14.184](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.183...v1.14.184) (2020-07-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.9 ([bbd5ff0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bbd5ff092ec498deef83a79a7a5370dcee0dd841))
* 🐛 bump eca ([e5d8065](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e5d8065c9f19bcc094b2c7458e18d1370c77e35b))
* 🐛 regression deploy args for groovy timeout ([b3d89d0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b3d89d03f3432c6a22caa6bf63115a81d68ba99b))

## [1.14.183](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.182...v1.14.183) (2020-07-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.37.1 ([3ebf34c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3ebf34ceba6877eb5b56c90ec3aa507513d8c676))

## [1.14.182](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.181...v1.14.182) (2020-07-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.16 ([f054693](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f05469307b26f75d95f45bfc2d220ccf11540733))

## [1.14.181](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.180...v1.14.181) (2020-07-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.36.8 ([06fd3b6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/06fd3b67bea2c864f5d88e2601768ef4bd3d1f5a))

## [1.14.180](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.179...v1.14.180) (2020-07-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.15 ([bf29995](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bf299950b4686a5f57c50a8010244638eaacdabd))

## [1.14.179](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.178...v1.14.179) (2020-07-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.14 ([23fffc5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/23fffc5116d2cfbb848442f0ddc87ef25025f245))

## [1.14.178](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.177...v1.14.178) (2020-07-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.8 ([4720358](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4720358f0673e99af6d11f31b73ed16042f54a02))

## [1.14.177](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.176...v1.14.177) (2020-07-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.36.7 ([47a3cdb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/47a3cdb9196513168cdfaed0cdc907c31b587834))

## [1.14.176](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.175...v1.14.176) (2020-07-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.13 ([fa885cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fa885cd1251240ef7af5816fe13cc334bd90dd8d))

## [1.14.175](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.174...v1.14.175) (2020-07-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.7 ([f170a45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f170a451aeb9196f7bb5abcec0e2fe730e2b909f))

## [1.14.174](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.173...v1.14.174) (2020-07-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.6 ([7ed45b7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7ed45b797b14a3cf9e90562712873a3930eee44d))

## [1.14.173](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.172...v1.14.173) (2020-07-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.5 ([cb11f53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cb11f53d86c05a9fb74746b4b5447483436d862f))
* config transaction.max.timeout.ms=1h ([3e23c68](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3e23c687f154868b481fbe3393522f55f33a56c8))

## [1.14.172](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.171...v1.14.172) (2020-07-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.12 ([6a538c2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6a538c2063151561a9bd0b8fefd43a269abe6558))

## [1.14.171](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.170...v1.14.171) (2020-07-22)


### Bug Fixes

* 🐛 hub 2.36.0 ([7c57aeb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7c57aeb22f9dbccdcd2c510febe99e792594484b))

## [1.14.170](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.169...v1.14.170) (2020-07-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.8 ([6b8486b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6b8486bf839d46c96412c5ee38c13461dea19e1d))

## [1.14.169](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.168...v1.14.169) (2020-07-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.3.1 ([58bba5a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/58bba5ac3c5d048143c64f8db0a8f12fdc6a2956))

## [1.14.168](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.167...v1.14.168) (2020-07-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.7 ([caeae2a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/caeae2a1fd2b528b7797bbd1fc522c2f60b0eddb))

## [1.14.167](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.166...v1.14.167) (2020-07-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.6 ([587c694](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/587c694ec8567a3e0fa6a4c6ca9ace0ef5df1177))

## [1.14.166](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.165...v1.14.166) (2020-07-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.5 ([d84e814](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d84e814e571a2113fda56bc68f55f7fe6257e38b))

## [1.14.165](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.164...v1.14.165) (2020-07-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.11 ([583b7d7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/583b7d72417e7c93b2d5271617140e51802557c9))

## [1.14.164](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.163...v1.14.164) (2020-07-21)


### Bug Fixes

* put device locaion api changes ([e0c3530](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e0c35306de892b5476c8e7701f3af021a6579e68))

## [1.14.163](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.162...v1.14.163) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.4 ([b6611e3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b6611e3532499df5d4a349fcb276ef76d9baa9f1))

## [1.14.162](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.161...v1.14.162) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.3 ([9001242](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9001242692db65d09fbd003633a9f225dd0c79aa))

## [1.14.161](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.160...v1.14.161) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.35.1 ([9af1ec1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9af1ec173c455fde7d3d205706ca85af0e111cb1))

## [1.14.160](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.159...v1.14.160) (2020-07-20)


### Bug Fixes

* 🐛 hub 2.35.0 ([31ef2b6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/31ef2b6e7410976c48dfc971ed1dad66cbb2e453))

## [1.14.159](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.158...v1.14.159) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.34.3 ([6b8d659](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6b8d659611352d3bbfbdbc96563c4f17f45508b0))

## [1.14.158](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.157...v1.14.158) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.4 ([000dc64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/000dc64e10598070a22770e1d3bcf46c0b6fcec3))

## [1.14.157](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.156...v1.14.157) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.3 ([c119cf9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c119cf9e9f88dfc9633ec87b63f982dc8e81a6ba))

## [1.14.156](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.155...v1.14.156) (2020-07-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.34.2 ([7244311](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/72443112131dba3982182b718fdbd025a6316bb0))

## [1.14.155](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.154...v1.14.155) (2020-07-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.2 ([a979584](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a97958497d240b6c18449dde8cdaaaedad219165))

## [1.14.154](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.153...v1.14.154) (2020-07-17)


### Bug Fixes

* update thing class model ([81a5902](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/81a5902bea870a71ee8697428e3f5ff10757280d))

## [1.14.153](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.152...v1.14.153) (2020-07-17)


### Bug Fixes

* 🐛 hub 2.33.3 ([230b4e9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/230b4e9098b821f40640a366b495e372402f839e))

## [1.14.152](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.151...v1.14.152) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.1 ([faac5fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/faac5fb0c5c9e534acf6373f06c5307895015fc6))

## [1.14.151](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.150...v1.14.151) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.45.0 ([983fdd9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/983fdd9d1172b737131f1e747770e621d10f4e2c))

## [1.14.150](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.149...v1.14.150) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.14 ([89bf231](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/89bf231fbf5f36cb346b182580181eac68f5ab4a))

## [1.14.149](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.148...v1.14.149) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.11.2 ([23d72bf](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/23d72bf680190ae70ad58335a8b6cc260fe81573))

## [1.14.148](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.147...v1.14.148) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.14.3 ([c51e0c9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c51e0c9c9fcd43f1f87082c042dd43c8fceedad7))

## [1.14.147](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.146...v1.14.147) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.33.2 ([48d6575](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/48d6575352f47338b65cf7c6c51baa534a45ccf6))

## [1.14.146](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.145...v1.14.146) (2020-07-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.33.1 ([2e09d86](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2e09d86a5f09d0b6b27af482f4e21e314b9e81b4))

## [1.14.145](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.144...v1.14.145) (2020-07-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.10 ([e9fa758](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e9fa7587258593b7c7e0afdc6b6c11adde846673))

## [1.14.144](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.143...v1.14.144) (2020-07-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.33.0 ([bfffd1c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bfffd1cec68f3df16fd1dee9bec4ce5dff44e4bf))

## [1.14.143](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.142...v1.14.143) (2020-07-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.32.5 ([8b776f8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8b776f83107430f6d4464bec040336d9e564aed4))

## [1.14.142](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.141...v1.14.142) (2020-07-15)


### Bug Fixes

* 🐛 hub 2.32.4 ([2dc0835](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2dc0835d1ad2f9c9e246bd98201dcb9ecb42ba40))

## [1.14.141](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.140...v1.14.141) (2020-07-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.13 ([92d9ab4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/92d9ab4701d12340cdad924060c6ae242ad40e18))

## [1.14.140](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.139...v1.14.140) (2020-07-14)


### Bug Fixes

* 🐛 hub 2.31.16 ([efb28c4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/efb28c478ee21af3a57a7b8848cd8e0ffd0b185b))

## [1.14.139](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.138...v1.14.139) (2020-07-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.12 ([14c70f5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/14c70f5138112d23e8e5fdc0317d0fe30ca782fd))

## [1.14.138](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.137...v1.14.138) (2020-07-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.11 ([f1ae924](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f1ae924bc402a5a8851e543e8b3c60892e83ab49))

## [1.14.137](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.136...v1.14.137) (2020-07-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.15 ([27d38d3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/27d38d359867ec486157916449947b02dc08469c))

## [1.14.136](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.135...v1.14.136) (2020-07-13)


### Bug Fixes

* 🐛 hub 2.31.14 ([988ae64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/988ae64a4692944e4461a8f9c49b076d68a99c56))

## [1.14.135](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.134...v1.14.135) (2020-07-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.14.2 ([6ffcc4a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6ffcc4aee4d18fc8356d15261bd99c3a4c2be50c))

## [1.14.134](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.133...v1.14.134) (2020-07-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.11.1 ([3cea0b5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3cea0b5746d574a7886349267674eae3a01bb586))

## [1.14.133](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.132...v1.14.133) (2020-07-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.3 ([3c32e72](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3c32e72be97176d84a30ca9d173d60103b6ad6cb))

## [1.14.132](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.131...v1.14.132) (2020-07-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.10 ([e983d3a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e983d3a4d32cb28661c7e3060cd146e425ab9a41))

## [1.14.131](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.130...v1.14.131) (2020-07-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.12 ([25fa370](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/25fa3703a5d8a4a73c6b71a625074f8b3f3bdfb0))

## [1.14.130](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.129...v1.14.130) (2020-07-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.9 ([da0b94f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/da0b94f9c854eb3e3fa8d5c2ce32c20ce2ff833d))

## [1.14.129](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.128...v1.14.129) (2020-07-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.11 ([66b09f2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/66b09f21a0f516751814e9290798ddfe394e8059))

## [1.14.128](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.127...v1.14.128) (2020-07-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.10 ([7b2d494](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7b2d494b66dffe6406e603039a0dd1a0853f545d))

## [1.14.127](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.126...v1.14.127) (2020-07-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.9 ([776ad25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/776ad25997ef4a6e29cb390963132c0de46d7b2b))

## [1.14.126](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.125...v1.14.126) (2020-07-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.11.0 ([0175c9c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0175c9c444e9ccbb9c8b4d75f16cb32dbd3dfbd4))

## [1.14.125](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.124...v1.14.125) (2020-07-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.8 ([e647ae1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e647ae1dd37b08e0ec70e50881bd708632d615a7))

## [1.14.124](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.123...v1.14.124) (2020-07-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.7 ([34eb73b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/34eb73bfbc41167ef057ad9f4c9d8896f733f4c7))

## [1.14.123](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.122...v1.14.123) (2020-07-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.2 ([7f704be](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7f704be264f289db766a5f9c4d893d94bcec5cc5))

## [1.14.122](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.121...v1.14.122) (2020-07-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.6 ([2c2ac83](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2c2ac83162d6d10fe8db8a1fe5980bd156fbbb69))
* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.7 ([b032419](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b03241984bef92eb15dd6e2d50a4fda292afe221))

## [1.14.121](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.120...v1.14.121) (2020-07-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.5 ([b7faf1b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b7faf1b32769279a83fad4d64b19b954ba5affde))

## [1.14.120](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.119...v1.14.120) (2020-07-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.5 ([6a61b83](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6a61b83ff620e64dd37971aebebda4ff133f8c45))

## [1.14.119](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.118...v1.14.119) (2020-07-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.4 ([9ff21c5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9ff21c53070b74c962f41cf49ed630ab3e113ea2))

## [1.14.118](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.117...v1.14.118) (2020-07-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.3 ([31ff642](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/31ff642d977f056dacfc0182b975d230250e2aba))

## [1.14.117](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.116...v1.14.117) (2020-07-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.1 ([1de3fe2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1de3fe2d53b0de53e82f42490c1cff90dceaaae4))

## [1.14.116](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.115...v1.14.116) (2020-07-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.31.2 ([32bed00](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/32bed00c9dada3f38dba200d6bcf7b934c2ed48e))

## [1.14.115](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.114...v1.14.115) (2020-07-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.3 ([05ad464](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/05ad46431d350f9db12750dc5f01ec9c4d5c77b6))

## [1.14.114](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.113...v1.14.114) (2020-07-04)


### Bug Fixes

* 🐛 hub 2.31.0 ([304da65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/304da65520b9177966dff2c46c8b517d95bffbbb))

## [1.14.113](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.112...v1.14.113) (2020-07-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.29.0 ([8afce12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8afce12fad8ba2e8b0e5811201fc59f8aa8f7893))

## [1.14.112](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.111...v1.14.112) (2020-07-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.2 ([56e0f56](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/56e0f56724a3733a4889d90c79c48236694d627b))

## [1.14.111](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.110...v1.14.111) (2020-07-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.30.10 ([78abc8d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/78abc8d0e36a5170086d6df9f576b9f7d778e3a6))

## [1.14.110](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.109...v1.14.110) (2020-07-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.30.9 ([6361091](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6361091266be0d9332874ee1a31f593852d10e99))

## [1.14.109](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.108...v1.14.109) (2020-07-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.3.0 ([7e2ee29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e2ee2927be202185f19631a01ad7980ce7854ae))

## [1.14.108](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.107...v1.14.108) (2020-07-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.30.8 ([2a800fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2a800fb5b18d67aa304298917cf3bf0ea44db6a2))

## [1.14.107](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.106...v1.14.107) (2020-07-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.1 ([8844409](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/88444097d2fd6d9bdcc83a44e5bcc49f8a97391c))

## [1.14.106](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.105...v1.14.106) (2020-07-01)


### Bug Fixes

* 🐛 fix hub 2.30.6 ([387bc7f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/387bc7f4d361a1d29167258c0965052f44fe6271))

## [1.14.105](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.104...v1.14.105) (2020-07-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.30.5 ([de25724](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/de25724983d439bafc96ce205a2cd52baab047f5))

## [1.14.104](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.103...v1.14.104) (2020-07-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.28.4 ([cd73d84](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cd73d8470096702b9a0312c865dbc17795d75fcb))

## [1.14.103](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.102...v1.14.103) (2020-07-01)


### Bug Fixes

* 🐛 fix hub 2.30.4 breack change ([a453af5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a453af543cbd84902cb8392cc30587c80f977afd))

## [1.14.102](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.101...v1.14.102) (2020-07-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.28.3 ([6f11010](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6f11010e5738b6510c746969d71368e9486ea9f0))

## [1.14.101](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.100...v1.14.101) (2020-06-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.30.2 ([2242d62](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2242d622ccfacf5092addf23b04669eaf6d6ce46))

## [1.14.100](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.99...v1.14.100) (2020-06-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.44.0 ([6fd3df3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6fd3df3818cf00eec23ddaa1d2978cd0075327ea))

## [1.14.99](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.98...v1.14.99) (2020-06-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.16 ([e61a46e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e61a46e93dec80ba332e06653aac6471caeb87b4))

## [1.14.98](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.97...v1.14.98) (2020-06-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.43.2 ([25a52e9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/25a52e96172f945e34157b9f33e367927274cd85))

## [1.14.97](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.96...v1.14.97) (2020-06-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.43.0 ([8786a99](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8786a9909b4564a0c8bb6bfe24909cbf359aff9b))

## [1.14.96](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.95...v1.14.96) (2020-06-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.42.5 ([6d392fa](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d392fa039f9b493e87518d81db449ec249c1896))

## [1.14.95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.94...v1.14.95) (2020-06-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.2.2 ([e023855](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e0238554417aa379facb1cc42edc0c9404e9f3a8))

## [1.14.94](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.93...v1.14.94) (2020-06-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.28.3 ([96e9459](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/96e9459b7fcaad6717234b42f5ecd119fcb4afca))

## [1.14.93](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.92...v1.14.93) (2020-06-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.42.4 ([22354b4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/22354b416e232534854f4b1e4f5bcb4864e6198d))

## [1.14.92](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.91...v1.14.92) (2020-06-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.28.2 ([ce7dbd3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ce7dbd3318bd8c3bc6690d6c51a3f14f9afb658a))

## [1.14.91](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.90...v1.14.91) (2020-06-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.42.3 ([89f043a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/89f043a2cb1d578a13f121d0715139bcc1b11a16))

## [1.14.90](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.89...v1.14.90) (2020-06-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.27.4 ([85ceca9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/85ceca9f419396b5bb44ef01221bd68339f6675e))

## [1.14.89](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.88...v1.14.89) (2020-06-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.27.3 ([7e1974d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e1974d54b041bcb8face59e9289ba4840c2246f))

## [1.14.88](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.87...v1.14.88) (2020-06-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.15 ([e917384](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e917384b1a29fdc7060a6ca8abf047425a4cf2b0))

## [1.14.87](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.86...v1.14.87) (2020-06-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.27.1 ([9edf9de](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9edf9de0329eb6846561a284c19a915d1f89eb4b))

## [1.14.86](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.85...v1.14.86) (2020-06-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.42.2 ([33f7d33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/33f7d338148b7c390c0d5f6b57faefd8d8b4ab66))

## [1.14.85](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.84...v1.14.85) (2020-06-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.14.1 ([fa1fa49](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fa1fa49490ea50dcfda62fb553facf4cb26e941b))

## [1.14.84](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.83...v1.14.84) (2020-06-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.10.1 ([54c1388](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/54c1388f515a0955de850c75ba86946b97419ad5))

## [1.14.83](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.82...v1.14.83) (2020-06-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.42.1 ([f854242](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f85424212513c9757f75116b97a4a60c3020597c))

## [1.14.82](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.81...v1.14.82) (2020-06-18)


### Bug Fixes

* 🐛 fix test failure for hub 2.27.0 ([8c0f388](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c0f388836e4522029e25076bd2daef97865006c))

## [1.14.81](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.80...v1.14.81) (2020-06-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.26.5 ([411bbe8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/411bbe87ac7d978cd41cce4791465b64160fb9bc))

## [1.14.80](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.79...v1.14.80) (2020-06-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.14.0 ([f1bbbea](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f1bbbea3c82108018486bd3ef08b8833b3a58b03))

## [1.14.79](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.78...v1.14.79) (2020-06-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.42.0 ([dbcbb8b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dbcbb8b2294c17ebf434b77c9231296f666b8c1a))

## [1.14.78](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.77...v1.14.78) (2020-06-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.26.4 ([7e97811](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e978112e7347ed1d014d93f77dbe13a96983aef))

## [1.14.77](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.76...v1.14.77) (2020-06-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.2.1 ([d3c0c6e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d3c0c6e4de6da6ebad2892f635279043429aaecc))

## [1.14.76](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.75...v1.14.76) (2020-06-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.28.1 ([bd2980b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bd2980b93875e1f0c4836ac8b969e1ca2c139fd2))

## [1.14.75](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.74...v1.14.75) (2020-06-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.12 ([d2aed9b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d2aed9b1f668339e880a239d2ed22256f133c321))

## [1.14.74](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.73...v1.14.74) (2020-06-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.14 ([dfa3b55](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dfa3b556b0702257c4c6122770efc6344f968a78))

## [1.14.73](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.72...v1.14.73) (2020-06-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.11 ([7d8a92c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7d8a92c6a125ef1ae5b2c5ae9be06dba35eaf130))

## [1.14.72](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.71...v1.14.72) (2020-06-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.10 ([3b24629](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3b24629a2ed7db58e81ab0b7852ab18a8078e519))

## [1.14.71](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.70...v1.14.71) (2020-06-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.26.3 ([b2bc3e5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b2bc3e520533e39ee503ae3470a6e4914e87c615))

## [1.14.70](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.69...v1.14.70) (2020-06-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.26.2 ([db80bd5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/db80bd5a9c12c879bb6b52c3c17f7f9f0229f3e0))

## [1.14.69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.68...v1.14.69) (2020-06-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.28.0 ([00da93a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/00da93a48452679cd19360babf773201077b1b5e))

## [1.14.68](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.67...v1.14.68) (2020-06-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.26.1 ([9f5e51f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9f5e51f6bcc82c46a91f0eb24d8d2872377586b2))

## [1.14.67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.66...v1.14.67) (2020-06-12)


### Bug Fixes

* 🐛 add alarm disorder case and eca 1.41.8 ([42ee1f6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/42ee1f665ce0733bc5f8e98203885be83c6f4e9f))

## [1.14.66](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.65...v1.14.66) (2020-06-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.20 ([68b153f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/68b153f820d978fc33e9e98a49d441d0d337f5d8))

## [1.14.65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.64...v1.14.65) (2020-06-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.7 ([5f95547](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5f955476e7208de5e375fd0a3efeeaf60eaf1ce9))

## [1.14.64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.63...v1.14.64) (2020-06-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.26.0 ([253a3a5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/253a3a5e85c63ffd89a5b521ced27ac4ed81635d))

## [1.14.63](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.62...v1.14.63) (2020-06-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.25.4 ([99a84b0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/99a84b0d5df9a7383a0eb1ba875168612b0a6582))

## [1.14.62](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.61...v1.14.62) (2020-06-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.6 ([4ce7a31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4ce7a31501cb04f76c44ec92fc06580a09dca886))

## [1.14.61](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.60...v1.14.61) (2020-06-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.5 ([ca16da4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ca16da42f3112b562016a7e6ff68c4d4af0a1b1f))

## [1.14.60](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.59...v1.14.60) (2020-06-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.25.0 ([4095dc8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4095dc84d1404dc8d4b50937217548fb6d096897))

## [1.14.59](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.58...v1.14.59) (2020-06-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.22 ([a95d2a2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a95d2a27d15a0975c26ade61952c54ae3445b461))

## [1.14.58](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.57...v1.14.58) (2020-06-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.21 ([ef2b414](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ef2b414251e9885f63663ef6a753183d89a94f07))

## [1.14.57](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.56...v1.14.57) (2020-06-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.20 ([db68edb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/db68edb312a5915908624efaa745d848b2f08214))

## [1.14.56](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.55...v1.14.56) (2020-06-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.4 ([994978c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/994978cf227d7d3c8ed8119d8c374ac4e669f2fe))

## [1.14.55](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.54...v1.14.55) (2020-06-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.13.0 ([89923fa](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/89923fa04e3b027047dbfe2b40e3670b2409ce5c))

## [1.14.54](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.53...v1.14.54) (2020-06-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.3 ([94cc32f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/94cc32fb55f9d1dc2992f7876e7317d8394133b2))

## [1.14.53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.52...v1.14.53) (2020-06-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.10.0 ([df3e306](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/df3e3065e1be908d04c9511a10f6a6da58efa926))

## [1.14.52](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.51...v1.14.52) (2020-06-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.2 ([3318e3b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3318e3b8de46306a4827e6b54756d22e8ac86f1a))

## [1.14.51](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.50...v1.14.51) (2020-06-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.13 ([53c1cf0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/53c1cf0c2b6243ec8a47a5d636762b8ffa08a1fa))

## [1.14.50](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.49...v1.14.50) (2020-06-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.1 ([10485cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/10485cda57022ff03d3d979ddceaa0f711072ee9))

## [1.14.49](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.48...v1.14.49) (2020-06-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.12 ([30112b5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/30112b5cc1debe04e17b555773dd6acf3ef56b1d))

## [1.14.48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.47...v1.14.48) (2020-06-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.11 ([8105a26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8105a2658fafe4d924dd692a4f1c5d6a8a6cb178))

## [1.14.47](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.46...v1.14.47) (2020-06-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.10 ([838efb1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/838efb194b3fde20d724b92f01e7b7bf7554f8f0))

## [1.14.46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.45...v1.14.46) (2020-06-04)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.10 ([9e3f7b2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9e3f7b240765f1e712219c971be79405aac76398))

## [1.14.45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.44...v1.14.45) (2020-06-04)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.41.0 ([ada8add](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ada8adda5cc18cf7603f6dc5183a43555557c82c))

## [1.14.44](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.43...v1.14.44) (2020-06-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.8 ([9c3ccbe](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9c3ccbe270f1620195fe262a43ea9340e4a509dd))

## [1.14.43](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.42...v1.14.43) (2020-06-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.7 ([5c34f94](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5c34f94c443d6feeff6cf2c364d203daa07498dd))
* bump flink version 1.9.0 -> 1.9.3 ([666f861](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/666f86106819cae19e0f442519e1db577ebf5294))

## [1.14.42](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.41...v1.14.42) (2020-06-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.24.9 ([dedfed7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dedfed73da4cb3c10261c564e65eafc1b1a70a89))

## [1.14.41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.40...v1.14.41) (2020-06-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.19 ([30a9ba6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/30a9ba6872ed23fb087c2a15d46298e6a240333f))

## [1.14.40](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.39...v1.14.40) (2020-06-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.6 ([304fa0d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/304fa0d7cc9be682c8d8f5eb017ea0129226c4d7))

## [1.14.39](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.38...v1.14.39) (2020-05-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.17 ([01a4ab4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/01a4ab414906ed2ee339729599714873f79de516))

## [1.14.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.37...v1.14.38) (2020-05-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.16 ([2e19cb1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2e19cb1b3d31321ef5199f176ee7731b1a2f69ac))

## [1.14.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.36...v1.14.37) (2020-05-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.15 ([930fb41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/930fb410e4f42ecb1b6c9995cd854943a0ec9ad6))

## [1.14.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.35...v1.14.36) (2020-05-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.5 ([b0398ae](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b0398ae0d2f6e73a48f48b997a6a79bf070a7f08))

## [1.14.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.34...v1.14.35) (2020-05-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.4 ([2c85556](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2c85556e677f4cd0e7c36286e40f69f4189af7eb))

## [1.14.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.33...v1.14.34) (2020-05-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.9 ([bc12be6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bc12be63cd98ad118c41897ca23b6bd9f607186b))

## [1.14.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.32...v1.14.33) (2020-05-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.14 ([c3567f1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c3567f12f89164111b338dbfcbb122e1eb86baac))

## [1.14.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.31...v1.14.32) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.13 ([fb80442](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fb80442f7260e73bae04b30bb854642bea23f4c8))

## [1.14.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.30...v1.14.31) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.23.0 ([b0bc983](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b0bc983de1d0afcd2d7b4279909bf6a8dabe1e20))

## [1.14.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.29...v1.14.30) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.7 ([ee88ff7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ee88ff7c2a9a26e71c4c542d097668fca6fb7c95))

## [1.14.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.28...v1.14.29) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.3 ([ab2f0b6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ab2f0b6107a820cbe45799c2a0bcfd0e5dc273e3))

## [1.14.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.27...v1.14.28) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.2 ([6dad42a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6dad42a1d970046e1fb1fbc23b9041d104238084))

## [1.14.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.26...v1.14.27) (2020-05-27)


### Bug Fixes

* 🐛 upgrade bridge and proxy ([11f0d82](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/11f0d82f18e5d32317e0629042e4c478a5ffcbae))

## [1.14.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.25...v1.14.26) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.12 ([c361f6d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c361f6ddf5df67de14c5951479af939c0d7acead))

## [1.14.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.24...v1.14.25) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.6 ([3001957](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3001957a74f9a133592606895fc86207bf6ce490))

## [1.14.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.23...v1.14.24) (2020-05-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.5 ([62a25be](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/62a25be2d84a26b22cada0165f92b80d1745507d))

## [1.14.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.22...v1.14.23) (2020-05-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.4 ([60e6ef7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/60e6ef76ad2bbfbec8e68daea9cb58918d5c82f6))

## [1.14.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.21...v1.14.22) (2020-05-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.3 ([75df023](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/75df023e7b819be69a06a3b4cc7aa23e8642a666))

## [1.14.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.20...v1.14.21) (2020-05-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.2 ([8f98f7a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8f98f7ad46e9dd5bfe98fa0004836028bc1f01d9))

## [1.14.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.19...v1.14.20) (2020-05-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.1 ([0f505b4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0f505b4af2410173c8a3ce20eb2eb01c04cf1bad))

## [1.14.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.18...v1.14.19) (2020-05-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.22.0 ([9afd559](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9afd559a97431b6175ac68c66487ad2e9d48300b))

## [1.14.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.17...v1.14.18) (2020-05-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.21.7 ([1280589](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/12805897592f33b6746f65d46105a3e15266de71))

## [1.14.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.16...v1.14.17) (2020-05-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.21.6 ([d9a534a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d9a534ad074ace0a28aafee072b2c5adf1b06247))

## [1.14.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.15...v1.14.16) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.11 ([6d5a052](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d5a052e524288b15236bb64bad1dcdd18157977))

## [1.14.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.14...v1.14.15) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.1 ([911343d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/911343decfbed4525d04d851b44c246aaf911025))

## [1.14.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.13...v1.14.14) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.40.0 ([be0f722](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/be0f722702bf86b3656c61288596421c3cef2123))

## [1.14.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.12...v1.14.13) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.21.3 ([1a77754](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1a77754c0af59979cc392a1f1ac60cfb9f79b3e3))

## [1.14.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.11...v1.14.12) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.21.2 ([21bc21c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/21bc21cd3aa46b2ab9f78c0b930fb85d336b93b1))

## [1.14.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.10...v1.14.11) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.13 ([f3ab9ce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f3ab9ce59c1b8a13c066e9b84e3321c3b8a6315c))

## [1.14.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.9...v1.14.10) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.10 ([8c056ff](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c056ff7f81dd4213f01b99f530aec8e8f01f943))

## [1.14.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.8...v1.14.9) (2020-05-22)


### Bug Fixes

* 🐛 add sleep after post job ([97bc2a8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/97bc2a8ceb6a0d9c648b26443f732e33f856945d))

## [1.14.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.7...v1.14.8) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.10 ([b7ebef5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b7ebef53da7e8fd49e0f74d22e1d50bdf1ebf52a))
* add DEVICE_STATUS_WINDOW_SIZE_SECONDS env for eca ([e47aa1d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e47aa1d7baf7a52bbabc5eca81ff8f1a291148c7))

## [1.14.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.6...v1.14.7) (2020-05-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.9 ([0ebea94](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0ebea94e154c714f00fbc5e4a9ddb52e5363cc25))

## [1.14.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.5...v1.14.6) (2020-05-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.12.4 ([4ceeecd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4ceeecd8355262ca51fe8fc44d4f2ce37c02345c))

## [1.14.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.4...v1.14.5) (2020-05-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.9 ([75c3b95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/75c3b95cf73275ed8d3807be51f6ac1034eb6490))

## [1.14.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.3...v1.14.4) (2020-05-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.8 ([d4d98aa](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d4d98aa514e5ff2431f91d3f8194b7323f790b4c))

## [1.14.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.2...v1.14.3) (2020-05-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.20.2 ([60c50a1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/60c50a14245a1a3b59fb20658790d31fe2947de9))

## [1.14.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.1...v1.14.2) (2020-05-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.7 ([4d3d094](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4d3d09441b2b91c444909fbdfba6d8c73c746f54))

## [1.14.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.14.0...v1.14.1) (2020-05-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.20.1 ([91a3f79](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/91a3f7977b549950aa7b7a2a0e29def847ee6288))

# [1.14.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.13.1...v1.14.0) (2020-05-20)


### Features

* bump mongo 4.0.8 -> 4.2.6 ([2cf58e4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2cf58e4d297033e2229219cb32fb5e2951297442))

## [1.13.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.13.0...v1.13.1) (2020-05-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.8 ([72548cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/72548cd36e471d67a670045b564a66e92361afc7))

# [1.13.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.384...v1.13.0) (2020-05-20)


### Features

* add file server address environment ([ef3d9e1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ef3d9e1161fcbdae307f0edde8cf243a97d9412c))

## [1.12.384](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.383...v1.12.384) (2020-05-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.20.0 ([6e66546](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6e665464765b5a70d2777df7d656c773a123e992))

## [1.12.383](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.382...v1.12.383) (2020-05-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.8 ([6c08066](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6c08066aaa9a2d69a395b179945ee1bd19e1f4d9))

## [1.12.382](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.381...v1.12.382) (2020-05-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.6 ([928263c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/928263cbef14b4a4615cc8b2222f334f19c0bc85))

## [1.12.381](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.380...v1.12.381) (2020-05-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.7 ([d20e372](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d20e3727d7819c0c3826e44b4433329d2d41f07c))

## [1.12.380](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.379...v1.12.380) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.7 ([ab54510](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ab545106ba09348647360b419cbc97cf8919efbc))

## [1.12.379](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.378...v1.12.379) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.6 ([ddf4cc6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ddf4cc6fb84c68441292e18d011d2f534ace66d1))

## [1.12.378](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.377...v1.12.378) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.17 ([e071693](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e071693b9cdad06d2e1b4167701e4109883dfad4))

## [1.12.377](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.376...v1.12.377) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.6 ([878db18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/878db1850169d5d2df7809a28e51b0bcffd47156))

## [1.12.376](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.375...v1.12.376) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.5 ([a92dd58](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a92dd586d186cc63cbed14973cc9bcf6aa25a3e4))

## [1.12.375](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.374...v1.12.375) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.4 ([0d53384](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0d5338486c941f96ee4515483afac7a3093fc666))

## [1.12.374](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.373...v1.12.374) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.12 ([e6a2401](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e6a24015dac68f0e0b372bb77b2b2761d3ba62fa))

## [1.12.373](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.372...v1.12.373) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.3 ([da6063d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/da6063dc90c843a4affb2565dc7fa36d384952cf))

## [1.12.372](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.371...v1.12.372) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.6 ([e030404](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e030404bdf23807406ab93dae7172f41b1dc7a8a))

## [1.12.371](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.370...v1.12.371) (2020-05-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.5 ([d4face1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d4face1a054fc744cee7cca83114a2203517cf28))

## [1.12.370](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.369...v1.12.370) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.4 ([e719f3f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e719f3faeba8b37a4c6795aa065c9765106989f8))

## [1.12.369](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.368...v1.12.369) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.12.3 ([aa1aeb4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/aa1aeb401edf3419c3b617b646dab5b14d60b450))

## [1.12.368](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.367...v1.12.368) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.5 ([3a674d4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3a674d49754360907c16cf306f1e90fac6ae4cd2))

## [1.12.367](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.366...v1.12.367) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.2 ([82b3f57](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/82b3f574a186d1f8c25c043c48b5a47dd0aa2d17))

## [1.12.366](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.365...v1.12.366) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.19.1 ([f2b45ed](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f2b45edb170a53a8375795b47ad4c0f6c4e6a122))

## [1.12.365](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.364...v1.12.365) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.4 ([3c42e47](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3c42e47d95c859341e0e858a77a7bd17f94b96c8))

## [1.12.364](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.363...v1.12.364) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.5 ([2175741](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2175741c328b73f758f6a2e07f6a7abd764e5730))

## [1.12.363](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.362...v1.12.363) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.3 ([8a14141](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8a14141a15157839ef0a78ce73846a791a4e1cb2))

## [1.12.362](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.361...v1.12.362) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.3 ([4738f96](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4738f961f1dfee2f576d78435f015a776fd1ba80))

## [1.12.361](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.360...v1.12.361) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.2 ([0de2926](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0de29265d937205898567bc3b7add85c0f11a471))

## [1.12.360](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.359...v1.12.360) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.18.1 ([fc543a3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fc543a3d1e61a1351119f614072ede505f5f737c))

## [1.12.359](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.358...v1.12.359) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.18.0 ([66deded](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/66deded9d176e394a496cc3691003d3abf7c30da))

## [1.12.358](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.357...v1.12.358) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.1 ([7bb80d2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7bb80d20d7295301156928f3b3fde49969470c78))

## [1.12.357](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.356...v1.12.357) (2020-05-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.39.0 ([7e8d655](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e8d6555db2a6998e92c92e730f19d5e9ece8350))

## [1.12.356](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.355...v1.12.356) (2020-05-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.2 ([cf852ca](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cf852caded72f7d40c3d4e4d0481fee9429b9f14))

## [1.12.355](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.354...v1.12.355) (2020-05-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.38.1 ([cdbde7e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cdbde7ea5c22c54e080ada58055800bb1559b9d9))

## [1.12.354](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.353...v1.12.354) (2020-05-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.17.0 ([3f588ca](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3f588ca30ab75476f1fc60203645d4a16b6ce10c))

## [1.12.353](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.352...v1.12.353) (2020-05-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.16.10 ([e9310ea](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e9310eae78b03a259b557a42bcec3e93db1ae33b))

## [1.12.352](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.351...v1.12.352) (2020-05-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.16.9 ([76bb810](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/76bb8108650f1a1a07c9a5a2eabb35fb0232b488))

## [1.12.351](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.350...v1.12.351) (2020-05-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.1 ([d2c3a3d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d2c3a3d734c65d622b45cfde6240933bd2e70dcf))

## [1.12.350](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.349...v1.12.350) (2020-05-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.11 ([6d675bf](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d675bf8dade8004f5458d7bd9d6a609988d8746))

## [1.12.349](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.348...v1.12.349) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.4 ([fe8dbef](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fe8dbefb722ed4227afc4dbcb305ef5e2754e4af))

## [1.12.348](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.347...v1.12.348) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-instruction-proxy to v1.1.0 ([0e49f66](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0e49f66fa824a5b75b393e8a367d0071f4b6c606))

## [1.12.347](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.346...v1.12.347) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.16.1 ([25ac8be](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/25ac8bedea89ab371fdcedb5d929869cbf077164))

## [1.12.346](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.345...v1.12.346) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.16.0 ([1c5278f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1c5278f95f29de5b1e0a14fbc2e0e441c2720aee))

## [1.12.345](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.344...v1.12.345) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.11 ([8c3bfd7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c3bfd77560a1d92bf7ee35fa7ba1dfcae93854d))

## [1.12.344](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.343...v1.12.344) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.10 ([6a565e2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6a565e212d7cbf919ae32575542abb842898fb78))

## [1.12.343](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.342...v1.12.343) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.9 ([9a9f1c2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9a9f1c2657743325a4e795b9c03ae777c7e6475e))

## [1.12.342](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.341...v1.12.342) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.8 ([d152da2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d152da2a2c78bc76d7dbb3ccb652caee29b1abfe))

## [1.12.341](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.340...v1.12.341) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.7 ([f5fa17b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f5fa17ba21159c47b373448e8555c789c7cb5c89))

## [1.12.340](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.339...v1.12.340) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.38.0 ([713de2a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/713de2a487446634b63ef40fd0a71711a555702a))

## [1.12.339](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.338...v1.12.339) (2020-05-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.6 ([0992610](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/099261003ef24bf0ed083be5cdcdab82c2aed9bc))

## [1.12.338](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.337...v1.12.338) (2020-05-15)


### Bug Fixes

* 🐛 ins-proxy 1.0.2 ([23da1e6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/23da1e6ea415d0d522dab1d8ba89c7616438761d))

## [1.12.337](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.336...v1.12.337) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.27.3 ([d7d8724](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d7d872427850659e7242283b12bedebf485ca2e4))

## [1.12.336](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.335...v1.12.336) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.5 ([8bbe4b8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8bbe4b8db1b8a6438423513052e2e4b3664f3dae))

## [1.12.335](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.334...v1.12.335) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.12.2 ([793877f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/793877f13c7741e29ad2df3580453d2d37cc1733))

## [1.12.334](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.333...v1.12.334) (2020-05-14)


### Bug Fixes

* 🐛 fix history 0.27.0 ([4aee28b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4aee28bfffb9f9fcd8c5087b5489daf8fab6ac79))

## [1.12.333](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.332...v1.12.333) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.4 ([986362c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/986362c90eeaf7e62e816450d6e8c1b8281228c7))

## [1.12.332](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.331...v1.12.332) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.3 ([a318234](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a318234d11284dc7cdd9173a778fb4bb3f52658a))

## [1.12.331](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.330...v1.12.331) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.10 ([b2827b7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b2827b7dd1ac7f7656922933f47e8b6a93cd1cfd))

## [1.12.330](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.329...v1.12.330) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.12.1 ([1d2ffe5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1d2ffe5d9c028d911d3823de3929e31b53237840))

## [1.12.329](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.328...v1.12.329) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.9.1 ([e9f2de1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e9f2de1169a305d86d926095d0f995bfd431e07c))

## [1.12.328](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.327...v1.12.328) (2020-05-14)


### Bug Fixes

* 🐛 add instruction proxy ([c1a4eec](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c1a4eece923173baef6220747fdf3accef706dfe))

## [1.12.327](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.326...v1.12.327) (2020-05-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.1 ([7edf2f8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7edf2f86b8fe8e2ceebd3686029707264cb3ea0d))

## [1.12.326](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.325...v1.12.326) (2020-05-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.15.0 ([b6763ca](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b6763ca7f26b9b0191c6450b9153285dc8aac673))

## [1.12.325](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.324...v1.12.325) (2020-05-13)


### Bug Fixes

* 🐛 fix 2.14.2 hub break change ([31b13d7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/31b13d7cb37a690d470c53028902138b7bf2374e))

## [1.12.324](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.323...v1.12.324) (2020-05-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.14.1 ([929047b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/929047b42b05279fe9f6835d46391466ee1ded9a))

## [1.12.323](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.322...v1.12.323) (2020-05-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.14.0 ([9d93eef](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9d93eefd24cc97463637c58f274c49c76be26378))

## [1.12.322](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.321...v1.12.322) (2020-05-13)


### Bug Fixes

* 🐛 fix hub 2.13.7 ([266fc8b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/266fc8b2007216e430cb5cd47272ebc1bd1b6eaf))

## [1.12.321](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.320...v1.12.321) (2020-05-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.9 ([0d6b109](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0d6b1090fe0197232c244a0455d9d2ac9c64fae1))

## [1.12.320](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.319...v1.12.320) (2020-05-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.15 ([63c6bdc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/63c6bdce219649a18f81e83efb70a2faa07d74c5))

## [1.12.319](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.318...v1.12.319) (2020-05-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.14 ([4dc5035](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4dc5035))

## [1.12.318](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.317...v1.12.318) (2020-05-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.13 ([3b05e7d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3b05e7d))

## [1.12.317](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.316...v1.12.317) (2020-05-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.12 ([88d9d26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/88d9d26))

## [1.12.316](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.315...v1.12.316) (2020-05-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.11 ([9011fb2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9011fb2))

## [1.12.315](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.314...v1.12.315) (2020-05-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.10 ([e0b10f6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e0b10f6))

## [1.12.314](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.313...v1.12.314) (2020-05-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.8 ([5acd810](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5acd810))

## [1.12.313](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.312...v1.12.313) (2020-05-11)


### Bug Fixes

* 🐛 hub break change ([3b37e45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3b37e45))

## [1.12.312](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.311...v1.12.312) (2020-05-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.7 ([5711431](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5711431))

## [1.12.311](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.310...v1.12.311) (2020-05-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.9 ([89761fd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/89761fd))

## [1.12.310](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.309...v1.12.310) (2020-05-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.13.5 ([61e8dee](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/61e8dee))

## [1.12.309](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.308...v1.12.309) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.8 ([d44ec2e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d44ec2e))

## [1.12.308](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.307...v1.12.308) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.7 ([37202fe](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/37202fe))

## [1.12.307](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.306...v1.12.307) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.13.4 ([a708621](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a708621))

## [1.12.306](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.305...v1.12.306) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.6 ([5a64c6a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5a64c6a))

## [1.12.305](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.304...v1.12.305) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.9 ([70106cc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/70106cc))

## [1.12.304](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.303...v1.12.304) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.5 ([6aaf616](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6aaf616))

## [1.12.303](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.302...v1.12.303) (2020-05-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.13.3 ([8984f0d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8984f0d))

## [1.12.302](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.301...v1.12.302) (2020-05-09)


### Bug Fixes

* 🐛 no directly post data, hub break change ([d23956c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d23956c))

## [1.12.301](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.300...v1.12.301) (2020-05-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.16 ([95c0a12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/95c0a12))

## [1.12.300](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.299...v1.12.300) (2020-05-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.6 ([f9e0738](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f9e0738))

## [1.12.299](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.298...v1.12.299) (2020-05-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.5 ([d45abec](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d45abec))

## [1.12.298](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.297...v1.12.298) (2020-05-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.13.0 ([4f3ccca](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4f3ccca))

## [1.12.297](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.296...v1.12.297) (2020-05-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.4 ([cc48fa2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cc48fa2))

## [1.12.296](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.295...v1.12.296) (2020-05-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.3 ([0f43dcb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0f43dcb))

## [1.12.295](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.294...v1.12.295) (2020-05-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.3 ([40c10c8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/40c10c8))

## [1.12.294](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.293...v1.12.294) (2020-05-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.12.13 ([97aee4d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/97aee4d))

## [1.12.293](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.292...v1.12.293) (2020-05-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.26.2 ([61d92d0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/61d92d0))

## [1.12.292](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.291...v1.12.292) (2020-05-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.37.2 ([1726ae8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1726ae8))

## [1.12.291](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.290...v1.12.291) (2020-05-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.12.5 ([65f307a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/65f307a))

## [1.12.290](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.289...v1.12.290) (2020-05-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.8 ([920e8c0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/920e8c0))

## [1.12.289](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.288...v1.12.289) (2020-05-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.56 ([f4f9457](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f4f9457))

## [1.12.288](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.287...v1.12.288) (2020-05-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.12.0 ([6fd14cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6fd14cd))

## [1.12.287](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.286...v1.12.287) (2020-05-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.55 ([8c0e056](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c0e056))

## [1.12.286](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.285...v1.12.286) (2020-04-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.23 ([7893c4b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7893c4b))

## [1.12.285](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.284...v1.12.285) (2020-04-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.22 ([de65aba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/de65aba))

## [1.12.284](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.283...v1.12.284) (2020-04-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.21 ([a59f120](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a59f120))

## [1.12.283](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.282...v1.12.283) (2020-04-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.36.0 ([95eaa4d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/95eaa4d))

## [1.12.282](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.281...v1.12.282) (2020-04-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.7 ([4dafd25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4dafd25))

## [1.12.281](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.280...v1.12.281) (2020-04-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.20 ([41b8821](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/41b8821))

## [1.12.280](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.279...v1.12.280) (2020-04-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.19 ([639cab1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/639cab1))

## [1.12.279](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.278...v1.12.279) (2020-04-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.6 ([fa138ac](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fa138ac))

## [1.12.278](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.277...v1.12.278) (2020-04-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.18 ([265a003](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/265a003))

## [1.12.277](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.276...v1.12.277) (2020-04-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.17 ([caa8fdb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/caa8fdb))

## [1.12.276](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.275...v1.12.276) (2020-04-28)


### Bug Fixes

* 🐛 fix break change for hub: 2.11.16 ([f3ed88e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f3ed88e))

## [1.12.275](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.274...v1.12.275) (2020-04-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.15 ([65eac21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/65eac21))

## [1.12.274](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.273...v1.12.274) (2020-04-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.35.3 ([cf81a2e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cf81a2e))

## [1.12.273](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.272...v1.12.273) (2020-04-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.14 ([e7e5434](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e7e5434))

## [1.12.272](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.271...v1.12.272) (2020-04-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.54 ([c47e0a4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c47e0a4))

## [1.12.271](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.270...v1.12.271) (2020-04-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.53 ([5a6697e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5a6697e))

## [1.12.270](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.269...v1.12.270) (2020-04-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.5 ([e2b07bf](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e2b07bf))

## [1.12.269](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.268...v1.12.269) (2020-04-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.52 ([e3cb14c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e3cb14c))

## [1.12.268](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.267...v1.12.268) (2020-04-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.35.2 ([ca13f1c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ca13f1c))

## [1.12.267](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.266...v1.12.267) (2020-04-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.11.1 ([88c670d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/88c670d))

## [1.12.266](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.265...v1.12.266) (2020-04-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.15 ([988e65e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/988e65e))

## [1.12.265](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.264...v1.12.265) (2020-04-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.13 ([e860dc0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e860dc0))

## [1.12.264](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.263...v1.12.264) (2020-04-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.35.1 ([ad3f4d5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ad3f4d5))

## [1.12.263](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.262...v1.12.263) (2020-04-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.12 ([c7997d2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c7997d2))

## [1.12.262](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.261...v1.12.262) (2020-04-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.35.0 ([5107c66](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5107c66))

## [1.12.261](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.260...v1.12.261) (2020-04-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.9 ([f25f621](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f25f621))

## [1.12.260](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.259...v1.12.260) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.8 ([ada2066](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ada2066))

## [1.12.259](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.258...v1.12.259) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.6 ([41e8d48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/41e8d48))

## [1.12.258](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.257...v1.12.258) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.51 ([ba4f998](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ba4f998))

## [1.12.257](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.256...v1.12.257) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.50 ([d7f2b7f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d7f2b7f))

## [1.12.256](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.255...v1.12.256) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.29 ([c2d8872](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c2d8872))

## [1.12.255](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.254...v1.12.255) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.11.0 ([db99954](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/db99954))

## [1.12.254](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.253...v1.12.254) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.8.0 ([bee34e2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bee34e2))

## [1.12.253](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.252...v1.12.253) (2020-04-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.28 ([482f94f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/482f94f))

## [1.12.252](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.251...v1.12.252) (2020-04-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.27 ([710b928](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/710b928))

## [1.12.251](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.250...v1.12.251) (2020-04-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.49 ([9a00f77](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9a00f77))

## [1.12.250](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.249...v1.12.250) (2020-04-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.48 ([395fc97](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/395fc97))

## [1.12.249](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.248...v1.12.249) (2020-04-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.26 ([5f927e4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5f927e4))

## [1.12.248](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.247...v1.12.248) (2020-04-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.5 ([7d5ae0d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7d5ae0d))

## [1.12.247](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.246...v1.12.247) (2020-04-21)


### Bug Fixes

* 🐛 add envs about sharememory to auth-acl ([706d207](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/706d207))

## [1.12.246](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.245...v1.12.246) (2020-04-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.22 ([00c9949](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/00c9949))

## [1.12.245](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.244...v1.12.245) (2020-04-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.21 ([0452df7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0452df7))

## [1.12.244](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.243...v1.12.244) (2020-04-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.2 ([a59746a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a59746a))

## [1.12.243](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.242...v1.12.243) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.19 ([b4a82f1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b4a82f1))

## [1.12.242](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.241...v1.12.242) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.10.0 ([1e99799](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1e99799))

## [1.12.241](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.240...v1.12.241) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.46 ([f5fb992](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f5fb992))

## [1.12.240](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.239...v1.12.240) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.11.1 ([913427a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/913427a))

## [1.12.239](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.238...v1.12.239) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.45 ([b0456f9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b0456f9))

## [1.12.238](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.237...v1.12.238) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.44 ([1d730d8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1d730d8))

## [1.12.237](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.236...v1.12.237) (2020-04-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.43 ([1fc6c69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1fc6c69))

## [1.12.236](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.235...v1.12.236) (2020-04-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.42 ([c9fc504](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c9fc504))

## [1.12.235](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.234...v1.12.235) (2020-04-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.41 ([3655846](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3655846))

## [1.12.234](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.233...v1.12.234) (2020-04-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.40 ([cb6e4f3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cb6e4f3))

## [1.12.233](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.232...v1.12.233) (2020-04-18)


### Bug Fixes

* 🐛 rollback eca version ([22460d3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/22460d3))

## [1.12.232](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.231...v1.12.232) (2020-04-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.12 ([81427f4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/81427f4))

## [1.12.231](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.230...v1.12.231) (2020-04-15)


### Bug Fixes

* 🐛 fix post data break change ([9dbb363](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9dbb363))

## [1.12.230](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.229...v1.12.230) (2020-04-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.11 ([863cbcb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/863cbcb))

## [1.12.229](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.228...v1.12.229) (2020-04-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.7 ([c540be1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c540be1))

## [1.12.228](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.227...v1.12.228) (2020-04-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.10 ([b9cea0e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b9cea0e))

## [1.12.227](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.226...v1.12.227) (2020-04-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.9 ([f04dab8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f04dab8))

## [1.12.226](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.225...v1.12.226) (2020-04-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.8 ([23bd588](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/23bd588))

## [1.12.225](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.224...v1.12.225) (2020-04-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.6 ([84e6aac](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/84e6aac))

## [1.12.224](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.223...v1.12.224) (2020-04-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.5 ([ce9052e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ce9052e))

## [1.12.223](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.222...v1.12.223) (2020-04-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.4 ([7e7e8b0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e7e8b0))

## [1.12.222](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.221...v1.12.222) (2020-04-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.7 ([ad63002](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ad63002))

## [1.12.221](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.220...v1.12.221) (2020-04-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.3 ([f68ad3b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f68ad3b))

## [1.12.220](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.219...v1.12.220) (2020-04-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.6 ([604af74](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/604af74))

## [1.12.219](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.218...v1.12.219) (2020-04-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.5 ([5354fd8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5354fd8))

## [1.12.218](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.217...v1.12.218) (2020-04-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.4 ([303c1f0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/303c1f0))

## [1.12.217](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.216...v1.12.217) (2020-04-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.3 ([a350653](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a350653))

## [1.12.216](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.215...v1.12.216) (2020-04-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.3 ([c7e62ea](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c7e62ea))

## [1.12.215](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.214...v1.12.215) (2020-04-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.2 ([446bdb6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/446bdb6))

## [1.12.214](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.213...v1.12.214) (2020-04-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.3.1 ([2a09a31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2a09a31))

## [1.12.213](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.212...v1.12.213) (2020-04-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.2 ([6046e88](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6046e88))

## [1.12.212](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.211...v1.12.212) (2020-04-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.10.2 ([421e2f0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/421e2f0))

## [1.12.211](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.210...v1.12.211) (2020-04-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.34.1 ([affa6c5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/affa6c5))

## [1.12.210](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.209...v1.12.210) (2020-04-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.34 ([1cf232b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1cf232b))

## [1.12.209](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.208...v1.12.209) (2020-04-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.33 ([bf4189a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bf4189a))

## [1.12.208](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.207...v1.12.208) (2020-04-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.31 ([8a8e983](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8a8e983))

## [1.12.207](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.206...v1.12.207) (2020-04-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.33.1 ([3d02a9b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3d02a9b))

## [1.12.206](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.205...v1.12.206) (2020-04-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.36 ([ad2ecae](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ad2ecae))

## [1.12.205](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.204...v1.12.205) (2020-04-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.35 ([c64f303](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c64f303))

## [1.12.204](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.203...v1.12.204) (2020-04-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.34 ([576afa1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/576afa1))

## [1.12.203](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.202...v1.12.203) (2020-04-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.33.0 ([1cfee95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1cfee95))

## [1.12.202](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.201...v1.12.202) (2020-04-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.15 ([c1a3b67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c1a3b67))

## [1.12.201](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.200...v1.12.201) (2020-04-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.33 ([4c3a912](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4c3a912))

## [1.12.200](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.199...v1.12.200) (2020-04-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.14 ([57ced8c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/57ced8c))

## [1.12.199](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.198...v1.12.199) (2020-04-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.32 ([ebca110](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ebca110))

## [1.12.198](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.197...v1.12.198) (2020-04-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.31 ([6f75dc5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6f75dc5))

## [1.12.197](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.196...v1.12.197) (2020-04-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.30 ([63c47d0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/63c47d0))

## [1.12.196](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.195...v1.12.196) (2020-03-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.24 ([3fbab21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3fbab21))

## [1.12.195](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.194...v1.12.195) (2020-03-31)


### Bug Fixes

* 🐛 export port in bridge docker ([945557d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/945557d))

## [1.12.194](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.193...v1.12.194) (2020-03-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.13 ([949a458](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/949a458))

## [1.12.193](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.192...v1.12.193) (2020-03-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.29 ([f8d09ad](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f8d09ad))

## [1.12.192](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.191...v1.12.192) (2020-03-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.12 ([2b33161](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2b33161))

## [1.12.191](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.190...v1.12.191) (2020-03-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.28 ([5a13d84](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5a13d84))

## [1.12.190](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.189...v1.12.190) (2020-03-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.27 ([34506e9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/34506e9))

## [1.12.189](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.188...v1.12.189) (2020-03-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.26 ([89ae08a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/89ae08a))

## [1.12.188](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.187...v1.12.188) (2020-03-26)


### Bug Fixes

* 🐛 bump bridge ([030eb08](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/030eb08))

## [1.12.187](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.186...v1.12.187) (2020-03-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.23 ([65fc4d7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/65fc4d7))

## [1.12.186](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.185...v1.12.186) (2020-03-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.25 ([3c9e3cb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3c9e3cb))

## [1.12.185](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.184...v1.12.185) (2020-03-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.22 ([50faba5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/50faba5))

## [1.12.184](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.183...v1.12.184) (2020-03-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.10 ([4338738](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4338738))

## [1.12.183](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.182...v1.12.183) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.21 ([06e328f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/06e328f))

## [1.12.182](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.181...v1.12.182) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.20 ([4dd5190](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4dd5190))

## [1.12.181](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.180...v1.12.181) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.19 ([0f6c16e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0f6c16e))

## [1.12.180](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.179...v1.12.180) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.18 ([a7dca59](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a7dca59))

## [1.12.179](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.178...v1.12.179) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.22 ([1a6a7cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1a6a7cd))

## [1.12.178](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.177...v1.12.178) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.17 ([e49a08b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e49a08b))

## [1.12.177](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.176...v1.12.177) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.8 ([4ed2351](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4ed2351))

## [1.12.176](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.175...v1.12.176) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.16 ([cd193ec](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cd193ec))

## [1.12.175](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.174...v1.12.175) (2020-03-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.7 ([4553c57](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4553c57))

## [1.12.174](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.173...v1.12.174) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.21 ([5ec1c67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5ec1c67))
* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.5 ([b013134](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b013134))

## [1.12.173](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.172...v1.12.173) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.15 ([f3734bd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f3734bd))

## [1.12.172](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.171...v1.12.172) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.20 ([417061a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/417061a))

## [1.12.171](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.170...v1.12.171) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.14 ([10d71bd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/10d71bd))

## [1.12.170](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.169...v1.12.170) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.30 ([72ffcc3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/72ffcc3))

## [1.12.169](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.168...v1.12.169) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.13 ([e0d1798](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e0d1798))

## [1.12.168](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.167...v1.12.168) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.19 ([bc004cc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bc004cc))

## [1.12.167](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.166...v1.12.167) (2020-03-24)


### Bug Fixes

* 🐛 upgrade bridge to 1.8.4 ([fc92749](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fc92749))

## [1.12.166](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.165...v1.12.166) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.18 ([639fa1b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/639fa1b))

## [1.12.165](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.164...v1.12.165) (2020-03-24)


### Bug Fixes

* update eca-deployer PARALLELISM env ([d46884c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d46884c))

## [1.12.164](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.163...v1.12.164) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.12 ([9af9f93](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9af9f93))

## [1.12.163](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.162...v1.12.163) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.11 ([48b845d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/48b845d))

## [1.12.162](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.161...v1.12.162) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.29 ([5a96b3f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5a96b3f))

## [1.12.161](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.160...v1.12.161) (2020-03-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.10 ([87f5028](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/87f5028))

## [1.12.160](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.159...v1.12.160) (2020-03-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.17 ([afb20e8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/afb20e8))

## [1.12.159](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.158...v1.12.159) (2020-03-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.9 ([ba65431](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ba65431))

## [1.12.158](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.157...v1.12.158) (2020-03-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.3 ([e8a8263](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e8a8263))

## [1.12.157](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.156...v1.12.157) (2020-03-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.8 ([f711506](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f711506))

## [1.12.156](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.155...v1.12.156) (2020-03-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.7 ([ccd7a9f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ccd7a9f))

## [1.12.155](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.154...v1.12.155) (2020-03-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.6 ([b5fb961](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b5fb961))

## [1.12.154](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.153...v1.12.154) (2020-03-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.27 ([a6cc59d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a6cc59d))

## [1.12.153](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.152...v1.12.153) (2020-03-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.5 ([280c134](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/280c134))

## [1.12.152](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.151...v1.12.152) (2020-03-22)


### Bug Fixes

* 🐛 add ENV_CLUSTER_MEMBERS ([6b3c02f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6b3c02f))

## [1.12.151](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.150...v1.12.151) (2020-03-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.4 ([8887e71](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8887e71))

## [1.12.150](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.149...v1.12.150) (2020-03-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.8.2 ([8456fae](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8456fae))

## [1.12.149](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.148...v1.12.149) (2020-03-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.25 ([53682bd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/53682bd))

## [1.12.148](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.147...v1.12.148) (2020-03-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.11 ([11ef961](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/11ef961))

## [1.12.147](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.146...v1.12.147) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.3 ([46acbd5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/46acbd5))

## [1.12.146](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.145...v1.12.146) (2020-03-20)


### Bug Fixes

* 🐛 redis key bug fix and bump historian and eca ([0c0623f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0c0623f))

## [1.12.145](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.144...v1.12.145) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.24 ([12bee51](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/12bee51))

## [1.12.144](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.143...v1.12.144) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.10 ([b2c7453](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b2c7453))

## [1.12.143](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.142...v1.12.143) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.9.1 ([ebfa3b3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ebfa3b3))

## [1.12.142](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.141...v1.12.142) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.9 ([c12d871](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c12d871))

## [1.12.141](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.140...v1.12.141) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.8 ([7e95eeb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e95eeb))

## [1.12.140](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.139...v1.12.140) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.7 ([3170e93](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3170e93))

## [1.12.139](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.138...v1.12.139) (2020-03-20)


### Bug Fixes

* 🐛 fix break change ([ab5b50a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ab5b50a))

## [1.12.138](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.137...v1.12.138) (2020-03-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.13 ([5385a72](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5385a72))

## [1.12.137](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.136...v1.12.137) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.6 ([f011473](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f011473))

## [1.12.136](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.135...v1.12.136) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.12 ([ebfa557](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ebfa557))

## [1.12.135](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.134...v1.12.135) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.11 ([1102ba3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1102ba3))

## [1.12.134](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.133...v1.12.134) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.5 ([c0e1df8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c0e1df8))

## [1.12.133](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.132...v1.12.133) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.10 ([ea673cd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ea673cd))

## [1.12.132](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.131...v1.12.132) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.4 ([b30d3ac](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b30d3ac))

## [1.12.131](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.130...v1.12.131) (2020-03-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.3 ([9d78059](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9d78059))

## [1.12.130](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.129...v1.12.130) (2020-03-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.7 ([4d0d8df](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4d0d8df))

## [1.12.129](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.128...v1.12.129) (2020-03-18)


### Bug Fixes

* 🐛 fix break change of thing ([dfc6d53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dfc6d53))

## [1.12.128](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.127...v1.12.128) (2020-03-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.32.1 ([e481b67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e481b67))

## [1.12.127](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.126...v1.12.127) (2020-03-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.2 ([4c9a1a1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4c9a1a1))

## [1.12.126](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.125...v1.12.126) (2020-03-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.23 ([f67db1f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f67db1f))

## [1.12.125](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.124...v1.12.125) (2020-03-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.22 ([44d9912](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/44d9912))

## [1.12.124](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.123...v1.12.124) (2020-03-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.1 ([c7c51f0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c7c51f0))

## [1.12.123](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.122...v1.12.123) (2020-03-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.12 ([a7a6174](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a7a6174))

## [1.12.122](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.121...v1.12.122) (2020-03-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.21 ([e87841e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e87841e))

## [1.12.121](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.120...v1.12.121) (2020-03-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.8.0 ([022d565](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/022d565))

## [1.12.120](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.119...v1.12.120) (2020-03-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.11 ([0b177ba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0b177ba))

## [1.12.119](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.118...v1.12.119) (2020-03-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.10 ([48f7125](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/48f7125))

## [1.12.118](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.117...v1.12.118) (2020-03-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.7 ([1472992](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1472992))

## [1.12.117](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.116...v1.12.117) (2020-03-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.6 ([162704e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/162704e))

## [1.12.116](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.115...v1.12.116) (2020-03-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.5 ([75f7b39](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/75f7b39))

## [1.12.115](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.114...v1.12.115) (2020-03-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.4 ([4c38342](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4c38342))

## [1.12.114](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.113...v1.12.114) (2020-03-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.20 ([75be3a7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/75be3a7))

## [1.12.113](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.112...v1.12.113) (2020-03-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.3 ([8944d34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8944d34))

## [1.12.112](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.111...v1.12.112) (2020-03-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.1 ([1f8e5fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1f8e5fb))

## [1.12.111](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.110...v1.12.111) (2020-03-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.20 ([1c68c28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1c68c28))

## [1.12.110](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.109...v1.12.110) (2020-03-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.31.0 ([f8ff7d7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f8ff7d7))

## [1.12.109](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.108...v1.12.109) (2020-03-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.19 ([169e223](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/169e223))

## [1.12.108](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.107...v1.12.108) (2020-03-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.33 ([3802921](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3802921))

## [1.12.107](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.106...v1.12.107) (2020-03-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.15 ([1e73118](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1e73118))

## [1.12.106](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.105...v1.12.106) (2020-03-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.32 ([569fd3b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/569fd3b))

## [1.12.105](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.104...v1.12.105) (2020-03-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.6.0 ([fbb525b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fbb525b))

## [1.12.104](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.103...v1.12.104) (2020-03-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.31 ([42f5641](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/42f5641))

## [1.12.103](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.102...v1.12.103) (2020-03-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.18 ([598edca](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/598edca))

## [1.12.102](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.101...v1.12.102) (2020-03-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.30 ([52bedf8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/52bedf8))

## [1.12.101](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.100...v1.12.101) (2020-03-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.10 ([e4d70bc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e4d70bc))

## [1.12.100](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.99...v1.12.100) (2020-03-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.9 ([45ebf31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/45ebf31))

## [1.12.99](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.98...v1.12.99) (2020-03-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.17 ([4ad975e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4ad975e))

## [1.12.98](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.97...v1.12.98) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.8 ([7fded71](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7fded71))

## [1.12.97](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.96...v1.12.97) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.7 ([c21670f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c21670f))

## [1.12.96](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.95...v1.12.96) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.29 ([0b4c49d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0b4c49d))

## [1.12.95](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.94...v1.12.95) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.6 ([0a43869](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0a43869))

## [1.12.94](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.93...v1.12.94) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.5 ([3425485](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3425485))

## [1.12.93](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.92...v1.12.93) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.3 ([2ac2ce9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2ac2ce9))

## [1.12.92](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.91...v1.12.92) (2020-03-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.28 ([dff7fe2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dff7fe2))

## [1.12.91](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.90...v1.12.91) (2020-03-04)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.2 ([7e4033c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e4033c))

## [1.12.90](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.89...v1.12.90) (2020-03-04)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.7.1 ([1624a8d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1624a8d))

## [1.12.89](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.88...v1.12.89) (2020-03-04)


### Bug Fixes

* 🐛 fix break change about manufacturerId in device type ([ba9da23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ba9da23))

## [1.12.88](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.87...v1.12.88) (2020-03-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.27 ([651964f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/651964f))

## [1.12.87](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.86...v1.12.87) (2020-03-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.5.0 ([d1e84bd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d1e84bd))

## [1.12.86](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.85...v1.12.86) (2020-03-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.6.1 ([1743ca9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1743ca9))

## [1.12.85](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.84...v1.12.85) (2020-03-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.26 ([6bfd702](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6bfd702))

## [1.12.84](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.83...v1.12.84) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.12 ([e54a172](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e54a172))

## [1.12.83](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.82...v1.12.83) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.6.0 ([922031c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/922031c))

## [1.12.82](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.81...v1.12.82) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.11 ([6ae810b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6ae810b))

## [1.12.81](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.80...v1.12.81) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.4.2 ([4bd215f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4bd215f))

## [1.12.80](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.79...v1.12.80) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.10 ([7c4e5ce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7c4e5ce))

## [1.12.79](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.78...v1.12.79) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.24 ([73d2fdf](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/73d2fdf))

## [1.12.78](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.77...v1.12.78) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.23 ([d45fd2b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d45fd2b))

## [1.12.77](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.76...v1.12.77) (2020-03-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.9 ([3fe2414](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3fe2414))

## [1.12.76](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.75...v1.12.76) (2020-02-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.16 ([9ed33db](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9ed33db))

## [1.12.75](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.74...v1.12.75) (2020-02-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.22 ([94dafc9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/94dafc9))

## [1.12.74](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.73...v1.12.74) (2020-02-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.5.1 ([4e35ce7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4e35ce7))

## [1.12.73](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.72...v1.12.73) (2020-02-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.8 ([f4fba36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f4fba36))

## [1.12.72](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.71...v1.12.72) (2020-02-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.21 ([599ad15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/599ad15))

## [1.12.71](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.70...v1.12.71) (2020-02-28)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.7 ([b905784](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b905784))

## [1.12.70](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.69...v1.12.70) (2020-02-27)


### Bug Fixes

* 🐛 break change and mqtt4.0上数 ([fb562b9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fb562b9))

## [1.12.69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.68...v1.12.69) (2020-02-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.15 ([b79450d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b79450d))

## [1.12.68](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.67...v1.12.68) (2020-02-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.5 ([9baef5e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9baef5e))

## [1.12.67](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.66...v1.12.67) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.19 ([ee880ce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ee880ce))

## [1.12.66](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.65...v1.12.66) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.14 ([12bb457](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/12bb457))

## [1.12.65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.64...v1.12.65) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.4 ([38b20cb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/38b20cb))

## [1.12.64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.63...v1.12.64) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.4.1 ([70d65a4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/70d65a4))

## [1.12.63](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.62...v1.12.63) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.13 ([45a4da0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/45a4da0))

## [1.12.62](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.61...v1.12.62) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.3 ([3d6216c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3d6216c))

## [1.12.61](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.60...v1.12.61) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.18 ([e28587b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e28587b))

## [1.12.60](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.59...v1.12.60) (2020-02-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.6.2 ([0c8ede0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0c8ede0))

## [1.12.59](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.58...v1.12.59) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.9 ([d89469d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d89469d))

## [1.12.58](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.57...v1.12.58) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.12 ([3bc4f72](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3bc4f72))

## [1.12.57](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.56...v1.12.57) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.4.0 ([799e4c4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/799e4c4))

## [1.12.56](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.55...v1.12.56) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.11 ([3804285](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3804285))

## [1.12.55](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.54...v1.12.55) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.8 ([9894618](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9894618))

## [1.12.54](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.53...v1.12.54) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.8 ([7545989](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7545989))
* auth acl dev mode ([f085f00](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f085f00))

## [1.12.53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.52...v1.12.53) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.6 ([59f05a5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/59f05a5))

## [1.12.52](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.51...v1.12.52) (2020-02-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.17 ([d5780e2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d5780e2))

## [1.12.51](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.50...v1.12.51) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.7 ([5855539](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5855539))

## [1.12.50](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.49...v1.12.50) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.5 ([0c29985](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0c29985))

## [1.12.49](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.48...v1.12.49) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.3.4 ([29834f6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/29834f6))

## [1.12.48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.47...v1.12.48) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.7 ([c28481e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c28481e))

## [1.12.47](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.46...v1.12.47) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.10 ([a66471b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a66471b))

## [1.12.46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.45...v1.12.46) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.5 ([892b91f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/892b91f))

## [1.12.45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.44...v1.12.45) (2020-02-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.16 ([d6e571e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d6e571e))

## [1.12.44](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.43...v1.12.44) (2020-02-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.4 ([f416ccd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f416ccd))

## [1.12.43](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.42...v1.12.43) (2020-02-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.3 ([3a37617](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3a37617))

## [1.12.42](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.41...v1.12.42) (2020-02-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.15 ([6e285ac](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6e285ac))

## [1.12.41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.40...v1.12.41) (2020-02-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.6 ([adeb60c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/adeb60c))

## [1.12.40](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.39...v1.12.40) (2020-02-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.12 ([f275234](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f275234))
* 🐛 deployer acl dev mode ([d7c5007](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d7c5007))

## [1.12.39](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.38...v1.12.39) (2020-02-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.5.1 ([f5739ff](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f5739ff))

## [1.12.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.37...v1.12.38) (2020-02-20)


### Bug Fixes

* 🐛 test super token ([6116207](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6116207))
* 🐛 update historian image and setting ([1f58539](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1f58539))

## [1.12.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.36...v1.12.37) (2020-02-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.11 ([385174e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/385174e))

## [1.12.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.35...v1.12.36) (2020-02-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.8 ([601e14d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/601e14d))

## [1.12.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.34...v1.12.35) (2020-02-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.10 ([3ebb7f2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3ebb7f2))
* 🐛 add missing env HUB_SUPER_TOKEN ([4c0faf4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4c0faf4))

## [1.12.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.33...v1.12.34) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.4.4 ([e74269b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e74269b))

## [1.12.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.32...v1.12.33) (2020-02-19)


### Bug Fixes

* 🐛 fix number位数截取， query device by li regression ([3aaa2fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3aaa2fb))

## [1.12.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.31...v1.12.32) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.4.3 ([e3e9d6f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e3e9d6f))

## [1.12.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.30...v1.12.31) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.7 ([43d1ece](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/43d1ece))

## [1.12.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.29...v1.12.30) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.4 ([a3b3810](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a3b3810))

## [1.12.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.28...v1.12.29) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.3.3 ([4f74626](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4f74626))

## [1.12.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.27...v1.12.28) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.4 ([392fa80](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/392fa80))

## [1.12.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.26...v1.12.27) (2020-02-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.4.0 ([d7aa3a6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d7aa3a6))

## [1.12.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.25...v1.12.26) (2020-02-18)


### Bug Fixes

* 🐛 fix break change of li properties, hub: 2.3.0 ([72d7223](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/72d7223))

## [1.12.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.24...v1.12.25) (2020-02-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.6 ([30cef8a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/30cef8a))

## [1.12.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.23...v1.12.24) (2020-02-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.3.2 ([f5f1168](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f5f1168))

## [1.12.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.22...v1.12.23) (2020-02-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.3 ([7b08cd6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7b08cd6))

## [1.12.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.21...v1.12.22) (2020-02-18)


### Bug Fixes

* 🐛 GYPT-10929, GYPT-10938 ([8010a96](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8010a96))

## [1.12.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.20...v1.12.21) (2020-02-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.5 ([ae8195d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ae8195d))

## [1.12.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.19...v1.12.20) (2020-02-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.3 ([cc3df3f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cc3df3f))

## [1.12.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.18...v1.12.19) (2020-02-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.2 ([ec18a25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ec18a25))

## [1.12.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.17...v1.12.18) (2020-02-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.6 ([49809fa](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/49809fa))

## [1.12.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.16...v1.12.17) (2020-02-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.5 ([c983dbc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c983dbc))

## [1.12.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.15...v1.12.16) (2020-02-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.2.0 ([05559f9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/05559f9))

## [1.12.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.14...v1.12.15) (2020-02-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.4 ([a1631d1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a1631d1))

## [1.12.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.13...v1.12.14) (2020-02-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.1.2 ([202746b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/202746b))

## [1.12.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.12...v1.12.13) (2020-02-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.1.1 ([2ad8425](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2ad8425))

## [1.12.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.11...v1.12.12) (2020-02-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.1.0 ([535c55f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/535c55f))

## [1.12.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.10...v1.12.11) (2020-02-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.3 ([b9bea3e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b9bea3e))

## [1.12.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.9...v1.12.10) (2020-02-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.0.4 ([892a013](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/892a013))

## [1.12.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.8...v1.12.9) (2020-02-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.2 ([480de59](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/480de59))

## [1.12.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.7...v1.12.8) (2020-02-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2.0.3 ([6d54bb3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d54bb3))

## [1.12.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.6...v1.12.7) (2020-02-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v2 ([cd33e47](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cd33e47))

## [1.12.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.5...v1.12.6) (2020-02-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.1 ([9be1925](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9be1925))

## [1.12.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.4...v1.12.5) (2020-02-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.4.0 ([b5c6e5f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b5c6e5f))

## [1.12.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.3...v1.12.4) (2020-02-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.15.9 ([a3a2e1c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a3a2e1c))

## [1.12.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.2...v1.12.3) (2020-02-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.15.8 ([d559281](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d559281))

## [1.12.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.1...v1.12.2) (2020-02-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-platform-metrics to v0.1.1 ([72fd0b6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/72fd0b6))

## [1.12.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.12.0...v1.12.1) (2020-02-11)


### Bug Fixes

* 🐛 remove volumes mapping from hub ([cc924a3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cc924a3))

# [1.12.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.13...v1.12.0) (2020-02-10)


### Features

* 🎸 add platform-metrics service ([8003f5b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8003f5b))

## [1.11.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.12...v1.11.13) (2020-02-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.15.4 ([73ee9fd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/73ee9fd))

## [1.11.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.11...v1.11.12) (2020-02-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.30.1 ([943e186](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/943e186))

## [1.11.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.10...v1.11.11) (2020-02-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.25.4 ([1fba14d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1fba14d))

## [1.11.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.9...v1.11.10) (2020-02-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.3.0 ([dace9b3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dace9b3))

## [1.11.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.8...v1.11.9) (2020-02-07)


### Bug Fixes

* 🐛 add environment variable aclMode=dev ([e2fcfb3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e2fcfb3))

## [1.11.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.7...v1.11.8) (2020-02-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.14.0 ([79cda5f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/79cda5f))

## [1.11.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.6...v1.11.7) (2020-02-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.3.1 ([81473ce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/81473ce))

## [1.11.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.5...v1.11.6) (2020-02-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.13.3 ([8fbc04a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8fbc04a))

## [1.11.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.4...v1.11.5) (2020-02-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.13.2 ([100f74c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/100f74c))

## [1.11.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.3...v1.11.4) (2020-02-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.3.0 ([f068df0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f068df0))

## [1.11.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.2...v1.11.3) (2020-02-05)


### Bug Fixes

* redis and add neg manufacturer ([5ce724d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5ce724d))

## [1.11.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.1...v1.11.2) (2020-02-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.13.1 ([9ee00c4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9ee00c4))

## [1.11.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.11.0...v1.11.1) (2020-02-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.13.0 ([f23b6d8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f23b6d8))

# [1.11.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.10...v1.11.0) (2020-02-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.28.2 ([4c20acd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4c20acd))


### Features

* 🎸 redis realtime sink ([32fe81c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/32fe81c))

## [1.10.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.9...v1.10.10) (2020-02-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.2.2 ([8595e9d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8595e9d))

## [1.10.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.8...v1.10.9) (2020-01-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.10.3 ([8a0d70c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8a0d70c))

## [1.10.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.7...v1.10.8) (2020-01-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.10.2 ([cb7084f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cb7084f))

## [1.10.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.6...v1.10.7) (2020-01-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.10.1 ([e421264](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e421264))

## [1.10.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.5...v1.10.6) (2020-01-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.10.0 ([51a0e71](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/51a0e71))

## [1.10.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.4...v1.10.5) (2020-01-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.9 ([76494f6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/76494f6))

## [1.10.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.3...v1.10.4) (2020-01-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.23.3 ([950c191](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/950c191))

## [1.10.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.2...v1.10.3) (2020-01-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.28.1 ([56b6275](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/56b6275))

## [1.10.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.1...v1.10.2) (2020-01-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.8 ([c429764](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c429764))

## [1.10.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.10.0...v1.10.1) (2020-01-16)


### Bug Fixes

* 🐛 migrate cd to new aluada dev environment ([eb64810](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/eb64810))

# [1.10.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.46...v1.10.0) (2020-01-16)


### Features

* 🎸 enable mongo replica cluster mode ([ebd0a44](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ebd0a44))

## [1.9.46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.45...v1.9.46) (2020-01-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.7 ([a2bd306](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a2bd306))

## [1.9.45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.44...v1.9.45) (2020-01-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.6 ([155f85f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/155f85f))

## [1.9.44](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.43...v1.9.44) (2020-01-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.5 ([d20d637](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d20d637))

## [1.9.43](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.42...v1.9.43) (2020-01-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.4 ([ac40d68](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ac40d68))

## [1.9.42](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.41...v1.9.42) (2020-01-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.3 ([99e2239](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/99e2239))

## [1.9.41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.40...v1.9.41) (2020-01-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.2.5 ([5f92857](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5f92857))

## [1.9.40](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.39...v1.9.40) (2020-01-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.2 ([a86b417](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a86b417))

## [1.9.39](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.38...v1.9.39) (2020-01-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.28.0 ([4ed59c8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4ed59c8))

## [1.9.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.37...v1.9.38) (2020-01-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.1 ([62d2835](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/62d2835))

## [1.9.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.36...v1.9.37) (2020-01-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.14 ([864d78a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/864d78a))

## [1.9.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.35...v1.9.36) (2020-01-14)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.9.0 ([4fbb689](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4fbb689))

## [1.9.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.34...v1.9.35) (2020-01-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.8.2 ([6f4d396](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6f4d396))

## [1.9.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.33...v1.9.34) (2020-01-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.8.0 ([ac45a3b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ac45a3b))

## [1.9.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.32...v1.9.33) (2020-01-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.27.5 ([adab2c8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/adab2c8))

## [1.9.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.31...v1.9.32) (2020-01-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.2.4 ([ed49d5f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ed49d5f))

## [1.9.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.30...v1.9.31) (2020-01-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.21 ([85a8487](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/85a8487))

## [1.9.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.29...v1.9.30) (2020-01-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.22.3 ([075ed8a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/075ed8a))

## [1.9.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.28...v1.9.29) (2020-01-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.2.1 ([ada7a16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ada7a16))

## [1.9.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.27...v1.9.28) (2020-01-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.22.2 ([64e20cb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/64e20cb))

## [1.9.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.26...v1.9.27) (2020-01-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.22.1 ([b6f2dc1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b6f2dc1))

## [1.9.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.25...v1.9.26) (2020-01-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.27.4 ([3a3753a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3a3753a))

## [1.9.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.24...v1.9.25) (2020-01-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.22.0 ([f9a9f40](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f9a9f40))

## [1.9.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.23...v1.9.24) (2020-01-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.18 ([78c54f4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/78c54f4))

## [1.9.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.22...v1.9.23) (2020-01-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.17 ([c682ec5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c682ec5))

## [1.9.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.21...v1.9.22) (2020-01-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.16 ([0d7f516](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0d7f516))

## [1.9.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.20...v1.9.21) (2020-01-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.15 ([84205e3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/84205e3))

## [1.9.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.19...v1.9.20) (2020-01-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.27.3 ([8038df1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8038df1))

## [1.9.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.18...v1.9.19) (2020-01-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.20 ([253b535](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/253b535))

## [1.9.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.17...v1.9.18) (2020-01-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.27.2 ([608672e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/608672e))

## [1.9.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.16...v1.9.17) (2020-01-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.27.1 ([a4979d4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a4979d4))

## [1.9.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.15...v1.9.16) (2020-01-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.27.0 ([1628f8e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1628f8e))

## [1.9.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.14...v1.9.15) (2020-01-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.12 ([83fafa7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/83fafa7))

## [1.9.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.13...v1.9.14) (2020-01-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.2.3 ([245b072](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/245b072))

## [1.9.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.12...v1.9.13) (2020-01-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.19 ([c43b2af](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c43b2af))

## [1.9.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.11...v1.9.12) (2019-12-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.9 ([d24a867](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d24a867))

## [1.9.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.10...v1.9.11) (2019-12-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.8 ([2777cdb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2777cdb))

## [1.9.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.9...v1.9.10) (2019-12-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.17 ([3b7ae04](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3b7ae04))

## [1.9.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.8...v1.9.9) (2019-12-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.2.0 ([0cd8566](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0cd8566))

## [1.9.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.7...v1.9.8) (2019-12-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.14 ([4bdffba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4bdffba))

## [1.9.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.6...v1.9.7) (2019-12-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.16 ([8176324](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8176324))

## [1.9.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.5...v1.9.6) (2019-12-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.7 ([4901549](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4901549))

## [1.9.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.4...v1.9.5) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.15 ([b4ad6b9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b4ad6b9))

## [1.9.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.3...v1.9.4) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.6 ([6d3b88f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d3b88f))

## [1.9.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.2...v1.9.3) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.13 ([4a50344](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4a50344))

## [1.9.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.1...v1.9.2) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.5 ([5f90635](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5f90635))

## [1.9.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.9.0...v1.9.1) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.12 ([8e877af](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8e877af))

# [1.9.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.49...v1.9.0) (2019-12-25)


### Features

* 🎸 add prometheus for metrics ([d34a09d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d34a09d))

## [1.8.49](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.48...v1.8.49) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.4 ([56f2c24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/56f2c24))

## [1.8.48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.47...v1.8.48) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.13 ([2c31c7d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2c31c7d))

## [1.8.47](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.46...v1.8.47) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.3 ([3f84bb2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3f84bb2))

## [1.8.46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.45...v1.8.46) (2019-12-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.11 ([78f6ea7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/78f6ea7))

## [1.8.45](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.44...v1.8.45) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.2 ([caf9c82](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/caf9c82))

## [1.8.44](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.43...v1.8.44) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.10 ([658d6c8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/658d6c8))

## [1.8.43](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.42...v1.8.43) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.2.2 ([c24ab59](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c24ab59))

## [1.8.42](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.41...v1.8.42) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.12 ([4cb8548](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4cb8548))

## [1.8.41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.40...v1.8.41) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.11 ([d31b69c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d31b69c))

## [1.8.40](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.39...v1.8.40) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.11 ([1644ef0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1644ef0))

## [1.8.39](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.38...v1.8.39) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.9 ([d803a53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d803a53))

## [1.8.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.37...v1.8.38) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.1 ([4dbe54c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4dbe54c))

## [1.8.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.36...v1.8.37) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.10 ([3835795](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3835795))

## [1.8.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.35...v1.8.36) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.9 ([026e111](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/026e111))

## [1.8.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.34...v1.8.35) (2019-12-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.8 ([4de3d27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4de3d27))

## [1.8.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.33...v1.8.34) (2019-12-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.7 ([336f281](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/336f281))

## [1.8.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.32...v1.8.33) (2019-12-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.8 ([a4ee954](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a4ee954))

## [1.8.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.31...v1.8.32) (2019-12-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.7 ([77de7e8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/77de7e8))

## [1.8.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.30...v1.8.31) (2019-12-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.6 ([a749d4f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a749d4f))

## [1.8.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.29...v1.8.30) (2019-12-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.5 ([c0bcbd3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c0bcbd3))

## [1.8.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.28...v1.8.29) (2019-12-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.4 ([6da87d7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6da87d7))
* 🐛 white list expiresAt date format ([fea11a9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fea11a9))

## [1.8.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.27...v1.8.28) (2019-12-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.26.0 ([7a4cf1b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7a4cf1b))

## [1.8.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.26...v1.8.27) (2019-12-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.10 ([2bb8fa6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2bb8fa6))

## [1.8.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.25...v1.8.26) (2019-12-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.6 ([0300e10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0300e10))

## [1.8.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.24...v1.8.25) (2019-12-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.5 ([315adf3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/315adf3))

## [1.8.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.23...v1.8.24) (2019-12-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.25.5 ([511032d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/511032d))

## [1.8.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.22...v1.8.23) (2019-12-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.3 ([60c44ea](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/60c44ea))

## [1.8.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.21...v1.8.22) (2019-12-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.25.4 ([29407de](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/29407de))

## [1.8.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.20...v1.8.21) (2019-12-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.25.3 ([7da2a77](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7da2a77))

## [1.8.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.19...v1.8.20) (2019-12-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.2 ([0d089ea](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0d089ea))

## [1.8.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.18...v1.8.19) (2019-12-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.4 ([0b2f54e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0b2f54e))

## [1.8.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.17...v1.8.18) (2019-12-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.3 ([3b4629e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3b4629e))

## [1.8.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.16...v1.8.17) (2019-12-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.7.0 ([a31110d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a31110d))

## [1.8.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.15...v1.8.16) (2019-12-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.19 ([641a0d0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/641a0d0))

## [1.8.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.14...v1.8.15) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.25.2 ([c0c0efd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c0c0efd))

## [1.8.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.13...v1.8.14) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.25.1 ([7596001](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7596001))

## [1.8.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.12...v1.8.13) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.18 ([9d4bfc0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9d4bfc0))

## [1.8.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.11...v1.8.12) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.2 ([a56223a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a56223a))

## [1.8.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.10...v1.8.11) (2019-12-19)


### Bug Fixes

* add topic for dev cmd ack ([6ff44fe](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6ff44fe))

## [1.8.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.9...v1.8.10) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.1.1 ([13cbd58](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/13cbd58))

## [1.8.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.8...v1.8.9) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-kafka-bridge to v1.1.0 ([96ed328](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/96ed328))

## [1.8.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.7...v1.8.8) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.25.0 ([7ec7a62](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7ec7a62))

## [1.8.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.6...v1.8.7) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.24.4 ([8dcd462](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8dcd462))

## [1.8.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.5...v1.8.6) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.1 ([0659a1c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0659a1c))

## [1.8.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.4...v1.8.5) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.17 ([6a0cf8b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6a0cf8b))

## [1.8.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.3...v1.8.4) (2019-12-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.21.0 ([17ddf0c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/17ddf0c))

## [1.8.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.2...v1.8.3) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.24.3 ([f1744b5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f1744b5))

## [1.8.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.1...v1.8.2) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.16 ([a7f53f7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a7f53f7))

## [1.8.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.8.0...v1.8.1) (2019-12-18)


### Bug Fixes

* 🐛 enable cd emqx-kafka-bridge ([9070e15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9070e15))

# [1.8.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.25...v1.8.0) (2019-12-18)


### Features

* replace data mapper with emq bridge ([acb2c36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/acb2c36))

## [1.7.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.24...v1.7.25) (2019-12-18)


### Bug Fixes

* 🐛 change emqx to open source version ([ff095a2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ff095a2))

## [1.7.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.23...v1.7.24) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.24.2 ([c7cc0a0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c7cc0a0))

## [1.7.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.22...v1.7.23) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.15 ([f040be1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f040be1))

## [1.7.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.21...v1.7.22) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.14 ([42f36ae](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/42f36ae))

## [1.7.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.20...v1.7.21) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.24.1 ([9e9fb37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9e9fb37))

## [1.7.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.19...v1.7.20) (2019-12-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.24.0 ([8c3a685](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c3a685))

## [1.7.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.18...v1.7.19) (2019-12-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.13 ([30aa3e9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/30aa3e9))

## [1.7.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.17...v1.7.18) (2019-12-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.11 ([a9df82c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a9df82c))

## [1.7.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.16...v1.7.17) (2019-12-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.11 ([db56316](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/db56316))

## [1.7.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.15...v1.7.16) (2019-12-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.10 ([fd47791](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fd47791))

## [1.7.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.14...v1.7.15) (2019-12-16)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.9 ([05e1b80](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/05e1b80))

## [1.7.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.13...v1.7.14) (2019-12-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.7 ([1272a8d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1272a8d))

## [1.7.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.12...v1.7.13) (2019-12-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.6 ([0230104](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0230104))

## [1.7.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.11...v1.7.12) (2019-12-13)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.5 ([cbcedad](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cbcedad))

## [1.7.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.10...v1.7.11) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.10 ([efe4e6c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/efe4e6c))

## [1.7.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.9...v1.7.10) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.4 ([d244e41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d244e41))

## [1.7.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.8...v1.7.9) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.8 ([8500292](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8500292))

## [1.7.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.7...v1.7.8) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.3 ([4aa8eaf](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4aa8eaf))

## [1.7.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.6...v1.7.7) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.2.1 ([b15ad07](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b15ad07))

## [1.7.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.5...v1.7.6) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.2 ([d75ee60](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d75ee60))

## [1.7.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.4...v1.7.5) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.9 ([1716145](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1716145))

## [1.7.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.3...v1.7.4) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.8 ([527badb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/527badb))

## [1.7.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.2...v1.7.3) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.7 ([4dddb69](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4dddb69))

## [1.7.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.1...v1.7.2) (2019-12-12)


### Bug Fixes

* 🐛 update eventTypeName tempevt->DEFAULT_EVENT ([8f99252](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8f99252))

## [1.7.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.7.0...v1.7.1) (2019-12-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.1 ([8467b22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8467b22))

# [1.7.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.38...v1.7.0) (2019-12-11)


### Features

* add emq infomation ([9cf9581](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9cf9581))

## [1.6.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.37...v1.6.38) (2019-12-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.6 ([22f79a2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/22f79a2))

## [1.6.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.36...v1.6.37) (2019-12-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.23.0 ([d3511a4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d3511a4))

## [1.6.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.35...v1.6.36) (2019-12-11)


### Bug Fixes

* 🐛 update postman collection and remove importData resource ([1edd67a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1edd67a))

## [1.6.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.34...v1.6.35) (2019-12-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.5 ([2984362](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2984362))

## [1.6.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.33...v1.6.34) (2019-12-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.4 ([805cb48](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/805cb48))

## [1.6.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.32...v1.6.33) (2019-12-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.22.0 ([3da9afc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3da9afc))

## [1.6.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.31...v1.6.32) (2019-12-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.2 ([b2b9793](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b2b9793))

## [1.6.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.30...v1.6.31) (2019-12-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.21.3 ([51a539a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/51a539a))

## [1.6.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.29...v1.6.30) (2019-12-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.21.2 ([ac7e854](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ac7e854))

## [1.6.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.28...v1.6.29) (2019-12-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.21.1 ([2ddbcd0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2ddbcd0))

## [1.6.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.27...v1.6.28) (2019-12-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.1 ([9a21a02](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9a21a02))

## [1.6.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.26...v1.6.27) (2019-12-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.6.0 ([72a233b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/72a233b))

## [1.6.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.25...v1.6.26) (2019-12-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.21.0 ([35e6274](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/35e6274))

## [1.6.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.24...v1.6.25) (2019-12-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.20.4 ([326bd91](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/326bd91))

## [1.6.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.23...v1.6.24) (2019-12-09)


### Bug Fixes

* Update the emqx license ([339c1e1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/339c1e1))

## [1.6.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.22...v1.6.23) (2019-12-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.5.0 ([d8e814f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d8e814f))

## [1.6.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.21...v1.6.22) (2019-12-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.20.3 ([37f7969](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/37f7969))

## [1.6.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.20...v1.6.21) (2019-12-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.4.0 ([cf7a5c9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cf7a5c9))

## [1.6.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.19...v1.6.20) (2019-12-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.3.0 ([6b8a9fb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6b8a9fb))

## [1.6.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.18...v1.6.19) (2019-12-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.8 ([230f247](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/230f247))

## [1.6.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.17...v1.6.18) (2019-12-05)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.2.2 ([928f3c3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/928f3c3))

## [1.6.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.16...v1.6.17) (2019-12-04)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.2.1 ([f01be53](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f01be53))

## [1.6.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.15...v1.6.16) (2019-12-03)


### Bug Fixes

* updated apikeys and image versions ([b37261b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b37261b))

## [1.6.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.14...v1.6.15) (2019-12-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.19.4 ([a1d4047](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a1d4047))

## [1.6.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.13...v1.6.14) (2019-12-03)


### Bug Fixes

* 🐛 add time series admin ([6016f5d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6016f5d))

## [1.6.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.12...v1.6.13) (2019-12-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.2.0 ([3836246](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3836246))

## [1.6.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.11...v1.6.12) (2019-12-03)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.1.0 ([0af716b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0af716b))

## [1.6.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.10...v1.6.11) (2019-12-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v1.0.8 ([eafa1a0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/eafa1a0))

## [1.6.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.9...v1.6.10) (2019-12-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.7 ([56bcad6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/56bcad6))

## [1.6.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.8...v1.6.9) (2019-12-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.19.3 ([03cc11c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/03cc11c))

## [1.6.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.7...v1.6.8) (2019-12-02)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.19.2 ([8c15ff0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c15ff0))

## [1.6.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.6...v1.6.7) (2019-11-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.6 ([ec677c0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ec677c0))

## [1.6.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.5...v1.6.6) (2019-11-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.5 ([1d8e3a6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1d8e3a6))

## [1.6.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.4...v1.6.5) (2019-11-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.11.4 ([29bdba7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/29bdba7))

## [1.6.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.3...v1.6.4) (2019-11-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.4 ([7835565](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7835565))

## [1.6.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.2...v1.6.3) (2019-11-25)


### Bug Fixes

* 🐛 enable tracing rest service ([812492b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/812492b))

## [1.6.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.1...v1.6.2) (2019-11-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.17.0 ([cd814a5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cd814a5))

## [1.6.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.6.0...v1.6.1) (2019-11-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.11.3 ([1033b04](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1033b04))

# [1.6.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.20...v1.6.0) (2019-11-22)


### Features

* 🎸 add start.sh -j to start jaeger ([5a54b32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5a54b32))

## [1.5.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.19...v1.5.20) (2019-11-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.16.0 ([fdeec10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fdeec10))

## [1.5.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.18...v1.5.19) (2019-11-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.11.2 ([5be2a0b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5be2a0b))

## [1.5.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.17...v1.5.18) (2019-11-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.11.1 ([7e34c2b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7e34c2b))

## [1.5.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.16...v1.5.17) (2019-11-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.11.0 ([4a003ba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4a003ba))

## [1.5.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.15...v1.5.16) (2019-11-19)


### Bug Fixes

* 🐛 import ApiKeyToken as a whitelist ([bef9d03](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bef9d03))
* 🐛 import ApiKeyToken as a whitelist ([35542c4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/35542c4))

## [1.5.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.14...v1.5.15) (2019-11-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.15.0 ([0cf1e46](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0cf1e46))

## [1.5.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.13...v1.5.14) (2019-11-19)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.10.0 ([2befd3c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2befd3c))

## [1.5.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.12...v1.5.13) (2019-11-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.9.2 ([c605a4b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c605a4b))

## [1.5.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.11...v1.5.12) (2019-11-17)


### Bug Fixes

* 🐛 scheam change ([2c1585e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2c1585e))
* 🐛 scheam change ([9148b80](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9148b80))
* 🐛 scheam change ([cf75b9a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cf75b9a))
* 🐛 scheam change ([7bf020e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7bf020e))

## [1.5.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.10...v1.5.11) (2019-11-15)


### Bug Fixes

* 🐛 add emqx Dockerfile with webhook registered ([f852111](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f852111))

## [1.5.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.9...v1.5.10) (2019-11-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.3 ([d2eeddb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d2eeddb))

## [1.5.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.8...v1.5.9) (2019-11-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.8.8 ([52b6ead](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/52b6ead))

## [1.5.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.7...v1.5.8) (2019-11-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.1.7 ([bfddd29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bfddd29))

## [1.5.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.6...v1.5.7) (2019-11-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.2 ([532a62b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/532a62b))

## [1.5.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.5...v1.5.6) (2019-11-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.11.2 ([42dc37b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/42dc37b))

## [1.5.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.4...v1.5.5) (2019-11-08)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.8.5 ([896c1f9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/896c1f9))

## [1.5.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.3...v1.5.4) (2019-11-08)


### Bug Fixes

* 🐛 update apikeytoken ([caee121](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/caee121))

## [1.5.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.2...v1.5.3) (2019-11-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.11.1 ([694dcae](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/694dcae))

## [1.5.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.1...v1.5.2) (2019-11-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.8.4 ([e008407](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e008407))

## [1.5.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.5.0...v1.5.1) (2019-11-07)


### Bug Fixes

* 🐛 add check cmd before starting ([54e9cd8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/54e9cd8))

# [1.5.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.4.5...v1.5.0) (2019-11-07)


### Features

* 🎸 add hive config for dev-env start shell ([df3071b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/df3071b))

## [1.4.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.4.4...v1.4.5) (2019-11-07)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.8.3 ([36d64ba](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/36d64ba))

## [1.4.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.4.3...v1.4.4) (2019-11-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.11.0 ([e9fc46a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e9fc46a))

## [1.4.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.4.2...v1.4.3) (2019-11-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.8.2 ([6ffb74a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6ffb74a))

## [1.4.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.4.1...v1.4.2) (2019-11-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.1 ([7ddb346](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7ddb346))

## [1.4.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.4.0...v1.4.1) (2019-11-06)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.10.2 ([5050c41](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5050c41))

# [1.4.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.38...v1.4.0) (2019-11-06)


### Features

* 🎸 start.sh -u to upgrade dev-env without data loss ([15d5a22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/15d5a22))

## [1.3.38](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.37...v1.3.38) (2019-11-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.9.6 ([336accd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/336accd))

## [1.3.37](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.36...v1.3.37) (2019-11-01)


### Bug Fixes

* 🐛 update data for adapting models' change ([f40a4c7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f40a4c7))

## [1.3.36](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.35...v1.3.36) (2019-11-01)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.20.0 ([25a4339](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/25a4339))

## [1.3.35](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.34...v1.3.35) (2019-10-31)


### Bug Fixes

* 🐛 simulator 0.0.3 and device type delete ([b221e06](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b221e06))
* 🐛 simulator 0.0.3, and delete device type ([fcc2269](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fcc2269))

## [1.3.34](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.33...v1.3.34) (2019-10-31)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.9.4 ([0e47c5b](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0e47c5b))

## [1.3.33](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.32...v1.3.33) (2019-10-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.19.5 ([4d91fa3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4d91fa3))

## [1.3.32](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.31...v1.3.32) (2019-10-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.9.3 ([8c0d731](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8c0d731))

## [1.3.31](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.30...v1.3.31) (2019-10-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.6 ([48b6df1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/48b6df1))

## [1.3.30](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.29...v1.3.30) (2019-10-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.9.2 ([22ed74c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/22ed74c))

## [1.3.29](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.28...v1.3.29) (2019-10-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.5 ([cac4f89](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cac4f89))

## [1.3.28](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.27...v1.3.28) (2019-10-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.19.4 ([b7c1da3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b7c1da3))

## [1.3.27](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.26...v1.3.27) (2019-10-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.1.3 ([9ac50c3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9ac50c3))

## [1.3.26](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.25...v1.3.26) (2019-10-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.9.1 ([79a3149](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/79a3149))

## [1.3.25](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.24...v1.3.25) (2019-10-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.19.2 ([0e317ed](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/0e317ed))

## [1.3.24](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.23...v1.3.24) (2019-10-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.9.0 ([4500ada](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4500ada))

## [1.3.23](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.22...v1.3.23) (2019-10-29)


### Bug Fixes

* 🐛 bump version of eca & hub ([dcc42d8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dcc42d8))

## [1.3.22](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.21...v1.3.22) (2019-10-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.8.0 ([cde3f64](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/cde3f64))

## [1.3.21](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.20...v1.3.21) (2019-10-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.7.3 ([bfffc18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/bfffc18))

## [1.3.20](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.19...v1.3.20) (2019-10-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.7.10 ([5864d8c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5864d8c))

## [1.3.19](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.18...v1.3.19) (2019-10-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.7.2 ([ee54032](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ee54032))

## [1.3.18](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.17...v1.3.18) (2019-10-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.7.1 ([e7ef4e8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e7ef4e8))
* 🐛 use eca-deployer service to deploy ([d6525cc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d6525cc))

## [1.3.17](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.16...v1.3.17) (2019-10-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.7.9 ([adf1707](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/adf1707))

## [1.3.16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.15...v1.3.16) (2019-10-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.7.0 ([dc46650](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dc46650))

## [1.3.15](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.14...v1.3.15) (2019-10-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.18.2 ([5e05809](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5e05809))

## [1.3.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.13...v1.3.14) (2019-10-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.18.1 ([a1ca48c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a1ca48c))

## [1.3.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.12...v1.3.13) (2019-10-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.6.5 ([6d50ba9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6d50ba9))

## [1.3.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.11...v1.3.12) (2019-10-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.18.0 ([e46f484](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e46f484))

## [1.3.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.10...v1.3.11) (2019-10-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.7.8 ([05838ce](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/05838ce))

## [1.3.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.9...v1.3.10) (2019-10-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.6.4 ([26485db](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/26485db))

## [1.3.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.8...v1.3.9) (2019-10-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.7.7 ([815e6a5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/815e6a5))

## [1.3.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.7...v1.3.8) (2019-10-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.17.0 ([803a15c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/803a15c))

## [1.3.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.6...v1.3.7) (2019-10-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.7.6 ([c72050e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c72050e))

## [1.3.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.5...v1.3.6) (2019-10-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.1.4 ([24c62ec](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/24c62ec))

## [1.3.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.4...v1.3.5) (2019-10-22)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.16.4 ([5b2c64a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5b2c64a))

## [1.3.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.3...v1.3.4) (2019-10-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.16.3 ([953c450](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/953c450))

## [1.3.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.2...v1.3.3) (2019-10-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.1.3 ([9d85b78](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9d85b78))
* **deps:** update dependency @rootcloud/rootcloud-hub to v0.7.4 ([02f4ce3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/02f4ce3))

## [1.3.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.1...v1.3.2) (2019-10-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.16.2 ([f8ca4ca](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f8ca4ca))

## [1.3.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.3.0...v1.3.1) (2019-10-18)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.16.1 ([855325c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/855325c))

# [1.3.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.7...v1.3.0) (2019-10-17)


### Features

* 🎸 tag image release version ([04753ac](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/04753ac))

## [1.2.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.6...v1.2.7) (2019-10-17)


### Bug Fixes

* 🐛 register emqx webhook after emqx-rest ready ([ecddd86](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ecddd86))

## [1.2.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.5...v1.2.6) (2019-10-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.16.0 ([1a2484f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1a2484f))

## [1.2.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.4...v1.2.5) (2019-10-17)


### Bug Fixes

* 🐛 pull image background in start.sh ([e88d0ed](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e88d0ed))

## [1.2.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.3...v1.2.4) (2019-10-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.6.2 ([07b2fb5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/07b2fb5))

## [1.2.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.2...v1.2.3) (2019-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-emqx-auth-acl to v0.1.0 ([db794f7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/db794f7))
* 🐛 update emqx-auth-acl environment ([95d350d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/95d350d))

## [1.2.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.1...v1.2.2) (2019-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.15.0 ([ad3e67c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ad3e67c))

## [1.2.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.2.0...v1.2.1) (2019-10-15)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.6.1 ([c59a1da](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c59a1da))

# [1.2.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.1.5...v1.2.0) (2019-10-14)


### Features

* 🎸 add @rootcloud/rootcloud-emqx-auth-acl as deps ([95985a7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/95985a7))

## [1.1.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.1.4...v1.1.5) (2019-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.11.1 ([e1fe2ac](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e1fe2ac))

## [1.1.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.1.3...v1.1.4) (2019-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.6.1 ([6e34e60](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6e34e60))

## [1.1.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.1.2...v1.1.3) (2019-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.5.2 ([2f54b93](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2f54b93))

## [1.1.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.1.1...v1.1.2) (2019-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.11.0 ([1f1a8f0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/1f1a8f0))

## [1.1.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.1.0...v1.1.1) (2019-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.6.0 ([5d17b52](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5d17b52))

# [1.1.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.0.5...v1.1.0) (2019-10-12)


### Bug Fixes

* 🐛 upgrade emqx 3.4.0->3.4.1 ([df575c6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/df575c6))


### Features

* 🎸 register emq webhook and rules ([fe7e63c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/fe7e63c))

## [1.0.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.0.4...v1.0.5) (2019-10-12)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.5.1 ([ccc81cb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ccc81cb))

## [1.0.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.0.3...v1.0.4) (2019-10-11)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.5.0 ([d4062bb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d4062bb))

## [1.0.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.0.2...v1.0.3) (2019-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.10.0 ([8ec8285](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8ec8285))

## [1.0.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.0.1...v1.0.2) (2019-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.3.1 ([f0a3aa3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/f0a3aa3))

## [1.0.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v1.0.0...v1.0.1) (2019-10-10)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.5.0 ([5818f65](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5818f65))

# [1.0.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.11...v1.0.0) (2019-10-09)


### chore

* 🤖 Updated EMQX license key ([84b1bf4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/84b1bf4))


### BREAKING CHANGES

* No

Closes: No.

## [0.7.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.10...v0.7.11) (2019-10-09)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.3.0 ([78a1689](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/78a1689))

## [0.7.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.9...v0.7.10) (2019-09-30)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.4.0 ([88d5a16](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/88d5a16))

## [0.7.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.8...v0.7.9) (2019-09-29)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.8.1 ([2e7088a](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2e7088a))

## [0.7.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.7...v0.7.8) (2019-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.3.1 ([6f6b9df](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/6f6b9df))

## [0.7.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.6...v0.7.7) (2019-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.2.1 ([5efd702](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/5efd702))

## [0.7.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.5...v0.7.6) (2019-09-27)


### Bug Fixes

* 🐛 enable debug eca ([be92fc2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/be92fc2))

## [0.7.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.4...v0.7.5) (2019-09-27)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.8.0 ([2fd2999](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2fd2999))

## [0.7.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.3...v0.7.4) (2019-09-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.3.0 ([c5053a5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/c5053a5))

## [0.7.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.2...v0.7.3) (2019-09-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.7.1 ([e9e78cc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e9e78cc))

## [0.7.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.1...v0.7.2) (2019-09-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.1.5 ([a2db6e3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/a2db6e3))

## [0.7.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.7.0...v0.7.1) (2019-09-26)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.7.0 ([d6b1cdd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d6b1cdd))

# [0.7.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.14...v0.7.0) (2019-09-26)


### Features

* 🎸 start.sh -u to update env without destroying ([497d72d](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/497d72d))

## [0.6.14](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.13...v0.6.14) (2019-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.2.11 ([76b4bd3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/76b4bd3))

## [0.6.13](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.12...v0.6.13) (2019-09-25)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.1.4 ([e15238f](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e15238f))
* 🐛 add logback.xml for task manager ([e1d25a6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e1d25a6))

## [0.6.12](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.11...v0.6.12) (2019-09-24)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.1.3 ([15be0cb](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/15be0cb))

## [0.6.11](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.10...v0.6.11) (2019-09-23)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.2.9 ([4189ffc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4189ffc))

## [0.6.10](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.9...v0.6.10) (2019-09-21)


### Bug Fixes

* 🐛 fast-data-dev -> docker-kafka ([291b4ef](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/291b4ef))

## [0.6.9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.8...v0.6.9) (2019-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.5.6 ([382d7dd](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/382d7dd))

## [0.6.8](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.7...v0.6.8) (2019-09-21)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.1.2 ([b685495](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/b685495))

## [0.6.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.6...v0.6.7) (2019-09-20)


### Bug Fixes

* 🐛 remove influx address 'http://' ([9375f56](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/9375f56))

## [0.6.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.5...v0.6.6) (2019-09-20)


### Bug Fixes

* 🐛 env overwirtten ([e804762](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/e804762))

## [0.6.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.4...v0.6.5) (2019-09-20)


### Bug Fixes

* 🐛 jq -> node ([dc78aff](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/dc78aff))

## [0.6.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.3...v0.6.4) (2019-09-20)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1.1.0 ([eb8ace4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/eb8ace4))

## [0.6.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.2...v0.6.3) (2019-09-19)


### Bug Fixes

* 🐛 env variables for startup ([2237ee1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/2237ee1))

## [0.6.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.1...v0.6.2) (2019-09-18)


### Bug Fixes

* 🐛 skip kafka topic creatation on exists ([64fc109](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/64fc109))

## [0.6.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.6.0...v0.6.1) (2019-09-18)


### Bug Fixes

* 🐛 missing parsing argument ([02ea4c7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/02ea4c7))

# [0.6.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.5.1...v0.6.0) (2019-09-17)


### Features

* 🎸 integrate with device simulator ([8a1a6e1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8a1a6e1))

## [0.5.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.5.0...v0.5.1) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v1 ([8b79441](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/8b79441))

# [0.5.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.7...v0.5.0) (2019-09-17)


### Features

* 🎸 add grafana as influx visualization in docker-compose ([7bd7855](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/7bd7855))

## [0.4.7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.6...v0.4.7) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.2.6 ([d00255c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/d00255c))

## [0.4.6](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.5...v0.4.6) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-historian to v0.4.7 ([ff55a81](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ff55a81))

## [0.4.5](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.4...v0.4.5) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-hub to v0.2.5 ([4cda1c7](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4cda1c7))

## [0.4.4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.3...v0.4.4) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-influx-cluster to v1.0.4 ([206dfe4](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/206dfe4))

## [0.4.3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.2...v0.4.3) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v0.2.6 ([4456ce9](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/4456ce9))

## [0.4.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.1...v0.4.2) (2019-09-17)


### Bug Fixes

* 🐛 missing npm plugin for semantic release ([22cc60e](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/22cc60e))

## [0.4.1](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.4.0...v0.4.1) (2019-09-17)


### Bug Fixes

* **deps:** update dependency @rootcloud/rootcloud-eca to v0.2.4 ([ae062dc](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/ae062dc))

# [0.4.0](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.3.2...v0.4.0) (2019-09-17)


### Features

* 🎸 add influx proxy into docker-compose ([3e51cf3](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/3e51cf3))

## [0.3.2](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/compare/v0.3.1...v0.3.2) (2019-09-17)


### Bug Fixes

* 🐛 enable gitlab plugin for semantic versioning ([930eb0c](http://gitlab.irootech.com/rootcloud-data-platform/rootcloud-dev-env/commit/930eb0c))
