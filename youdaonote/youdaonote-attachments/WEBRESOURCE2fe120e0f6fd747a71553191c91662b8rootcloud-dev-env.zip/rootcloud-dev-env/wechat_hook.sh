#!/bin/sh

set -ex

STATUS='构建成功✅'
if [ -n "${1}" ]; then
  STATUS='构建失败❌'
fi

curl "${WECHAT_ROBOT_WEBHOOK}" \
  -H 'Content-Type: application/json' \
  -d "{ \
    \"msgtype\": \"markdown\", \
    \"markdown\": { \
      \"content\": \"### [${CI_PROJECT_NAME}](${CI_PROJECT_URL}) ${STATUS}\n\n\
> 提交者：${GITLAB_USER_NAME}\n\
> 查看Pipeline：[${CI_COMMIT_TITLE}](${CI_PIPELINE_URL})\"\
    }}"
