#!/bin/bash

CWD=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${CWD}"/env.sh

if [[ "${ALAUDA_TOKEN}" == "" ]]; then
  echo "ALAUDA_TOKEN not specified"
  exit 1
fi

VERSION_MAP=(
  "eca-deployer"
  "eca-deployer"
  "${ECA_VERSION}"
  "historian"
  "historian"
  "${HISTORIAN_VERSION}"
  "hub"
  "hub"
  "${HUB_VERSION}"
  "emqx-auth-acl"
  "emqx-auth-acl"
  "${EMQX_AUTH_ACL_VERSION}"
  "emqx-kafka-bridge"
  "emq-kafka-connector"
  "${EMQX_KAFKA_BRIDGE_VERSION}"
  "influxproxy"
  "influxproxy"
  "${INFLUXDB_PROXY_VERSION}"
  "platform-metrics"
  "platform-metrics"
  "${PLATFORM_METRICS_VERSION}"
  "instructionproxy"
  "instructionproxy"
  "${INSTRUCTION_PROXY_VERSION}"
  "analysis-api"
  "analysis-api"
  "${IOTWORKS_API_VERSION}"
)

ALAUDA_API_BASE="https://acpqav4.rootcloudapp.com/kubernetes/rootcloudv4-dev/apis/apps/v1/namespaces/rootcloudv4-dev-iotbase/deployments"

# use for loop read all nameservers
for (( i=0; i< ${#VERSION_MAP[@]}; i+=3 )); do
  projectName=${VERSION_MAP[$i]}
  serviceName=${VERSION_MAP[$i+1]}
  version=${VERSION_MAP[$i+2]}
  preImage=${DOCKER_REGISTRY}/rootcloud/${projectName}:pre-${version}
  releaseImage=${DOCKER_REGISTRY}/rootcloud/${projectName}:${RELEASE_VERSION}

  echo "tag image ${preImage} into ${releaseImage}"
  docker tag "${preImage}" "${releaseImage}"

  echo "pushing image ${releaseImage}"
  docker push "${releaseImage}"

  echo "deploying ${releaseImage}"
  code=$(curl -s -X PUT -H "Authorization: Bearer ${ALAUDA_TOKEN}" -H "Content-Type: application/json" \
    -o /dev/null -s -w "%{http_code}\n" --connect-timeout 1 "${ALAUDA_API_BASE}/${serviceName}" -d \
    "$(curl -s -H "Authorization: Bearer ${ALAUDA_TOKEN}" "${ALAUDA_API_BASE}/${serviceName}" \
    | sed s@"\"image\": .*"@"\"image\": \"${releaseImage}\","@)")
  if [[  $code == '200' ]]; then
    echo "${projectName} is deployed successfully"
  else
    echo "failed to deploy ${projectName} (status = ${code})"
    exit 1
  fi
done
