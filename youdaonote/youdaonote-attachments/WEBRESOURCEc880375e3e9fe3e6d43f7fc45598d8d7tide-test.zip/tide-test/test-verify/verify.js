'use strict';

const _ = require('lodash');
const {getData} = require('@rootcloud/darjeeling/dist/src/data-store');
const {Assert} = require('@rootcloud/darjeeling');

/*
* justPayload默认true,默认校验payload层的schema
* false表示校验body最外层
* */
function verifySchema(responseGetter, schema, justPayload = true) {

    it(`verify schema`, async () => {
        const response = getData(responseGetter);

        let body;
        if (justPayload) {
            body = JSON.parse(response.body).payload;
        } else {
            body = JSON.parse(response.body);
        }
        try {
            await schema.validateAsync(body);
        } catch (exc) {
            Assert.fail(`Verify schema with error message: ${exc.message}`);
        }
    });
}

/*
* 功能:json value的校验
* jsonPath：string 传入获取具体json路径的数据
* exceptedBody为相应路径对应的预期json数据
* jsonPath：不传默认校验payload整层的数据
* */

function verifyPayload(responseGetter, exceptedBody, jsonPath) {

    it(`verify ${jsonPath} contains ${JSON.stringify(exceptedBody)}`, async () => {
        const response = getData(responseGetter);
        let body;
        if (jsonPath) {
            if ('body' == jsonPath) {
                body = JSON.parse(response.body);
            } else {
                body = _.get(JSON.parse(response.body), jsonPath);
            }
        } else {
            body = JSON.parse(response.body).payload;
        }
        Assert.isTrue(_.isMatch(body, exceptedBody), `match pass`);
    });
}


function verifyPayloadDeepEqual(responseGetter, postBody) {

    it(`verify payload deep equal`, async () => {
        const response = getData(responseGetter);
        const body = JSON.parse(response.body);
        Assert.deepEqual(body, postBody, `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body)}`);
    });
}

function verifyResponse(responseGetter, expectResponseGetter) {

    it(`verify two response getter`, async () => {
        const response = getData(responseGetter);
        const body = JSON.parse(response.body);
        const expectResponse = getData(expectResponseGetter);
        const expectBody = JSON.parse(expectResponse.body);
        Assert.deepEqual(body, expectBody, `\nExpect body: \n  ${JSON.stringify(expectBody)}\nActual body: \n  ${JSON.stringify(body)}`);
    });
}

function verifyHistoryResult(responseGetter, expectResult) {

    it(`verify historian result`, () => {
        const response = getData(responseGetter);
        const body = JSON.parse(response.body);
        let rows = body['payload'][0]['rows'];
        for (let i = 0; i < rows.length; i++) {
            for (let j = 0; j < rows[i].length - 1; j++) {
                if (rows[i][j + 1] !== expectResult[i][j]) {
                    Assert.fail(`\n  Expect value: ${expectResult}\n  Actual value: ${rows}`);
                }
            }
        }
    });
}

function verifyMultiSchema(responseGetter, schema) {

    it(`verifyMultiSchema`, async () => {
        const response = getData(responseGetter);
        const body = JSON.parse(response.body);

        for (let i = 0; i < body.payload.length; i++) {
            try {
                await schema.validateAsync(body.payload.length && body.payload[i]);
            } catch (exc) {
                Assert.fail(`Verify multi schema with error message: ${exc.message}`);
            }
        }
    });
}

function verifyMultiPayload(responseGetter, postBody) {

    it(`verifyMultiPayload`, async () => {
        const response = getData(responseGetter);
        const body = JSON.parse(response.body);
        const num = body.payload.length;
        if (num == 0) {
            Assert.isTrue(_.isMatch(body.payload, postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload)}`);
        }
        Assert.isTrue(_.isMatch(body.payload.length && body.payload[num - 1], postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload.length && body.payload[num - 1])}`);
    });
}

// #########################################################################
// 去除方法中的it
/*
* justPayload默认true,默认校验payload层的schema
* false表示校验body最外层
* */
async function verifySchemaAsync(response, schema, justPayload = true) {
    let body;
    if (justPayload) {
        body = JSON.parse(response.body).payload;
    } else {
        body = JSON.parse(response.body);
    }
    try {
        await schema.validateAsync(body);
    } catch (exc) {
        Assert.fail(`Verify schema with error message: ${exc.message}`);
    }
}

/*
* 功能:json value的校验
* jsonPath：string 传入获取具体json路径的数据
* exceptedBody为相应路径对应的预期json数据
* jsonPath：不传默认校验payload整层的数据
* */

function verifyPayloadSync(response, exceptedBody, jsonPath) {
    let body;
    if (jsonPath) {
        if ('body' === jsonPath) {
            body = JSON.parse(response.body);
        } else {
            body = _.get(JSON.parse(response.body), jsonPath);
        }
    } else {
        body = JSON.parse(response.body).payload;
    }
    Assert.isTrue(_.isMatch(body, exceptedBody), `match pass`);
}


function verifyPayloadDeepEqualSync(response, postBody) {
    const body = JSON.parse(response.body);
    Assert.deepEqual(body, postBody, `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body)}`);
}

function verifyResponseSync(response, expectResponseGetter) {
    const body = JSON.parse(response.body);
    const expectResponse = getData(expectResponseGetter);
    const expectBody = JSON.parse(expectResponse.body);
    Assert.deepEqual(body, expectBody, `\nExpect body: \n  ${JSON.stringify(expectBody)}\nActual body: \n  ${JSON.stringify(body)}`);
}

function verifyHistoryResultSync(response, expectResult) {
    const body = JSON.parse(response.body);
    let rows = body['payload'][0]['rows'];
    for (let i = 0; i < rows.length; i++) {
        for (let j = 0; j < rows[i].length - 1; j++) {
            if (rows[i][j + 1] !== expectResult[i][j]) {
                Assert.fail(`\n  Expect value: ${expectResult}\n  Actual value: ${rows}`);
            }
        }
    }
}

async function verifyMultiSchemaAsync(response, schema) {
    const body = JSON.parse(response.body);
    for (let i = 0; i < body.payload.length; i++) {
        try {
            await schema.validateAsync(body.payload.length && body.payload[i]);
        } catch (exc) {
            Assert.fail(`Verify multi schema with error message: ${exc.message}`);
        }
    }
}

function verifyMultiPayloadSync(response, postBody) {
    const body = JSON.parse(response.body);
    const num = body.payload.length;
    if (num === 0) {
        Assert.isTrue(_.isMatch(body.payload, postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload)}`);
    }
    Assert.isTrue(_.isMatch(body.payload.length && body.payload[num - 1], postBody), `\nExpect body: \n  ${JSON.stringify(postBody)}\nActual body: \n  ${JSON.stringify(body.payload.length && body.payload[num - 1])}`);
}

async function verifyObjectSchemaAsync(actualObj, schema) {
    if (actualObj.statusCode) {
        delete actualObj.statusCode;
    }
    try {
        await schema.validateAsync(actualObj);
    } catch (exc) {
        Assert.fail(`Verify Object schema with error message: ${exc.message}`);
    }
}


function verifyObjectPayloadSync(actualObj, exceptedBody) {
    Assert.isTrue(_.isMatch(actualObj, exceptedBody), `match pass`);
}

module.exports = {
    verifySchema,
    verifyPayload,
    verifyPayloadDeepEqual,
    verifyResponse,
    verifyHistoryResult,
    verifyMultiSchema,
    verifyMultiPayload,
    verifyObjectSchemaAsync,
    verifySchemaAsync,
    verifyPayloadSync,
    verifyPayloadDeepEqualSync,
    verifyResponseSync,
    verifyHistoryResultSync,
    verifyMultiSchemaAsync,
    verifyMultiPayloadSync,
    verifyObjectPayloadSync
};
