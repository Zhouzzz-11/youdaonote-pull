This module is unlicensed.

Copyright (c) 2020 RootCloud
