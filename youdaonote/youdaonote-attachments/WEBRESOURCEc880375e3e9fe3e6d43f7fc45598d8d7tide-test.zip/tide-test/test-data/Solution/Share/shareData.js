'use strict';


function ShareObj(
    {
        evidenceId = '',
        includeOriginal = false,
        includeHistory = false,
        expiresAfter = 86400
    } = {}) {
    this.evidenceId = evidenceId;
    this.includeOriginal = includeOriginal;
    this.includeHistory = includeHistory;
    this.expiresAfter = expiresAfter;
}

module.exports = {
    ShareObj
};