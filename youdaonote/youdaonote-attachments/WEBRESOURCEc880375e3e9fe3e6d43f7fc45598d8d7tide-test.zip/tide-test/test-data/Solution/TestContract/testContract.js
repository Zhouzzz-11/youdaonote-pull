'use strict';

function TestContractObj(
    {
        accountId = 'account_id',
        issueBank = 'BANK_OF_CHINA',
        balance = '0.00',
        owner = 'resource:cn.gezhitech.tidemsc.model.User#Steve'
    } = {}) {
    this.accountId = accountId;
    this.issueBank = issueBank;
    this.balance = balance;
    this.owner = owner;
}


module.exports = {
    TestContractObj
};

