'use strict';

const {dataBody} = require('../../../test-lib/mockdata');

const {randomString} = require('../../../test-utils/utils_comFunc');

/*
     TextEvidence
*/
function EvidenceObj(
    {
        title = 'test_title_text',
        referenceId='test_referenceId',
        content = 'test content',
        labels = ['test_label'],
        isPublic = true,
        useTrustedTimestamp = false,
        metadata = {'key': 'value'},
        signature = 'example signature',
        comments = '示例备注'
    } = {}) {
    this.title = title;
    this.referenceId = referenceId;
    this.content = content;
    this.labels = labels;
    this.isPublic = isPublic;
    this.useTrustedTimestamp = useTrustedTimestamp;
    this.metadata = metadata;
    this.signature = signature;
    this.comments = comments;
}

//update data
const updateTextEvidenceData_1 = dataBody.updateTextEvidenceBody('label1');
const updateTextEvidenceData_2 = dataBody.updateTextEvidenceBody('label2');
const updateTextEvidenceData_3 = dataBody.updateTextEvidenceBody(' ');

/*
     FileEvidence
*/
function FileEvidenceObj(
    {
        referenceId = 'custom_id',
        title = 'test_title_file',
        fileName = 'evidence.pdf',
        fileSize = 1024,
        useTrustedTimestamp = false,
        fileHash = '3bc1fcaef5ec64c2da7cd882d19a28c6',
        persist = false,
        labels = ['label'],
        isPublic = true,
        metadata = {'key': 'value'},
        signature = 'example signature',
        comments = '示例备注'
    } = {}) {
    this.referenceId = referenceId;
    this.title = title;
    this.fileName = fileName;
    this.fileSize = fileSize;
    this.useTrustedTimestamp = useTrustedTimestamp;
    this.fileHash = fileHash;
    this.persist = persist;
    this.labels = labels;
    this.isPublic = isPublic;
    this.metadata = metadata;
    this.signature = signature;
    this.comments = comments;
}

//update data
const updateFileEvidenceData_1 = dataBody.updateFileEvidenceBody('label1');
const updateFileEvidenceData_2 = dataBody.updateFileEvidenceBody('label2');
const updateFileEvidenceData_3 = dataBody.updateFileEvidenceBody(' ');


/*
     AuditDataEvidence
*/
function AuditDataEvidenceObj(
    {
        title = 'test_title_audit',
        referenceId='test_referenceId',
        labels = ['test_label'],
        comments = '示例备注',
        isPublic = false,
        useTrustedTimestamp = false,
        metadata = {'key': 'value'},
        signature = 'example signature',
        evidenceId = randomString({length: 32}),
        logId = randomString({length: 32}),
        source = {
            'service': 'CDPOS(SAP)',
            'component': 'ods_sap_cdpos_di'
        },
        info = {
            "operateObject": "ods_sap_cdpos_di",
            "operateTime": "2020-09-16T07:26:04.032Z",
            "operator": "zhangsan@sany.com.cn",
            "ipAddress": "192.168.1.100"
        },
        data = {
            'test_case' : 'audit-data'
        }
    } = {}) {
    this.title = title;
    this.referenceId = referenceId;
    this.labels = labels;
    this.comments = comments;
    this.metadata = metadata;
    this.signature = signature;
    this.isPublic = isPublic;
    this.useTrustedTimestamp = useTrustedTimestamp;
    this.evidenceId = evidenceId;
    this.source = source;
    this.info = info;
    this.data = data;
    this.logId = logId;
}


module.exports = {
    EvidenceObj,
    FileEvidenceObj,
    AuditDataEvidenceObj,
    updateTextEvidenceData_1,
    updateTextEvidenceData_2,
    updateTextEvidenceData_3,
    updateFileEvidenceData_1,
    updateFileEvidenceData_2,
    updateFileEvidenceData_3,
};

