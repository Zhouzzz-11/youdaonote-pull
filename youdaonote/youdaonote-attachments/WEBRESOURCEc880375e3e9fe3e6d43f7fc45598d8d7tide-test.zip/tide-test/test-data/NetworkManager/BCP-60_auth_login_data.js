'use strict';

const {dataBody, BaasOrg, SuperUser, NormalUser} = require('../../test-lib/mockdata');
const env = process.env.CURRENT_ENV;
var topadmin, baasOrg1, baasOrg2,nonActivateUser;
//IAM登录


if (env === 'dev') {
    topadmin = {reqBody: dataBody.loginIAMBody('rootcloudAdmin', '123qweasd'), token: '', networkId: '', companyId: ''};  //超管用户
    baasOrg1 = {reqBody: dataBody.loginIAMBody('', ''), token: '', networkId: '', companyId: ''};  //普通用户
    baasOrg2 = {reqBody: dataBody.loginIAMBody('', ''), token: '', networkId: '', companyId: ''};  //普通用户
} else if (env === 'pre') {
    topadmin = {
        iAMBody: dataBody.loginIAMBody('rc_admin', '123qweasd')
    };  //超管用户
    let superIamLoginBody1 = dataBody.loginIAMBody('rc_1622686250557', 'test_123');
    let superUser1 = new SuperUser({
        iamLoginBody: superIamLoginBody1,
        consortiaInfo: [{id: '60d3e4c17425737917a0d055', apps: ['Evidence-p54c705774']}]
    });
    let org1User1IamLoginBody = dataBody.loginIAMBody('nomal_user1', 'test_123');
    let org1User1 = new NormalUser({iamLoginBody: org1User1IamLoginBody, userId: '60b83e35827858005010e032'});
    baasOrg1 = new BaasOrg({superUser: superUser1, user1: org1User1});// 企业1信息
} else if (env === 'prod') {
    topadmin = {
        iAMBody: dataBody.loginIAMBody('', '')
    };  //超管用户
    let superIamLoginBody1 = dataBody.loginIAMBody('', '');
    let superUser1 = new SuperUser({
        iamLoginBody: superIamLoginBody1,
        consortiaInfo: [{id: '60d3dbefba1fb9735c14e710', apps: ['Evidence-yb90663c38']}]
    });
    let org1User1IamLoginBody = dataBody.loginIAMBody('rc_user_1623159576', '123321');
    let org1User1 = new NormalUser({iamLoginBody: org1User1IamLoginBody, userId: '60bf731848ffe100576fe096'});
    baasOrg1 = new BaasOrg({superUser: superUser1, user1: org1User1});// 企业1信息

} else if (env === 'local') {
    //超管用户
    topadmin = {
        iAMBody: dataBody.loginIAMBody('rc_admin', 'admin')
    };

    baasOrg1 = {
        superUser: {
            iamLoginBody: {
                username: '',
                password: '',
                client_id: 'web_app',
                client_secret: 'changeit',
                grant_type: 'password'
            },
            orgId: '',
            email: '',
            cellphone: '',
            superToken: '',
            consortiaInfo: []
        },
        normalUsers: {
            user1: {
                iamLoginBody: {
                    username: '',
                    password: '',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '',
                userToken: ''
            },
            user2: {
                iamLoginBody: {
                    username: '',
                    password: '123321',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '',
                userToken: ''
            }
        }
    };

    baasOrg2 = {
        superUser: {
            iamLoginBody: {
                username: '',
                password: '',
                client_id: '',
                client_secret: '',
                grant_type: ''
            },
            orgId: '',
            email: '',
            cellphone: '',
            superToken: '',
            consortiaInfo: []
        },
        normalUsers: {
            user1: {
                iamLoginBody: {
                    username: '',
                    password: '',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '',
                userToken: ''
            },
            user2: {
                iamLoginBody: {
                    username: '',
                    password: '',
                    client_id: '',
                    client_secret: '',
                    grant_type: ''
                },
                userId: '',
                userToken: ''
            }
        }
    };
    nonActivateUser = dataBody.loginIAMBody('superAdmin_1623836344', '123321');
} else if (env === 'qa') {
    //超管用户
    topadmin = {
        iAMBody: dataBody.loginIAMBody('rc_admin', 'admin')
    };

    baasOrg1 = {
        superUser: {
            iamLoginBody: {
                username: 'superAdmin_38140798',
                password: '123321',
                client_id: 'web_app',
                client_secret: 'changeit',
                grant_type: 'password'
            },
            orgId: '60c847550eb30c0054e158ab',
            email: '82356679438@rootcloud.com',
            cellphone: '13121071595',
            superToken: '',
            consortiaInfo: [{id: '60cc6537f8a2921dd4534f81', networkCode: 't765d767',apps:['Evidence-ud7cf0485c']}]
        },
        normalUsers: {
            user1: {
                iamLoginBody: {
                    username: 'TideUser_17361078',
                    password: '123321',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '60c847573bbac4004b5a4665',
                userToken: ''
            },
            user2: {
                iamLoginBody: {
                    username: 'TideUser_92196606',
                    password: '123321',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '60c847590eb30c0054e158b3',
                userToken: ''
            }
        }
    };

    baasOrg2 = {
        superUser: {
            iamLoginBody: {
                username: 'superAdmin_76835137',
                password: '123321',
                client_id: 'web_app',
                client_secret: 'changeit',
                grant_type: 'password'
            },
            orgId: '60c8475a46b1ed004b0e40c4',
            email: '28918532346@rootcloud.com',
            cellphone: '13199658577',
            superToken: '',
            consortiaInfo: []
        },
        normalUsers: {
            user1: {
                iamLoginBody: {
                    username: 'TideUser_66139437',
                    password: '123321',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '60c8475c46b1ed004b0e40cc',
                userToken: ''
            },
            user2: {
                iamLoginBody: {
                    username: 'TideUser_66139437',
                    password: '123321',
                    client_id: 'web_app',
                    client_secret: 'changeit',
                    grant_type: 'password'
                },
                userId: '60c8475d3bbac4004b5a4666',
                userToken: ''
            }
        }
    };
    nonActivateUser = dataBody.loginIAMBody('superAdmin_1623836344', '123321');
} else if (env === 'nightly') {
    topadmin = {
        iAMBody: dataBody.loginIAMBody('', '')
    };  //超管用户
    let superIamLoginBody1 = dataBody.loginIAMBody('', '');
    let superUser1 = new SuperUser({
        iamLoginBody: superIamLoginBody1,
        consortiaInfo: [{id: '60bf6a81577fd00b704e446f', apps: ['Evidence-nd822df89b']}]
    });
    let org1User1IamLoginBody = dataBody.loginIAMBody('rc_1601210696310', 'Sghl%2020');
    let org1User1 = new NormalUser({iamLoginBody: org1User1IamLoginBody, userId: '5f708948e931c8004bf9bbb6'});
    baasOrg1 = new BaasOrg({superUser: superUser1, user1: org1User1});// 企业1信息
} else if (env === 'sanyLogsVM') {
    topadmin = {reqBody: dataBody.loginBody('superAdmin', 'Abcd1234'), token: '', networkId: '', companyId: ''};  //超管用户
    baasOrg1 = {reqBody: dataBody.loginBody('', ''), token: '', networkId: '', companyId: ''};  //普通用户
    baasOrg2 = {reqBody: dataBody.loginBody('', ''), token: '', networkId: '', companyId: ''};  //普通用户
} else {
    topadmin = {
        iAMBody: dataBody.loginIAMBody('', '')
    };  //超管用户
    let superIamLoginBody1 = dataBody.loginIAMBody('', '');
    let superUser1 = new SuperUser({
        iamLoginBody: superIamLoginBody1,
        consortiaInfo: [{id: '60bf6a81577fd00b704e446f', apps: ['Evidence-nd822df89b']}]
    });
    let org1User1IamLoginBody = dataBody.loginIAMBody('rc_1601210696310', 'Sghl%2020');
    let org1User1 = new NormalUser({iamLoginBody: org1User1IamLoginBody, userId: '5f708948e931c8004bf9bbb6'});
    baasOrg1 = new BaasOrg({superUser: superUser1, user1: org1User1});// 企业1信息
}


module.exports = {
    topadmin,
    baasOrg1,
    baasOrg2,
    nonActivateUser
};
