'use strict';

const { dataBody } = require('../../test-lib/mockdata');

//invoke
const invokeData_error = dataBody.postInvokeBody('getAllResources', 'cn.gezhitech.digitalevidence.asset.TextEvidence');

module.exports = {
    invokeData_error,
};
