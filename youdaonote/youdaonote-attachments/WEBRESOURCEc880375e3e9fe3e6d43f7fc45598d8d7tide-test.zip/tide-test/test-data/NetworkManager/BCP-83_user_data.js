'use strict';

const {dataBody} = require('../../test-lib/mockdata');
const pre = new Date().getTime().toString();
//创建user reqBody
const userReqBody = dataBody.getDefaultUserBody();

const existIdReqBody = dataBody.createUserBody({'userid': `${pre}_exsitid123`});

const SpecialCharactersReqBody = dataBody.createUserBody(
    {
        'userId': '汉字gbytest_userId001.*/"\\:";,!@#$%^&*()' + pre,
        'userName': '汉字gbytest_userId001.*/"\\:";,!@#$%^&*()' + pre,
        'password': '123456.*/"\\:";,!@#$%^&*()',
        'mobile': '13700000000',
        'userRole': [
            'tester'
        ]
    }
);

const invialdPhoneReqBody_toolong = dataBody.createUserBody({'mobile': `137123456789`});

const useridEmptyReqBody = dataBody.createUserBody({'userId': ''});
const mutilRolesReqBody = dataBody.createUserBody({
    'userId': `${pre}_userRoleisString`,
    'userRole': ['user', 'admin']
});

const stringRolesReqBody = dataBody.createUserBody({'userRole': 'user'});


let allUpdateBody = dataBody.createUserBody(
    {
        'userName': 'updateUserName' + pre,
        'password': '12345.@*()' + pre,
        'mobile': '137' + pre.substring(pre.length - 8),
        'userRole': [
            'updateUserRole1' + pre, 'updateUserRole2' + pre
        ]
    }
);

let selfUpdateBody = dataBody.createUserBody(
    {
        'userName': 'updateUserName' + pre,
        'password': '12345.@*()' + pre,
        'mobile': '137' + pre.substring(pre.length - 8)
    }
);

const createReqBodyForDelete = dataBody.createUserBody();

module.exports = {
    userReqBody, existIdReqBody, SpecialCharactersReqBody,
    invialdPhoneReqBody_toolong, useridEmptyReqBody, mutilRolesReqBody,
    stringRolesReqBody, allUpdateBody, selfUpdateBody,
    createReqBodyForDelete,
};
