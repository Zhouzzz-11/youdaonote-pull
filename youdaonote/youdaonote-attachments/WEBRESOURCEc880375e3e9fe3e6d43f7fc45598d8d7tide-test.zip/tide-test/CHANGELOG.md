## [0.20.8](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.7...v0.20.8) (2021-06-24)


### Bug Fixes

* resolve pre and prod env ([1d80df3](http://gitlab.irootech.com/tide/tide-test/commit/1d80df3e755161c7f0d4571c9b367f3aa3ea5118))

## [0.20.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.6...v0.20.7) (2021-06-24)


### Bug Fixes

* adapter evidence search ([dfd056f](http://gitlab.irootech.com/tide/tide-test/commit/dfd056f466a321721597fac7f8dee5a07f3862cc))
* adapter query async evidence ([e349eb1](http://gitlab.irootech.com/tide/tide-test/commit/e349eb1e8cf37272c5ce7f4d1169065148eff18c))
* add query consortia network status ([e1e72c6](http://gitlab.irootech.com/tide/tide-test/commit/e1e72c60c8e8230bef70966a19cd649762b4e2de))
* add validate schema ([dc1656f](http://gitlab.irootech.com/tide/tide-test/commit/dc1656f761f2f6145eafe97dcf1fccc5a27be66d))

## [0.20.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.5...v0.20.6) (2021-06-12)


### Bug Fixes

* resove share text and share file recodrd failed ([dc34795](http://gitlab.irootech.com/tide/tide-test/commit/dc347955c228a8ecd459a871c7b4a189a2fad81e))
* stop smoke test emporary ([a41b750](http://gitlab.irootech.com/tide/tide-test/commit/a41b750c6f757a370468a773e5ca054d27efa984))

## [0.20.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.4...v0.20.5) (2021-06-09)


### Bug Fixes

* change org datatype ([d8f27fc](http://gitlab.irootech.com/tide/tide-test/commit/d8f27fc9dffafa762772580241dd1b6082b0f319))

## [0.20.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.3...v0.20.4) (2021-06-08)


### Bug Fixes

* adapter prod baas ([a0393d8](http://gitlab.irootech.com/tide/tide-test/commit/a0393d8242cc2af9b698945aae2ca95f8ba47270))

## [0.20.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.2...v0.20.3) (2021-06-08)


### Bug Fixes

* adapter prod test ([066f2be](http://gitlab.irootech.com/tide/tide-test/commit/066f2becb6e8bb7c1ff604873fb4b7fe54cfa414))

## [0.20.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.1...v0.20.2) (2021-06-08)


### Bug Fixes

* change version ([e45d318](http://gitlab.irootech.com/tide/tide-test/commit/e45d3184f8673d4389480739232af01febc76244))

## [0.20.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.20.0...v0.20.1) (2021-06-08)


### Bug Fixes

* change version ([05bb45d](http://gitlab.irootech.com/tide/tide-test/commit/05bb45d0448399d9530e081ee4fdbb93cdf3ddad))

# [0.20.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.7...v0.20.0) (2021-06-08)


### Bug Fixes

* adapter pre  baas ([bd6d297](http://gitlab.irootech.com/tide/tide-test/commit/bd6d297e149d98bfb850f9238a5d9f8fee0f39d7))
* resolve daily pre ([e3d1826](http://gitlab.irootech.com/tide/tide-test/commit/e3d1826f339643a63b656f91e7dc42dd4da3ac30))


### Features

* add baas org and create consortia ([2188987](http://gitlab.irootech.com/tide/tide-test/commit/2188987f41e6be030b269ca76f716c5059f387db))

## [0.19.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.6...v0.19.7) (2021-05-31)


### Bug Fixes

* separate login from the first case ([de04288](http://gitlab.irootech.com/tide/tide-test/commit/de042883225764c24563f28c55c3de6ecaa286f1))

## [0.19.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.5...v0.19.6) (2021-05-13)


### Bug Fixes

* commit cases about sanylogs ([df3afa8](http://gitlab.irootech.com/tide/tide-test/commit/df3afa87b2afe4a2a94b4d93e8067a6a1e5de3f6))

## [0.19.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.4...v0.19.5) (2021-04-28)


### Bug Fixes

* change url ([4ab2a65](http://gitlab.irootech.com/tide/tide-test/commit/4ab2a65198d03d58034d3255addb2733704d716a))

## [0.19.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.3...v0.19.4) (2021-04-28)


### Bug Fixes

* decrease docker iamge size ([88b2749](http://gitlab.irootech.com/tide/tide-test/commit/88b27495b3909012374adc5c532582648e386cfc))

## [0.19.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.2...v0.19.3) (2021-04-28)


### Bug Fixes

* change wechat message title ([3cf01a7](http://gitlab.irootech.com/tide/tide-test/commit/3cf01a7f1a479d1e10210a5a4ae37ef1be5fd46a))

## [0.19.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.1...v0.19.2) (2021-04-28)


### Bug Fixes

* docker image user yarn ([b9713da](http://gitlab.irootech.com/tide/tide-test/commit/b9713dac07cfc5a26e794bdbb18863a73b7e40f4))

## [0.19.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.19.0...v0.19.1) (2021-04-28)


### Bug Fixes

* delete package.lock.json ([3f2cf69](http://gitlab.irootech.com/tide/tide-test/commit/3f2cf695efb1b37f6793f33de152fe951f8fc95e))

# [0.19.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.16...v0.19.0) (2021-04-28)


### Bug Fixes

* change TideMscProxy to TideNetworkManagerUrl ([a25c698](http://gitlab.irootech.com/tide/tide-test/commit/a25c698d47171d33b65474861913f1c1a69af102))


### Features

* add test contract ([d7711b4](http://gitlab.irootech.com/tide/tide-test/commit/d7711b4e24383bb2107654811564375cdf6fa59a))

## [0.18.16](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.15...v0.18.16) (2021-04-27)


### Bug Fixes

* change gateway to proxy ([a8d9f6d](http://gitlab.irootech.com/tide/tide-test/commit/a8d9f6d576f98922d8fac70d747acf8b15f3f206))

## [0.18.15](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.14...v0.18.15) (2021-04-27)


### Bug Fixes

* downlaod newest tide-test-contract and deploy ([2097134](http://gitlab.irootech.com/tide/tide-test/commit/20971343fce692f620a7ddf54bb7f75b9e003aad))
* downlaod newest tide-test-contract and deploy ([b2e76cf](http://gitlab.irootech.com/tide/tide-test/commit/b2e76cfb07bf660cf4aea60d98e00e3b014d4c71))

## [0.18.14](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.13...v0.18.14) (2021-04-22)


### Bug Fixes

* deploy test contract ([b957242](http://gitlab.irootech.com/tide/tide-test/commit/b957242bf580d1be355135acfa02abfca5cae187))

## [0.18.13](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.12...v0.18.13) (2021-04-15)


### Bug Fixes

* move chaos test to zstack ([a0c220f](http://gitlab.irootech.com/tide/tide-test/commit/a0c220fa095d941dcffaa8b500f2231a8ae6255b))

## [0.18.12](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.11...v0.18.12) (2021-04-15)


### Bug Fixes

* init user add userRole ([41097f3](http://gitlab.irootech.com/tide/tide-test/commit/41097f30be1822131e99e07c357cae23296c3cce))

## [0.18.11](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.10...v0.18.11) (2021-04-06)


### Bug Fixes

* add digit jar ([57973aa](http://gitlab.irootech.com/tide/tide-test/commit/57973aaf6f120b5d25af7ad0f1b7c07a4b86bc9a))

## [0.18.10](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.9...v0.18.10) (2021-04-06)


### Bug Fixes

* delete digit jar ([aeb0b88](http://gitlab.irootech.com/tide/tide-test/commit/aeb0b885a3b2a4c39e0e74a73db278782eb252f0))
* resolve ci cd ([4f016df](http://gitlab.irootech.com/tide/tide-test/commit/4f016dfd976d3e07a1b97810af10f96f089bbcc5))

## [0.18.9](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.8...v0.18.9) (2021-04-02)


### Bug Fixes

* resolve tide-msc-proxy url ([3962de6](http://gitlab.irootech.com/tide/tide-test/commit/3962de678fe5388e62873b01ee2b9e0ced305826))

## [0.18.8](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.7...v0.18.8) (2021-04-02)


### Bug Fixes

* update msc-proxy url ([7b9547b](http://gitlab.irootech.com/tide/tide-test/commit/7b9547b03dd7a828288a7dc87405b228ef654ad1))

## [0.18.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.6...v0.18.7) (2021-04-01)


### Bug Fixes

* daily build report ([739ee41](http://gitlab.irootech.com/tide/tide-test/commit/739ee416c72dc5572e0000a2330956f15c119706))

## [0.18.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.5...v0.18.6) (2021-04-01)


### Bug Fixes

* daily build init user ([e748f1e](http://gitlab.irootech.com/tide/tide-test/commit/e748f1eaac9830bb264563048c0aaa9d38412c94))

## [0.18.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.4...v0.18.5) (2021-04-01)


### Bug Fixes

* resolve deploy double model ([9aed6c6](http://gitlab.irootech.com/tide/tide-test/commit/9aed6c62cafe1753b0bf3b4873bf8908ba1c6f90))

## [0.18.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.3...v0.18.4) (2021-04-01)


### Bug Fixes

* resolve ci cd ([821e179](http://gitlab.irootech.com/tide/tide-test/commit/821e179ecfab0caab9a859af0be3852eadb485c5))

## [0.18.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.2...v0.18.3) (2021-04-01)


### Bug Fixes

* resolve ci cd ([27c7ee4](http://gitlab.irootech.com/tide/tide-test/commit/27c7ee45c1427403d4c9545e39c6ac6f5ff2ad25))

## [0.18.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.1...v0.18.2) (2021-04-01)


### Bug Fixes

* daily test onchain offchain full test ([9abb596](http://gitlab.irootech.com/tide/tide-test/commit/9abb5963fe67834318770f62ade1b4741fc13fe1))
* resolve ci cd ([3a825aa](http://gitlab.irootech.com/tide/tide-test/commit/3a825aaa9e46db8527c5a83d7d3faea9f3b3f83a))

## [0.18.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.18.0...v0.18.1) (2021-03-31)


### Bug Fixes

* resolve ci cd ([2452c1e](http://gitlab.irootech.com/tide/tide-test/commit/2452c1ec0dcc1f26d2a81398da3815817f7b5158))

# [0.18.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.17.0...v0.18.0) (2021-03-31)


### Features

* resolve deploy double model ([b95f703](http://gitlab.irootech.com/tide/tide-test/commit/b95f7034e83767b4d25de75e54a43f7f2d91d687))

# [0.17.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.16.0...v0.17.0) (2021-03-26)


### Features

* double parallel ([fc5364d](http://gitlab.irootech.com/tide/tide-test/commit/fc5364d9f7062a0393a3b04a144daedfd33a77d4))

# [0.16.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.22...v0.16.0) (2021-03-25)


### Features

* add double switch ([131dfed](http://gitlab.irootech.com/tide/tide-test/commit/131dfedddd608ae079f1fb713aced4fa66c2cc12))

## [0.15.22](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.21...v0.15.22) (2021-03-19)


### Bug Fixes

* change gateway to proxy ([5a417a2](http://gitlab.irootech.com/tide/tide-test/commit/5a417a25cbea352a74b3cab295000ff8f4acc02f))

## [0.15.21](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.20...v0.15.21) (2021-03-19)


### Bug Fixes

* resove console schema ([15e0865](http://gitlab.irootech.com/tide/tide-test/commit/15e0865cfb21dec72443fbaa5a7fa3c5bac2927e))

## [0.15.20](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.19...v0.15.20) (2021-02-26)


### Bug Fixes

* change IAM url ([e7b4cb1](http://gitlab.irootech.com/tide/tide-test/commit/e7b4cb1a3fa0ae94bc61ccec2bd73d5bb56bb077))

## [0.15.19](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.18...v0.15.19) (2021-02-23)


### Bug Fixes

* change npmrc registry to https ([b3e71cf](http://gitlab.irootech.com/tide/tide-test/commit/b3e71cf82079f390462038f4ac9b23808da4986b))

## [0.15.18](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.17...v0.15.18) (2021-02-22)


### Bug Fixes

* modify the address of rootcloud-identity and increase timeout time ([8987933](http://gitlab.irootech.com/tide/tide-test/commit/89879337a38d59d85cb1d59489533349374185ef))

## [0.15.17](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.16...v0.15.17) (2021-02-18)


### Bug Fixes

* add schema verification to query evidence case ([263f410](http://gitlab.irootech.com/tide/tide-test/commit/263f41084b972046d8b48d55f79f13fda5847878))

## [0.15.16](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.15...v0.15.16) (2021-02-17)


### Bug Fixes

* fix daily build ([7b329cc](http://gitlab.irootech.com/tide/tide-test/commit/7b329cc5068a47c929986fb2f8c398523cda536f))

## [0.15.15](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.14...v0.15.15) (2021-02-08)


### Bug Fixes

* increase the timeout time of includeBlockInfo cases ([206fdd3](http://gitlab.irootech.com/tide/tide-test/commit/206fdd3b22386886982bfde57de39e638d8ce97d))

## [0.15.14](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.13...v0.15.14) (2021-02-06)


### Bug Fixes

* rerun some skiped cases ([ab27c40](http://gitlab.irootech.com/tide/tide-test/commit/ab27c40cce15520720dff36c0c15d47e377ab693))

## [0.15.13](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.12...v0.15.13) (2021-02-05)


### Bug Fixes

* modify the test describtion ([fdd55af](http://gitlab.irootech.com/tide/tide-test/commit/fdd55afb27057d6c1312b8970cfcb1f839106778))

## [0.15.12](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.11...v0.15.12) (2021-01-30)


### Bug Fixes

* resolve run report shell script ([6e20299](http://gitlab.irootech.com/tide/tide-test/commit/6e2029931855682296a277a38d6276969a56c2f2))

## [0.15.11](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.10...v0.15.11) (2021-01-30)


### Bug Fixes

* custom prod testcace ([0922e03](http://gitlab.irootech.com/tide/tide-test/commit/0922e03f68af07c737660b1538c6b0e3416a5f3f))

## [0.15.10](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.9...v0.15.10) (2021-01-29)


### Bug Fixes

* modify the case about timeout ([5b8a32c](http://gitlab.irootech.com/tide/tide-test/commit/5b8a32c34c79c1552c48f2a322ee03a4e9aaee47))

## [0.15.9](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.8...v0.15.9) (2021-01-28)


### Bug Fixes

* reset version ([26e5a35](http://gitlab.irootech.com/tide/tide-test/commit/26e5a35d9dd44605bb4867c454fcd8d901e335ab))

## [0.15.8](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.7...v0.15.8) (2021-01-28)


### Bug Fixes

* add case and update pre/prod case ([eb94c16](http://gitlab.irootech.com/tide/tide-test/commit/eb94c167b82bde3c3dcb777911ee7223a0adf8cc))

## [0.15.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.6...v0.15.7) (2021-01-28)


### Bug Fixes

* resove message format ([a74b8b6](http://gitlab.irootech.com/tide/tide-test/commit/a74b8b60ac77ab67104a998a7fe57450d0e150fa))

## [0.15.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.5...v0.15.6) (2021-01-28)


### Bug Fixes

* send alarm message when pre/prod fail ([772cddb](http://gitlab.irootech.com/tide/tide-test/commit/772cddb1853a1e1b37a419f7bbda2392baad0398))

## [0.15.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.4...v0.15.5) (2021-01-23)


### Bug Fixes

* resolve daily test bug ([1963d26](http://gitlab.irootech.com/tide/tide-test/commit/1963d26dced1358380744ddc8b59e1d57362c24d))

## [0.15.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.3...v0.15.4) (2021-01-22)


### Bug Fixes

* add case for get employee by userId and searchCondition ([aea979e](http://gitlab.irootech.com/tide/tide-test/commit/aea979ec0f7f3aa52b3ea98e90d82050e43970ae))

## [0.15.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.2...v0.15.3) (2021-01-21)


### Bug Fixes

* add case for a user have two company and activated ([857ec79](http://gitlab.irootech.com/tide/tide-test/commit/857ec79b43218e490c2e57107231a917d1a49fbc))

## [0.15.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.1...v0.15.2) (2021-01-18)


### Bug Fixes

* resolve api query company response ([5e12d8f](http://gitlab.irootech.com/tide/tide-test/commit/5e12d8f7de231b55088450617c36285a958a228e))

## [0.15.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.15.0...v0.15.1) (2021-01-13)


### Bug Fixes

* add verification for getEmployeeSchema ([1b07154](http://gitlab.irootech.com/tide/tide-test/commit/1b07154cca22dc588f4c1db0cae09ac14ce2a9db))

# [0.15.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.14.5...v0.15.0) (2021-01-12)


### Features

* add test case about record list for console ([a64c31b](http://gitlab.irootech.com/tide/tide-test/commit/a64c31b0e7a3b13b647cc33830382c00de356241))

## [0.14.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.14.4...v0.14.5) (2021-01-12)


### Bug Fixes

* api response add shareType ([a7c06fd](http://gitlab.irootech.com/tide/tide-test/commit/a7c06fd921229cc9c3e8c2bba8b91917de09634d))

## [0.14.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.14.3...v0.14.4) (2021-01-11)


### Bug Fixes

* resolve api createShare, getShare, getShare change ([04dbec7](http://gitlab.irootech.com/tide/tide-test/commit/04dbec7d550c6cb4f936f53bb64f65c65339f3ac))

## [0.14.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.14.2...v0.14.3) (2021-01-11)


### Bug Fixes

* change chaos-test image ([0167ba2](http://gitlab.irootech.com/tide/tide-test/commit/0167ba2b59a544d38d04bd2ac4506d58fa3d8f0d))

## [0.14.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.14.1...v0.14.2) (2021-01-05)


### Bug Fixes

* add aditional case for choosing share expire time ([a0084a6](http://gitlab.irootech.com/tide/tide-test/commit/a0084a6e0925d1120511b66552bf5b9f51590c5b))

## [0.14.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.14.0...v0.14.1) (2021-01-05)


### Bug Fixes

* adapt cron time zone ([6b4e5e3](http://gitlab.irootech.com/tide/tide-test/commit/6b4e5e31ee128ae21cf256917f0087dcb219189e))

# [0.14.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.13.2...v0.14.0) (2020-12-31)


### Features

* add chaos test and cronjob ([7b2c49c](http://gitlab.irootech.com/tide/tide-test/commit/7b2c49cbaf424730811f9266c8458f751a3f0b10))

## [0.13.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.13.1...v0.13.2) (2020-12-30)


### Bug Fixes

* sync to master ([ee78a28](http://gitlab.irootech.com/tide/tide-test/commit/ee78a285b74a57e291abcdb0d1376631686f3f40))

## [0.13.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.13.0...v0.13.1) (2020-12-29)


### Bug Fixes

* the bug verification ([7db7d09](http://gitlab.irootech.com/tide/tide-test/commit/7db7d099302589e66f399742a4c348dbf8da940b))

# [0.13.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.7...v0.13.0) (2020-12-28)


### Features

* add case for sharing ([3315132](http://gitlab.irootech.com/tide/tide-test/commit/3315132986bb477140f071cecdba15d3a3ce365d))

## [0.12.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.6...v0.12.7) (2020-12-21)


### Bug Fixes

* bug fixed and modify related case ([22114dd](http://gitlab.irootech.com/tide/tide-test/commit/22114dd10e747ba0794a58d1184427a4925ec52a))

## [0.12.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.5...v0.12.6) (2020-12-16)


### Bug Fixes

* add debug mode ([09124b3](http://gitlab.irootech.com/tide/tide-test/commit/09124b3dfda13bc340ec67fa9c7d43eb426e61fb))

## [0.12.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.4...v0.12.5) (2020-12-14)


### Bug Fixes

* resolve query employee result ([5ecf599](http://gitlab.irootech.com/tide/tide-test/commit/5ecf599b51f2fbf028018e277a05a596a5b58599))

## [0.12.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.3...v0.12.4) (2020-12-11)


### Bug Fixes

* bug verification about sharing ([df6d4de](http://gitlab.irootech.com/tide/tide-test/commit/df6d4de4cad01820e3f30c2a3121e232f7feda2e))

## [0.12.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.2...v0.12.3) (2020-12-11)


### Bug Fixes

* wait 2min before service evidence be ready ([c9e3fed](http://gitlab.irootech.com/tide/tide-test/commit/c9e3fed74c00c26d6cad47101d80482b42f3de9e))

## [0.12.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.1...v0.12.2) (2020-12-09)


### Bug Fixes

* resolve query resources(user) and company ([47fff1f](http://gitlab.irootech.com/tide/tide-test/commit/47fff1fa70b3665326603047882b9204e7698cea))

## [0.12.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.12.0...v0.12.1) (2020-12-08)


### Bug Fixes

* after dev update,sleep 20s to wait service and pod to be healthy ([10471ff](http://gitlab.irootech.com/tide/tide-test/commit/10471ff7f31df2a420bb0147d48f915f153d5ff5))

# [0.12.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.11.0...v0.12.0) (2020-12-08)


### Features

* add query shared evidence include history ([c35f0e7](http://gitlab.irootech.com/tide/tide-test/commit/c35f0e7b328913faf67a8e3bde13cd10487c5bce))

# [0.11.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.12...v0.11.0) (2020-12-07)


### Features

* add query text and file evidence include history ([e4d8c7e](http://gitlab.irootech.com/tide/tide-test/commit/e4d8c7e12116484d34600632dfe1ad9285824060))

## [0.10.12](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.11...v0.10.12) (2020-12-07)


### Bug Fixes

* add nagetive case for sharing ([166c085](http://gitlab.irootech.com/tide/tide-test/commit/166c085673cbc296894d6dc1908647f3e881f996))

## [0.10.11](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.10...v0.10.11) (2020-12-04)


### Bug Fixes

* add nagetive case about sharing ([54f887f](http://gitlab.irootech.com/tide/tide-test/commit/54f887fe90071367a4e210d6db4758ae42620c2e))

## [0.10.10](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.9...v0.10.10) (2020-12-02)


### Bug Fixes

* add case run result display ([62267ae](http://gitlab.irootech.com/tide/tide-test/commit/62267ae2d2851da81e108cc5dc215768d79152bd))

## [0.10.9](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.8...v0.10.9) (2020-12-01)


### Bug Fixes

* add test user and prod env url ([d7aa828](http://gitlab.irootech.com/tide/tide-test/commit/d7aa828504463b42fcb2e94071da361ad5900246))

## [0.10.8](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.7...v0.10.8) (2020-11-30)


### Bug Fixes

* change batch text evidence ([607759e](http://gitlab.irootech.com/tide/tide-test/commit/607759e084c603489aea5df32bdf52e68c5a789e))

## [0.10.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.6...v0.10.7) (2020-11-30)


### Bug Fixes

* resolve batch create text evidence failed ([fdf0c8d](http://gitlab.irootech.com/tide/tide-test/commit/fdf0c8d60505d7dd589c73b61a42f02aab7763e4))

## [0.10.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.5...v0.10.6) (2020-11-27)


### Bug Fixes

* after deploy solution,wait 2 min ([d01650a](http://gitlab.irootech.com/tide/tide-test/commit/d01650a72885f2a672302fa1d884e0aa6fc9b8e5))

## [0.10.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.4...v0.10.5) (2020-11-25)


### Bug Fixes

* add differ env url ([de78107](http://gitlab.irootech.com/tide/tide-test/commit/de78107da5e2f41166f797df62c435e4e1d09730))

## [0.10.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.3...v0.10.4) (2020-11-25)


### Bug Fixes

* modify the run_report.sh ([69810b9](http://gitlab.irootech.com/tide/tide-test/commit/69810b9a1a0ed99754b07f4ff84df4879c6efc18))

## [0.10.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.2...v0.10.3) (2020-11-24)


### Bug Fixes

* modify the url name and deploy solution ([2c92359](http://gitlab.irootech.com/tide/tide-test/commit/2c92359370491b1b28f9dbfb1f4c0589dd6bf763))

## [0.10.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.1...v0.10.2) (2020-11-24)


### Bug Fixes

* change deploy and run case script ([dc2f7d5](http://gitlab.irootech.com/tide/tide-test/commit/dc2f7d5e6abbcb625666ce5c04401d36ddc8a7d4))

## [0.10.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.10.0...v0.10.1) (2020-11-24)


### Bug Fixes

* update send_failure script ([3f65301](http://gitlab.irootech.com/tide/tide-test/commit/3f653016fccf13d4ea1af30de77f0388f82ad290))

# [0.10.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.9.0...v0.10.0) (2020-11-24)


### Features

* share evidence case for console ([e5874ca](http://gitlab.irootech.com/tide/tide-test/commit/e5874ca5cb8e4b11ad55eaffc857f0acbb14f09b))

# [0.9.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.8.0...v0.9.0) (2020-11-18)


### Features

* add case for share evidence ([76e575c](http://gitlab.irootech.com/tide/tide-test/commit/76e575cea1d5f2b02ec63136dba50edf4bee3783))

# [0.8.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.7.0...v0.8.0) (2020-11-13)


### Features

* add case for block browser ([38f2327](http://gitlab.irootech.com/tide/tide-test/commit/38f232730ca9a3c8facce2a1958eb67bd931c01f))

# [0.7.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.6.1...v0.7.0) (2020-11-13)


### Features

* add file evidencd upload case ([8b9c8b3](http://gitlab.irootech.com/tide/tide-test/commit/8b9c8b38ff65c592368f9ac8248fd6687ae1cb18))

## [0.6.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.6.0...v0.6.1) (2020-11-09)


### Bug Fixes

* add negative case ([66fb7ca](http://gitlab.irootech.com/tide/tide-test/commit/66fb7ca24feec83965184565307cb5cea14904ea))

# [0.6.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.5.2...v0.6.0) (2020-11-09)


### Features

* add smoke_test ([4f31a75](http://gitlab.irootech.com/tide/tide-test/commit/4f31a75a29449c393591f40bf7ff51a41936d50a))

## [0.5.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.5.1...v0.5.2) (2020-11-05)


### Bug Fixes

* modify the length of random number ([bc332ba](http://gitlab.irootech.com/tide/tide-test/commit/bc332ba1aa6cf172ff4183b40026883c0afcabb9))

## [0.5.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.5.0...v0.5.1) (2020-11-05)


### Bug Fixes

* modify the timeout problem ([c34e2bb](http://gitlab.irootech.com/tide/tide-test/commit/c34e2bba814d4f4a01648701746703c0669b46bc))

# [0.5.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.4.0...v0.5.0) (2020-11-03)


### Features

* able to deploy solution and add user initialization ([680a774](http://gitlab.irootech.com/tide/tide-test/commit/680a774907567d4db416eca79d4e19fe7d757144))

# [0.4.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.11...v0.4.0) (2020-10-30)


### Bug Fixes

* grpc crud microbenchmark [skip ci] ([e46eabb](http://gitlab.irootech.com/tide/tide-test/commit/e46eabbdf288051ee00ac1e2540e28df886f610f))


### Features

* add smoke test for console API ([327510a](http://gitlab.irootech.com/tide/tide-test/commit/327510a717fb4bfa3dde5e59e6335b952e24d507))

## [0.3.11](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.10...v0.3.11) (2020-10-26)


### Bug Fixes

* add priority for case and report when failure ([c57fdd9](http://gitlab.irootech.com/tide/tide-test/commit/c57fdd9d6681dbbe359b1681bcdd245feaa6cd3e))

## [0.3.10](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.9...v0.3.10) (2020-10-21)


### Bug Fixes

* add smoke test ([326288e](http://gitlab.irootech.com/tide/tide-test/commit/326288e44f4d0ad18ae3ed0d6cc774020d8589e6))

## [0.3.9](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.8...v0.3.9) (2020-09-30)


### Bug Fixes

* add error code ([dfe787d](http://gitlab.irootech.com/tide/tide-test/commit/dfe787d53843a4502ed3a8d1778d9cd4a860eb79))

## [0.3.8](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.7...v0.3.8) (2020-09-28)


### Bug Fixes

* add ghz load testing tool for msc load test ([1d37ca5](http://gitlab.irootech.com/tide/tide-test/commit/1d37ca5d398a3a7ca7d8e206776a7d9eca8851de))
* create/query/blockinfo a textevidence ([cb93574](http://gitlab.irootech.com/tide/tide-test/commit/cb93574a951c81980630e2df3160991e6afe2e35))

## [0.3.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.6...v0.3.7) (2020-09-28)


### Bug Fixes

* delete 'it' of function ([8b91d97](http://gitlab.irootech.com/tide/tide-test/commit/8b91d97fa6b9477fb551c8bcdce6a2b6cca10404))

## [0.3.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.5...v0.3.6) (2020-09-24)


### Bug Fixes

* change url ([356361c](http://gitlab.irootech.com/tide/tide-test/commit/356361ca3f2a334f289cd624d8e3ef92be4d20fa))
* fix 400 to 500 statuscode ([9ad0be7](http://gitlab.irootech.com/tide/tide-test/commit/9ad0be733abb3b78801e970ed3c4533d783ba69e))

## [0.3.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.4...v0.3.5) (2020-09-23)


### Bug Fixes

* fix missing code ([fea44ba](http://gitlab.irootech.com/tide/tide-test/commit/fea44ba03728e278094c3a354d0c443032d8c392))

## [0.3.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.3...v0.3.4) (2020-09-23)


### Bug Fixes

* fix some cases to accommodate some changes ([67c33a3](http://gitlab.irootech.com/tide/tide-test/commit/67c33a3da311c7c4398e24af69c6705f3dfdff53))

## [0.3.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.2...v0.3.3) (2020-09-17)


### Bug Fixes

* add query parameter ([3607e28](http://gitlab.irootech.com/tide/tide-test/commit/3607e28f2891262692484ff7b0dcbc0226e6f390))
* fix check schema and soretd result check ([92f6113](http://gitlab.irootech.com/tide/tide-test/commit/92f61132a025f6f799951e8eab19402a45694d28))

## [0.3.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.1...v0.3.2) (2020-09-16)


### Bug Fixes

* modify the function about user and add utils file ([86be885](http://gitlab.irootech.com/tide/tide-test/commit/86be885d9e951c7a211da8023905b60ca6b10340))

## [0.3.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.3.0...v0.3.1) (2020-09-14)


### Bug Fixes

* modify the function ([47f0024](http://gitlab.irootech.com/tide/tide-test/commit/47f00242ed932447b2ec32fa3344302babdba0c9))

# [0.3.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.2.4...v0.3.0) (2020-09-11)


### Features

* add query evidence total num ([f338bf8](http://gitlab.irootech.com/tide/tide-test/commit/f338bf859cf62dbca4932366f4636e9af00d1365))

## [0.2.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.2.3...v0.2.4) (2020-09-10)


### Bug Fixes

* fix bugs ([7b4349e](http://gitlab.irootech.com/tide/tide-test/commit/7b4349ef1afb4ee6fa8167cfd20f9689b154ca3c))
* 修复查询文本接口用例中的筛选问题和排序问题并优化代码 ([306575f](http://gitlab.irootech.com/tide/tide-test/commit/306575f32cc277eb5e23dd505138a4c822ee4489))

## [0.2.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.2.2...v0.2.3) (2020-09-10)


### Bug Fixes

* 修复排序方法及相关case ([b927d5b](http://gitlab.irootech.com/tide/tide-test/commit/b927d5b455afb7706fe483783d5355ee1cfabe61))

## [0.2.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.2.1...v0.2.2) (2020-09-09)


### Bug Fixes

* fix some bugs ([c647969](http://gitlab.irootech.com/tide/tide-test/commit/c64796991814c76e740c4f294d6c646523408f0e))

## [0.2.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.2.0...v0.2.1) (2020-09-09)


### Bug Fixes

* 修复getUserId方法 ([4e59069](http://gitlab.irootech.com/tide/tide-test/commit/4e59069de66fb664296e9cce9958b1691fd456c5))

# [0.2.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.1.1...v0.2.0) (2020-09-09)


### Features

* test for activate user ([73638ae](http://gitlab.irootech.com/tide/tide-test/commit/73638ae58b05a1b29647f92c13506c00d4b8319a))

## [0.1.1](http://gitlab.irootech.com/tide/tide-test/compare/v0.1.0...v0.1.1) (2020-09-09)


### Bug Fixes

* 修复排序方法bug,新增文件存证参数搜索及排序用例 ([7bbe570](http://gitlab.irootech.com/tide/tide-test/commit/7bbe57006126dcfcf0338a7a5db46707b99c129b))

# [0.1.0](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.12...v0.1.0) (2020-09-08)


### Features

* add create FileEvidence ([a51bcc0](http://gitlab.irootech.com/tide/tide-test/commit/a51bcc02ff94d867afe8f6df40eaf2c41e5a5131))

## [0.0.12](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.11...v0.0.12) (2020-09-03)


### Bug Fixes

* add patch/delete file evidence case ([7890950](http://gitlab.irootech.com/tide/tide-test/commit/78909502f936e08eef11244df16519c30ccf087b))

## [0.0.11](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.10...v0.0.11) (2020-09-02)


### Bug Fixes

* add common function/schema ([da033d0](http://gitlab.irootech.com/tide/tide-test/commit/da033d0205c2d667d2f52fa0a550924edd8eff84))

## [0.0.10](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.9...v0.0.10) (2020-08-31)


### Bug Fixes

* 修改方法中包含it ([a7ea0e3](http://gitlab.irootech.com/tide/tide-test/commit/a7ea0e3711b597ea85b09bd8209889a10d4342be))

## [0.0.9](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.8...v0.0.9) (2020-08-31)


### Bug Fixes

* 去除基础方法中的it ([987d6b7](http://gitlab.irootech.com/tide/tide-test/commit/987d6b7f4ba056abd058db2ca472f2b76d448633))

## [0.0.8](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.7...v0.0.8) (2020-08-27)


### Bug Fixes

* 增加获取userId的方法并适配查询相关用例 ([ed52dbd](http://gitlab.irootech.com/tide/tide-test/commit/ed52dbd00391251140ad918f78a197717aed8847))
* 增加错误码和错误信息 ([2265b15](http://gitlab.irootech.com/tide/tide-test/commit/2265b15de9bc60d5d596ccefa30ecb6186a4d9d6))
* 解决CD后用例失败的问题 ([fb804c3](http://gitlab.irootech.com/tide/tide-test/commit/fb804c3af4d8c2df134f4079782bcb7374aed33d))
* 解决schema校验问题 ([ac58eb9](http://gitlab.irootech.com/tide/tide-test/commit/ac58eb94be5681e6a7d6c6dc5fac9f1b3b714315))
* 重构存证构造函数，切换成异步的方式批量创建存证 ([16db5fb](http://gitlab.irootech.com/tide/tide-test/commit/16db5fb91ac13b64f29e5e69d2dd68b486f10ee3))
* 重构存证构造函数，切换成异步的方式批量创建存证 ([5f92e68](http://gitlab.irootech.com/tide/tide-test/commit/5f92e6892422fcea85999a86bce40cc889cda7df))

## [0.0.7](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.6...v0.0.7) (2020-08-21)


### Bug Fixes

* replace some values with random string ([97366b5](http://gitlab.irootech.com/tide/tide-test/commit/97366b5d2600a4fb4e965c591a0c1ddefa5a266d))

## [0.0.6](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.5...v0.0.6) (2020-08-20)


### Bug Fixes

* 修改文本存证批量新建的方式为异步 ([9ca37f3](http://gitlab.irootech.com/tide/tide-test/commit/9ca37f305333f0d42f17bcea34f5c39550f8075c))

## [0.0.5](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.4...v0.0.5) (2020-08-19)


### Bug Fixes

* evidenceSearch 相关方法及case添加 ([86c5d21](http://gitlab.irootech.com/tide/tide-test/commit/86c5d21b934f9f15c3f4742e9dea9cb2212d3d4c))

## [0.0.4](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.3...v0.0.4) (2020-08-19)


### Bug Fixes

* textEvidence get/patch/delete ([5783818](http://gitlab.irootech.com/tide/tide-test/commit/578381844b6a6d5a434939d6ced57f3de8f53004))

## [0.0.3](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.2...v0.0.3) (2020-08-13)


### Bug Fixes

* url获取方式调整及eslint缩进校验改为4个space ([b7ac980](http://gitlab.irootech.com/tide/tide-test/commit/b7ac98027dcea5d376cdaa877848836d4ce55816))

## [0.0.2](http://gitlab.irootech.com/tide/tide-test/compare/v0.0.1...v0.0.2) (2020-08-11)


### Bug Fixes

* fix the bug in package.json ([d6064db](http://gitlab.irootech.com/tide/tide-test/commit/d6064db44f160806c6da0ba04fb7f409da4ae123))
* fix the semantic-release config ([264e691](http://gitlab.irootech.com/tide/tide-test/commit/264e6911b69a515139f570624f5bdbc38c104729))
