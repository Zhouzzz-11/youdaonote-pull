'use strict';

const env = process.env.CURRENT_ENV;
const url_env = process.env.URL_ENV;
var daily_env;

class Host {
    constructor(apiPaths, hosts, env1 = env) {
        this.apiPaths = apiPaths;
        this.hosts = hosts;
        this.env = env1;
    }

    getHost(appName) {
        return this.hosts[appName][this.env];
    }

    compositeUrl(appName) {
        let api_path = this.apiPaths[appName];
        for (const key in api_path) {
            if (key.startsWith('http')) {
                continue;
            }
            api_path[key] = `${this.getHost(appName)}/${api_path[key]}`;
        }
        return api_path;
    }
}

var HOSTS = {
    'iamOpenAPI': {
        'pre': 'https://openapi-pre.rootcloudapp.com',
        'prod': 'https://openapi.rootcloud.com'
    },
    'homepage': {
        'qa': 'https://blockchain-qa.rootcloudapp.com',
        'pre': 'https://blockchain-pre.rootcloudapp.com',
        'dev': 'https://blockchain-dev.rootcloudapp.com',
        'prod': 'https://blockchain.rootcloud.com'
    },
    'console': {
        'qa': 'https://bc-console-qa.rootcloudapp.com',
        'pre': 'https://bc-console-pre.rootcloudapp.com',
        'dev': 'https://bc-console-dev.rootcloudapp.com',
        'prod': 'https://bc-console.rootcloud.com',
        'local': 'http://localhost:3000'
    },
    'evidenceSolution': {
        'qa': 'http://bc-evidence-baas-qa.rootcloudapp.com',
        'pre': 'http://bc-evidence-pre.rootcloudapp.com',
        'dev': 'http://bc-evidence-dev.rootcloudapp.com',
        'prod': 'http://bc-evidence.rootcloud.com',
        'local': 'http://10.67.0.6:32380',
        'sanyLogsVM': 'http://10.67.0.34:31383',
    },
    'TideNetworkManagerUrl': {
        'qa': 'http://network-manager-qa.rootchain.com.cn',
        'pre': 'http://bc-gateway-pre.rootcloudapp.com',
        'dev': 'http://bc-gateway-dev.rootcloudapp.com',
        'prod': 'http://bc-gateway.rootcloud.com',
        'local': 'http://10.66.231.226:31801',
        'sanyLogsVM': 'http://10.67.0.34:32083',
    },
    'iamGateway': {
        'qa': 'http://iam-identity-service.iot-qa.rootcloudapp.com',
        'pre': 'http://iam-identity-service.iot-pre.rootcloudapp.com',
        'dev': 'http://iam-identity-service.iot-dev.rootcloudapp.com',
        'prod': 'http://iam-identity-service.iot-prod.rootcloudapp.com',
        'local': 'http://iam-identity-service.iot-qa.rootcloudapp.com'
    },
    'iamServiceManagement': {
        'qa': 'http://iam-service-management-api.iot-qa.rootcloudapp.com',
        'pre': 'http://iam-service-management-api.iot-qa.rootcloudapp.com',
        'dev': 'http://iam-service-management-api.iot-qa.rootcloudapp.com',
        'prod': 'http://iam-service-management-api.iot-qa.rootcloudapp.com',
        'local': 'http://iam-service-management-api.iot-qa.rootcloudapp.com',
    }
};

const URLS = {
    'iamOpenAPI': {
        login: 'account-manage/v1/auth/login',
        company: 'tenant-manage/v1/tenant/company',
        user: 'account-manage/v1/user',
    },
    'homepage': {
        shareMsg: 'api/v1/share',
    },
    'console': {
        textEvidence: 'api/v1/evidence/text',
        fileEvidence: 'api/v1/evidence/file',
        certificate: 'api/v1/evidence/certificate',
        getEvidenceTotalNum: 'api/v1/evidence/metrics/statistics',
        company: 'api/company',
        user: 'api/company/user',
        org: 'api/org',
        network: 'api/tenant/networks',
        shareCode: 'api/v1/evidence/share',
    },
    'iamGateway': {
        login: 'api/v1/auth/login',
        company: 'api/v1/company',
        user: 'api/v1/user'
    },
    'iamServiceManagement':{
        subscription: 'api/v1/subscription'
    },
    'TideNetworkManagerUrl': {
        login: 'auth/login',
        user: 'user',
        userProbe: 'user/probe',
        userApp: 'user/apps',
        resources: 'msc/resources',
        consortia: 'api/v1/consortia',
        org: 'org',
        searchUser: '',
        logout: '',
        provenance: 'msc/provenance',
        invoke: 'msc/invoke',
        company: 'company',
        network: 'tenant/networks',
        browser: 'msc/provenance/browser',
        testContractAssert: 'msc/rest/cn.gezhitech.test.integration.asset.BankAccount',
        testContractTransaction: 'msc/transaction'
    },
    'evidenceSolution': {
        textEvidence: 'api/v1/text',
        search: 'api/v1/search',
        queryasync: 'api/v1/text/queue',
        fileEvidence: 'api/v1/file',
        getEvidenceTotalNum: 'api/v1/metrics/statistics',
        share: 'api/v1/share',
        auditDataEvidence: 'api/v1/bulk/audit-data',
        verifyAudit: 'api/v1/verification',
        queryAudit: 'api/v1/audit-data',
    }
};

if (url_env !== undefined && url_env.length !== 0) {
    daily_env = JSON.parse(url_env);
    HOSTS['console']['nightly'] = daily_env.CONSOLE_URL;
    HOSTS['evidenceSolution']['nightly'] = daily_env.EVIDENCESOLUTION_URL;
    HOSTS['TideNetworkManagerUrl']['nightly'] = daily_env.TIDEPROXY_URL + ':8081';
    HOSTS['iamGateway']['nightly'] = daily_env.IAM_URL;
    HOSTS['homepage']['nightly'] = daily_env.HOMEPAGE_URL;
}

let hostInstance = new Host(URLS, HOSTS);
let evidenceSolutionUrl = hostInstance.compositeUrl('evidenceSolution');
let TideNetworkManagerUrl = hostInstance.compositeUrl('TideNetworkManagerUrl');
let IAMGatewayUrl = hostInstance.compositeUrl('iamGateway');
let IAMServiceManagementUrl = hostInstance.compositeUrl('iamServiceManagement');
let consoleUrl = hostInstance.compositeUrl('console');
let homepageUrl = hostInstance.compositeUrl('homepage');
let IAMOpenAPIUrl = hostInstance.compositeUrl('iamOpenAPI');

module.exports = {
    evidenceSolutionUrl,
    TideNetworkManagerUrl,
    IAMGatewayUrl,
    IAMServiceManagementUrl,
    consoleUrl,
    homepageUrl,
    IAMOpenAPIUrl,
};
