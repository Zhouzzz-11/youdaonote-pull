'use strict';

const Moment = require('moment');
const myDate = Moment.utc().format('YYYYMMDD');
const randNum = parseInt(Math.random() * 100000000);
//console.log(`random num is: ${randNum}`);>>>>>>> test:Get provenance list

//default value
const code = 'local';
const userId = 'yy-user';
const password = 'yy12345';


const commonDict = {
    randStr: `${myDate}_${randNum}`,
    code: code,
    userId: userId,
    password: password,
};

module.exports = {
    commonDict
};
