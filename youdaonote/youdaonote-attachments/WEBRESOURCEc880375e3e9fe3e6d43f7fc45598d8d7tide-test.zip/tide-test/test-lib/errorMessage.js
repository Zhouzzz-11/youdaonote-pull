`use strict`;

const TIDE = {
    'UserCredentialsInvalidError': {
        errorCode: 'TIDE-1001',
        errorMessage: 'user credentials are invalid'
    },
    'UnableToVerifyServiceStatusError': {
        errorCode: 'TIDE-1002',
        errorMessage: 'unable to verify the service status'
    },
    'ServiceUnreadyError': {
        errorCode: 'TIDE-1003',
        errorMessage: 'service unready error'
    },
    'CodeUndefinedError': {
        errorCode: 'TIDE-1004',
        errorMessage: 'code is not undefined.'
    },
    'RefreshTokenExpiredError': {
        errorCode: 'TIDE-1005',
        errorMessage: 'invalid token: refresh token has expired'
    },
    'UserNotExistError': {
        errorCode: 'TIDE-1006',
        errorMessage: 'cannot find the current user in db'
    },
    'InvalidAccessToken': {
        errorCode: 'TIDE-1007',
        errorMessage: 'invalid token'
    },
    'FailedToInitDueToPrivilegeError': {
        errorCode: 'TIDE-1008',
        errorMessage: 'failed to initialize the network since the current user is not network admin'
    },
    'FailedToFindCompanyInfo': {
        errorCode: 'TIDE-1009',
        errorMessage: 'failed to find company or organization information'
    },
    'PermissionDenied': {
        errorCode: 'TIDE-1010',
        errorMessage: 'user does not have insufficient privileges to process'
    },
    'MissingAccessTokenError': {
        errorCode: 'TIDE-1011',
        errorMessage: 'missing access token'
    },
    'AccessTokenExpiredError': {
        errorCode: 'TIDE-1012',
        errorMessage: 'access token is expired'
    },
    'FailedToCreateUserDueToIAMError': {
        errorCode: 'TIDE-2001',
        errorMessage: 'failed to create user due to IAM error'
    },
    'FailedToCreateUserDueToInvalidParamsError': {
        errorCode: 'TIDE-2002',
        errorMessage: 'failed to create user due to invalid params'
    },
    'FailedToCreateUserDueToInvalidUserIdError': {
        errorCode: 'TIDE-2003',
        errorMessage: 'User ID already exists'
    },
    'FailedToCreateUserDueToInvalidMobileError': {
        errorCode: 'TIDE-2004',
        errorMessage: 'mobile already exists'
    },
    'PermissionError': {
        errorCode: 'TIDE-2005',
        errorMessage: 'you do not have the authority to use this API.'
    },
    'DBOperateError': {
        errorCode: 'TIDE-2006',
        errorMessage: 'operate database exception.'
    },
    'UpdateUserOrgError': {
        errorCode: 'TIDE-2007',
        errorMessage: 'Update user org must remove all user role first.'
    },
    'InvalidUserIdentifierError': {
        errorCode: 'TIDE-2008',
        errorMessage: 'Invalid user identifier.'
    },
    'FailedCloneUserError': {
        errorCode: 'TIDE-2009',
        errorMessage: 'Can not clone user from #sourceUserId# to #targetUserId#.'
    },
    'UserExistError': {
        errorCode: 'TIDE-2010',
        errorMessage: 'User with the id of #userId# already exists'
    },
    'NoRedirectUrlError': {
        errorCode: 'TIDE-2011',
        errorMessage: 'No redirect url is provided'
    },
    'IdentityVerifiedError': {
        errorCode: 'TIDE-2012',
        errorMessage: 'Your identity has already been verified'
    },
    'FailedToUpdateUserDueToInvalidParamsError': {
        errorCode: 'TIDE-2013',
        errorMessage: 'failed to update user due to invalid params'
    },
    'FailedFindUserError': {
        errorCode: 'TIDE-2014',
        errorMessage: 'Can not find user in db'
    },
    'FailedFindUserByTenantIdOrUserIdError': {
        errorCode: 'TIDE-2015',
        errorMessage: 'lack userId(#userId#) or tenantId(#tenantId#) or both to find target user'
    },
    'NoUUIDError': {
        errorCode: 'TIDE-2016',
        errorMessage: 'No uuid is provided.'
    },
    'ResourceConflictError': {
        errorCode: 'TIDE-2017',
        errorMessage: 'duplication resource'
    },
    'BusinessStateAbnormal': {
        errorCode: 'TIDE-2018',
        errorMessage: 'business state abnormal'
    },
    'MSCCreateOrgFailed': {
        errorCode: 'TIDE-2019',
        errorMessage: 'msc create org failed'
    },
    'InvalidQueryParamError': {
        errorCode: 'TIDE-9901',
        errorMessage: 'invalid query parameters'
    },
    'InvalidRequestError': {
        errorCode: 'TIDE-9902',
        errorMessage: 'invalid request format'
    },
    'DBServiceError': {
        errorCode: 'TIDE-9903',
        errorMessage: 'database service unavailable'
    },
    'MscForbiddenError': {
        errorCode: 'TIDE-20001',
        errorMessage: 'msc resource operation forbidden'
    },
    'MscNotExistError': {
        errorCode: 'TIDE-20002',
        errorMessage: 'msc resource not exist'
    },
    'MscInternalError': {
        errorCode: 'TIDE-20003',
        errorMessage: 'msc internal error'
    },
    'MscApplicationError': {
        errorCode: 'TIDE-20004',
        errorMessage: 'msc application error'
    },
    'MscParseError': {
        errorCode: 'TIDE-20005',
        errorMessage: 'msc parse error'
    },
    'MscInvalidRequestError': {
        errorCode: 'TIDE-20006',
        errorMessage: 'msc invalid request error'
    },
    'MscNotImplementedError': {
        errorCode: 'TIDE-20007',
        errorMessage: 'msc not implemented'
    },
    'MscAlreadyExistError': {
        errorCode: 'TIDE-20008',
        errorMessage: 'msc resource already exist'
    },
    'MscTimeoutError': {
        errorCode: 'TIDE-20009',
        errorMessage: 'msc timeout error'
    },
    'MscFabricSDKError': {
        errorCode: 'TIDE-20010',
        errorMessage: 'msc fabric sdk error'
    },
    'MscInvalidInputError': {
        errorCode: 'TIDE-20011',
        errorMessage: 'msc invalid input error'
    },
    'MscWrongFieldError': {
        errorCode: 'TIDE-20012',
        errorMessage: 'msc wrong field error'
    },
    'MscUnCategorizedError': {
        errorCode: 'TIDE-20013',
        errorMessage: 'msc uncategorized error'
    }
};

const TIDESOL = {
    'UnknownServerError': {
        errorCode: 'TIDESOL-91001',
        errorMessage: 'unknown server error'
    },
    'ParamsIllegalError': {
        errorCode: 'TIDESOL-91002',
        errorMessage: 'parameter #param_name# is illegal'
    },
    'MissingRequiredFieldError': {
        errorCode: 'TIDESOL-91003',
        errorMessage: 'missing required field #field_name#'
    },
    'UserUnauthorizedError': {
        errorCode: 'TIDESOL-91004',
        errorMessage: 'unauthorized request'
    },
    'UnsupportedEncodingError': {
        errorCode: 'TIDESOL-91006',
        errorMessage: 'unsupported encoding error'
    },
    'AssetNotFoundError': {
        errorCode: 'TIDESOL-91007',
        errorMessage: 'asset not found error'
    },
    'InvalidTokenError': {
        errorCode: 'TIDESOL-91008',
        errorMessage: 'invalid token error'
    },
    'ForbiddenError': {
        errorCode: 'TIDESOL-91009',
        errorMessage: 'forbidden request error'
    },
    'UnknownNtpServerError': {
        errorCode: 'TIDESOL-91011',
        errorMessage: 'unknown ntp sever'
    },
    'InternalServerError': {
        errorCode: 'TIDESOL-91012',
        errorMessage: 'internal server error'
    }
};
const IAM = {
    'ModelNotFound404Error': {
        errorCode: 'IAM-14005',
        errorMessage: 'organization with id ${id} does not exists'
    },
    'AuthorizationError': {
        errorCode: 'IAM-9001',
        errorMessage: 'current user is not authorized to perform this operation'
    }
};

module.exports = {
    TIDE,
    TIDESOL,
    IAM
};
