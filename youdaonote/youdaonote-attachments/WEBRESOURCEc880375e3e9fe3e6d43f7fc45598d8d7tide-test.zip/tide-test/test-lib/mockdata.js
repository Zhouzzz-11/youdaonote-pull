'use strict';

const {commonDict} = require('../test-lib/requireData');
const {Assert} = require('@rootcloud/darjeeling');

class DataBody {
    returnRandomStr(str) {
        let randomNumber = Math.random().toString().substr(2, 8);
        return `${str}_${randomNumber}`;
    }

    /*
        POST api/v1/auth/login
    */
    loginIAMBody(username, password, option = {}) {
        let loginIAMBody = {
            username: username,
            password: password || '123321',
            client_id: option.client_id || 'web_app',
            client_secret: option.client_secret || 'changeit',
            grant_type: option.grant_type || 'password',
        };
        return loginIAMBody;
    }

    /*
        POST api/v1/company
    */
    createCompanyIAMBody(option = {}) {
        const name = this.returnRandomStr('TideCompany');
        const username = this.returnRandomStr('superAdmin');
        let createCompanyIAMBody = {
            name: name,
            superAdmin: {
                username: username,
                email: `${Math.random().toString().substr(2, 11)}@rootcloud.com`,
                cellphone: `131${Math.random().toString().substr(2, 8)}`,
                password: option.password || '123321',
                exist: option.exist || 'false',
            },
            verified: option.verified || 'false',
            isOperator: option.isOperator || 'true',
        };
        return createCompanyIAMBody;
    }

    /*
        POST api/v1/user
    */
    createUserIAMBody(companyId, maincompanyId, option = {}) {
        const username = this.returnRandomStr('TideUser');
        const displayName = this.returnRandomStr('tideuser');
        let createUserIAMBody = {
            username: username,
            email: `${Math.random().toString().substr(2, 11)}@rootcloud.com`,
            nationCode: '86',
            cellphone: `131${Math.random().toString().substr(2, 8)}`,
            displayName: displayName,
            password: option.password || '123321',
            nationalIdNo: '342111111111',
            companies: companyId,
            mainCompany: maincompanyId,
            departments: option.department || [],
            roles: option.role || [],
            metadata: option.metadata || {},
        };
        return createUserIAMBody;
    }

    /*
        POST /auth/login (暂时先不做修改，该接口目前只用于临时登录，以后是直接使用IAM登录)
    */
    loginBody(userName, password) {
        let loginBody = {
            userName: userName,
            password: password
        };
        return loginBody;
    }

    /*
        POST /org
    */
    createOrgBody(orgId, orgName) {
        let createOrgBody = {
            orgId: orgId,
            orgName: orgName,
            mspId: 'Org1MSP'
        };
        return createOrgBody;
    }

    /*
        POST /company
    */
    activateCompanyBody(companyId) {
        let activateCompanyBody = {
            companyId: companyId
        };
        return activateCompanyBody;
    }

    /*
        POST /user
    */
    activateUserBody(userId, userName, orgId, userRole, option = {}) {
        let activateUserBody = {
            userId: userId,
            userName: userName,
            password: option.password || '123321',
            mobile: `131${Math.random().toString().substr(2, 8)}`,
            orgId: orgId,
            userRole: userRole
        };
        return activateUserBody;
    }

    createUserBody(updateBody = {}) {
        return this.updateJs(this.getDefaultUserBody(), updateBody);
    }

    updateJs(originBody, updateBody) {
        let copy_body;
        try {
            copy_body = JSON.stringify(originBody);
            copy_body = JSON.parse(copy_body);
        } catch (error) {
            Assert.fail('copy_body error');
        }

        if (updateBody) {
            for (let i in updateBody) {
                copy_body[i] = updateBody[i];
            }
        }
        return copy_body;
    }

    //POST /msc/resources
    createMscResourcesBody(classType, classValue) {
        var rBody;
        var randomNumber = parseInt(Math.random() * 100000000);
        switch (classType) {
            case 'User':
                rBody = {
                    '$class': classValue,
                    'name': 'mscResourcesUserName_' + randomNumber,
                    'id': 'mscResourcesUserId_' + randomNumber,
                    'org': 'resource:cn.gezhitech.tidemsc.model.Org#core',
                    'roles': ['resource:cn.gezhitech.tidemsc.model.Role#user']
                };
                break;
            // TODO  add different classtype
            case 'Role':
                rBody = {};
                break;
            default:
                rBody = {};
        }
        return rBody;
    }

    //POST /msc/invoke
    postInvokeBody(method, $class) {
        let postInvokeBody = {
            method: method,
            params: {
                $class: $class,
            },
        };
        return postInvokeBody;
    }

    //PATCH /api/v1/solution/evidence/text/{evidenceId}
    updateTextEvidenceBody(label) {
        let updateTextEvidenceBody = label ? {labels: [label]} : {labels: []};
        return updateTextEvidenceBody;
    }

    //PATCH /api/v1/solution/evidence/file/{evidenceId}
    updateFileEvidenceBody(label) {
        let updateFileEvidenceBody = label ? {labels: [label]} : {labels: []};
        return updateFileEvidenceBody;
    }
}

// BaaS的一个机构信息，包括管理员下的所有信息，普通用户的信息
class BaasOrg {
    constructor({superUser = '', user1 = '', user2 = ''} = {}) {
        this.superUser = superUser;
        this.normalUsers = {
            user1: user1,
            user2: user2
        };
    }
}

// 企业管理员信息
class SuperUser {
    constructor({iamLoginBody = '', orgId = '', email = '', cellphone = '', consortiaInfo = ''} = {}) {
        this.iamLoginBody = iamLoginBody;
        this.orgId = orgId;
        this.email = email;
        this.cellphone = cellphone;
        this.superToken = '';
        this.consortiaInfo = consortiaInfo;
    }
}

// 普通用户信息
class NormalUser {
    constructor({iamLoginBody = '', userId = '', userToken = ''} = {}) {
        this.iamLoginBody = iamLoginBody;
        this.userId = userId;
        this.userToken = userToken;
    }
}

const dataBody = new DataBody();

module.exports = {
    dataBody,
    BaasOrg,
    SuperUser,
    NormalUser
};
