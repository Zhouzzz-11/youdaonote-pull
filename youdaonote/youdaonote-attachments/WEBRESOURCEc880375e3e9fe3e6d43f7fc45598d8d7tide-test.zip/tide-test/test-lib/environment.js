'use strict';

const env = process.env;


module.exports = {
    BASE_URL: env.TEST_BASE_URL
};
