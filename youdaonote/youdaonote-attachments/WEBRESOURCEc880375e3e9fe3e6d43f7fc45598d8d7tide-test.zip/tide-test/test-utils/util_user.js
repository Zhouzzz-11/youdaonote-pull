'use strict';

const {getHttpClient} = require('@rootcloud/darjeeling-http');
const {TideNetworkManagerUrl, IAMGatewayUrl, IAMServiceManagementUrl} = require('../test-lib/url');
const {dataBody} = require('../test-lib/mockdata');
const httpClient = new getHttpClient();
const {topadmin} = require('../test-data/NetworkManager/BCP-60_auth_login_data');


async function user() {

    //超管登录
    let loginUserData = topadmin.loginIAMBody;
    const resp_postLogin = await httpClient.post(IAMGatewayUrl.login, {json: loginUserData});
    let token = JSON.parse(resp_postLogin.body).access_token;
    let __header = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    };
    //创建企业
    let postOrgData = dataBody.createCompanyIAMBody();
    const resp_postOrg = await httpClient.post(IAMGatewayUrl.company, {json: postOrgData, headers: __header});
    const body_postOrg = JSON.parse(resp_postOrg.body);
    // 企业授权
    const subCompanyBody = {
        service: 'rootchain',
        grantTo: body_postOrg.id
    };
    await httpClient.post(IAMServiceManagementUrl.subscription, {
        json: subCompanyBody,
        headers: __header
    });

    //创建用户
    let postUserData = dataBody.createUserIAMBody([body_postOrg.id], body_postOrg.id);
    const resp_postUser = await httpClient.post(IAMGatewayUrl.user, {json: postUserData, headers: __header});
    const body_postUser = JSON.parse(resp_postUser.body);
    //激活企业
    let activeOrgData = dataBody.activateCompanyBody(body_postOrg.id);
    await httpClient.post(TideNetworkManagerUrl.company, {json: activeOrgData, headers: __header});
    //激活用户
    let activeUserData = dataBody.activateUserBody(body_postUser.id, body_postUser.username, body_postOrg.id, ['user']);
    await httpClient.post(TideNetworkManagerUrl.user, {json: activeUserData, headers: __header});

    let baasOrgInfo = {
        superUser: {
            loginIAMBody: dataBody.loginIAMBody(postOrgData.superAdmin.username, postOrgData.superAdmin.password),
            orgIdId: body_postOrg.id,
            email: postOrgData.superAdmin.email,
            cellphone: postOrgData.superAdmin.cellphone,
            superToken: '',
            consortiaArray: []
        },
        normalUser: {
            loginIAMBody: dataBody.loginIAMBody(postUserData.username, postUserData.password),
            uerId: body_postUser.id,
            userToken: ''
        }
    };
    return baasOrgInfo;
}

//获取请求头,包含token
async function getHeaders(loginUserData) {
    //登录
    const resp_postLogin = await httpClient.post(IAMGatewayUrl.login, {json: loginUserData});
    let token = JSON.parse(resp_postLogin.body).access_token;
    let headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    };
    return headers;
}


//IAM创建企业,返回企业Id
async function iamCreatOrg(headers) {

    //创建企业
    let postOrgData = dataBody.createCompanyIAMBody();
    let resp = await httpClient.post(IAMGatewayUrl.company, {json: postOrgData, headers: headers});
    let body_postOrg = JSON.parse(resp.body);
    let respBody = {
        companyId: body_postOrg.id,
        companyUserName: postOrgData.superAdmin.username,
        companyUserPassword: postOrgData.superAdmin.password,
        companyEmail: postOrgData.superAdmin.email,
        companyCellphone: postOrgData.superAdmin.cellphone,
        statusCode: resp.statusCode
    };
    return respBody;
}

// IAM授权企业
async function subscribeCompany(headers, companyId) {
    // 企业授权
    let subCompanyBody = {
        service: 'rootchain',
        grantTo: companyId
    };
    let rsp = await httpClient.post(IAMServiceManagementUrl.subscription, {
        json: subCompanyBody,
        headers: headers
    });
    return rsp;
}


//IAM创建用户
async function createUser(headers, companyId) {
    let postUserData = dataBody.createUserIAMBody([companyId], companyId);
    let resp_postUser = await httpClient.post(IAMGatewayUrl.user, {json: postUserData, headers: headers});
    let body_postUser = JSON.parse(resp_postUser.body);
    let respBody = {
        userId: body_postUser.id,
        username: body_postUser.username,
        statusCode: resp_postUser.statusCode
    };
    return respBody;
}

//tide的network-manager激活企业
async function activateCompany(headers, companyId) {
    let activeOrgData = dataBody.activateCompanyBody(companyId);
    let rsp = await httpClient.post(TideNetworkManagerUrl.company, {json: activeOrgData, headers: headers});
    return rsp;
}

//tide的network-manager激活普通用户
async function activateUser(headers, userId, userName, orgId) {
    //激活用户
    let activeUserData = dataBody.activateUserBody(userId, userName, orgId, ['user']);
    let rsp = await httpClient.post(TideNetworkManagerUrl.user, {json: activeUserData, headers: headers});
    return rsp;
}

// 创建测试需要的一个企业的全部信息，包括，企业管理员信息，两个普通用户
async function creatFullOrg(baasOrg) {
    // 获取超管的请求头，主要是token
    let headers = await getHeaders();
    // IAM创建企业
    let companyId, companyUserName, companyEmail, companyCellphone = await iamCreatOrg(headers);
    // IAM授权企业
    await subscribeCompany(headers, companyId);
    // IAM创建用户
    let user1Id, user1name = await createUser(headers, companyId);
    let user2Id, user2name = await createUser(headers, companyId);
    // tide network-manager激活企业
    await activateCompany(headers, companyId);
    await activateUser(headers, user1Id, user1name, companyId);
    await activateUser(headers, user2Id, user2name, companyId);
    baasOrg.superUser.iamLoginBody.orgId = companyId;
    baasOrg.superUser.iamLoginBody.username = companyUserName;
    baasOrg.superUser.iamLoginBody.email = companyEmail;
    baasOrg.superUser.iamLoginBody.cellphone = companyCellphone;
    Object.assign(baasOrg.superUser.iamLoginBody, {
        orgId: companyId,
        username: companyUserName,
        email: companyEmail,
        cellphone: companyCellphone
    });
    baasOrg.normalUser.user1.iamLoginBody.username = user1name;
    baasOrg.normalUser.user2.iamLoginBody.username = user2name;
}


module.exports = {
    user,
    creatFullOrg,
    getHeaders,
    iamCreatOrg,
    subscribeCompany,
    createUser,
    activateCompany,
    activateUser
};