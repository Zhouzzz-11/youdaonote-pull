'use strict';

const _ = require('lodash');
const {Assert} = require('@rootcloud/darjeeling');
const promiseRetry = require('promise-retry');
const Moment = require('moment');


function randomString({length = null, chars = '0123456789abcdefghijklmnopqrstuvwxyz'} = {}) {
    let result = '';
    if (length) {
        for (let i = length; i > 0; --i) {
            result += chars[Math.floor(Math.random() * chars.length)];
        }
    } else {
        result = `test_${Moment.utc().format('YYYYMMDD')}_${parseInt(Math.random() * 100000000)}`;
    }
    return result;
}

function getJsonBody(response) {

    try {
        return JSON.parse(response.body.toString());
    } catch (exc) {
        Assert.fail(`Response body does NOT appear to be valid JSON: ${exc.message}`);
    }
}

function processObject(obj) {
    for (let attr in obj) {
        if (obj[attr] === undefined) delete obj[attr];
        else if (typeof obj[attr] == 'object') {
            processObject(obj[attr]);
        }
    }
}

function saveData(sData, key1, pData, key2) {

    it('Save data', async () => {
        sData[key1] = pData.getData(key2);
    });
}

function getHeadersWithBearer(token) {
    return {
        Authorization: `Bearer ${token}`
    };
}

class MaxRetriesExceededError extends Error {
    constructor(message) {
        super(message);
        Object.setPrototypeOf(this, MaxRetriesExceededError.prototype);
    }
}

async function retryRequest(options, action, shouldRetry) {
    return await promiseRetry(options, async (retry) => {
        const response = await action();
        if (shouldRetry(response)) {
            return retry(new MaxRetriesExceededError('shouldRetry returned true'));
        }
        return response;
    });
}

function itWait(delayMs) {
    it(`Wait ${delayMs}ms`, function (done) {
        this.timeout = delayMs + 1000;
        setTimeout(function () {
            done();
        }, delayMs);
    });
}

/**
 * 排序函数
 * @param attribute：根据对象的属性进行排序
 * @param isDesc：是否是倒序
 * @returns {Function}：返回排序函数
 */
function orderByAttribute(attribute, isDesc) {
    return function (obj1, obj2) {
        if (obj1[attribute] > obj2[attribute]) {
            return isDesc ? -1 : 1;
        } else if (obj1[attribute] < obj2[attribute]) {
            return isDesc ? 1 : -1;
        } else {
            return 0;
        }
    };
}

/*
* 对需要排序的数组先深度copy,再对copy后的数组进行排序
* 返回排序后的copy数组
* @params sorts:["title","createdAt,desc"]
* @return copyArrays
* */
function resultsSort(arrays, sorts) {
    let copyArrays = deepCopy(arrays);
    bubbleSort(copyArrays, (v1, v2) => {
        let flag = 0;
        for (let props of sorts) {
            let [prop, orderBy] = props.trim().split(',');
            if (v1[prop] < v2[prop]) {
                flag = orderBy === 'desc' ? 1 : -1;
                break;
            } else if (v1[prop] > v2[prop]) {
                flag = orderBy === 'desc' ? -1 : 1;
                break;
            } else {
                continue;
            }
        }
        return flag;
    });
    return copyArrays;
}

function deepCopy(obj) {
    let temp = obj.constructor === Array ? [] : {};
    for (let val in obj) {
        if (obj[val] === null) {
            temp[val] = null;
        } else {
            temp[val] = typeof obj[val] == 'object' ? deepCopy(obj[val]) : obj[val];
        }
    }
    return temp;
}

function bubbleSort(array, compareFn) {
    let n = array.length;
    let i, j, temp;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (compareFn(array[j], array[j + 1]) > 0) {
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
}


function getRspValue(responseBody, jsonPath) {
    let value;
    if (typeof responseBody === 'string') {
        value = _.get(JSON.parse(responseBody), jsonPath);
    } else {
        value = _.get(responseBody, jsonPath);
    }
    return value !== undefined ? value : {};
}

function isSorted(arr, attr, isDesc = false) {
    let flag = true;
    for (let i = 0; i < arr.length - 1; i++) {
        if (String(arr[i][`${attr}`]) < String(arr[i + 1][`${attr}`])) {
            flag = !isDesc;
        } else if (String(arr[i][`${attr}`]) > String(arr[i + 1][`${attr}`])) {
            flag = isDesc;
        } else {
            continue;
        }
        if (!flag) {
            return flag;
        }
    }
    return flag;
}

module.exports = {
    getJsonBody,
    processObject,
    saveData,
    getHeadersWithBearer,
    retryRequest,
    itWait,
    randomString,
    orderByAttribute,
    resultsSort,
    getRspValue,
    deepCopy,
    isSorted
};
