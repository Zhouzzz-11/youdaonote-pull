'use strict';

const {getHttpClient} = require('@rootcloud/darjeeling-http');
const {IAMOpenAPIUrl, IAMGatewayUrl, TideNetworkManagerUrl} = require('../test-lib/url');
const {topadmin} = require('../test-data/NetworkManager/BCP-60_auth_login_data');
const httpClient = new getHttpClient();
const {user} = require('./util_user');
const env = process.env.CURRENT_ENV;
let IAMUrl;

if (env === 'pre' || env === 'prod') {
    IAMUrl = IAMOpenAPIUrl;
} else {
    IAMUrl = IAMGatewayUrl;
}


// tokenOrUserData： string: token or object: UserData;
// UserData.token或loginReqBody登录获取token,返回该token
async function getToken(tokenOrUserData = topadmin) {

    let token = '';
    if (typeof tokenOrUserData === 'string') {
        token = tokenOrUserData;
    } else if (tokenOrUserData.token) {
        token = tokenOrUserData.token;
    } else if (tokenOrUserData === topadmin) {
        let userData = tokenOrUserData;
        const resp = await httpClient.post(`${IAMUrl.login}`, {json: userData.reqBody});
        const loginJsBody = JSON.parse(resp.body);
        userData.token = loginJsBody.access_token;
        token = loginJsBody.access_token;
    } else if (tokenOrUserData.username) {
        let userData = tokenOrUserData;
        const resp = await httpClient.post(`${IAMUrl.login}`, {json: userData});
        const loginJsBody = JSON.parse(resp.body);
        token = loginJsBody.access_token;
    }
    return token;
}

//proxy登录
async function getTideToken(tokenOrUserData = topadmin) {
    let token = '';
    if (typeof tokenOrUserData === 'string') {
        token = tokenOrUserData;
    } else if (tokenOrUserData.token) {
        token = tokenOrUserData.token;
    } else if (tokenOrUserData === topadmin) {
        let userData = tokenOrUserData;
        const resp = await httpClient.post(`${TideNetworkManagerUrl.login}`, {json: userData.reqBody});
        const loginJsBody = JSON.parse(resp.body);
        userData.token = loginJsBody.payload.token;
        token = loginJsBody.payload.token;
    } else if (tokenOrUserData.reqBody.userName) {
        let userData = tokenOrUserData;
        const resp = await httpClient.post(`${TideNetworkManagerUrl.login}`, {json: userData.reqBody});
        const loginJsBody = JSON.parse(resp.body);
        userData.token = loginJsBody.payload.token;
        token = loginJsBody.payload.token;
    }
    return token;
}

module.exports = {getToken, getTideToken};
