'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {getHttpClient} = require('@rootcloud/darjeeling-http');
const httpClient = new getHttpClient();

async function httpRequestAsync(method = 'post', url, headers, reqBody, isJson = true) {
    let resp;
    let response = {};

    switch (method) {
        case 'post':
            resp = await httpClient.post(url, {json: reqBody, headers: headers});
            break;
        case 'get':
            resp = await httpClient.get(url, {headers: headers});
            break;
        case 'put':
            if (isJson) {
                resp = await httpClient.put(url, {json: reqBody, headers: headers});
            } else {
                resp = await httpClient.put(url, {body: reqBody, headers: headers});
            }
            break;
        case 'patch':
            resp = await httpClient.patch(url, {json: reqBody, headers: headers});
            break;
        case 'delete':
            resp = await httpClient.delete(url, {headers: headers});
            break;
        default:
            Assert.fail(`httpRequest method 暂未支持${method},请添加。`);
    }
    if (resp.body) {
        response = JSON.parse(resp.body);
    }
    response.statusCode = resp.statusCode;
    return response;
}

module.exports = {httpRequestAsync};