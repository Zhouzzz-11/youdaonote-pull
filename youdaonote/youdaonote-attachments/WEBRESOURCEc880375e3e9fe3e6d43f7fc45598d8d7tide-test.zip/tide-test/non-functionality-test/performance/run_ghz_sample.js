const execa = require('execa');

const cert =
  process.env.CERT ||
  '-----BEGIN CERTIFICATE-----\\nMIICEDCCAbWgAwIBAgIQEq4oLJsyZg8OmUiMplxABTAKBggqhkjOPQQDAjBzMQsw\\nCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNU2FuIEZy\\nYW5jaXNjbzEZMBcGA1UEChMQb3JnMS5leGFtcGxlLmNvbTEcMBoGA1UEAxMTY2Eu\\nb3JnMS5leGFtcGxlLmNvbTAeFw0yMDA5MjgwODA2MTRaFw0zMDA5MjYwODA2MTRa\\nMCMxITAfBgNVBAMMGDVmNzE5OTcwMTRhYTcyMDA0NjE2N2YxMzBZMBMGByqGSM49\\nAgEGCCqGSM49AwEHA0IABPpCOK2zHuOSBQ+vHauEbj1f6XXt4uxsRNm/FctnCEVq\\nSH8chTMVI2cvNTRMubm5dlx6fvNI9dBmw3fjZK4rUmOjezB5MBMGA1UdJQQMMAoG\\nCCsGAQUFBwMBMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgWgMB0GA1UdDgQWBBSxcZKD\\nGg5e+Ozj+3+Y7V/0HfrlTDArBgNVHSMEJDAigCCSDihwFuZSjdoly7QnCnhAYvlh\\n2FGNAgStGx/oZGoHjzAKBggqhkjOPQQDAgNJADBGAiEA6mPxG9wpvdLsrByV+5vt\\nkU+GMLlrj8HJSzbGFnR9w5YCIQDUyvcFf6K9isbGDmIx+xg7XXL0OOsmjdvPExbH\\nreoVaA==\\n-----END CERTIFICATE-----';
const host = process.env.HOST || 'localhost:1036';

(async () => {
    // create a Config asset
    // const { stdout: s1 } = await execa("ghz", [
    //   "--insecure",
    //   "--call",
    //   "cn.gezhitech.tidemsc.offchain.service.OffChainPeer.invoke",
    //   "-d",
    //   `{"chaincodeName": "local-default-channel/tidemsc","functionName": "submitTransaction","args": ["{\\"resources\\": [{\\"$class\\": \\"cn.gezhitech.tidemsc.model.Config\\",\\"key\\": \\"{{ randomString 8 }}\\",\\"value\\": \\"{{ randomString 8 }}\\"}],\\"updateExisting\\": false,\\"$class\\":\\"org.hyperledger.composer.system.AddAsset\\",\\"targetRegistry\\":\\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.tidemsc.model.Config\\"}"],"certificate": "${cert}"}`,
    //   host,
    // ]);
    // console.log(s1);

    // create a TextEvidence asset
    const { stdout: s2 } = await execa('ghz', [
        '--insecure',
        '--call',
        'cn.gezhitech.tidemsc.offchain.service.OffChainPeer.invoke',
        '-d',
        `{"chaincodeName": "local-default-channel/tidemsc","functionName": "submitTransaction","args": ["{\\"resources\\":[{\\"evidenceId\\":\\"{{.RequestNumber}}\\",\\"title\\":\\"ABC\\",\\"dataHash\\":\\"ABC\\",\\"content\\":\\"sample text\\",\\"labels\\":[\\"labels\\"],\\"metadata\\":{\\"key\\":\\"value\\"},\\"isPublic\\":true,\\"signature\\":\\"example signature\\",\\"comments\\":\\"sample comments\\",\\"$class\\":\\"cn.gezhitech.digitalevidence.asset.TextEvidence\\"}],\\"updateExisting\\":false,\\"$class\\":\\"org.hyperledger.composer.system.AddAsset\\",\\"targetRegistry\\":\\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\\"}"],"certificate": "${cert}}"}`,
        host,
    ]);
    console.log(s2);

    // query a TextEvidence asset (without blockinfo)
    const { stdout: s3 } = await execa('ghz', [
        '--insecure',
        '--call',
        'cn.gezhitech.tidemsc.offchain.service.OffChainPeer.query',
        '-d',
        `{"chaincodeName": "local-default-channel/tidemsc","functionName": "getResourceInRegistry","args":["Asset","cn.gezhitech.digitalevidence.asset.TextEvidence","ABC"],"certificate": "${cert}"}`,
        host,
    ]);
    console.log(s3);

    // query a TextEvidence asset (blockInfo)
    const { stdout: s4 } = await execa('ghz', [
        '--insecure',
        '--call',
        'cn.gezhitech.tidemsc.offchain.service.OffChainPeer.query',
        '-d',
        `{"chaincodeName": "local-default-channel/tidemsc","functionName": "getResourceHistory","args":["Asset","cn.gezhitech.digitalevidence.asset.TextEvidence","ABC","true","{}","{\\"doResolve\\":false}"],"certificate": "${cert}"}`,
        host,
    ]);
    console.log(s4);
})();
