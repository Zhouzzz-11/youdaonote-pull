#!/bin/bash

# create an asset
# ["{\"resources\":[{\"evidenceId\":\"ABC\",\"title\":\"ABC\",\"content\":\"sample text\",\"isPublic\":true,\"signature\":\"example signature\",\"comments\":\"sample comments\",\"$class\":\"cn.gezhitech.digitalevidence.asset.TextEvidence\"}],\"updateExisting\":false,\"$class\":\"org.hyperledger.composer.system.AddAsset\",\"targetRegistry\":\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\"}"]
payload='{"chaincodeName": "local-default-channel/tidemsc", 
    "functionName": "submitTransaction", 
    "args":["{\"resources\":[{\"evidenceId\":\"ABC\",\"title\":\"ABC\",\"content\":\"sample text\",\"isPublic\":true,\"signature\":\"example signature\",\"comments\":\"sample comments\",\"$class\":\"cn.gezhitech.digitalevidence.asset.TextEvidence\"}],\"updateExisting\":false,\"$class\":\"org.hyperledger.composer.system.AddAsset\",\"targetRegistry\":\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\"}"], 
    "certificate": "CERT"}'
grpcurl -d "${payload//CERT/$CERT}" -plaintext localhost:1036 cn.gezhitech.tidemsc.offchain.service.OffChainPeer.invoke

# query an asset
payload='{"chaincodeName": "local-default-channel/tidemsc", 
    "functionName": "getResourceHistory", 
    "args":["Asset","cn.gezhitech.digitalevidence.asset.TextEvidence","ABC","true","{}","{\"doResolve\":false}"], 
    "certificate": "CERT"}'
grpcurl -d "${payload//CERT/$CERT}" -plaintext localhost:1036 cn.gezhitech.tidemsc.offchain.service.OffChainPeer.query

# update an asset
# ["{\"resources\":[{\"$class\":\"cn.gezhitech.digitalevidence.asset.TextEvidence\",\"comments\":\"sample comments\",\"signature\":\"example signature\",\"evidenceId\":\"ABC\",\"isPublic\":true,\"title\":\"ABCD\",\"type\":\"TextEvidence\",\"content\":\"sample text\"}],\"targetRegistry\":\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\",\"$class\":\"org.hyperledger.composer.system.UpdateAsset\"}"]
payload='{"chaincodeName": "local-default-channel/tidemsc", 
    "functionName": "submitTransaction", 
    "args":["{\"resources\":[{\"$class\":\"cn.gezhitech.digitalevidence.asset.TextEvidence\",\"comments\":\"sample comments\",\"signature\":\"example signature\",\"evidenceId\":\"ABC\",\"isPublic\":true,\"title\":\"ABCD\",\"type\":\"TextEvidence\",\"content\":\"sample text\"}],\"targetRegistry\":\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\",\"$class\":\"org.hyperledger.composer.system.UpdateAsset\"}"], 
    "certificate": "CERT"}'
grpcurl -d "${payload//CERT/$CERT}" -plaintext localhost:1036 cn.gezhitech.tidemsc.offchain.service.OffChainPeer.invoke

# delete an asset
# ["{\"$class\":\"org.hyperledger.composer.system.RemoveAsset\",\"resourceIds\":[\"ABC\"],\"resources\":[],\"targetRegistry\":\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\"}"]
payload='{"chaincodeName": "local-default-channel/tidemsc", 
    "functionName": "submitTransaction", 
    "args":["{\"$class\":\"org.hyperledger.composer.system.RemoveAsset\",\"resourceIds\":[\"ABC\"],\"resources\":[],\"targetRegistry\":\"resource:org.hyperledger.composer.system.AssetRegistry#cn.gezhitech.digitalevidence.asset.TextEvidence\"}"],
    "certificate": "CERT"}'
grpcurl -d "${payload//CERT/$CERT}" -plaintext localhost:1036 cn.gezhitech.tidemsc.offchain.service.OffChainPeer.invoke
