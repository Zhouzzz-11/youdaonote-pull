#!/bin/bash

#获得随机数返回值，shell函数里算出随机数后，更新该值
function random()
{
    len=$1
    num=$(date +%s);
    ((retnum=num%service_length));
    selecteditem=${service_arr[${retnum}]}
    echo $selecteditem;
}

function main()
{
    svc_name=$1
    period_time=$2
    service_arr=("evidence" "tide-msc-proxy" "orderer" "mongodb" "redis-cluster")
    if [[ "${svc_name}" = "all" ]];then
        echo "full chaos test"
    elif [[ ! "${service_arr[@]}" =~ "${svc_name}" ]];then
        echo "service $svc_name not exists"
        exit 1
    else
        service_arr=("${svc_name}")
    fi
    
    service_length=${#service_arr[*]}
    while true
    do
        selected_service=$(random service_length)
        random_num="$(date +%s)"
        sed "s/delete-one-pod-by-labels/delete-one-pod-by-labels-${random_num}/g" delete_pod_by_labels.yaml > delete_pod.yaml
        if [ $(echo ${selected_service} | grep "mongo\|redis") ];then
            sed -i "s/app=evidence/app.kubernetes.io\/name=${selected_service}/g" delete_pod.yaml
        else           
            sed -i "s/app=evidence/app=${selected_service}/g" delete_pod.yaml
        fi
        date_time=$(date +"%Y-%m-%d %H:%M:%S")
        echo "================================================  ${date_time} start kill ${selected_service} pod ========================================="
        kubectl apply -f delete_pod.yaml
        sleep $period_time
        kubectl get blade delete-one-pod-by-labels-${random_num} -o json
        kubectl delete -f delete_pod.yaml
    done
}

main  $@