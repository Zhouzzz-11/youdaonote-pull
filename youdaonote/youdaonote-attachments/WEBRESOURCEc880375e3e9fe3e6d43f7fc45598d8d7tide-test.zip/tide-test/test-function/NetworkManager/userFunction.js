`use strict`;

const {TideNetworkManagerUrl, IAMGatewayUrl} = require('../../test-lib/url');
const {httpRequestAsync} = require('../../test-utils/util_httpRequest');
const {getToken, getTideToken} = require('../../test-utils/util_token');
const jwt = require('jsonwebtoken');
const {user} = require('../../test-utils/util_user');
const {update} = require('lodash');


/*
    POST api/v1/auth/login
*/
async function loginIAMAsync(reqBody, tokenOrUserData) {
    let url = IAMGatewayUrl.login;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, tokenOrUserData, params);
}

/*
    POST api/v1/company
*/
async function createCompanyIAMAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = IAMGatewayUrl.company;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    POST api/v1/user
*/
async function createUserIAMAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = IAMGatewayUrl.user;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    POST /auth/login
*/
async function loginTIDEAsync(reqBody, tokenOrUserData) {
    let url = TideNetworkManagerUrl.login;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, tokenOrUserData, params);
}

/*
    POST /company
*/
async function activateCompanyAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.company;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    POST /org
*/
async function createOrgAsync(reqBody, tokenOrUserData) {
    let token = await getTideToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.org;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    POST /user
    tide内创建用户，不走iam
*/
async function createUserAsync(reqBody, tokenOrUserData) {
    let token = await getTideToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.user;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    POST /user
*/
async function activateUserAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.user;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    GET /company/{id}/employee
*/
async function getUserByCompanyIdAsync(companyId, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.company}/${companyId}/employee`;
    var params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/*
    GET /company/{id}
*/
async function getCompanyByCompanyIdAsync(companyId, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.company}/${companyId}`;
    var params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/*
    GET /user/Probe/{id}
*/
async function getUserByUserIdAsync(userId, token) {
    let url = `${TideNetworkManagerUrl.userProbe}/${userId}`;
    let userinfo = await httpRequestAsync('get', url, token);
    return userinfo;
}

//根据token解析出userId
async function getUserId(token) {
    const resp = jwt.decode(token);
    const userId = resp.user.id;
    return userId;
}

/**
 * 获取用户所属的网络信息
 */
async function getNetwork(loginUserData) {
    let token = await getToken(loginUserData);
    let userId = await getUserId(token);
    let userinfoRsp = await getUserByUserIdAsync(userId, token);
    let userInfo = JSON.parse(userinfoRsp.body);
    let netId = userInfo.payload.networks;
    return netId;
}

/**
 * 用户切换网络
 */
async function switchNetwork(tokenOrUserData, req) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.switchNetwork}`;
    let params = {reqBody: req};
    return await httpRequestAsync('post', url, token, params);
}


async function getCompanyId(tokenOrUserData = topadmin) {
    let token = await getToken(tokenOrUserData);
    const resp = jwt.decode(token);
    const companyId = resp.activeCompany.id;
    return companyId;
}

//  IAM更新企业
async function updateIAMCompany(companyId, headers) {
    let url = `${IAMGatewayUrl.company}/${companyId}`;
    let reqBody = {
        'isOperator': 'false'
    };
    return await httpRequestAsync('put', url, headers, reqBody);
}

//  IAM删除企业
async function deleteIAMCompany(companyId, headers) {
    let url = `${IAMGatewayUrl.company}/${companyId}`;
    return await httpRequestAsync('delete', url, headers);
}

// IAM删除用户
async function deleteIAMUser(userId, headers) {
    let url = `${IAMGatewayUrl.user}/${userId}`;
    return await httpRequestAsync('delete', url, headers);
}


module.exports = {
    loginIAMAsync,
    createCompanyIAMAsync,
    createUserIAMAsync,
    loginTIDEAsync,
    activateCompanyAsync,
    activateUserAsync,
    getUserByCompanyIdAsync,
    getCompanyByCompanyIdAsync,
    getUserByUserIdAsync,
    getUserId,
    getCompanyId,
    getNetwork,
    switchNetwork,
    updateIAMCompany,
    deleteIAMCompany,
    deleteIAMUser,
    createOrgAsync,
    createUserAsync,
};