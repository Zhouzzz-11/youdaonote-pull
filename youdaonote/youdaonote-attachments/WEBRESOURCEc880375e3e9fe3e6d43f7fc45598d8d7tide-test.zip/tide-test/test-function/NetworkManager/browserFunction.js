'use strict';

const {TideNetworkManagerUrl} = require('../../test-lib/url');
const {httpRequestAsync} = require('../../test-utils/util_httpRequest');
const {getToken} = require('../../test-utils/util_token');


/*
    GET /msc/provenance/browser/count
*/
async function getBlockCount(tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.browser}/count`;
    return await httpRequestAsync('get', url, token);
}


/*
    GET /msc/provenance/browser/blocks
*/
async function getBlockList(tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.browser}/blocks`;
    var params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

module.exports = {
    getBlockCount,
    getBlockList,
};