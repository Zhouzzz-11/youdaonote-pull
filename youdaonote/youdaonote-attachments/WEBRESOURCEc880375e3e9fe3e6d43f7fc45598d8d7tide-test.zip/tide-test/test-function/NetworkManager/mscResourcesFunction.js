//Add resuable function used in your test script into this file

'use strict';

const {TideNetworkManagerUrl} = require('../../test-lib/url');
const {httpRequestAsync} = require('../../test-utils/util_httpRequest');
const {getToken} = require('../../test-utils/util_token');

/**
 * Post  /msc/resources
 * @param reqBody
 * @param tokenOrUserData
 * @param responsePutter
 */
async function createMscResource(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    const mscResourcesUrl = TideNetworkManagerUrl.resources;
    const queryString = '$class=' + reqBody['$class'];
    const params = {reqBody: reqBody, queryString: queryString};
    return await httpRequestAsync('post', mscResourcesUrl, token, params);
}

/**
 *  Put /msc/resources
 * @param reqBody
 * @param tokenOrUserData
 * @param responsePutter
 */
async function updateMscResource(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);

    const mscResourcesUrl = TideNetworkManagerUrl.resources + '?$class=' + reqBody['$class'];
    const params = {reqBody: reqBody};
    return await httpRequestAsync('put', mscResourcesUrl, token, params);
}

/**
 * Delete /msc/resources/{id}
 * @param reqBody
 * @param tokenOrUserData
 * @param responsePutter
 */
async function deleteMscResource(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let mscResourcesUrl = TideNetworkManagerUrl.resources + `/${reqBody.id}`;
    const queryString = '$class=' + reqBody['$class'];
    const params = {queryString: queryString};
    return await httpRequestAsync('delete', mscResourcesUrl, token, params);
}

/**
 *  Get /msc/resources/{id}
 * @param reqBody
 * @param tokenOrUserData
 * @param responsePutter
 */
async function getMscResourceById(reqBody, resolve = false, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let mscResourcesUrl = TideNetworkManagerUrl.resources + `/${reqBody.id}`;
    let queryString;
    if (resolve) {
        queryString = '$class=' + reqBody['$class'] + '&resolve=' + reqBody['resolve'];
    } else {
        queryString = '$class=' + reqBody['$class'];
    }
    const params = {queryString: queryString};
    return await httpRequestAsync('get', mscResourcesUrl, token, params);
}

/**
 * Get /msc/resources
 * @param reqBody
 * @param tokenOrUserData
 * @param responsePutter
 * @param queryObject
 */
async function getMscResources(queryObject, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let mscResourcesUrl = TideNetworkManagerUrl.resources;
    var queryStr = '';
    var queryString;
    for (let key in queryObject) {
        let link = '&' + key + '=' + queryObject[key];
        queryStr += link;
    }
    queryString = queryStr.substr(1);
    const params = {queryString: queryString};
    return await httpRequestAsync('get', mscResourcesUrl, token, params);
}


/*
	Get  /msc/provenance/{id}
 */
async function getProvenanceListByID(id, options = {}, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.provenance}/${id}`;
    var params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}


/*
	POST  /msc/invoke
 */
async function postInvoke(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.invoke;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

module.exports = {
    createMscResource,
    updateMscResource,
    getMscResourceById,
    deleteMscResource,
    getMscResources,
    getProvenanceListByID,
    postInvoke,
};
