'use strict';

const {TideNetworkManagerUrl} = require('../../test-lib/url');
const {httpRequestAsync} = require('../../test-utils/util_httpRequest');
const {getToken} = require('../../test-utils/util_token');


/**
 *
 * @param reqBody
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function createConsortia(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    const consortiaUrl = TideNetworkManagerUrl.consortia;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', consortiaUrl, token, params);
}

/**
 *
 * @param reqBody
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function getConsortiaById(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let consortiaUrl = TideNetworkManagerUrl.resources + `/${reqBody.id}`;
    return await httpRequestAsync('get', consortiaUrl, token);
}

/**
 *
 * @param reqBody
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function deleteConsortia(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let consortiaUrl = TideNetworkManagerUrl.resources + `/${reqBody.id}`;
    return await httpRequestAsync('delete', consortiaUrl, token);
}

async function queryConsortiaStatus(consortiaId, networkCode, orgSuperHeaders) {
    let consortiaStatusInfo = await httpRequestAsync('get', TideNetworkManagerUrl.consortia +
        `/${consortiaId}/networks/${networkCode}`, orgSuperHeaders);
    return consortiaStatusInfo;
}

async function queryAppStatus(consortiaId, applicationId, channelCode, orgSuperHeaders) {
    let consortiaStatusInfo = await httpRequestAsync('get', TideNetworkManagerUrl.consortia +
        `/${consortiaId}/applications/${applicationId}/channels/${channelCode}`, orgSuperHeaders);
    return consortiaStatusInfo;
}


function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = {
    createConsortia,
    getConsortiaById,
    deleteConsortia,
    queryConsortiaStatus,
    queryAppStatus,
    sleep
};
