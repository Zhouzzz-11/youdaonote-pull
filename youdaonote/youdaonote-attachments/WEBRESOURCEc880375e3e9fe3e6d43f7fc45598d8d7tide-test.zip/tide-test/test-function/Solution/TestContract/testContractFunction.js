'use strict';

const {TideNetworkManagerUrl} = require('../../../test-lib/url');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getToken} = require('../../../test-utils/util_token');


/**
 *
 * @param reqBody
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function createAssertAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.testContractAssert;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/**
 *
 * @param tokenOrUserData
 * @returns {Promise<void>}
 */
async function getAssertsAsync(tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.testContractAssert;
    return await httpRequestAsync('get', url, token);
}

/**
 *
 * @param accountId
 * @param reqBody
 * @param tokenOrUserData
 * @param options
 * @returns {Promise<void>}
 */
async function updateAssertByIdAsync(accountId, reqBody, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.testContractAssert}/${accountId}`;
    var params;
    if (options.queryString) {
        params = {reqBody: reqBody, queryString: options.queryString};
    } else {
        params = {reqBody: reqBody};
    }
    return await httpRequestAsync('put', url, token, params);
}

/**
 *
 * @param accountId
 * @param tokenOrUserData
 * @returns {Promise<void>}
 */
async function deleteAssertByIdAsync(accountId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${TideNetworkManagerUrl.testContractAssert}/${accountId}`;
    return await httpRequestAsync('delete', url, token);
}

/**
 *
 * @param reqBody
 * @param tokenOrUserData
 * @param queryString
 * @returns {Promise<*>}
 */
async function createByTransactionAsync(reqBody, tokenOrUserData, queryString) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.testContractTransaction;
    const params = {reqBody: reqBody};
    if (queryString) {
        params.queryString = queryString;
    }
    return await httpRequestAsync('post', url, token, params);
}

/**
 *
 * @param accountId
 * @param tokenOrUserData
 * @param options
 * @returns {Promise<*>}
 */
async function getByTransactionAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.testContractTransaction;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/**
 *
 * @param accountId
 * @param reqBody
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function deleteByTransactionAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.testContractTransaction;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/**
 *
 * @param reqBody
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function transferTransactionAsync(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = TideNetworkManagerUrl.testContractTransaction;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

module.exports = {
    createAssertAsync,
    getAssertsAsync,
    updateAssertByIdAsync,
    deleteAssertByIdAsync,
    createByTransactionAsync,
    getByTransactionAsync,
    deleteByTransactionAsync,
    transferTransactionAsync
};
