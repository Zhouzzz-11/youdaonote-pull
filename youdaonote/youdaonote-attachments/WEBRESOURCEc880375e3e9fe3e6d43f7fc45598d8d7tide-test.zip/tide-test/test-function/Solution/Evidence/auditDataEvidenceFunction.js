'use strict';

const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getTideToken} = require('../../../test-utils/util_token');



/*
   Post api/v1/bulk/audit-data
*/
async function createAuditDataEvidence(reqBody, tokenOrUserData, options = {}) {
    let token = await getTideToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.auditDataEvidence}`;
    var params = {reqBody: reqBody};
    if(options.param){
        params = {reqBody: reqBody, queryString: options.param};
    }
    return await httpRequestAsync('post', url, token, params);
}

/*
   Post api/v1/verification
*/
async function verifyAuditDataEvidence(reqBody, tokenOrUserData) {
    let token = await getTideToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.verifyAudit}`;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
   Get api/v1/audit-data
*/
async function queryAuditDataEvidence(tokenOrUserData, options = {}) {
    let token = await getTideToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.queryAudit}`;
    var params;
    if(options.queryString){
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/*
   delete api/v1/audit-data/{evidenceId}
*/
async function deleteAuditDataEvidence(evidenceId, tokenOrUserData) {
    let token = await getTideToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.queryAudit}/${evidenceId}`;
    return await httpRequestAsync('delete', url, token);
}

module.exports = {
    createAuditDataEvidence,
    verifyAuditDataEvidence,
    queryAuditDataEvidence,
    deleteAuditDataEvidence,
};