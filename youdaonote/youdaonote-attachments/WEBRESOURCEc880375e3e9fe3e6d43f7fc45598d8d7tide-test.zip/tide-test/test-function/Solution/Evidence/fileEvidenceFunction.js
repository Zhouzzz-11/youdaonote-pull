'use strict';

const Moment = require('moment');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {Assert} = require('@rootcloud/darjeeling');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getToken} = require('../../../test-utils/util_token');

/**
 * get file size
 * @param filePah
 * @returns {Number}
 */
function getFileSize(filePah) {
    let stats = fs.statSync(filePah);
    return stats.size;
}

/**
 * get file name
 * @param filePath
 * @returns {string}
 */
function getFileName(filePath) {
    return path.basename(filePath);
}

/**
 * read file sync
 * @param filePath
 * @returns {Buffer}
 */
function readFile(filePath) {
    return fs.readFileSync(filePath);
}

/**
 * get file hash ,then use it as fileHash in creating file evidence
 * @param filePath
 * @returns {string}
 */
function getFileHash(filePath) {
    let buff = readFile(filePath);
    let hash = crypto.createHash('md5');
    hash.update(buff, 'utf8');
    return hash.digest('hex');
}

/**
 * get file md5,then use it as request's header:Content-MD5
 * @param filePath
 * @returns {string}
 */
function getFileMd5(filePath) {
    let fileMd5 = getFileHash(filePath);
    let fileBase64 = Buffer.from(fileMd5, 'hex').toString('base64');
    return fileBase64;
}

/**
 * upload file to bucket
 * @param url
 * @param fileData
 * @param md5
 * @returns {Promise<void>}
 */
async function uploadFileAsync(url, fileData, md5) {
    const params = {reqBody: fileData, header: {'Content-MD5': md5, 'Content-Type': 'application/json'}};
    return await httpRequestAsync('put', url, null, params, false);
}

/**
 * down file
 * @param url
 * @returns {Promise<void>}
 */
async function downloadFileAsync(url) {
    // const params = {reqBody: fileData, header: {'Content-MD5': md5, 'Content-Type': 'application/json'}};
    return await httpRequestAsync('get', url);
}

/**
 * Post /api/v1/solution/evidence/file
 * create file evidence
 * @param reqBody
 * @param token
 * @param queryString
 * @returns {Promise<*>}
 */
async function createFileEvidenceAsync(reqBody, tokenOrUserData, queryString) {
    let token = await getToken(tokenOrUserData);
    let url = evidenceSolutionUrl.fileEvidence;
    const params = {reqBody: reqBody};
    if (queryString) {
        params.queryString = queryString;
    }
    return await httpRequestAsync('post', url, token, params);
}

/**
 * get file download url
 * @param evidenceId
 * @param tokenOrUserData
 * @returns {Promise<void>}
 */
async function getFileEvidenceUploadUrlByIdAsync(evidenceId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.fileEvidence}/${evidenceId}/upload`;
    return await httpRequestAsync('get', url, token);
}

/**
 *  Get /api/v1/solution/evidence/file
 *  query file evidence
 * @param tokenOrUserData
 * @param queryObj
 * @returns {Promise<void>}
 */
async function queryFileEvidenceAsync(tokenOrUserData, queryObj = {}) {
    let token = await getToken(tokenOrUserData);
    let url = evidenceSolutionUrl.fileEvidence;
    let params = {};
    if (queryObj) {
        let queryString_ = '';
        for (var key in queryObj) {
            queryString_ += '&' + key + '=' + queryObj[key];
        }
        let queryString = queryString_.substr(1);
        params = {queryString: queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/**
 * Get /api/v1/solution/evidence/file/{evidenceId}
 * get single file evidence
 * @param evidenceId
 * @param tokenOrUserData
 * @param options
 * @returns {Promise<void|*>}
 */
async function getFileEvidenceByIdAsync(evidenceId, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.fileEvidence}/${evidenceId}`;
    var params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/**
 * patch /api/v1/solution/evidence/file/{evidenceId}
 * update file evidence
 * @param evidenceId
 * @param reqBody
 * @param tokenOrUserData
 * @param options
 * @returns {Promise<void>}
 */
async function updateFileEvidenceByIdAsync(evidenceId, reqBody, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.fileEvidence}/${evidenceId}`;
    var params;
    if (options.queryString) {
        params = {reqBody: reqBody, queryString: options.queryString};
    } else {
        params = {reqBody: reqBody};
    }
    return await httpRequestAsync('patch', url, token, params);
}

/**
 * Delete /api/v1/solution/evidence/file/{evidenceId}
 * delete single file evidence
 * @param evidenceId
 * @param token
 * @returns {Promise<*>}
 */
async function deleteFileEvidenceByIdAsync(evidenceId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.fileEvidence}/${evidenceId}`;
    return await httpRequestAsync('delete', url, token);
}

/**
 * batch create  file evidence
 * @param storeBatch
 * @param limit
 * @returns {Promise<void>}
 */
async function batchCreateFileEvidence(storeBatch, limit) {
    let begin = Math.floor(Math.random() * 1000 + 1000);
    let dateStr = Moment.utc().format('YYYYMMDD');
    let rspPromiseStore = [];
    for (var i = begin; i < begin + limit; i++) {
        let evidenceId = `${dateStr}_${i}`;
        storeBatch.set(`rsp${evidenceId}`, `test_${evidenceId}`);
        let evidenceReqBody = new EvidenceObj({content: `test_${i}`, evidenceId: evidenceId});
        let rsp = createFileEvidenceAsync(evidenceReqBody, baasOrg01);
        rspPromiseStore.push(rsp);
    }
    let responses = await Promise.all(rspPromiseStore);
    for (let rsp of responses) {
        Assert.deepEqual(rsp.statusCode, 201, 'code is not 201');
    }
}

/**
 * batch delete file evidence
 * @param storeBatch
 * @returns {Promise<void>}
 */
async function batchDeleteFileEvidenceAysnc(storeBatch) {
    let rspPromiseStore = [];
    for (var [key, value] of storeBatch) {
        let evidenceId = key.substr(3);
        let rsp = deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
        rspPromiseStore.push(rsp);
    }
    let responses = await Promise.all(rspPromiseStore);
    for (let rsp of responses) {
        Assert.deepEqual(rsp.statusCode, 204, 'code is not 201');
    }
}

async function searchFileEvidenceAsync({queryString, tokenOrUserData}) {
    let token = await getToken(tokenOrUserData);
    const params = queryString && {queryString: queryString};
    return await httpRequestAsync('get', evidenceSolutionUrl.fileEvidence, token, params);
}

module.exports = {
    createFileEvidenceAsync,
    queryFileEvidenceAsync,
    getFileEvidenceByIdAsync,
    updateFileEvidenceByIdAsync,
    deleteFileEvidenceByIdAsync,
    batchCreateFileEvidence,
    batchDeleteFileEvidenceAysnc,
    searchFileEvidenceAsync,
    getFileSize,
    getFileName,
    getFileHash,
    getFileMd5,
    readFile,
    uploadFileAsync,
    downloadFileAsync,
    getFileEvidenceUploadUrlByIdAsync
};
