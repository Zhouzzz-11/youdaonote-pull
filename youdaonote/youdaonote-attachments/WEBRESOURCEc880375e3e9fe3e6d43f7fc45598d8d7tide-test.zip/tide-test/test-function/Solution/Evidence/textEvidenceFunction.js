'use strict';

const Moment = require('moment');
const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getToken} = require('../../../test-utils/util_token');
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {Assert} = require('@rootcloud/darjeeling');


/**
 * Post /api/v1/solution/evidence/text
 * create text evidence
 * @param reqBody
 * @param tokenOrUserData
 * @param queryString
 * @returns {Promise<*>}
 */
async function createEvidenceAsync(reqBody, tokenOrUserData, queryString) {
    let token = await getToken(tokenOrUserData);
    let url = evidenceSolutionUrl.textEvidence;
    const params = {reqBody: reqBody};
    if (queryString) {
        params.queryString = queryString;
    }
    return await httpRequestAsync('post', url, token, params);
}

/**
 *  Get   /api/v1/solution/evidence/text/queue/{evidenceId}
 *  query async evidence result
 * @param evidenceId
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function getAsyncEvidenceByIdAsync(evidenceId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.queryasync}/${evidenceId}`;
    return await httpRequestAsync('get', url, token);
}

/**
 *  Get /api/v1/solution/evidence/text
 *  query text evidence
 * @param tokenOrUserData
 * @param queryObj
 * @returns {Promise<void>}
 */
async function queryEvidenceAsync(tokenOrUserData, queryObj = {}) {
    let token = await getToken(tokenOrUserData);
    let url = evidenceSolutionUrl.textEvidence;
    let params = {};
    if (queryObj) {
        let queryString_ = '';
        for (var key in queryObj) {
            queryString_ += '&' + key + '=' + queryObj[key];
        }
        let queryString = queryString_.substr(1);
        params = {queryString: queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/**
 * Get /api/v1/solution/evidence/text/{evidenceId}
 * get single text evidence
 * @param evidenceId
 * @param tokenOrUserData
 * @param options
 * @returns {Promise<void|*>}
 */
async function getEvidenceByIdAsync(evidenceId, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.textEvidence}/${evidenceId}`;
    var params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/**
 * patch /api/v1/solution/evidence/text/{evidenceId}
 * update text evidence
 * @param evidenceId
 * @param reqBody
 * @param tokenOrUserData
 * @param options
 * @returns {Promise<void>}
 */
async function updateEvidenceByIdAsync(evidenceId, reqBody, tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.textEvidence}/${evidenceId}`;
    var params;
    if (options.queryString) {
        params = {reqBody: reqBody, queryString: options.queryString};
    } else {
        params = {reqBody: reqBody};
    }
    return await httpRequestAsync('patch', url, token, params);
}

/**
 * Delete /api/v1/solution/evidence/text/{evidenceId}
 * delete single text evidence
 * @param evidenceId
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function deleteEvidenceByIdAsync(evidenceId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.textEvidence}/${evidenceId}`;
    return await httpRequestAsync('delete', url, token);
}

/**
 * Get /api/v1/solution/evidence/search
 * search text evidence
 * @param queryString
 * @param tokenOrUserData
 * @returns {Promise<*>}
 */
async function searchEvidenceAsync({queryString, tokenOrUserData}) {
    let token = await getToken(tokenOrUserData);
    const params = queryString && {queryString: queryString};
    return await httpRequestAsync('get', evidenceSolutionUrl.search, token, params);
}

/**
 * batch create  text evidence
 * @param storeBatch
 * @returns {Promise<void>}
 */
async function batchCreateEvidence(storeBatch, createNum) {
    let rspPromiseStore = [];
    for (let i = 0; i < createNum; i++) {
        let evidenceReqBody = new EvidenceObj({content: `test_${i}`});
        let rsp = createEvidenceAsync(evidenceReqBody, baasOrg01);
        rspPromiseStore.push(rsp);
    }
    let responses = await Promise.all(rspPromiseStore);
    for (let rsp of responses) {
        let rspBody = JSON.parse(rsp.body);
        let evidenceId = rspBody.evidenceId;
        storeBatch.set(`rsp${evidenceId}`, `test_${evidenceId}`);
        Assert.deepEqual(rsp.statusCode, 201, 'code is not 201');
    }
}

/**
 * batch delete text evidence
 * @param storeBatch
 * @returns {Promise<void>}
 */
async function batchDeleteEvidenceAysnc(storeBatch) {
    let rspPromiseStore = [];
    for (var key of storeBatch.keys()) {
        let evidenceId = key.substr(3);
        let rsp = deleteEvidenceByIdAsync(evidenceId, baasOrg01);
        rspPromiseStore.push(rsp);
    }
    let responses = await Promise.all(rspPromiseStore);
    for (let rsp of responses) {
        Assert.deepEqual(rsp.statusCode, 204, 'code is not 201');
    }
}

async function batchAsyncCreateEvidence(storeBatch, limit) {
    let begin = Math.floor(Math.random() * 1000 + 1000);
    let dateStr = Moment.utc().format('YYYYMMDD');
    let rspPromiseArr = [];
    for (var i = begin; i < begin + limit; i++) {
        let evidenceId = `${dateStr}_${i}`;
        let evidenceReqBody = new EvidenceObj(`test_${i}`, ['labels'], true, evidenceId);
        let rsp = createEvidenceAsync(evidenceReqBody, baasOrg01);
        rspPromiseArr.push(rsp);
    }
    let responses = await Promise.all(rspPromiseArr);
    for (let rsp of responses) {
        Assert.deepEqual(rsp.statusCode, 201, 'check status code is 201');
        // storeBatch.set(`rsp${evidenceId}`, rsp);
    }
}

async function getEvidenceTotalNum(tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    return await httpRequestAsync('get', evidenceSolutionUrl.getEvidenceTotalNum, token);
}

module.exports = {
    batchCreateEvidence,
    createEvidenceAsync,
    getAsyncEvidenceByIdAsync,
    queryEvidenceAsync,
    getEvidenceByIdAsync,
    updateEvidenceByIdAsync,
    deleteEvidenceByIdAsync,
    searchEvidenceAsync,
    batchAsyncCreateEvidence,
    batchDeleteEvidenceAysnc,
    getEvidenceTotalNum
};
