'use strict';

const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getToken} = require('../../../test-utils/util_token');

/*
    POST api/v1/share
*/
async function createShareCode(reqBody, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = evidenceSolutionUrl.share;
    const params = {reqBody: reqBody};
    return await httpRequestAsync('post', url, token, params);
}

/*
    GET api/v1/share/{code}
*/
async function getSharedEvidence(code) {
    let url = `${evidenceSolutionUrl.share}/${code}`;
    return await httpRequestAsync('get', url, null);
}

/*
    GET api/v1/share/record
*/
async function getSharingRecord(tokenOrUserData, options = {}) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.share}/record`;
    let params;
    if (options.queryString) {
        params = {queryString: options.queryString};
    }
    return await httpRequestAsync('get', url, token, params);
}

/*
    GET api/v1/share/record/{shareId}
*/
async function getSharingRecordById(shareId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.share}/record/${shareId}`;
    return await httpRequestAsync('get', url, token);
}

/*
    DELETE api/v1/share/record/{shareId}
*/
async function deleteSharingRecordById(shareId, tokenOrUserData) {
    let token = await getToken(tokenOrUserData);
    let url = `${evidenceSolutionUrl.share}/record/${shareId}`;
    return await httpRequestAsync('delete', url, token);
}

module.exports = {
    createShareCode,
    getSharedEvidence,
    getSharingRecord,
    getSharingRecordById,
    deleteSharingRecordById,
};