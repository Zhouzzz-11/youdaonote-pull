#!/bin/sh

set -e

mode=
while :; do
  case $1 in
    --mode=?*)
      mode=${1#*=}
      ;;
   *)
    break
  esac

  shift
done


echo "$mode"
if [[ "$mode" != "master" && "$mode" != "release" && "$mode" != "snapshot" && "$mode" != "local" ]]; then
  echo "mode must be master or release or local or snapshot"
  exit 1
fi

pwd

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$DIR/.."
DOCKER_REPO="bc-registry-pre.rootcloudapp.com/tide"
PROJECT_NAME="tide-test"
DOCKER_USER="admin"
DOCKER_PASS="Harbor12345"
DOCKER_HOST="bc-registry-pre.rootcloudapp.com"

docker login --username=$DOCKER_USER --password=$DOCKER_PASS $DOCKER_HOST

echo "----> Start Build Docker Images at ${PROJECT_ROOT} "

cd ${PROJECT_ROOT}

## 根据 mode 获取版本号
VERSION=

if [[ "$mode" == "master" || "$mode" == "local" ]];then
    VERSION=$(node -p "require('$PROJECT_ROOT/package.json').version")
elif [[ "${mode}" == "snapshot" ]]; then
    TAG_VERSION=$(node -p "require('$PROJECT_ROOT/snapshot.json').tag")
    SNAPSHOT_VERSION=$(node -p "require('$PROJECT_ROOT/snapshot.json').version")
    VERSION="${TAG_VERSION}-${mode}.${SNAPSHOT_VERSION}"
else
    MAIN_VERSION=$(node -p "require('$PROJECT_ROOT/package.json').version")
    RELEASE_VERSION=$(node -p "require('$PROJECT_ROOT/release.json').version")
    VERSION="$MAIN_VERSION-$RELEASE_VERSION"
fi
echo "=====> ${TAG_VERSION}  - ${SNAPSHOT_VERSION}-${VERSION}"
DOCKER_IMAGE_NAME_VERSION="$DOCKER_REPO/$PROJECT_NAME:$VERSION"

DOCKER_IMAGE_NAME_LATEST="$DOCKER_REPO/$PROJECT_NAME:latest"
echo "----> Build Docker Image: ${DOCKER_IMAGE_NAME_VERSION} "

docker build -t ${DOCKER_IMAGE_NAME_VERSION} --build-arg BUILD_VERSION=${VERSION} .
docker tag  ${DOCKER_IMAGE_NAME_VERSION} ${DOCKER_IMAGE_NAME_LATEST}

if [[ "$mode" == "local" ]]; then
  echo "----> skip pushing docker images "
else

  echo "----> Push Docker Image to remote repository"

  docker push ${DOCKER_IMAGE_NAME_VERSION}
  docker push ${DOCKER_IMAGE_NAME_LATEST}

  echo "----> Remove the local docker image "

  docker rmi ${DOCKER_IMAGE_NAME_VERSION}
  docker rmi ${DOCKER_IMAGE_NAME_LATEST}
fi
