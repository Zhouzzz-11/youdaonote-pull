const axios = require('axios');
const fs = require('fs');
const path = require('path');
const version = require('../package.json').version;


function readFileJson(filepath) {
    const str = fs.readFileSync(filepath, 'utf8');
    const obj = JSON.parse(str);
    return obj;
}

function writeFileJson(filepath, obj) {
    fs.writeFileSync(filepath, JSON.stringify(obj, null, 4));
}

function getCoverageReportStr() {
    const coverageFilePath = path.join(__dirname, '../coverage/coverage-summary.json');
    if(!fs.existsSync(coverageFilePath)){
        return '### Coverage report not avaiable\n';
    }
    const coverageReport = readFileJson(coverageFilePath).total;
    const { lines, statements, functions, branches } = coverageReport;

    const str = `#### Coverage Report\n
> lines:          ${lines.pct}%, ${lines.covered}/${lines.total}
> statements: ${statements.pct}%, ${statements.covered}/${statements.total}
> functions:    ${functions.pct}%, ${functions.covered}/${functions.total}
> branches:    ${branches.pct}%, ${branches.covered}/${branches.total}`;
    return str;
}

const webhook = process.env.WECHAT_ROBOT_URL;

const projectName = process.env.CI_PROJECT_NAME;

const projectUrl = process.env.CI_PROJECT_URL;

//const build = process.env.CI_BUILD_STAGE;

const jobName = process.env.CI_JOB_NAME;

const title = process.env.CI_COMMIT_TITLE;

const user = process.env.GITLAB_USER_NAME;

const pipeline = process.env.CI_PIPELINE_URL;

const commitRefName = process.env.CI_COMMIT_REF_NAME;

const type = title.split(':')[0].trim();

const newVersionTypes = ['fix', 'feat'];

function buildTextNotification(msg) {
    return {
        'msgtype': 'markdown',
        'text': {
            'content': msg,
            'mentioned_mobile_list': [
                '' 
            ]
        }
    };
}

function buildDeployNotificationBody() {
    const msg = `${projectName} <font color=\"info\">${user}</font> 的部署成功啦\nTIDE-TEST版本升级到${version}\n${title}\n\n`;

    return buildTextNotification(msg);
}

function buildPreReleaseNotificationBody() {
    const msg = `${projectName} <font color=\"info\">${user}</font> 的构建成功啦\npre-release分支发布新版本${version}\n${title}\n\n`;

    return buildTextNotification(msg);
}

function buildFailureNotificationBody() {
    const msg = `${projectName} <font color=\"info\">${user}</font> 的构建失败了\n${title}\n\n查看结果：${pipeline}`;

    return buildTextNotification(msg);
}

function buildReleaseNotificationBody() {
    const releaseVersion = require('../package.json').version;

    const msg = `release: ${projectName} 的构建成功了，release版本更新到了 ${version}-${releaseVersion}`;

    return buildTextNotification(msg);
}

function getNotificationBody(notificationType) {
    switch (notificationType) {
        case 'deploy':
            return buildDeployNotificationBody();
        case 'buildImage':
            return buildPreReleaseNotificationBody();
        case 'release':
            return buildReleaseNotificationBody();
        default:
            return buildFailureNotificationBody();
    }
}

function sendNotification(body) {
    axios.post(webhook, body).then((result) => {
        console.log('send notification to wechat group, status: ', result.status);
    });
}

let body;

if (commitRefName === 'master' || commitRefName === 'pre-release') {
    if (newVersionTypes.includes(type)) {
        body = getNotificationBody(jobName);
    }
} else if (commitRefName === 'release') {
    body = getNotificationBody('release');
} else {
    let success = `<font color=\"info\">构建成功✅</font>`;
    if (jobName === 'send_failure') {
        success = `<font color=\"warn\">构建失败❌</font>了`;
    }

    let msg = `[${projectName}](${projectUrl}) ${success}\n
> 查看Pipeline: [${title}](${pipeline})
> 提交者: ${user}
> 版本: ${version}
`;

    if (jobName === 'unitTest' || jobName === 'test') {
        const coverage = getCoverageReportStr();
        msg = msg + coverage;
    }

    body = {
        'msgtype': 'markdown',
        'markdown': {
            'content': msg
        }
    };
}
sendNotification(body);
