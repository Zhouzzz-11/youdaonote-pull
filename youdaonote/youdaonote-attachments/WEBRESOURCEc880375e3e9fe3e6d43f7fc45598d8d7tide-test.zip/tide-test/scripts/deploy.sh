#!/bin/bash

name='poc'
adminId='1'
orgId='-1'
adminName='rc_admin'
username='rc_admin'
password='admin'
onchainChannelName='mvpcc'
offchainChannelName='poc'
baasNetwork='baas/network'
deployContractUrl='msc/solution'
switchNetwork='baas/network/switch'
gitlabPrivateToken='kChq12R13fNLQaXSqLaR'
solutionIndustrialEvidence='http://gitlab.irootech.com/api/v4/projects/3148/repository/tags'
tideTestContract='http://gitlab.irootech.com/api/v4/projects/3993/repository/tags'
iamLoginUrl='http://iam-identity-service.iot-qa.rootcloudapp.com/api/v1/auth/login'

function split_str() {
  local str
  str="${1#*${2}}"
  str="${str%%$3*}"
  echo $str
}

function get_url_env() {
  CONSOLE_URL=$(split_str "$URL_ENV" 'CONSOLE_URL":"' '","EVIDENCESOLUTION_URL')
  EVIDENCESOLUTION_URL=$(split_str "${URL_ENV}" 'EVIDENCESOLUTION_URL": "' '","TIDEPROXY_URL')
  TIDEPROXY_URL_DOMAIN=$(split_str "${URL_ENV}" 'TIDEPROXY_URL": "' '","IAM_URL')
  TIDEPROXY_URL="$TIDEPROXY_URL_DOMAIN:8081"
  IAM_URL=$(split_str "${URL_ENV}" 'IAM_URL":"' '"}')
}

function download_contrat() {
  evidenceRes=$(curl --header "PRIVATE-TOKEN: ${gitlabPrivateToken}" ${solutionIndustrialEvidence})
  tideTestContractRes=$(curl --header "PRIVATE-TOKEN: ${gitlabPrivateToken}" ${tideTestContract})
  evidenceVersion=$(split_str "$evidenceRes" 'name":"' '","message')
  testContractVersion=$(split_str "$tideTestContractRes" 'name":"' '","message')
  digitalevidenceVersion=${evidenceVersion:1}
  testVersion=${testContractVersion:1}
  rm -rf /app/jar/*
  echo "digitalevidence-${digitalevidenceVersion}.jar is downloading..."
  wget -P /app/jar/ https://nexus.irootechapp.com/repository/maven-releases/cn/gezhitech/digitalevidence/digitalevidence/${digitalevidenceVersion}/digitalevidence-${digitalevidenceVersion}.jar
  wget  -P /app/jar/ https://nexus.irootechapp.com/repository/maven-releases/com/gezhitech/tide-test-proxy/${testVersion}/tide-test-proxy-${testVersion}.jar
  if [[ -e /app/jar/digitalevidence-${digitalevidenceVersion}.jar && -e /app/jar/tide-test-proxy-${testVersion}.jar ]];then
    echo "Download contract success."
  else
    echo "Download contract failed."
    exit 3
  fi
}

# deploy onchain network
function deploy_onchain_network() {
  echo "----------------------------------------------- deploy onchain  network -----------------------------------------------"
  deploy_onchain_body='{
  "code" : "local.0",
  "type" : "on_chain",
  "name" : "Rootchain",
  "channels" : [
      {
          "name": "'${onchainChannelName}'",
          "mspIds": ["Org1MSP"]
      }
  ],
  "organizations" : [
      {
          "mspId" : "Org1MSP",
          "name" : "Org1",
          "endpoint" : "file:///app/config/connections/connection-org1.yaml",
          "channels" : ["'${onchainChannelName}'"]
      }
  ],
  "_class" : "com.gezhi.proxy.domain.tide.entity.Network"
}'
  onchain_http_response=$(curl -s -o onchain_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
  -H "CERT-IDENTITY:5bb0815c3588500f5f801ef1f7a26bc8e0294b9369b61f79a503eff1b27f1cc8" -X POST -d "${deploy_onchain_body}" \
   ${TIDEPROXY_URL}/${baasNetwork})
  if [[ $onchain_http_response == "200" ]];then
    echo "deploy onchain success"
  else
    echo "deploy onchain failed"
    exit 1
  fi
#{"code":null,"message":null,"payload":{"id":"6062e204d06a7b5508957503","code":"local.0","type":"on_chain","name":"可信存证网络","channels":[{"name":"local","version":null,"packageId":null,"chaincodes":[],"mspIds":["Org1MSP"]},{"name":"mvpcc","version":null,"packageId":null,"chaincodes":[],"mspIds":["Org1MSP"]}],"organizations":[{"id":null,"mspId":"Org1MSP","name":"Org1","endpoint":"file:///app/config/connections/connection-org1.yaml","channels":["mvpcc","local"]}]},"httpStatus":200,"success":true}
  onchain_res=$(cat onchain_response.txt)
  onchain_networkId=$(split_str "${onchain_res}" 'id":"'  '","code')
  echo "onchain_networkId: ${onchain_networkId}"
}

# deploy offchain network
function deploy_offchain_network() {
  echo "----------------------------------------------- deploy offchain  network -----------------------------------------------"
  deploy_offchain_body='{
    "code" : "poc",
    "type" : "off_chain",
    "name" : "可信存证网络",
    "channels" : [
        {
            "name": "'${offchainChannelName}'",
            "mspIds": ["Org1MSP"]
        }
    ],
    "organizations" : [
        {
            "mspId" : "Org1MSP",
            "name" : "Org1",
            "endpoint" : "grpc://msc-offchain:1046",
            "channels" : ["'${offchainChannelName}'"]
        }
    ],
    "_class" : "com.gezhi.proxy.domain.tide.entity.Network"
}'
  offchain_http_response=$(curl -s -o offchain_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
  -H "CERT-IDENTITY:5bb0815c3588500f5f801ef1f7a26bc8e0294b9369b61f79a503eff1b27f1cc8" -X POST -d "${deploy_offchain_body}" \
    ${TIDEPROXY_URL}/${baasNetwork})
  if [[ $offchain_http_response == "200" ]];then
    echo "deploy offchain success"
  else
    echo "deploy offchain failed"
    exit 1
  fi
  offchain_res=$(cat offchain_response.txt)
  offchain_networkId=$(split_str "${offchain_res}" 'id":"'  '","code')
  echo "offchain_networkId: ${offchain_networkId}"
}

function get_cert_key() {
  echo "----------------------------------------------- get certs and keys -----------------------------------------------"
  end_str='caCert":'
  adminCert_=$(split_str "${CERTS_KEYS}" 'adminCert": ' '"caCert"')
  adminCert=${adminCert_%?}
  caCert_="${CERTS_KEYS#*$end_str}"
  caCert=${caCert_%?}
#  echo "================================================="
#  echo $adminCert
#  echo "================================================="
#  echo $caCert
}

function init_onchain_user() {
  echo "----------------------------------------------- init onchain user -----------------------------------------------"
  init_onchain_body='{
    "userId": "'${adminId}'",
    "userName": "'${adminName}'",
    "password": "'${password}'",
    "userRole": ["networkadmin","admin"],
    "orgId": "'${orgId}'",
    "tenantId": "local",
    "mspId": "Org1MSP",
    "networkId": "'${onchain_networkId}'",
    "adminCert": '${adminCert}',
    "caCert": '${caCert}',
    "channelName": "'${onchainChannelName}'"
}'
  echo "------------------------------------------------------------------------------------"
  echo $init_onchain_body
  echo "------------------------------------------------------------------------------------"
  onchain_init_response=$(curl -s -o onchain_init_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
  -H "CERT-IDENTITY:5bb0815c3588500f5f801ef1f7a26bc8e0294b9369b61f79a503eff1b27f1cc8" -X POST -d "${init_onchain_body}" ${TIDEPROXY_URL}/msc/init)
  if [ $onchain_init_response == "200" ]; then
    echo "Initialize onchain user succeeded."
  else
    echo "Initialize onchain user failed."
    cat onchain_init_response.txt
    exit 2
  fi
}

function init_offchain_user() {
  echo "----------------------------------------------- init offchain user -----------------------------------------------"
  init_offchain_body='{
    "userId": "'${adminId}'",
    "userName": "'${adminName}'",
    "password": "'${password}'",
    "userRole": ["networkadmin","admin"],
    "orgId": "'${orgId}'",
    "tenantId": "local",
    "mspId": "Org1MSP",
    "networkId": "'${offchain_networkId}'",
    "adminCert": '${adminCert}',
    "caCert": '${caCert}',
    "channelName": "'${offchainChannelName}'"
}'
  echo "------------------------------------------------------------------------------------"
  echo $init_offchain_body
  echo "------------------------------------------------------------------------------------"
  offchain_init_response=$(curl -s -o offchain_init_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
  -H "CERT-IDENTITY:5bb0815c3588500f5f801ef1f7a26bc8e0294b9369b61f79a503eff1b27f1cc8" -X POST -d "${init_offchain_body}" ${TIDEPROXY_URL}/msc/init)
  if [ $offchain_init_response == "200" ]; then
    echo "Initialize offchain user succeeded."
  else
    echo "Initialize offchain user failed."
    cat offchain_init_response.txt
    exit 2
  fi
}

function get_admin_token() {
  echo "----------------------------------------------- get superAdmin token -----------------------------------------------"
  login_body='{
    "grant_type": "password",
    "username": "'${username}'",
    "password": "'${password}'",
    "client_id": "web_app",
    "client_secret": "changeit"
}'
  echo "------------------------------------------------------------------------------------"
  echo login_body
  echo "------------------------------------------------------------------------------------"
  login_response=$(curl -s -o login_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
   -X POST -d "${login_body}" ${iamLoginUrl})
  if [ $login_response == "200" ]; then
    echo "super admin login iam success."
    login_res=$(cat login_response.txt)
    iamToken=$(split_str "${login_res}" 'access_token":"' '","token_type')
  else
    echo "super admin login iam failed."
    echo $login_res
    exit 2
  fi
}

function switchNetwork() {
  onOrOff=$1
  if [[ $onOrOff == "onchain" ]];then
    switch_body='{
      "networkId": "'${onchain_networkId}'",
      "channelName": "'${onchainChannelName}'"
    }'
  elif [[ $onOrOff == "offchain" ]]; then
    switch_body='{
      "networkId": "'${offchain_networkId}'",
      "channelName": "'${offchainChannelName}'"
    }'
  else
    echo "non model"
    exit 4
  fi

  switch_response=$(curl -s -o switch_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
   -H "Authorization: Bearer ${iamToken}" \
   -X POST -d "${switch_body}" ${TIDEPROXY_URL}/${switchNetwork})
  if [ $switch_response == "200" ]; then
    echo "switch $onOrOff success"
  else
    echo "switch $onOrOff failed"
    cat switch_response.txt
    exit 5
  fi
}

function deploy_contract() {
  echo "----------------------------------------------- deploy contract '$1'-----------------------------------------------"
  model=$1
  evidenceJar=$(cat /app/jar/digitalevidence-${digitalevidenceVersion}.jar | base64 -w 0)
  testContractJar=$(cat /app/jar/tide-test-proxy-${testVersion}.jar | base64 -w 0)
  evidenceBody='{
    "subModules": [
        {
            "name": "digitalevidence",
            "namespace": "cn.gezhitech.digitalevidence",
            "version": "'${digitalevidenceVersion}'",
            "jar": "'${evidenceJar}'"
        }
    ]
}'
  testContractBody='{
    "subModules": [
        {
            "name": "tide-test-proxy",
            "namespace": "cn.gezhitech.test.integration",
            "version": "'${testVersion}'",
            "jar": "'${testContractJar}'"
        }
    ]
}'
  if [[ $model == "onchain"  || $model == "offchain" ]];then
    deploy_response=$(curl -s -o deploy_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
   -H "Authorization: Bearer ${iamToken}" \
   -X PUT -d "${evidenceBody}" ${TIDEPROXY_URL}/${deployContractUrl})
  else
    deploy_response=$(curl -s -o deploy_response.txt -w "%{http_code}" -H "Content-Type:application/json" \
   -H "Authorization: Bearer ${iamToken}" \
   -X PUT -d "${testContractBody}" ${TIDEPROXY_URL}/${deployContractUrl})
  fi
  if [ $deploy_response == "200" ]; then
    echo "deploy contract $model success"
  else
    echo "deploy contract $model failed"
    cat deploy_response.txt
    exit 6
  fi
}

function main() {
  # get url env
  get_url_env
  # deploy onchain network
  deploy_onchain_network
  # deploy offchain network
  deploy_offchain_network
  # get admin ca and key
  get_cert_key
  # init onchain user
  init_onchain_user
  # init offchain user
  init_offchain_user
  # superAdmin  get token to deploy contract
  get_admin_token
  # download contract
  download_contrat
  # switch onchain network
  switchNetwork "onchain"
  #deploy onchain evidence contract
  deploy_contract "onchain"
  #deploy onchain test contract
  deploy_contract "test-contract"
  # switch onchain network
  switchNetwork "offchain"
  #deploy offchain contract
  deploy_contract  "offchain"
  switchNetwork "onchain"
}

main
