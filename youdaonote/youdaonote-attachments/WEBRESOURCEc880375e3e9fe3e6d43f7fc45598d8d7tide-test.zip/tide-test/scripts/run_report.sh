#!/bin/bash

MODEL=$1
current_date=$(date "+%Y%m%d%H%M%S")
common_url='https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key='
common_message_id='0d1b54d1-0d95-4c8e-a329-029a8c060163'
debug_message_id='4d075506-5239-4218-8d5f-fa697ca781f0'
alarm_message_id='0d77ffc3-893d-40e5-902b-406c400202cf'
head='Content-Type: application/json'


mkdir -p  /app/darjeeling-report/${current_date}
if [ "${MODE}" = "debug" || "MODEL" = "smoke_test" ];then
  url=${common_url}${debug_message_id}
else
  url=${common_url}${common_message_id}
fi

function split_str() {
   local str
   str="${1#*${2}}"
   str="${str%%$3*}"
   echo $str
}

function operate_deploy_report() {
  # only store seven days report and create file to restore test rusult
  find  /app/darjeeling-report/  -type d -mtime +7 | xargs rm -rf
  echo "" > /app/darjeeling-report/test_status.txt
}

function get_test_case_result() {
  # get case results: total, passes, failed, pending
  local result_json=$(head -18 /app/darjeeling-report/darjeeling.json)
  local result_str=$(echo $result_json | sed 's/\"//g' | sed "s/\'//g")
  total=$(split_str "$result_str" "tests: "  ", passes")
  passes=$(split_str "$result_str" "passes: "  ", pending")
  pending=$(split_str "$result_str" "pending: "  ", failures")
  failed=$(split_str "$result_str" "failures: "  ", start")
}

function run_send_message() {
  # check the test is full or smoke
  echo CURRENT_ENV=${CURRENT_ENV} > /app/.env
  title="${CURRENT_ENV}"

  # construct wechat robot message format
  data_success='{"msgtype": "markdown","markdown": {"content": "## tide-test【'${title}'-'${MODEL}'】测试成功✅ \n
   >**测试报告地址** ：['${REPORT_URL}'/'${current_date}'/darjeeling.html]('${REPORT_URL}'/'${current_date}'/darjeeling.html)"}}'

  data_non_report='{"msgtype": "markdown", "markdown": {"content": "## tide-test【'${title}'-'${MODEL}'】测试失败❌ \n
   >**生成报告失败** ：请定位"}}'

  # run test case
  npm run ${MODEL}
  if [ $? -eq 0 ] && [ -f /app/darjeeling-report/darjeeling.html ]; then
      curl "${url}"  -H "{head}" -d "${data_success}"
      echo "success" > /app/darjeeling-report/test_status.txt
  elif [ -f /app/darjeeling-report/darjeeling.html ];then
      get_test_case_result
      data_fail='{"msgtype": "markdown", "markdown": {"content": "## tide-test【'${title}'-'${MODEL}'】测试失败❌ \n
   **用例执行结果统计**:\n>Total: <font color=\"comment\">'${total}'</font>\n>Passed: <font color=\"info\">'${passes}'</font>\n>Failed: <font color=\"warning\">'${failed}'</font>\n>Pending: <font color=\"comment\">'${pending}'</font>\n
   **测试报告地址** ：['${REPORT_URL}'/'${current_date}'/darjeeling.html]('${REPORT_URL}'/'${current_date}'/darjeeling.html)"\n**请尽快处理!}}'
      if [[ "${MODEL}" = "test_pre" || "${MODEL}" = "test_prod" ]];then
        url=${common_url}${alarm_message_id}
      fi
      curl "${url}"  -H "{head}" -d "${data_fail}"
      echo "failed" > /app/darjeeling-report/test_status.txt
  else
      curl "${url}"  -H "{head}" -d "${data_non_report}"
  fi
}

function move_report() {
  # move report file
  mv /app/darjeeling-report/assets /app/darjeeling-report/${current_date}
  mv /app/darjeeling-report/darjeeling* /app/darjeeling-report/${current_date}
}


function main() {
  # delete report 7 days ago and create  test result file
  operate_deploy_report
  # run test case
  run_send_message
  # move report files
  move_report
}

main