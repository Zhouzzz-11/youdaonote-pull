#!/bin/sh

NODE_VERSION='v14.7.0'

function install_nvm() {
#    node_version_check=`node --version | grep ${NODE_VERSION}`
#    if [[ ${node_version_check} == ${NODE_VERSION} ]] && [[ -n ${NVM_DIR} ]];
#    then
#        echo "$NODE_VERSION is already installed."
#        return
#    fi

    export NVM_DIR="$HOME/.nvm" && (
      git clone https://github.com/nvm-sh/nvm.git "$NVM_DIR"
      cd "$NVM_DIR"
      git checkout `git describe --abbrev=0 --tags --match "v[0-9]*" $(git rev-list --tags --max-count=1)`
    ) && \. "$NVM_DIR/nvm.sh"

}

function load_nvm() {
    export NVM_DIR="$HOME/.nvm"
    [[ -s "$NVM_DIR/nvm.sh" ]] && \. "$NVM_DIR/nvm.sh" # This loads nvm
    nvm install ${NODE_VERSION}
    nvm use ${NODE_VERSION}
}


# =================== Main ===================
arg0=$0
arg1=$1

case $arg1 in

    "load_nvm" )
        load_nvm
        ;;
    "install_nvm" )
        install_nvm
        ;;
    * )
        echo " [Error] input error. "
        echo " please usage: [./$arg0 load_nvm | install_nvm ]"
        ;;
esac;