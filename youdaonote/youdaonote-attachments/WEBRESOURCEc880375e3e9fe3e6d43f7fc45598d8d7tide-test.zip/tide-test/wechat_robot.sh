#!/bin/sh

set -ex

STATUS='成功✅'
if [ -n "${1}" ]; then
  STATUS='失败❌'
fi

curl "${WECHAT_ROBOT_URL}" \
  -H 'Content-Type: application/json' \
  -d "{ \
    \"msgtype\": \"markdown\", \
    \"markdown\": { \
      \"content\": \"### [${CI_PROJECT_NAME}](${CI_PROJECT_URL}) 测试环境 ${STATUS}\n\n\
> 提交者：${GITLAB_USER_NAME}\n\
> 查看Pipeline：[${CI_COMMIT_TITLE}](${CI_PIPELINE_URL})\"\
    }}"
