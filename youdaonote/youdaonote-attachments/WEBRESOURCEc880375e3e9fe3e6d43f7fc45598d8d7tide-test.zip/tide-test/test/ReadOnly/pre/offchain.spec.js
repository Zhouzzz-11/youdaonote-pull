'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {baasOrg01, superUser} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {ShareObj} = require('../../../test-data/Solution/Share/shareData');
const {queryFileEvidence, queryTextEvidence} = require('../../../test-function/Console/Evidence/evidenceFunction');
const {getUserId, getCompanyId} = require('../../../test-function/NetworkManager/userFunction');
const {getUser, getCompany} = require('../../../test-function/Console/UserManagement/userFunction'); 
const {getCompanyByCompanyIdAsync, getUserByCompanyIdAsync} = require('../../../test-function/NetworkManager/userFunction');
const { getBlockCount, getBlockList } = require('../../../test-function/NetworkManager/browserFunction');
const {searchFileEvidenceAsync, getFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {queryEvidenceAsync, getEvidenceByIdAsync, getEvidenceTotalNum} = require('../../../test-function/Solution/Evidence/textEvidenceFunction');
const {createShareCode, getSharedEvidence, getSharingRecord, getSharingRecordById, deleteSharingRecordById} = require('../../../test-function/Solution/Share/shareFunction');
const {getToken} = require('../../../test-utils/util_token');

//Used for pre env
describe(`test for pre env and only to read`, function () {

    let userId, companyId;
    describe('console', function () {
        it('set-up:get userId and companyId', async function () {
            let token = await getToken(baasOrg01);
            userId = await getUserId(token);
            companyId = await getCompanyId(baasOrg01);
        });
        it('FileEvidence: default query all', async function () {
            //全查询
            let rspGet = await queryFileEvidence(baasOrg01,
                {queryString: `createdBy=${userId}&includeBlockInfo=true&sort=createdAt,desc&limit=5&skip=0`});
            Assert.deepEqual(rspGet.statusCode, 200);
        });
        it('TextEvidence: default query all', async function () {
            //全查询
            let rspGet = await queryTextEvidence(baasOrg01,
                {queryString: `createdBy=${userId}&includeBlockInfo=true&sort=createdAt,desc&limit=5&skip=0`});
            Assert.deepEqual(rspGet.statusCode, 200);
        });
        it('get company by companyId', async function () {
            let respGet = await getCompany(baasOrg01,
                {queryString: `companyId=${companyId}`});
            Assert.deepEqual(respGet.statusCode, 200);
        });
        it('get employee of company', async function () {
            let respGet = await getUser(baasOrg01,
                {queryString: `companyId=${companyId}&sort=createdAt,desc&limit=10&skip=0`});
            Assert.deepEqual(respGet.statusCode, 200);
        });
    });

    describe('gateway', function () {
        it('get company by companyId', async function () {
            let respGet = await getCompanyByCompanyIdAsync(companyId, baasOrg01);
            Assert.deepEqual(respGet.statusCode, 200);
        });
        it('get employee of company', async function () {
            let respGet = await getUserByCompanyIdAsync(companyId, superUser);
            Assert.deepEqual(respGet.statusCode, 200);
        });
        it('get block count', async function(){
            let resp = await getBlockCount(baasOrg01);
            Assert.deepEqual(resp.statusCode, 200);
        });
        it('get block list', async function(){
            let resp = await getBlockList(baasOrg01);
            Assert.deepEqual(resp.statusCode, 200);
        });
    });

    describe('evidence', function () {
        let body_textCode, body_fileCode;
        let body_fileId, body_textId;
        it('FileEvidence: query all', async function () {
            //全查询
            let rsp = await searchFileEvidenceAsync({
                queryString: `createdBy=${userId}&includeBlockInfo=true&sort=createdAt,desc&limit=5&skip=0`,
                tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'check status code');
            body_fileId = JSON.parse(rsp.body);
        });
        it('FileEvidence: query single include blockInfo and history', async function () {
            //查询单个存证
            let resp = await getFileEvidenceByIdAsync(body_fileId.results[0].evidenceId, baasOrg01,
                {queryString: 'includeBlockInfo=true&includeHistory=true'});
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
        });
        it('TextEvidence: query all', async function () {
            //全查询
            let rsp = await queryEvidenceAsync(baasOrg01,
                {createdBy: `${userId}`, includeBlockInfo: 'true', sort: 'createdAt,desc', limit: 5, skip: 0});
            Assert.deepEqual(rsp.statusCode, 200);
            body_textId = JSON.parse(rsp.body);
        });
        it('TextEvidence: query single include blockInfo and history', async function () {
            //查询单个存证
            let rspGet = await getEvidenceByIdAsync(body_textId.results[0].evidenceId, baasOrg01,
                {queryString: 'includeBlockInfo=true&includeHistory=true'});
            Assert.deepEqual(rspGet.statusCode, 200);
        });
        it('get the total number of evidence', async function () {
            let rsp = await getEvidenceTotalNum(baasOrg01);
            Assert.deepEqual(rsp.statusCode, 200, 'check status code');
        });
        it('create sharing code for text evidence', async function() {
            let shareReqBody = new ShareObj({evidenceId: body_textId.results[0].evidenceId, includeOriginal: true});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            body_textCode = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('get sharing text evidence', async function() {
            let resp = await getSharedEvidence(body_textCode.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
        });
        it('create sharing code for file evidence', async function() {
            let shareReqBody = new ShareObj({evidenceId: body_fileId.results[0].evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            body_fileCode = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('get sharing file evidence', async function() {
            let resp = await getSharedEvidence(body_fileCode.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
        });
        it('get share record', async function () {
            let rsp = await getSharingRecord(baasOrg01);
            Assert.deepEqual(rsp.statusCode, 200);
        });
        it('get share record by shareId (textEvidence)', async function () {
            //textEvidence share msg
            let rsp_text = await getSharingRecordById(body_textCode.shareId, baasOrg01);
            Assert.deepEqual(rsp_text.statusCode, 200);
        });
        it('get share record by shareId (fileEvidence)', async function () {
            //fileEvidence share msg
            let rsp_file = await getSharingRecordById(body_fileCode.shareId, baasOrg01);
            Assert.deepEqual(rsp_file.statusCode, 200);
        });
        it('delete share (textEvidence)', async function () {
            let rsp_text = await deleteSharingRecordById(body_textCode.shareId, baasOrg01);
            Assert.deepEqual(rsp_text.statusCode, 204);
        });
        it('delete share (fileEvidence)', async function () {
            let rsp_file = await deleteSharingRecordById(body_fileCode.shareId, baasOrg01);
            Assert.deepEqual(rsp_file.statusCode, 204);
        });
    });
});

