'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {ShareObj} = require('../../../test-data/Solution/Share/shareData');
const {getToken} = require('../../../test-utils/util_token');
const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');

//Used for pre env
describe(`test for pre env and only to read`, function () {
    let headers = {'RC-APP-TYPE': `Evidence`};
    let textCode, fileCode;
    let fileId, textId;
    let textShareId, fileShareId;
    it('Get org1 user1 token', async function () {
        let token = await getToken(baasOrg1.normalUsers.user1.iamLoginBody);
        Assert.deepEqual(typeof token, 'string');
        baasOrg1.normalUsers.user1.userToken = token;
        headers['X-RC-BaaS-Generation'] = '1.0';
        headers['Authorization'] = `Bearer ${token}`;
        headers['RC-APP-ID'] = `${baasOrg1.superUser.consortiaInfo[0].apps[0]}`;
    });

    it('FileEvidence: query all', async function () {
        //全查询
        let url = evidenceSolutionUrl.fileEvidence.concat(`?createdBy=${baasOrg1.normalUsers.user1.userId}&includeBlockInfo=true&sort=createdAt&limit=5&skip=0`);
        let rsp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
        fileId = rsp.results[0].evidenceId;
    });

    it('FileEvidence: query single include blockInfo and history', async function () {
        //查询单个存证
        let url = evidenceSolutionUrl.fileEvidence.concat(`/${fileId}?includeBlockInfo=true&includeHistory=true`);
        let rsp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('TextEvidence: query all', async function () {
        //全查询
        let url = evidenceSolutionUrl.textEvidence.concat(`?createdBy=${baasOrg1.normalUsers.user1.userId}&includeBlockInfo=true&sort=createdAt,desc&limit=5&skip=0`);
        let rsp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
        textId = rsp.results[0].evidenceId;
    });

    it('TextEvidence: query single include blockInfo and history', async function () {
        //查询单个存证
        let url = evidenceSolutionUrl.textEvidence.concat(`/${textId}?includeBlockInfo=true&includeHistory=true`);
        let rsp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('get the total number of evidence', async function () {
        //查询存证总数
        let url = evidenceSolutionUrl.getEvidenceTotalNum;
        let rsp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('create sharing code for text evidence', async function () {
        //分享文本存证
        let shareReqBody = new ShareObj({evidenceId: textId, includeOriginal: true});
        let url = evidenceSolutionUrl.share;
        let resp = await httpRequestAsync('post', url, headers, shareReqBody);
        textCode = resp.code;
        textShareId = resp.shareId;
        Assert.deepEqual(resp.statusCode, 201, 'check status code');
    });

    it('get sharing text evidence', async function () {
        //获取分享的文本存证
        let url = `${evidenceSolutionUrl.share}/${textCode}`;
        let resp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(resp.statusCode, 200, 'check status code');
    });

    it('create sharing code for file evidence', async function () {
        //分享文件存证
        let shareReqBody = new ShareObj({evidenceId: fileId, includeOriginal: true});
        let url = evidenceSolutionUrl.share;
        let resp = await httpRequestAsync('post', url, headers, shareReqBody);
        fileCode = resp.code;
        fileShareId = resp.shareId;
        Assert.deepEqual(resp.statusCode, 201, 'check status code');
    });

    it('get sharing file evidence', async function () {
        //获取分享的文件存证
        let url = `${evidenceSolutionUrl.share}/${fileCode}`;
        let resp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(resp.statusCode, 200, 'check status code');
    });

    it('get share record', async function () {
        //获取分享的存证总数
        let url = `${evidenceSolutionUrl.share}/record`;
        let resp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(resp.statusCode, 200);
    });

    it('get share record by shareId (textEvidence)', async function () {
        //textEvidence share msg
        let url = `${evidenceSolutionUrl.share}/record/${textShareId}`;
        let resp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(resp.statusCode, 200);
    });

    it('get share record by shareId (fileEvidence)', async function () {
        //fileEvidence share msg
        let url = `${evidenceSolutionUrl.share}/record/${fileShareId}`;
        let resp = await httpRequestAsync('get', url, headers);
        Assert.deepEqual(resp.statusCode, 200);
    });

    it('delete share (textEvidence)', async function () {
        let url = `${evidenceSolutionUrl.share}/record/${textShareId}`;
        let resp = await httpRequestAsync('delete', url, headers);
        Assert.deepEqual(resp.statusCode, 204);
    });

    it('delete share (fileEvidence)', async function () {
        let url = `${evidenceSolutionUrl.share}/record/${fileShareId}`;
        let resp = await httpRequestAsync('delete', url, headers);
        Assert.deepEqual(resp.statusCode, 204);
    });

});

