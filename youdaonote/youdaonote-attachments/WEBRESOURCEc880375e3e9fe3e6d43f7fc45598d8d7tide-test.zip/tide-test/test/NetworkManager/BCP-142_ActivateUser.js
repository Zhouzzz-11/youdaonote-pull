//NetworkManager-用户激活-POST-/user
//BCP-142
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=195482

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {createCompanyIAMAsync, createUserIAMAsync, activateCompanyAsync, activateUserAsync, getUserByCompanyIdAsync} = require('../../test-function/NetworkManager/userFunction');
const {topadmin} = require('../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user admin.
const {dataBody} = require('../../test-lib/mockdata');
const {activateUserSchema} = require('../../test-schema/Proxy/user');
const {TIDE, IAM} = require('../../test-lib/errorMessage');
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify');
const env = process.env.CURRENT_ENV;

describe('/test: POST /user', function () {

    let resp_company;
    let body_company;
    let resp_user;
    let body_user;
    let code,networkId;
    if (env === 'local') {
        code = 'local';
    } else {
        code = 'poc';
    }
    describe('T0:Pre-steps', function () {
        this.timeout(25 * 1000);
        it('create company at IAM', async function () {
            networkId = topadmin.networkId;
            let createCompanyIAMData = dataBody.createCompanyIAMBody();
            resp_company = await createCompanyIAMAsync(createCompanyIAMData, topadmin);
            body_company = JSON.parse(resp_company.body);
            Assert.deepEqual(resp_company.statusCode, 200);
        });
        it('create user at IAM', async function () {
            let createUserIAMData = dataBody.createUserIAMBody([body_company.id], body_company.id);
            resp_user = await createUserIAMAsync(createUserIAMData, topadmin);
            body_user = JSON.parse(resp_user.body);
            Assert.deepEqual(resp_user.statusCode, 200);
        });
        it('activate company at tide', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code, networkId, body_company.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
        });
    });

    describe('T0:C2414223: activate user', function () {
        it('test', async function () {
            let activateUserData = dataBody.activateUserBody(body_user.id, body_user.username, body_company.id, ['user']);
            let respActivate = await activateUserAsync(activateUserData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
            await verifySchemaAsync(respActivate, activateUserSchema);
        });
    });

    describe('T1:C2414224: activate user with not exist userId', function () {
        it('test', async function () {
            let activateUserData = dataBody.activateUserBody('userId_not_exist', body_user.username, body_company.id, ['user']);
            let respActivate = await activateUserAsync(activateUserData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 404);
            verifyPayloadSync(respActivate, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });

    describe('T1:C2414230: activate user with already activated userId', function () {
        it('test', async function () {
            let activateUserData = dataBody.activateUserBody(body_user.id, body_user.username, body_company.id, ['user']);
            let respActivate = await activateUserAsync(activateUserData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 400);
            verifyPayloadSync(respActivate, TIDE.FailedToCreateUserDueToInvalidUserIdError.errorCode, 'code');
        });
    });

    describe('T1:C3566085: a user belongs to two company whether can be activated', function () {
        let body_company_1, body_company_2, body_user;
        it('pre-steps: create company and user', async function () {
            //create two company
            let createCompanyIAMData_1 = dataBody.createCompanyIAMBody();
            let resp_company_1 = await createCompanyIAMAsync(createCompanyIAMData_1, topadmin);
            body_company_1 = JSON.parse(resp_company_1.body);
            Assert.deepEqual(resp_company_1.statusCode, 200);
            let createCompanyIAMData_2 = dataBody.createCompanyIAMBody();
            let resp_company_2 = await createCompanyIAMAsync(createCompanyIAMData_2, topadmin);
            body_company_2 = JSON.parse(resp_company_2.body);
            Assert.deepEqual(resp_company_2.statusCode, 200);
            //create a user
            let createUserIAMData = dataBody.createUserIAMBody([body_company_1.id, body_company_2.id], body_company_1.id);
            let resp_user = await createUserIAMAsync(createUserIAMData, topadmin);
            body_user = JSON.parse(resp_user.body);
            Assert.deepEqual(resp_user.statusCode, 200);
            //activate company
            let activateCompanyData_1 = dataBody.activateCompanyBody(code, networkId, body_company_1.id);
            let respActivate_1 = await activateCompanyAsync(activateCompanyData_1, topadmin);
            Assert.deepEqual(respActivate_1.statusCode, 200);
            let activateCompanyData_2 = dataBody.activateCompanyBody(code, networkId, body_company_2.id);
            let respActivateC_2 = await activateCompanyAsync(activateCompanyData_2, topadmin);
            Assert.deepEqual(respActivateC_2.statusCode, 200);
        });
        it('test1: either company to do activate', async function () {
            let activateUserData_1 = dataBody.activateUserBody(body_user.id, body_user.username, body_company_2.id, ['user']);
            let respActivateU_1 = await activateUserAsync(activateUserData_1, topadmin);
            Assert.deepEqual(respActivateU_1.statusCode, 200);

        });
        it('test2: other company to do activate', async function () {
            let activateUserData_2 = dataBody.activateUserBody(body_user.id, body_user.username, body_company_1.id, ['user']);
            let respActivateU_2 = await activateUserAsync(activateUserData_2, topadmin);
            Assert.deepEqual(respActivateU_2.statusCode, 400);
            verifyPayloadSync(respActivateU_2, TIDE.FailedToCreateUserDueToInvalidUserIdError.errorCode, 'code');
        });
        it('test3: this user can be queried in TIDE', async function () {
            let respGet_1 = await getUserByCompanyIdAsync(body_company_1.id, topadmin, {queryString: `userName=${body_user.username}`});
            let bodyGet_1 = JSON.parse(respGet_1.body);
            Assert.deepEqual(respGet_1.statusCode, 200);
            Assert.deepEqual(bodyGet_1.payload.results[0].id, body_user.id, 'check this user can be queried');
            let respGet_2 = await getUserByCompanyIdAsync(body_company_2.id, topadmin, {queryString: `userName=${body_user.username}`});
            let bodyGet_2 = JSON.parse(respGet_2.body);
            Assert.deepEqual(respGet_2.statusCode, 200);
            Assert.deepEqual(bodyGet_2.payload.results[0].id, body_user.id, 'check this user can be queried');
        });
    }).timeout(15 * 1000);
});