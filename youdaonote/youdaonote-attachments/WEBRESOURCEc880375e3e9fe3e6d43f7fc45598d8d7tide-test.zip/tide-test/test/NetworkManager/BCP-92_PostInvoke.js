// //NetworkManager-POST-/msc/invoke
// //BCP-92 
// //TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=196125

// 'use strict';

// const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
// const {invokeData_error} = require('../../test-data/NetworkManager/BCP-92_invoke_data');
// const {postInvoke} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
// //const { verifySchemaAsync } = require('../test-verify/verify');
// //const { invokeSchema } = require('../test-schema/invoke');

// describe(`/test: POST /msc/invoke`, function () {
// //bug: http://jira2.irootech.com:8080/browse/BCP-635
//     describe('C2085602: verify syntax error', function () {
//         it('test', async function () {
//             let resp = await postInvoke(invokeData_error);
//             Assert.deepEqual(resp.statusCode, 400);
//             //await verifySchemaAsync(resp, invokeSchema);
//         });
//     });
// });

