//NetworkManager-企业和企业管理员激活-POST-/company
//BCP-142
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=210326

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {createCompanyIAMAsync, activateCompanyAsync} = require('../../test-function/NetworkManager/userFunction');
const {topadmin} = require('../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user admin.
const {dataBody} = require('../../test-lib/mockdata');
const {activateCompanySchema} = require('../../test-schema/Proxy/user');
const {TIDE,TIDESOL} = require('../../test-lib/errorMessage');
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify');
const env = process.env.CURRENT_ENV;

describe('/test: POST /company', function() {

    let respCreate;
    let bodyCreate;
    let code,networkId;
    if (env === 'local') {
        code = 'local';
    } else {
        code = 'poc';
    }
    describe('T0:Pre-steps', function() {
        it('create company at IAM', async function(){
            networkId = topadmin.networkId;
            let createCompanyIAMData = dataBody.createCompanyIAMBody();
            respCreate = await createCompanyIAMAsync(createCompanyIAMData, topadmin);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 200);
        }).timeout(25 * 1000);
    });

    describe('T1:C2249099: activate company with not exist networkId', function() {
        it('test', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code,'networkId_not_exist', bodyCreate.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 400);
            verifyPayloadSync(respActivate, TIDE.FailedFindUserByTenantIdOrUserIdError.errorCode, 'code');
        });
    });
    describe('T0: C2249095: activate company', function() {
        it('test', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code, networkId, bodyCreate.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
            await verifySchemaAsync(respActivate, activateCompanySchema);
        });
    });

    describe('T1:C2249096: activate company with not exist companyId', function() {
        it('test', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code,networkId, 'companyId_not_exist');
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 404);
            // verifyPayloadSync(respActivate, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });


    describe('T1:C2249097/C2249098/C2249100: required items verification', function() {
        it('C2249097: activate company with null companyId', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code,networkId, '');
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 422);
            verifyPayloadSync(respActivate, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C2249098: activate company with null networkId', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code,'', bodyCreate.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 422);
            verifyPayloadSync(respActivate, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C2249100: activate company with null companyId and null networkId', async function () {
            let activateCompanyData = dataBody.activateCompanyBody('','', '');
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 422);
            verifyPayloadSync(respActivate, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
    });

    describe('T1:C2256191: activate company with long string', function() {
        it('test', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(
                '参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111',
                '参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111',
                '参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111参数1111111111');
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 404);
            // verifyPayloadSync(respActivate, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });

    describe('T1:C2256192: activate company with special string', function() {
        it('test', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(
                '!~@%',
                '!~@%',
                '!~@%');
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 404);
            // verifyPayloadSync(respActivate, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });
    // TODO: bug
    describe('T1:C2414231: activate company with already activated companyId', function() {
        it('test', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code,networkId, bodyCreate.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
            // verifyPayloadSync(respActivate, TIDE.ResourceConflictError.errorCode, 'code');
        });
    });
});