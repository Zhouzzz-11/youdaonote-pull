//NetworkManager-GET-/msc/provenance/{id}
//BCP-85 获取源表 
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=196126

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test.
const {getProvenanceListByID} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify'); //VerifySchema is used to verify the params.
const {provenanceSchema} = require('../../test-schema/Proxy/provenance');
const {TIDE} = require('../../test-lib/errorMessage');

describe(`/test: GET /msc/provenance/{id}`, function () {

    describe('T0:C2085578: Query by model and id', function () {
        it('test', async function () {
            let respGet = await getProvenanceListByID('AGENT_6425042e-be49-4d52-bb25-111111111113', {queryString: '$class=cn.gezhitech.tidemsc.model.User'});
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, provenanceSchema);
        });
    });
    // TODO onchain 不支持富查询,offchain支持
    describe.skip('T1:C2085580: Use filter to query', function () {
        it('test', async function () {
            let respGet = await getProvenanceListByID('AGENT_6425042e-be49-4d52-bb25-111111111113', {queryString: '$class=cn.gezhitech.tidemsc.model.User&filter={"where":{"txId":"5ed6d489-ef46-4c1c-b055-fcc158e5e867"}}'});
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, provenanceSchema);
        });
    });

    describe('T1:C2085565: Query by not exist model ', function () {
        it('test', async function () {
            let respGet = await getProvenanceListByID('AGENT_6425042e-be49-4d52-bb25-111111111113', {queryString: '$class=test.not.exist'});
            Assert.deepEqual(respGet.statusCode, 400);
            verifyPayloadSync(respGet, TIDE.MscUnCategorizedError.errorCode, 'code');
        });
    });

    describe('T1:C2085570: Query by not exist id ', function () {
        it('test', async function () {
            let respGet = await getProvenanceListByID('000000011', {queryString: '$class=cn.gezhitech.tidemsc.model.User'});
            var bodyGet = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(Object.keys(bodyGet.payload).length, 0);
        });
    });

    describe('T1:C2085582: Required item verification', function () {
        //必填项model、id校验：只传id
        it('test', async function () {
            let respGet = await getProvenanceListByID('AGENT_6425042e-be49-4d52-bb25-111111111113', {queryString: ''});
            Assert.deepEqual(respGet.statusCode, 400);
        });
    });
});

