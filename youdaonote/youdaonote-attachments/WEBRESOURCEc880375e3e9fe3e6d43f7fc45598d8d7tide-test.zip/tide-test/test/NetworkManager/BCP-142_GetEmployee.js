//NetworkManager-查询企业下所有用户-GET-/company/{id}/employee
//BCP-142
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=210328

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {createCompanyIAMAsync, createUserIAMAsync, activateCompanyAsync, activateUserAsync, getUserByCompanyIdAsync} = require('../../test-function/NetworkManager/userFunction');
const {topadmin, baasOrg01} = require('../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user admin.
const {dataBody} = require('../../test-lib/mockdata');
const {getAllEmployeesSchema} = require('../../test-schema/Proxy/user');
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify');
const {IAM} = require('../../test-lib/errorMessage');
const env = process.env.CURRENT_ENV;

describe('/test: GET /company/{id}/employee', function () {

    let resp_company;
    let body_company;
    let resp_user;
    let body_user;
    let code;
    if (env === 'local') {
        code = 'local';
    } else {
        code = 'poc';
    }
    describe('T0:Set-up', function () {
        this.timeout(25 * 1000);
        it('create company at IAM', async function () {
            let createCompanyIAMData = dataBody.createCompanyIAMBody();
            resp_company = await createCompanyIAMAsync(createCompanyIAMData, topadmin);
            body_company = JSON.parse(resp_company.body);
            Assert.deepEqual(resp_company.statusCode, 200);
        });
        it('create user at IAM', async function () {
            let createUserIAMData = dataBody.createUserIAMBody([body_company.id], body_company.id);
            resp_user = await createUserIAMAsync(createUserIAMData, topadmin);
            body_user = JSON.parse(resp_user.body);
            Assert.deepEqual(resp_user.statusCode, 200);
        });
        it('activate company at tide', async function () {
            let activateCompanyData = dataBody.activateCompanyBody(code, topadmin.networkId, body_company.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
        });
        it('activate user at tide', async function () {
            let activateUserData = dataBody.activateUserBody(body_user.id, body_user.username, body_company.id, ['user']);
            let respActivate = await activateUserAsync(activateUserData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
        });
    });

    describe('T0:C2249101: query by companyId', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
    });

    describe('T1:C2252646: query by not exist companyId', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync('companyId_not_exist', topadmin);
            Assert.deepEqual(respGet.statusCode, 404);
            // verifyPayloadSync(respGet, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });

    describe('T1:C2492134: query by null companyId', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync('', topadmin);
            Assert.deepEqual(respGet.statusCode, 404);
        });
    });

    describe('T1:C2492135: query by special string', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync('!~@', topadmin);
            Assert.deepEqual(respGet.statusCode, 404);
            // verifyPayloadSync(respGet, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });

    describe('T1:C3575747: query by userId', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `userId=${body_user.id}`});
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
    });

    describe('T1:C3575749: query by userName', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `userName=${body_user.username}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].username, body_user.username, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
    });

    describe('T1:C3575750: query by displayName', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `displayName=${body_user.displayName}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].id, body_user.id, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
    });

    describe('T1:C3575748: query by searchCondition,include userId/userName/displayName/cellphone/email', function () {
        it('test: searchCondition userId', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `searchCondition=${body_user.id}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].id, body_user.id, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
        it('test: searchCondition userName', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `searchCondition=${body_user.username}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].id, body_user.id, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
        it('test: searchCondition displayName', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `searchCondition=${body_user.displayName}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].id, body_user.id, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
        it('test: searchCondition cellphone', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `searchCondition=${body_user.cellphone}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].id, body_user.id, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
        it('test: searchCondition email', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, topadmin, {queryString: `searchCondition=${body_user.email}`});
            let body_get = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(body_get.payload.results[0].id, body_user.id, 'check this user can be queried');
            await verifySchemaAsync(respGet, getAllEmployeesSchema);
        });
    });

    describe('T1:C3709103: normal user is not allowed to query employee', function () {
        it('test', async function () {
            let respGet = await getUserByCompanyIdAsync(body_company.id, baasOrg01);
            Assert.deepEqual(respGet.statusCode, 403);
            verifyPayloadSync(respGet, IAM.AuthorizationError.errorCode, 'code');
        });
    });
});