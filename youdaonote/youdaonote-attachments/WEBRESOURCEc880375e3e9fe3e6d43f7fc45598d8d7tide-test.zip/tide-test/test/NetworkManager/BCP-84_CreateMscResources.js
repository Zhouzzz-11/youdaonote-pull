//TIDE平台-新建业务资源-POST-/msc/resources
//BCP-84 TIDE平台新建业务资源
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085591
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085588
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085589
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085620
`use strict`;

const {createMscResource} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify');
const {postMscResourcesUserSchema} = require('../../test-schema/Proxy/msc_resources');
const {dataBody} = require('../../test-lib/mockdata');
const {Assert} = require('@rootcloud/darjeeling');


describe(`/test: POST /msc/resources`, function () {

    describe('T0:C2085591: create Msc Resources user', function () {
        it('test', async function () {
            var UserReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            let resp = await createMscResource(UserReqBody);
            Assert.deepEqual(resp.statusCode, 201);
            await verifySchemaAsync(resp, postMscResourcesUserSchema);
            verifyPayloadSync(resp, [UserReqBody], 'payload.resources');
        });
    });

    describe('T1:C2085588: create MscResources user(Required fields are missing)', function () {
        it('test', async function () {
            var UserMissReqBody = dataBody.createMscResourcesBody('User', '');
            let resp = await createMscResource(UserMissReqBody);
            Assert.deepEqual(resp.statusCode, 400);
            verifyPayloadSync(resp, 'please input $class', 'message');
        });
    });
    describe('T1:C2085589: create MscResources (class not exist)', function () {
        it('test', async function () {
            var UserClassNotExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.UserN');
            let resp = await createMscResource(UserClassNotExistReqBody);
            Assert.deepEqual(resp.statusCode, 400);
            verifyPayloadSync(resp, 'No registry for specified model name', 'message');
        });
    });

    describe('T1:C2085620: create MscResources (msc resources already exists)', function () {
        it('test', async function () {
            var UserExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            let resp1 = await createMscResource(UserExistReqBody);
            Assert.deepEqual(resp1.statusCode, 201);
            let resp2 = await createMscResource(UserExistReqBody);
            Assert.deepEqual(resp2.statusCode, 400);
        });
    });
});
