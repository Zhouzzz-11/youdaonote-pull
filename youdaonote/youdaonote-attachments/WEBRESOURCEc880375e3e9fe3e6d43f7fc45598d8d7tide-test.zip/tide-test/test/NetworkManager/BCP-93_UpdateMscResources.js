//TIDE平台-更新业务资源-PUT-/msc/resources
//BCP-93  TIDE平台更新业务资源
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085601
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085595
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085597
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085600
`use strict`;

const {Assert} = require('@rootcloud/darjeeling');
const {topadmin} = require('../../test-data/NetworkManager/BCP-60_auth_login_data');
const {verifyPayloadSync} = require('../../test-verify/verify');
const {createMscResource, updateMscResource} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
const {dataBody} = require('../../test-lib/mockdata');
const {TIDE} = require('../../test-lib/errorMessage');

describe(`/test: PUT /msc/resources`, function () {

    describe('T0:C2085601: update Msc Resources user', function () {
        let UserReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
        let expected_message = true;
        it(`create msc resource`, async function() {
            let resp = await createMscResource(UserReqBody,topadmin);
            Assert.deepEqual(resp.statusCode, 201, 'check create response status code');
        });
        it(`update msc resource`, async function () {
            UserReqBody['name'] = 'update_username';
            let respUpdate = await updateMscResource(UserReqBody,topadmin);
            Assert.deepEqual(respUpdate.statusCode, 200, 'check update response status code ');
            verifyPayloadSync(respUpdate, expected_message, 'success');
        });
    });

    describe('T1:C2085595: update MscResources user(Required fields are missing)', function () {
        var UserMissReqBody = dataBody.createMscResourcesBody('User', '');
        it(`update msc resource(required field missing)`, async function () {
            let respUpdate = await updateMscResource(UserMissReqBody, topadmin);
            let bodyUpdate = JSON.parse(respUpdate.body);
            Assert.deepEqual(respUpdate.statusCode, 400, 'check update response status code ');
            Assert.deepEqual(bodyUpdate.code, TIDE.MscUnCategorizedError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C2085597: update MscResources (class not exist)', function () {
        let UserClassNotExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.UserN');
        it(`update msc resource(class non exist)`, async function () {
            let respUpdate = await updateMscResource(UserClassNotExistReqBody, topadmin);
            let bodyUpdate = JSON.parse(respUpdate.body);
            Assert.deepEqual(respUpdate.statusCode, 400, 'check update response status code ');
            Assert.deepEqual(bodyUpdate.code, TIDE.MscUnCategorizedError.errorCode, 'check customized error code');
        });
    });
    describe('T1:C2085600: update MscResources (msc resources not exists)', function () {
        let UserExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
        it(`update msc resource(msc resource not exist)`,async function() {
            let respUpdate = await updateMscResource(UserExistReqBody, topadmin);
            let bodyUpdate = JSON.parse(respUpdate.body);
            Assert.deepEqual(respUpdate.statusCode, 404, 'check update response status code ');
            Assert.deepEqual(bodyUpdate.code, TIDE.MscNotExistError.errorCode, 'check customized error code');
        });
    });
});
