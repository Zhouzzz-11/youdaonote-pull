//TIDE平台-查询业务资源-GET-/msc/resources
//BCP-109  TIDE平台查询 业务资源
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085532
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085533
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085534
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085587
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085571
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085572
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085573
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085574
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085575
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085576
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085583
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085584
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085586
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2096042

`use strict`;

const _ = require('lodash');
const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {commonDict} = require('../../test-lib/requireData');
const {createMscResource, getMscResources, deleteMscResource} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify');
const {orderByAttribute} = require('../../test-utils/utils_comFunc');
const {getMscResourcesUserSchema, getMscResourcesUserResolveSchema} = require('../../test-schema/Proxy/msc_resources');
const {dataBody} = require('../../test-lib/mockdata');
const {TIDE, TIDESOL} = require('../../test-lib/errorMessage');


describe(`/test: GET /msc/resources`, function () {

    describe('T0:C2085587: get Msc Resources user full query', function () {
        var UserReqBody_1;
        var UserReqBody_2;
        it('Pre-steps: create Msc Resource', async function () {
            // 构造两个业务资源请求
            UserReqBody_1 = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            UserReqBody_2 = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            UserReqBody_1['name'] = 'mscResourcesUserName_1';
            UserReqBody_1['id'] = 'mscResourcesUserId_1';
            UserReqBody_2['name'] = 'mscResourcesUserName_2';
            UserReqBody_2['id'] = 'mscResourcesUserId_2';
            // 创建两个业务资源并检查创建结果
            let respCreate1 = await createMscResource(UserReqBody_1);
            Assert.deepEqual(respCreate1.statusCode, 201);
            let respCreate2 = await createMscResource(UserReqBody_2);
            Assert.deepEqual(respCreate2.statusCode, 201);
        });
        it('test', async function () {
            // 构造查询条件
            var queryObject = {
                resolve: true,
                filter: '{"where": {"or": [{"id":"mscResourcesUserId_1"}, {"name": "mscResourcesUserName_2"}]}}',
                sort: '[{"name": "desc"}]',
                skip: 0,
                limit: 2,
                $class: 'cn.gezhitech.tidemsc.model.User'
            };
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 200);
            const exceptedBody = [
                {
                    '$class': 'cn.gezhitech.tidemsc.model.User',
                    id: 'mscResourcesUserId_2',
                    name: 'mscResourcesUserName_2',
                    org: 'resource:cn.gezhitech.tidemsc.model.Org#core',
                    roles: ['resource:cn.gezhitech.tidemsc.model.Role#user']
                },
                {
                    '$class': 'cn.gezhitech.tidemsc.model.User',
                    id: 'mscResourcesUserId_1',
                    name: 'mscResourcesUserName_1',
                    org: 'resource:cn.gezhitech.tidemsc.model.Org#core',
                    roles: ['resource:cn.gezhitech.tidemsc.model.Role#user']
                }
            ];
            await verifySchemaAsync(respGet, getMscResourcesUserSchema);
            verifyPayloadSync(respGet, exceptedBody, 'payload.queryResult');
        });
        it('After-steps: delete test data', async function () {
            let respDelete1 = await deleteMscResource(UserReqBody_1);
            Assert.deepEqual(respDelete1.statusCode, 200);
            let respDelete2 = await deleteMscResource(UserReqBody_2);
            Assert.deepEqual(respDelete2.statusCode, 200);
        });
    });

    describe('T1:C2085533: get Msc Resources user(required field missing)', function () {
        it('test', async function () {
            var queryObject = {$class: ''};
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 400);
            verifyPayloadSync(respGet, TIDESOL.MissingRequiredFieldError.errorCode, 'code');
        });
    });

    describe('T1:C2085534: get MscResources (class not exist)', function () {
        it('test', async function () {
            var queryObject = {$class: 'cn.gezhitech.tidemsc.model.UserN'};
            var expected_message = 'No registry for specified model name';
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 400);
            verifyPayloadSync(respGet, expected_message, 'message');
        });
    });


    describe('C2085532: get MscResources (invalid token)', function () {
        it('test', async function () {
            var queryObject = {$class: 'cn.gezhitech.tidemsc.model.User'};
            let respGet = await getMscResources(queryObject, '123');
            Assert.deepEqual(respGet.statusCode, 401);
            verifyPayloadSync(respGet, TIDE.InvalidAccessToken.errorCode, 'code');
        });
    });

    describe('C2085571: get MscResources (single argument: resolve)', function () {
        it('单个参数：resolve 查询', async function () {
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                resolve: true
            };
            this.timeout(10000);
            let resp = await getMscResources(queryObject);
            Assert.deepEqual(resp.statusCode, 200);
            await verifySchemaAsync(resp, getMscResourcesUserResolveSchema);
        });
    });

    describe('T1:C2085572: get MscResources (single argument: filter)', function () {
        var UserReqBody;
        it('Pre-steps: create Msc Resource', async function () {
            UserReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            UserReqBody['name'] = 'mscResourcesUserName_name';
            UserReqBody['id'] = 'mscResourcesUserId_id';
            // 创建两个业务资源并检查创建结果
            let respCreate = await createMscResource(UserReqBody);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('test', async function () {
            //单个参数：filter 查询
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                filter: '{"where": {"or": [{"id":"mscResourcesUserId_id"}, {"name": "mscResourcesUserName_name"}]}}'
            };
            let respGet = await getMscResources(queryObject);
            let bodyGet = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getMscResourcesUserSchema);
            const actual_message = _.get(bodyGet, 'payload.queryResult');
            const actual_org = actual_message[0];
            Assert.deepEqual(actual_org, UserReqBody);
        });
        it('After-steps: delete test data', async function () {
            let respDelete = await deleteMscResource(UserReqBody);
            Assert.deepEqual(respDelete.statusCode, 200);
        });
    });

    describe('T1:C2085573: get MscResources (single argument: skip)', function () {
        it('单个参数：skip 查询', async function () {
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                skip: 2,
                limit: 1
            };
            let respGet = await getMscResources(queryObject);
            const bodyGet = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getMscResourcesUserSchema);
            const actual_message = _.get(bodyGet, 'payload.bookmark');
            const actual_arr = _.get(bodyGet, 'payload.queryResult');
            const len = actual_arr.length;
            Assert.deepEqual(String(len), '1', '检查skip的筛选结果');
            Assert.deepEqual(actual_message, '3', '检查skip的筛选结果');
        });
    });

    describe('T1:C2085574: get MscResources (single argument: limit)', function () {
        it('单个参数：limit 查询', async function () {
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                limit: 1
            };
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getMscResourcesUserSchema);
            const body = JSON.parse(respGet.body);
            const actual_arr = _.get(body, 'payload.queryResult');
            const len = actual_arr.length;
            Assert.deepEqual(String(len), '1', '检查skip的筛选结果');
        });
    });

    describe('T1:C2085575: get MscResources (single argument: sort)', function () {
        it('单个参数：sort 查询', async function () {
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                sort: '[{"id":"desc"}]',
                limit: 5
            };
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getMscResourcesUserSchema);
            const body = JSON.parse(respGet.body);
            const actual_arr = _.get(body, 'payload.queryResult');
            let by_name_sorted = actual_arr.slice(0);
            by_name_sorted.sort(orderByAttribute('id', true));
            Assert.deepEqual(actual_arr, by_name_sorted, '检查sort参数的排序');
        });
    });

    describe('T1:C2085583: get MscResources (double argument: resolve and filter)', function () {
        var UserReqBody_3;
        it('Pre-steps: create msc resource', async function () {
            UserReqBody_3 = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            UserReqBody_3['id'] = 'mscResourcesUserId_' + commonDict['randStr'];
            UserReqBody_3['name'] = 'mscResourcesUserName_' + commonDict['randStr'];
            let respCreate = await createMscResource(UserReqBody_3);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('两个参数：resolve和filter查询', async function () {
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                resolve: true,
                filter: `{"where": {"and": [{"id": "${UserReqBody_3['id']}"},{"name": "${UserReqBody_3['name']}"}]}}`
            };
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 200);
            const body = JSON.parse(respGet.body);
            const resources_arr = _.get(body, 'payload.queryResult');
            let resources_first = resources_arr[0];
            const expected =
                {
                    '$class': 'cn.gezhitech.tidemsc.model.User',
                    'id': UserReqBody_3['id'],
                    'name': UserReqBody_3['name'],
                    'org': 'resource:cn.gezhitech.tidemsc.model.Org#core',
                    'roles': ['resource:cn.gezhitech.tidemsc.model.Role#user']
                };
            Assert.deepEqual(resources_first, expected, '检查sort参数的排序');
        });
        it('After-steps: delete test data', async function () {
            let respDelete = await deleteMscResource(UserReqBody_3);
            Assert.deepEqual(respDelete.statusCode, 200);
        });
    });

    describe('T1:C2085584: get MscResources (double argument: skip and limit )', function () {
        it('两个参数：skip和limit查询', async function () {
            var queryObject = {
                $class: 'cn.gezhitech.tidemsc.model.User',
                skip: 5,
                limit: 2
            };
            let respGet = await getMscResources(queryObject);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getMscResourcesUserSchema);
            const body = JSON.parse(respGet.body);
            const actual_message = _.get(body, 'payload.bookmark');
            const actual_arr = _.get(body, 'payload.queryResult');
            const len = actual_arr.length;
            Assert.deepEqual(String(len), '2', '检查skip的筛选结果');
            Assert.deepEqual(actual_message, '7', '检查skip的筛选结果');
        });
    });
});
