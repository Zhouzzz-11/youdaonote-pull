'use strict';

const { baasOrg01 } = require('../../test-data/NetworkManager/BCP-60_auth_login_data');
const { Assert } = require('@rootcloud/darjeeling');
const { getBlockCount, getBlockList } = require('../../test-function/NetworkManager/browserFunction');
const { blockBrowserSchema } = require('../../test-schema/Proxy/blockBrowser');
const { verifySchemaAsync } = require('../../test-verify/verify');
const { EvidenceObj } = require('../../test-data/Solution/Evidence/evidenceData');
const { updateTextEvidenceData_1 } = require('../../test-data/Solution/Evidence/evidenceData');
const { createEvidenceAsync, updateEvidenceByIdAsync, deleteEvidenceByIdAsync } = require('../../test-function/Solution/Evidence/textEvidenceFunction');
// const { user } = require('../../test-utils/util_user');


describe('test for block browser', function() {
    describe('T0:SetUp: add transaction', function() {
        let respCreate;
        let bodyCreate;
        it('create evidence', async function(){
            var evidenceReqBody = new EvidenceObj();
            respCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        }).timeout(25 * 1000);
        it('update evidence', async function () {
            let rspUpdate = await updateEvidenceByIdAsync(bodyCreate.evidenceId, updateTextEvidenceData_1, baasOrg01);
            Assert.deepEqual(rspUpdate.statusCode, 200);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('/test: GET /msc/provenance/browser/count', function() {
        it('T0:C2913044: get block count and check the response', async function(){
            let resp = await getBlockCount(baasOrg01);
            Assert.deepEqual(resp.statusCode, 200);
        });
    });

    describe('/test: GET /msc/provenance/browser/blocks', function() {
        it('T0:C2913045: get block list: default query', async function(){
            let resp = await getBlockList(baasOrg01);
            Assert.deepEqual(resp.statusCode, 200);
            await verifySchemaAsync(resp, blockBrowserSchema);
        });
        it('T1:C2913046: get block list: use skip and limit', async function(){
            let resp = await getBlockList(baasOrg01, {queryString: 'skip=2&limit=1'});
            let payload = JSON.parse(resp.body).payload;
            Assert.deepEqual(resp.statusCode, 200);
            Assert.deepEqual(payload.length, 1, 'check the result number');
            await verifySchemaAsync(resp, blockBrowserSchema);
        });
    });
});