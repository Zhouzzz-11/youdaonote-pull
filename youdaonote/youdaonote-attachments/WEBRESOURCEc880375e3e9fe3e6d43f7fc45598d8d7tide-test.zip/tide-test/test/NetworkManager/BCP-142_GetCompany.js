//NetworkManager-查询企业-GET-/company/{id}
//BCP-142
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=210330

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {createCompanyIAMAsync, createUserIAMAsync, activateCompanyAsync, activateUserAsync, getCompanyByCompanyIdAsync} = require('../../test-function/NetworkManager/userFunction');
const {topadmin} = require('../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user admin.
const {dataBody} = require('../../test-lib/mockdata');
const {getCompanySchema} = require('../../test-schema/Proxy/user');
// const {IAM} = require('../../test-lib/errorMessage');
const {verifySchemaAsync} = require('../../test-verify/verify');
const env = process.env.CURRENT_ENV;

describe('/test: GET /company/{id}', function() {
    let resp_company;
    let body_company;
    let resp_user;
    let body_user;
    let code;
    if (env === 'local') {
        code = 'local';
    } else {
        code = 'poc';
    }
    describe('T0:Pre-steps', function() {
        this.timeout(25 * 1000);
        it('create company at IAM', async function(){
            let createCompanyIAMData = dataBody.createCompanyIAMBody();
            resp_company = await createCompanyIAMAsync(createCompanyIAMData, topadmin);
            body_company = JSON.parse(resp_company.body);
            Assert.deepEqual(resp_company.statusCode, 200);
        });
        it('create user at IAM', async function(){
            let createUserIAMData = dataBody.createUserIAMBody([body_company.id], body_company.id);
            resp_user = await createUserIAMAsync(createUserIAMData, topadmin);
            body_user = JSON.parse(resp_user.body);
            Assert.deepEqual(resp_user.statusCode, 200);
        });
        it('activate company at tide', async function(){
            let activateCompanyData = dataBody.activateCompanyBody(code,topadmin.networkId, body_company.id);
            let respActivate = await activateCompanyAsync(activateCompanyData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
        });
        it('activate user at tide', async function () {
            let activateUserData = dataBody.activateUserBody(body_user.id, body_user.username, body_company.id, ['user']);
            let respActivate = await activateUserAsync(activateUserData, topadmin);
            Assert.deepEqual(respActivate.statusCode, 200);
        });
    });

    describe('T0:C2412170: query by companyId', function() {
        it('test', async function () {
            let respGet = await getCompanyByCompanyIdAsync(body_company.id, topadmin);
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getCompanySchema);
        });
    });

    describe('T1:C2412171: query by not exist companyId', function() {
        it('test', async function () {
            let respGet = await getCompanyByCompanyIdAsync('companyId_not_exist', topadmin);
            Assert.deepEqual(respGet.statusCode, 404);
            // verifyPayloadSync(respGet, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });

    describe('T1:C2492136: query by null companyId', function() {
        it('test', async function () {
            let respGet = await getCompanyByCompanyIdAsync('', topadmin);
            Assert.deepEqual(respGet.statusCode, 405);
        });
    });

    describe('T1:C2492137: query by special string', function() {
        it('test', async function () {
            let respGet = await getCompanyByCompanyIdAsync('!~@', topadmin);
            Assert.deepEqual(respGet.statusCode, 404);
            // verifyPayloadSync(respGet, IAM.ModelNotFound404Error.errorCode, 'code');
        });
    });

    describe('T1:C2495859: query by companyId and code("code" is non-required param)', function() {
        it('test', async function () {
            let respGet = await getCompanyByCompanyIdAsync(body_company.id, topadmin, {queryString: 'code=poc'});
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getCompanySchema);
        });
    });

    describe('T1:C2495861: query by companyId and not exist code("code" is non-required param)', function() {
        it('test', async function () {
            let respGet = await getCompanyByCompanyIdAsync(body_company.id, topadmin, {queryString: 'code=code_not_exist'});
            Assert.deepEqual(respGet.statusCode, 200);
            await verifySchemaAsync(respGet, getCompanySchema);
        });
    });
});