//TIDE平台-删除业务资源-DELETE-/msc/resources
//BCP-95  TIDE平台删除业务资源
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085612
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085609
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085610
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085605
`use strict`;

const {Assert} = require('@rootcloud/darjeeling');
const {topadmin} = require('../../test-data/NetworkManager/BCP-60_auth_login_data');
const {dataBody} = require('../../test-lib/mockdata');
const {createMscResource, deleteMscResource} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
const {verifyPayloadSync} = require('../../test-verify/verify');
const {TIDE, TIDESOL} = require('../../test-lib/errorMessage');

describe(`/test: DELETE /msc/resources/{id}`, function () {

    describe('T0:C2085612: delete Msc Resources user', function () {
        let UserReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
        let expected_message = true;
        it(`create msc resource`, async function () {
            let respCreate = await createMscResource(UserReqBody, topadmin);
            Assert.deepEqual(respCreate.statusCode, 201, 'check create response status code');
        });
        it(`delete msc resource`, async function () {
            let respDelete = await deleteMscResource(UserReqBody, topadmin);
            Assert.deepEqual(respDelete.statusCode, 200, 'check delete response status code');
            verifyPayloadSync(respDelete, expected_message, 'success');
        });
    });

    describe('T1:C2085609: delete MscResources user(Required fields are missing)', function () {
        let UserMissReqBody = dataBody.createMscResourcesBody('User', '');
        it(`delete msc resource(required field missing)`, async function () {
            let respDelete = await deleteMscResource(UserMissReqBody, topadmin);
            let bodyDelete = JSON.parse(respDelete.body);
            Assert.deepEqual(respDelete.statusCode, 400, 'check delete response status code');
            Assert.deepEqual(bodyDelete.code, TIDESOL.MissingRequiredFieldError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C2085611: delete MscResources (class not exist)', function () {
        let UserClassNotExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.UserN');
        it(`delete msc resource(class not exist)`, async function () {
            let respDelete = await deleteMscResource(UserClassNotExistReqBody, topadmin);
            let bodyDelete = JSON.parse(respDelete.body);
            Assert.deepEqual(respDelete.statusCode, 400, 'check delete response status code');
            Assert.deepEqual(bodyDelete.code, TIDE.MscUnCategorizedError.errorCode, 'check customized error code');
        });
    });
    describe('T1:C2085610:  delete MscResources (msc resources not exists)', function () {
        let UserExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
        it(`delete msc resource(msc resource not exist)`, async function () {
            let respDelete = await deleteMscResource(UserExistReqBody, topadmin);
            let bodyDelete = JSON.parse(respDelete.body);
            Assert.deepEqual(respDelete.statusCode, 404, 'check delete response status code');
            Assert.deepEqual(bodyDelete.code, TIDE.MscNotExistError.errorCode, 'check customized error code');
        });
    });
});
