//TIDE平台-根据ID查询业务资源-GET-/msc/resources/{id}
//BCP-109  TIDE平台根据ID查询 业务资源
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/C2141820
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085604
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085605
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085606
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2085607
`use strict`;

const {Assert} = require('@rootcloud/darjeeling');
const {topadmin} = require('../../test-data/NetworkManager/BCP-60_auth_login_data');
const {dataBody} = require('../../test-lib/mockdata');
const {createMscResource, getMscResourceById} = require('../../test-function/NetworkManager/mscResourcesFunction');   //Function used in script should required from test-function
const {verifySchemaAsync, verifyPayloadSync} = require('../../test-verify/verify');
const {getMscResourcesUserByIdSchema} = require('../../test-schema/Proxy/msc_resources');
const {TIDE, TIDESOL} = require('../../test-lib/errorMessage');

describe(`/test: GET /msc/resources/{id}`, function () {

    describe('T0:C2085606: get Msc Resources user by id', function () {
        let UserReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
        it(`create msc resource`, async function () {
            let resp = await createMscResource(UserReqBody, topadmin);
            Assert.deepEqual(resp.statusCode, 201, 'check create response status code');
        });
        it(`get msc resource`, async function () {
            let respGet = await getMscResourceById(UserReqBody, topadmin);
            Assert.deepEqual(respGet.statusCode, 200, 'check create response status code');
            await verifySchemaAsync(respGet, getMscResourcesUserByIdSchema);
            verifyPayloadSync(respGet, {
                '$class': 'cn.gezhitech.tidemsc.model.User',
                'id': UserReqBody['id'],
                'name': UserReqBody['name'],
                'org': 'resource:cn.gezhitech.tidemsc.model.Org#core',
                'roles': [
                    'resource:cn.gezhitech.tidemsc.model.Role#user'
                ]
            }, 'payload');
        });
    });

    describe('T1:C2141820: get MscResources user by id(Required fields are missing)', function () {
        let UserMissReqBody = dataBody.createMscResourcesBody('User', '');
        it(`get msc resource(required field missing)`, async function () {
            let respGet = await getMscResourceById(UserMissReqBody, topadmin);
            let bodyGet = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 400, 'check delete response status code');
            Assert.deepEqual(bodyGet.code, TIDESOL.MissingRequiredFieldError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C2085605: get MscResources user by id(class not exist)', function () {
        it('get msc resource(class not exist)', async function () {
            let UserClassNotExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.UserN');
            let respGet = await getMscResourceById(UserClassNotExistReqBody, topadmin);
            let bodyGet = JSON.parse(respGet.body);
            Assert.deepEqual(respGet.statusCode, 400, 'check delete response status code');
            Assert.deepEqual(bodyGet.code, TIDE.MscUnCategorizedError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C2085604:  get MscResources user by id(msc resources not exists)', function () {
        it(`get msc resource(msc resource not exist)`, async function () {
            let UserExistReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
            let respGet = await getMscResourceById(UserExistReqBody, topadmin);
            Assert.deepEqual(respGet.statusCode, 404, 'check delete response status code');
        });
    });

    describe('T1:C2085607: get Msc Resources user by id', function () {
        let UserReqBody = dataBody.createMscResourcesBody('User', 'cn.gezhitech.tidemsc.model.User');
        it(`create msc resource`, async function () {
            let respCreate = await createMscResource(UserReqBody, topadmin);
            Assert.deepEqual(respCreate.statusCode, 201, 'check create response status code');
        });
        it(`get msc resource`, async function () {
            let respGet = await getMscResourceById(UserReqBody, topadmin);
            Assert.deepEqual(respGet.statusCode, 200, 'check create response status code');
            await verifySchemaAsync(respGet, getMscResourcesUserByIdSchema);
            verifyPayloadSync(respGet, {
                '$class': 'cn.gezhitech.tidemsc.model.User',
                'id': UserReqBody['id'],
                'name': UserReqBody['name'],
                'org': 'resource:cn.gezhitech.tidemsc.model.Org#core',
                'roles': [
                    'resource:cn.gezhitech.tidemsc.model.Role#user'
                ]
            });
        });
    });
});
