'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {
    getHeaders,
    iamCreatOrg,
    subscribeCompany,
    createUser,
    activateCompany,
    activateUser
} = require('../test-utils/util_user');
let {baasOrg1, baasOrg2, topadmin} = require('../test-data/NetworkManager/BCP-60_auth_login_data');
// const {deleteIAMCompany, deleteIAMUser, updateIAMCompany} = require('../test-function/NetworkManager/userFunction');
const {httpRequestAsync} = require('../test-utils/util_httpRequest');
const {TideNetworkManagerUrl} = require('../test-lib/url');
const {randomString} = require('../test-utils/utils_comFunc');
const {queryConsortiaStatus, sleep} = require('../test-function/NetworkManager/consortiaFuntion');

before('T0: global setup: create user', function () {
    this.timeout(30 * 1000);
    let headers;
    let org1SuperHeaders;
    let company1Info, org1User1Info, org1User2Info;
    let company2Info, org2User1Info, org2User2Info;

    // 创建企业1
    it('T0: IAM get topAdmin token and create company1', async function () {
        headers = await getHeaders(topadmin.iAMBody);
        company1Info = await iamCreatOrg(headers);
        Assert.deepEqual(company1Info.statusCode, 200, 'check if create company success');
        Object.assign(baasOrg1.superUser.iamLoginBody, {
            username: company1Info.companyUserName,
            password: company1Info.companyUserPassword
        });
        baasOrg1.superUser.orgId = company1Info.companyId;
        baasOrg1.superUser.email = company1Info.companyEmail;
        baasOrg1.superUser.cellphone = company1Info.companyCellphone;
    });

    it('T0: IAM subscribe company1', async function () {
        let rsp = await subscribeCompany(headers, company1Info.companyId);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('T0: IAM create company1\'s user1 and user2', async function () {
        org1User1Info = await createUser(headers, company1Info.companyId);
        org1User2Info = await createUser(headers, company1Info.companyId);
        Assert.deepEqual(org1User1Info.statusCode, 200, 'check status code');
        Assert.deepEqual(org1User2Info.statusCode, 200, 'check status code');
        baasOrg1.normalUsers.user1.iamLoginBody.username = org1User1Info.username;
        baasOrg1.normalUsers.user1.userId = org1User1Info.userId;
        baasOrg1.normalUsers.user2.iamLoginBody.username = org1User1Info.username;
        baasOrg1.normalUsers.user2.userId = org1User2Info.userId;
    });


    it('T0: TIDE activate company1', async function () {
        let rsp = await activateCompany(headers, company1Info.companyId);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('T0: TIDE activate company1\'s user1 and user2', async function () {
        let rsp1 = await activateUser(headers, org1User1Info.userId, org1User1Info.username, company1Info.companyId);
        let rsp2 = await activateUser(headers, org1User2Info.userId, org1User2Info.username, company1Info.companyId);
        Assert.deepEqual(rsp1.statusCode, 200, 'check status code');
        Assert.deepEqual(rsp2.statusCode, 200, 'check status code');
    });


    // 创建企业2
    it('T0: IAM get topAdmin token and create company2', async function () {
        company2Info = await iamCreatOrg(headers);
        Assert.deepEqual(company2Info.statusCode, 200, 'check if create company success');
        Object.assign(baasOrg2.superUser.iamLoginBody, {
            username: company2Info.companyUserName,
            password: company2Info.companyUserPassword
        });
        baasOrg2.superUser.orgId = company2Info.companyId;
        baasOrg2.superUser.email = company2Info.companyEmail;
        baasOrg2.superUser.cellphone = company2Info.companyCellphone;
    });

    it('T0: IAM subscribe company2', async function () {
        let rsp = await subscribeCompany(headers, company2Info.companyId);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('T0: IAM create company2\'s user1 and user2', async function () {
        org2User1Info = await createUser(headers, company2Info.companyId);
        org2User2Info = await createUser(headers, company2Info.companyId);
        Assert.deepEqual(org2User1Info.statusCode, 200, 'check status code');
        Assert.deepEqual(org2User2Info.statusCode, 200, 'check status code');
        baasOrg2.normalUsers.user1.iamLoginBody.username = org2User1Info.username;
        baasOrg2.normalUsers.user1.userId = org2User1Info.userId;
        baasOrg2.normalUsers.user2.iamLoginBody.username = org2User1Info.username;
        baasOrg2.normalUsers.user2.userId = org2User2Info.userId;
    });


    it('T0: TIDE activate company2', async function () {
        let rsp = await activateCompany(headers, company2Info.companyId);
        Assert.deepEqual(rsp.statusCode, 200, 'check status code');
    });

    it('T0: TIDE activate company2\'s user1 and user2', async function () {
        let rsp1 = await activateUser(headers, org2User1Info.userId, org2User1Info.username, company2Info.companyId);
        let rsp2 = await activateUser(headers, org2User2Info.userId, org2User2Info.username, company2Info.companyId);
        Assert.deepEqual(rsp1.statusCode, 200, 'check status code');
        Assert.deepEqual(rsp2.statusCode, 200, 'check status code');
    });


    // 企业1创建联盟
    it('T0: org1 super user get headers and create consortia', async function () {
        org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
        let reqBody = {
            'displayName': randomString(),
            'description': 'string',
            'deployMode': 'CLOUD_MODE'
        };
        let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
            org1SuperHeaders, reqBody);
        Assert.deepEqual(consortiaInfo.statusCode, 202);
        baasOrg1.superUser.consortiaInfo.push({
            id: consortiaInfo.payload.id,
            networkCode: consortiaInfo.payload.networkCode
        });

        console.dir(baasOrg1, {depth: null});
    });

    it('T0: org1 super user query consortia\'s status', async function () {
        let consortiaStatusInfo = await queryConsortiaStatus(baasOrg1.superUser.consortiaInfo[0].id,
            baasOrg1.superUser.consortiaInfo[0].networkCode, org1SuperHeaders);
        for (let i = 0; i < 10; i++) {
            if (consortiaStatusInfo.payload === 'RUNNING') {
                break;
            } else {
                await sleep(10000);
                consortiaStatusInfo = await queryConsortiaStatus(baasOrg1.superUser.consortiaInfo[0].id,
                    baasOrg1.superUser.consortiaInfo[0].networkCode, org1SuperHeaders);
                console.log(`query${i} -----------------` + (new Date()).valueOf(), consortiaStatusInfo);
            }
        }
        Assert.deepEqual(consortiaStatusInfo.statusCode, 200);
    }).timeout(100 * 1000);


    it('T0: org1 super user create consortia\'s Evidence App', async function () {
        let reqBody = {
            'displayName': randomString(),
            'type': 'Evidence',
            'orgIds': [],
            'description': 'string'
        };
        let appInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia +
            `/${baasOrg1.superUser.consortiaInfo[0].id}/applications`, org1SuperHeaders, reqBody);
        Assert.deepEqual(appInfo.statusCode, 202);

        console.dir(baasOrg1, {depth: null});
        console.dir(baasOrg2, {depth: null});
    });
})
;

// after('T0: global teardown: delete user', async function () {
//     this.timeout(80 * 1000);
//     let org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
//     let consortiaDeleteInfo = await httpRequestAsync('delete', TideNetworkManagerUrl.consortia +
//         `/${baasOrg1.superUser.consortiaInfo[0].id}`, org1SuperHeaders);
//     Assert.deepEqual(consortiaDeleteInfo.statusCode, 200);
//     console.log('delete baasOrg01 ');
//     let headers = await getHeaders(topadmin.iAMBody);
//     let org1user1DeleteResp = await deleteIAMUser(baasOrg1.normalUsers.user1.userId, headers);
//     let org1user2DeleteResp = await deleteIAMUser(baasOrg1.normalUsers.user2.userId, headers);
//     // console.log(org1user1DeleteResp);
//     Assert.deepEqual(org1user1DeleteResp.statusCode, 204);
//     Assert.deepEqual(org1user2DeleteResp.statusCode, 204);
//     let org1UpdateResp = await updateIAMCompany(baasOrg1.superUser.orgId, headers);
//     // console.log(org1UpdateResp);
//     Assert.deepEqual(org1UpdateResp.statusCode, 200);
//     let org1DeleteResp = await deleteIAMCompany(baasOrg1.superUser.orgId, headers);
//     // console.log(org1DeleteResp);
//     Assert.deepEqual(org1DeleteResp.statusCode, 204);
//
// });