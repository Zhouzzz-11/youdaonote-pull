'use strict';

const {Assert} = require('@rootcloud/darjeeling');
// const {getHeaders,} = require('../../../test-utils/util_user');
// let {baasOrg1, nonActivateUser} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {TideNetworkManagerUrl} = require('../../../test-lib/url');
const {randomString} = require('../../../test-utils/utils_comFunc');
// const {queryConsortiaStatus, sleep} = require('../../../test-function/NetworkManager/consortiaFuntion');
// const {consortiaBasicInfoSchema} = require('../../../test-schema/Networkmanager/consortia');
// const {createConsortiaSchema, consortiaBasicInfoSchema} = require('../../../test-schema/Networkmanager/consortia');
// const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');

describe(' /test: GET /api/v1/consortia/{id}', function () {
    let org1SuperHeaders;
    describe('查看联盟的基本信息', function () {

        // TODO bug
        it('T1: C5511368: 查看联盟的基本信息(参数类型、字符串内容、字符串长度校验)', async function () {
            let url = TideNetworkManagerUrl.consortia + `/~!`;
            let consortiaBasicInfo = await httpRequestAsync('get', url, org1SuperHeaders);
            Assert.deepEqual(consortiaBasicInfo.statusCode, 401);
        });

        // TODO bug
        it('T1: C5511369: 查看联盟的基本信息(查询的联盟不存在)', async function () {
            let nonExistConsortia = randomString();
            let url = TideNetworkManagerUrl.consortia + `/${nonExistConsortia}`;
            let consortiaBasicInfo = await httpRequestAsync('get', url, org1SuperHeaders);
            Assert.deepEqual(consortiaBasicInfo.statusCode, 401);
        });

    });
});