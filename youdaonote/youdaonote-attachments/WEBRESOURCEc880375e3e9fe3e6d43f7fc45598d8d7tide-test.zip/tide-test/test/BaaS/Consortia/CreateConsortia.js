'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {
    getHeaders,
} = require('../../../test-utils/util_user');
let {baasOrg1, nonActivateUser} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {TideNetworkManagerUrl} = require('../../../test-lib/url');
const {randomString} = require('../../../test-utils/utils_comFunc');
const {queryConsortiaStatus, sleep} = require('../../../test-function/NetworkManager/consortiaFuntion');
const {createConsortiaSchema, consortiaBasicInfoSchema} = require('../../../test-schema/Networkmanager/consortia');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');

describe(' /test: POST /api/v1/consortia', function () {
    let org1SuperHeaders;
    let consortiaId, networkCode;
    let reqBody;
    describe('机构1获取请求头，创建联盟', function () {
        it('T0:C5511357: 创建联盟', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            reqBody = {
                'displayName': randomString(),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 202);
            await verifyObjectSchemaAsync(consortiaInfo.payload, createConsortiaSchema);
            consortiaId = consortiaInfo.payload.id;
            networkCode = consortiaInfo.payload.networkCode;
        });

        it('T1:C5511361: 唯一性校验(使用相同的请求再次创建联盟，创建失败)', async function () {
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia, org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 400);
        });


        it('T0:C5511366: 机构1管理员查询联盟的基本信息', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let consortiaBasicInfo = await httpRequestAsync('get', url, org1SuperHeaders);
            Assert.deepEqual(consortiaBasicInfo.statusCode, 200);
            await verifyObjectSchemaAsync(consortiaBasicInfo.payload, consortiaBasicInfoSchema);
        });

        it('T1: C5511373: 查看联盟的基本信息(使用未激活tide身份的用户做查询 返回 400，返回该用户未激活区块链服务)', async function () {
            let nonActivateSuperHeaders = await getHeaders(nonActivateUser);
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let consortiaBasicInfo = await httpRequestAsync('get', url, nonActivateSuperHeaders);
            Assert.deepEqual(consortiaBasicInfo.statusCode, 400);
        });

        it('T0:C5511375: 机构1查询联盟网络的创建状态', async function () {
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            for (let i = 0; i < 10; i++) {
                if (consortiaStatusInfo.payload === 'RUNNING') {
                    break;
                } else {
                    await sleep(10000);
                    consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
                }
            }
            Assert.deepEqual(consortiaStatusInfo.statusCode, 200);
        }).timeout(100 * 1000);


        it('T0:C5511383: 机构1管理员删除联盟', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let consortiaDeleteInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(consortiaDeleteInfo.statusCode, 200);
        });

        it('T1:C5511362: 删除联盟后再次创建(创建成功)', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            reqBody = {
                'displayName': randomString(),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 202);
            await verifyObjectSchemaAsync(consortiaInfo.payload, createConsortiaSchema);
            consortiaId = consortiaInfo.payload.id;
            networkCode = consortiaInfo.payload.networkCode;
        });

        it('teardown: 删除联盟', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let consortiaDeleteInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(consortiaDeleteInfo.statusCode, 200);
        });

    });

    describe('创建联盟: 必填项校验', function () {

        it('T1:C5511358: 创建联盟(必填项displayName)', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let reqBody = {
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 400);
        });
    });

    describe('创建联盟：非必填项校验', function () {
        it('T1:C5511359: 创建联盟(非必填项description)', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let reqBody = {
                'displayName': randomString(),
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 202);
            await verifyObjectSchemaAsync(consortiaInfo.payload, createConsortiaSchema);
            consortiaId = consortiaInfo.payload.id;
        });

        it('删除联盟', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let consortiaDeleteInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(consortiaDeleteInfo.statusCode, 200);
        });
    });

    describe('创建联盟：参数类型、字符串内容、字符串长度校验', function () {
        it('T1:C5511360: 创建联盟(字符串长度校验:displayName 3)', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            reqBody = {
                'displayName': randomString({length: 3}),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 400);
        });

        it('T1:C5511360: 创建联盟(字符串长度校验:displayName 61)', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            reqBody = {
                'displayName': randomString({length: 61}),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 400);
        });
    });

    describe('创建联盟：用户异常', function () {
        it('T1:C5511363: 创建联盟(使用未激活tide身份的用户创建联盟)', async function () {
            let nonActivateSuperHeaders = await getHeaders(nonActivateUser);
            reqBody = {
                'displayName': randomString(),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                nonActivateSuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 400);
        });

        it('T1:C5511360: 创建联盟(token为空/token错误/token失效)', async function () {
            org1SuperHeaders.Authorization = randomString();
            reqBody = {
                'displayName': randomString(),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1SuperHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 401);
        });

        it('T1:C5511365: 创建联盟(使用普通的用户创建联盟)', async function () {
            let org1NormalHeaders = getHeaders(baasOrg1.normalUsers.user1.iamLoginBody);
            reqBody = {
                'displayName': randomString(),
                'description': 'string',
                'deployMode': 'CLOUD_MODE'
            };
            let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
                org1NormalHeaders, reqBody);
            Assert.deepEqual(consortiaInfo.statusCode, 401);
        });
    });

});