'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {
    getHeaders,
} = require('../../../test-utils/util_user');
// let {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
let {baasOrg1, baasOrg2} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {TideNetworkManagerUrl} = require('../../../test-lib/url');
const {randomString} = require('../../../test-utils/utils_comFunc');
const {queryAppStatus, sleep} = require('../../../test-function/NetworkManager/consortiaFuntion');
const {createAppSchema} = require('../../../test-schema/Networkmanager/app');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');


describe(' /test: POST /api/v1/consortia/{consortiaId}/applications', function () {
    let consortiaId, org1SuperHeaders, org2SuperHeaders;
    let length;
    let appId, channelCode;
    describe(' 机构1管理员获取请求头，在联盟中创建应用', function () {
        it('setup-1: org1\'s consortia invite org2', async function () {
            length = baasOrg1.superUser.consortiaInfo.length;
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            consortiaId = baasOrg1.superUser.consortiaInfo[length - 1].id;
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations`;
            let reqBody = {
                'orgIds': [baasOrg2.superUser.orgId],
                'reason': '联盟1邀请机构2加入联盟1'
            };
            let inviteOrgInfo = await httpRequestAsync('post', url, org1SuperHeaders, reqBody);
            Assert.deepEqual(inviteOrgInfo.statusCode, 200);
        });

        it('setup-2: 机构2接受机构1的联盟邀请', async function () {
            org2SuperHeaders = await getHeaders(baasOrg2.superUser.iamLoginBody);
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations?action=APPROVE`;
            let acceptInfo = await httpRequestAsync('put', url, org2SuperHeaders);
            Assert.deepEqual(acceptInfo.statusCode, 200);
        });

        it('T0:C5511428: 机构1创建存证应用', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications`;
            let reqBody = {
                'displayName': randomString(),
                'type': 'Evidence',
                'orgIds': [],
                'description': 'string'
            };
            let appInfo = await httpRequestAsync('post', url, org1SuperHeaders, reqBody);
            await verifyObjectSchemaAsync(appInfo.payload,createAppSchema);
            appId = appInfo.payload.id;
            channelCode = appInfo.payload.channelCode;
            baasOrg1.superUser.consortiaInfo[length - 1]['app'] = [appId];
            Assert.deepEqual(appInfo.statusCode, 202);
        });

        it('T0:C5511438: 查询应用创建状态', async function () {
            let appStatusInfo = await queryAppStatus(consortiaId, appId, channelCode, org1SuperHeaders);
            for (let i = 0; i < 10; i++) {
                if (appStatusInfo.payload === 'RUNNING') {
                    break;
                } else {
                    await sleep(5000);
                    appStatusInfo = await queryAppStatus(consortiaId, appId, channelCode, org1SuperHeaders);
                    // console.log(`query${i} -----------------`);
                    // console.dir(appStatusInfo, {depth: null});
                }
            }
            Assert.deepEqual(appStatusInfo.statusCode, 200);
            Assert.deepEqual(appStatusInfo.payload, 'RUNNING');
        }).timeout(50 * 1000);

        it('T0:C5511441: 查询应用详情', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}`;
            let appDetailInfo = await httpRequestAsync('get', url, org1SuperHeaders);
            Assert.deepEqual(appDetailInfo.statusCode, 200);
        });

        it('T0:C5511461: 管理员向应用添加机构', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}/organizations`;
            let reqbody = {
                'orgIds': [
                    baasOrg2.superUser.orgId
                ]
            };
            let addOrgToAppInfo = await httpRequestAsync('post', url, org1SuperHeaders, reqbody);
            Assert.deepEqual(addOrgToAppInfo.statusCode, 200);
        });

        it('T0:C5511492: 从应用中删除机构', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}/organizations/${baasOrg2.superUser.orgId}`;
            let deleteOrgFromAppInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(deleteOrgFromAppInfo.statusCode, 200);
        });

        it('T0:C5511472-1: 机构2申请加入应用1', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}/request`;
            let applyToJoinAppInfo = await httpRequestAsync('post', url, org2SuperHeaders);
            Assert.deepEqual(applyToJoinAppInfo.statusCode, 200);
        });

        it('T0:C5511481-1: 机构1拒绝机构2申请加入应用1', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}/organizations/${baasOrg2.superUser.orgId}/request?action=REJECT`;
            let rejectInfo = await httpRequestAsync('put', url, org1SuperHeaders);
            Assert.deepEqual(rejectInfo.statusCode, 200);
        });

        it('T0:C5511472-2: 机构2申请加入应用1', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}/request`;
            let applyToJoinAppInfo = await httpRequestAsync('post', url, org2SuperHeaders);
            Assert.deepEqual(applyToJoinAppInfo.statusCode, 200);
        });

        it('T0:C5511481-2: 机构1接受机构2申请加入应用1', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}/organizations/${baasOrg2.superUser.orgId}/request?action=APPROVE`;
            let approveInfo = await httpRequestAsync('put', url, org1SuperHeaders);
            Assert.deepEqual(approveInfo.statusCode, 200);
        });

        it('T0:C5511479: 机构1管理员给机构1的普通用户赋予进入应用1的权限', async function () {
            let url = TideNetworkManagerUrl.userApp;
            Object.assign(org1SuperHeaders, {
                'RC-APP-ID': appId
            });
            let reqbody = {
                'userIds': [
                    baasOrg1.normalUsers.user1.userId
                ]
            };
            let approveInfo = await httpRequestAsync('post', url, org1SuperHeaders, reqbody);
            Assert.deepEqual(approveInfo.statusCode, 200);
        });

        it('T0:C5511452: 机构1删除应用', async function () {
            let url = `${TideNetworkManagerUrl.consortia}/${consortiaId}/applications/${appId}`;
            let deleteAppInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(deleteAppInfo.statusCode, 200);
        });

        it('teardown: 机构1从联盟中删除机构2', async function () {
            delete org1SuperHeaders['RC-APP-ID'];
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations/${baasOrg2.superUser.orgId}`;
            let deleteOrgFromConsortiaInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(deleteOrgFromConsortiaInfo.statusCode, 200);
        });

    });
});