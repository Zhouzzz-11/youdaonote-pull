'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {getHeaders} = require('../../../test-utils/util_user');
let {baasOrg1, nonActivateUser} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {randomString} = require('../../../test-utils/utils_comFunc');
const {queryConsortiaStatus} = require('../../../test-function/NetworkManager/consortiaFuntion');
describe(' /test: GET /api/v1/consortia/{id}/network-state/{networkCode}', function () {
    let org1SuperHeaders;
    let consortiaId, networkCode;
    describe('查看联盟网络创建状态', function () {
        // TODO bug
        it('T1:C5511376: 查看联盟网络创建状态(必填项校验 必填项缺失，返回404，以及具体的错误信息)', async function () {
            org1SuperHeaders = getHeaders(baasOrg1.superUser.iamLoginBody);
            consortiaId = baasOrg1.superUser.consortiaInfo[0].id;
            networkCode = baasOrg1.superUser.consortiaInfo[0].networkCode;
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, null, org1SuperHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 401);
        });
        // TODO bug
        it('T1:C5511377: 查看联盟网络创建状态(字符串内容、字符串长度校验)', async function () {
            let networkCode = '~!@()_+';
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 401);
        });
        // TODO bug
        it('T1:C5511378: 查看联盟网络创建状态(联盟不存在 404，联盟不存在)', async function () {
            let consortiaId = randomString();
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 401);
        });
        // TODO bug
        it('T1:C5511379: 查看联盟网络创建状态(联盟存在，网络不存在)', async function () {
            let networkCode = randomString();
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 401);
        });
        // TODO bug
        it('T1:C5511380: 查看联盟网络创建状态(联盟和网络同时不存在，查不到结果)', async function () {
            let consortiaId = randomString();
            let networkCode = randomString();
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 401);
        });

        it('T1:C5511381: 查看联盟网络创建状态(使用未激活tide身份的用户做查询,返回 400)', async function () {
            let nonActivateUserHeaders = await getHeaders(nonActivateUser);
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, nonActivateUserHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 400);
        });

        it('T1:C5511382: 查看联盟网络创建状态(token为空/token错误/token失效，查询返回400提示无效token)', async function () {
            org1SuperHeaders['Authorization'] = `Bearer wedsfvsedhrfedhujsrtyhr`;
            let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            Assert.deepEqual(consortiaStatusInfo.statusCode, 401);
        });

    });

});