'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {
    getHeaders,
} = require('../../../test-utils/util_user');
// let {baasOrg1, nonActivateUser} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
let {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
// let {baasOrg1, nonActivateUser} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {TideNetworkManagerUrl} = require('../../../test-lib/url');
// const {randomString} = require('../../../test-utils/utils_comFunc');
// const {queryConsortiaStatus, sleep} = require('../../../test-function/NetworkManager/consortiaFuntion');
// const {createConsortiaSchema, consortiaBasicInfoSchema} = require('../../../test-schema/Networkmanager/consortia');
// const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');

describe(' /test: /api/v1/consortia/{id}', function () {
    // let org1SuperHeaders;
    // let consortiaId, networkCode;
    // let reqBody;
    describe('删除联盟', function () {

        it('T0:C5511384: 删除联盟(必填项校验)', async function () {
            let url = TideNetworkManagerUrl.consortia + `/`;
            let org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let consortiaDeleteInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(consortiaDeleteInfo.statusCode, 405);
        });

    });

});