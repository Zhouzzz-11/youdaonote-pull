'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {
    getHeaders,
} = require('../../../test-utils/util_user');
let {baasOrg1, baasOrg2} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {TideNetworkManagerUrl} = require('../../../test-lib/url');
const {randomString} = require('../../../test-utils/utils_comFunc');
const {queryConsortiaStatus, sleep} = require('../../../test-function/NetworkManager/consortiaFuntion');
const {
    createConsortiaSchema,
    invitedOrgInfoSchema,
    queryCurrentUserConsortiaInfoSchema,
    consortiaBasicInfoSchema
} = require('../../../test-schema/Networkmanager/consortia');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');


describe(' /test: POST /api/v1/consortia/{id}/invitations', function () {
    let org1SuperHeaders, org2SuperHeaders;
    let consortiaId, networkCode;

    it('setup-1: 机构1获取请求头，创建联盟', async function () {
        org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
        let reqBody = {
            'displayName': randomString(),
            'description': 'string',
            'deployMode': 'CLOUD_MODE'
        };
        let consortiaInfo = await httpRequestAsync('post', TideNetworkManagerUrl.consortia,
            org1SuperHeaders, reqBody);
        Assert.deepEqual(consortiaInfo.statusCode, 202);
        await verifyObjectSchemaAsync(consortiaInfo.payload, createConsortiaSchema);
        consortiaId = consortiaInfo.payload.id;
        networkCode = consortiaInfo.payload.networkCode;
    });

    it('setup-2: 机构1管理员查询联盟网络的创建状态', async function () {
        let consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
        for (let i = 0; i < 10; i++) {
            if (consortiaStatusInfo.payload === 'RUNNING') {
                break;
            } else {
                await sleep(10000);
                consortiaStatusInfo = await queryConsortiaStatus(consortiaId, networkCode, org1SuperHeaders);
            }
        }
        Assert.deepEqual(consortiaStatusInfo.statusCode, 200);
    }).timeout(100 * 1000);

    it('T1: C5511372: 查询联盟的基本信息(机构管理员或普通用户查询未加入也未被邀请的联盟，查询不到结果)', async function () {
        org2SuperHeaders = await getHeaders(baasOrg2.superUser.iamLoginBody);
        let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
        let consortiaBasicInfo = await httpRequestAsync('get', url, org2SuperHeaders);
        Assert.deepEqual(consortiaBasicInfo.statusCode, 404);
    });

    it('T1:C5511374: 查询联盟的基本信息(C5511370token为空/token错误/token失效)', async function () {
        let org1SuperToken = org1SuperHeaders.Authorization;
        let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
        org1SuperHeaders.Authorization = randomString();
        let consortiaBasicInfo = await httpRequestAsync('get', url, org1SuperHeaders);
        Assert.deepEqual(consortiaBasicInfo.statusCode, 401);
        org1SuperHeaders.Authorization = org1SuperToken;
    });

    describe('机构1管理员邀请机构2加入联盟', function () {
        it('T0:C5511392-1:  invite org to join consortia', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations`;
            let reqBody = {
                'orgIds': [baasOrg2.superUser.orgId],
                'reason': '联盟1邀请机构2加入联盟1'
            };
            let inviteOrgInfo = await httpRequestAsync('post', url, org1SuperHeaders, reqBody);
            Assert.deepEqual(inviteOrgInfo.statusCode, 200);
        });

        it('T1: C5511370: 查询联盟的基本信息(机构管理员被其他联盟邀请， 查询其他机构管理员创建的联盟，可以查询成功)', async function () {

            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let consortiaBasicInfo = await httpRequestAsync('get', url, org2SuperHeaders);
            Assert.deepEqual(consortiaBasicInfo.statusCode, 200);
            await verifyObjectSchemaAsync(consortiaBasicInfo.payload, consortiaBasicInfoSchema);
        });

        // TODO bug
        it.skip('T1: C5511371: 查询联盟的基本信息(普通用户所在的机构管理员被邀请，但还未加入被邀请的联盟，普通用户查询不到该被邀请的联盟信息)', async function () {
            let org2NormalUser1Headers = await getHeaders(baasOrg2.normalUsers.user1.iamLoginBody);
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let consortiaBasicInfo = await httpRequestAsync('get', url, org2NormalUser1Headers);
            Assert.deepEqual(consortiaBasicInfo.statusCode, 400);
        });


        it('T0:C5511401: 机构2管理员查看受邀信息', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations`;
            let invitedOrgInfo = await httpRequestAsync('get', url, org2SuperHeaders);
            await verifyObjectSchemaAsync(invitedOrgInfo.payload, invitedOrgInfoSchema);
            Assert.deepEqual(invitedOrgInfo.statusCode, 200);
        });

        it('T0:C5511416: 机构2查看本组织已加入和待加入的联盟', async function () {
            let queryCurrentUserConsortiaInfo = await httpRequestAsync('get', TideNetworkManagerUrl.consortia, org2SuperHeaders);
            await verifyObjectSchemaAsync(queryCurrentUserConsortiaInfo, queryCurrentUserConsortiaInfoSchema);
            Assert.deepEqual(queryCurrentUserConsortiaInfo.statusCode, 200);
        });

        it('T0:C5594303-2:  机构2拒绝联盟邀请', async function () {
            org2SuperHeaders = await getHeaders(baasOrg2.superUser.iamLoginBody);
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations?action=REJECT`;
            let rejectInfo = await httpRequestAsync('put', url, org2SuperHeaders);
            Assert.deepEqual(rejectInfo.statusCode, 200);
        });

        it('T0:C5511392-2:  机构1邀请机构2加入联盟', async function () {
            org1SuperHeaders = await getHeaders(baasOrg1.superUser.iamLoginBody);
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations`;
            let reqBody = {
                'orgIds': [baasOrg2.superUser.orgId],
                'reason': '联盟1邀请机构2加入联盟1'
            };
            let inviteOrgInfo = await httpRequestAsync('post', url, org1SuperHeaders, reqBody);
            Assert.deepEqual(inviteOrgInfo.statusCode, 200);
        });

        it('T0:C5594303-1: 机构2接受邀请', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations?action=APPROVE`;
            let acceptInfo = await httpRequestAsync('put', url, org2SuperHeaders);
            Assert.deepEqual(acceptInfo.statusCode, 200);
        });

        it('T0:C5511420:  机构1从联盟中删除机构2', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}/invitations/${baasOrg2.superUser.orgId}`;
            let deleteInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(deleteInfo.statusCode, 200);
        });

        it('teardown: 机构1删除联盟', async function () {
            let url = TideNetworkManagerUrl.consortia + `/${consortiaId}`;
            let consortiaDeleteInfo = await httpRequestAsync('delete', url, org1SuperHeaders);
            Assert.deepEqual(consortiaDeleteInfo.statusCode, 200);
        });
    });

});