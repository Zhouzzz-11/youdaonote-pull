//AuditDataEvidence - 上链 -POST-/api/v1/bulk/audit-data
//BCP-2101
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=335658

'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {AuditDataEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {generalUser003, topadmin} = require('../../../test-data/Gateway/BCP-60_auth_login_data');
const {createAuditDataEvidence, verifyAuditDataEvidence, queryAuditDataEvidence} = require('../../../test-function/Solution/Evidence/auditDataEvidenceFunction');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');
const { dataBody } = require('../../../test-lib/mockdata');
const { createOrgAsync, createUserAsync } = require('../../../test-function/NetworkManager/userFunction');
const { 
    auditEvidenceCreateSchema,
    auditEvidenceCreateHashSchema,
    auditEvidenceCreateRawSchema,
    auditEvidenceVerifySchema,
    auditEvidenceVerifyRawSchema,
    auditEvidenceVerifyHashSchema
} = require('../../../test-schema/Solution/Evidence/auditEvidence');

describe.skip(`testAPI: POST /api/v1/bulk/audit-data, POST /api/v1/verification`, function () {

    let randomNumber = Math.random().toString().substr(2,6);
    describe('setUp: create user', function () {
        let orgId = `orgId${randomNumber}`;
        let orgName = `orgname${randomNumber}`;
        let userId = `userId${randomNumber}`;
        let userName = `username${randomNumber}`;
        it('create org', async function () {
            let orgReqBody = dataBody.createOrgBody(orgId, orgName);
            let rspOrg = await createOrgAsync(orgReqBody, topadmin);
            Assert.deepEqual(rspOrg.statusCode, 200, 'check status code');
        });
        it('create user', async function () {
            let createUserBody = dataBody.activateUserBody(userId, userName, orgId, ['user']);
            let rspUser = await createUserAsync(createUserBody, topadmin);
            Assert.deepEqual(rspUser.statusCode, 200, 'check status code');
            generalUser003.reqBody.userName = userName;
            generalUser003.reqBody.password = '123321';
        });
    });

    describe('T0:C3840178: create 1 audit-data evidence(dataForm=null)', function () {
        it('create evidence and check response ', async function () {
            let evidenceReqBody = new AuditDataEvidenceObj();
            let rspCreate = await createAuditDataEvidence([evidenceReqBody], generalUser003);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, auditEvidenceCreateSchema);
        });
    });

    describe('T0:C3840180: create 50 audit-data evidences(dataForm=null)', function () {
        it('create evidence and check response ', async function () {
            let auditData = [];
            for(let i = 0; i < 50; i++) {
                let evidenceReqBody = new AuditDataEvidenceObj();
                auditData.push(evidenceReqBody);
            }
            let rspCreate = await createAuditDataEvidence(auditData, generalUser003);
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
        });
    });

    describe('T0:C3840194: verify 1 audit-data evidences(dataForm=null)', function () {
        let auditData;
        it('query audit data', async function () {
            let rspQuery = await queryAuditDataEvidence(generalUser003, {queryString: 'limit=1&sort=createdAt,desc'});
            Assert.deepEqual(rspQuery.statusCode, 200, 'check status code');
            let bodyQuery_results = JSON.parse(rspQuery.body).results;
            auditData = [];
            bodyQuery_results.map(item=>{
                let obj = {};
                obj.evidenceId = item.evidenceId;
                obj.target = item.data;
                auditData.push(obj);
            });
        });
        it('verify audit data and check response ', async function () {
            let rspVerify = await verifyAuditDataEvidence(auditData, generalUser003);
            let bodyVerify = JSON.parse(rspVerify.body);
            Assert.deepEqual(rspVerify.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyVerify, auditEvidenceVerifySchema);
        });
    });

    describe('T0:C3840197: verify 50 audit-data evidences(dataForm=null)', function () {
        let auditData;
        it('query audit data', async function () {
            let rspQuery = await queryAuditDataEvidence(generalUser003, {queryString: 'limit=50&sort=createdAt,desc'});
            Assert.deepEqual(rspQuery.statusCode, 200, 'check status code');
            let bodyQuery_results = JSON.parse(rspQuery.body).results;
            auditData = [];
            bodyQuery_results.map(item=>{
                let obj = {};
                obj.evidenceId = item.evidenceId;
                obj.target = item.data;
                auditData.push(obj);
            });
        });
        it('verify audit data and check response ', async function () {
            let rspVerify = await verifyAuditDataEvidence(auditData, generalUser003);
            Assert.deepEqual(rspVerify.statusCode, 200, 'check status code');
        });
    });

    describe('T0:C4139798: create 1 audit-data evidence with params(dataForm=raw)', function () {
        let auditData = [];
        let bodyCreate;
        it('create evidence and check response ', async function () {
            let evidenceReqBody = new AuditDataEvidenceObj();
            let rspCreate = await createAuditDataEvidence([evidenceReqBody], generalUser003, {param: 'dataForm=raw'});
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, auditEvidenceCreateRawSchema);
        });
        it('prepare verify data', async function () {
            let data = {
                'test_case' : 'audit-data'
            };
            bodyCreate.map(item=>{
                let obj = {};
                obj.evidenceId = item.response.evidenceId;
                obj.target = data;
                obj.logId = item.response.logId;
                auditData.push(obj);
            });
        });
        it('verify audit data and check response ', async function () {
            let rspVerify = await verifyAuditDataEvidence(auditData, generalUser003);
            let bodyVerify = JSON.parse(rspVerify.body);
            Assert.deepEqual(rspVerify.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyVerify, auditEvidenceVerifyRawSchema);
        });
    });

    describe('T0:C4139805: create 100 audit-data evidence with params(dataForm=raw)', function () {
        let auditData = [];
        let bodyCreate;
        it('create evidence and check response ', async function () {
            let auditData = [];
            for(let i = 0; i < 100; i++) {
                let evidenceReqBody = new AuditDataEvidenceObj();
                auditData.push(evidenceReqBody);
            }
            let rspCreate = await createAuditDataEvidence(auditData, generalUser003, {param: 'dataForm=raw'});
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            bodyCreate = JSON.parse(rspCreate.body);
        });
        it('prepare verify data', async function () {
            let arr = [];
            let data = {
                'test_case' : 'audit-data'
            };
            bodyCreate.map(item=>{
                let obj = {};
                obj.evidenceId = item.response.evidenceId;
                obj.target = data;
                obj.logId = item.response.logId;
                arr.push(obj);
                if (arr.length>50){
                    auditData.push(obj);
                }
            });
        });
        it('verify audit data and check response ', async function () {
            let rspVerify = await verifyAuditDataEvidence(auditData, generalUser003);
            Assert.deepEqual(rspVerify.statusCode, 200, 'check status code');
        });
    });

    describe('create and then verify audit-data evidence(dataForm=hash,num=1)', function () {
        let auditData = [];
        let bodyCreate;
        it('T0:C4166705: create 1 audit-data evidence with params(dataForm=hash)', async function () {
            let evidenceReqBody = new AuditDataEvidenceObj();
            let rspCreate = await createAuditDataEvidence([evidenceReqBody], generalUser003, {param: 'dataForm=hash'});
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, auditEvidenceCreateHashSchema);
        });
        it('prepare verify data', async function () {
            let data = {
                'test_case' : 'audit-data'
            };
            bodyCreate.map(item=>{
                let obj = {};
                obj.evidenceId = item.response.evidenceId;
                obj.target = data;
                obj.logId = item.response.logId;
                auditData.push(obj);
            });
        });
        it('T0:C4166712: verify 1 audit-data evidences(dataForm=hash)', async function () {
            let rspVerify = await verifyAuditDataEvidence(auditData, generalUser003);
            let bodyVerify = JSON.parse(rspVerify.body);
            Assert.deepEqual(rspVerify.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyVerify, auditEvidenceVerifyHashSchema);
        });
    });



    describe('create and then verify audit-data evidence(dataForm=hash,num=100)', function () {
        let auditData = [];
        let bodyCreate;
        it('T0:C4166707: create 100 audit-data evidence with params(dataForm=hash)', async function () {
            let auditData = [];
            for(let i = 0; i < 100; i++) {
                let evidenceReqBody = new AuditDataEvidenceObj();
                auditData.push(evidenceReqBody);
            }
            let rspCreate = await createAuditDataEvidence(auditData, generalUser003, {param: 'dataForm=hash'});
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            bodyCreate = JSON.parse(rspCreate.body);
        });
        it('prepare verify data', async function () {
            let arr = [];
            let data = {
                'test_case' : 'audit-data'
            };
            bodyCreate.map(item=>{
                let obj = {};
                obj.evidenceId = item.response.evidenceId;
                obj.target = data;
                obj.logId = item.response.logId;
                arr.push(obj);
                if (arr.length>50){
                    auditData.push(obj);
                }
            });
        });
        it('T0:C4166713: verify 50 audit-data evidences(dataForm=hash)', async function () {
            let rspVerify = await verifyAuditDataEvidence(auditData, generalUser003);
            Assert.deepEqual(rspVerify.statusCode, 200, 'check status code');
        });
    });

});