// test tide-test-contract
//BCP-2508
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&\
// group_by=cases:section_id&group_order=asc&group_id=377148

'use strict';

const {Assert} = require('@rootcloud/darjeeling');
const {TestContractObj} = require('../../../test-data/Solution/TestContract/testContract');
const {topadmin, baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {
    createAssertAsync,
    getAssertsAsync,
    updateAssertByIdAsync,
    deleteAssertByIdAsync,
    createByTransactionAsync,
    getByTransactionAsync,
    deleteByTransactionAsync,
    transferTransactionAsync
} = require('../../../test-function/Solution/TestContract/testContractFunction');
const {assertCreateSchema, queryAssertsSchema, assertCreateByTrasactionSchema} = require('../../../test-schema/Solution/TestContract/testContract');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');
const {randomString} = require('../../../test-utils/utils_comFunc');

describe(`/tide-test-contract`, function () {

    let respCreate, bodyCreate;
    let respQuery, bodyQuery;
    let respGet, bodyGet;
    let respUpdate;
    let respDelete;
    let accountId;
    describe('T0:C4376073: crate assert by Assert', function () {
        /*      accountId 必选
                issueBank;必选
                balance;必选
                owner;必选
                holderInfo;可选*/
        it('abnormal: create assert (non param accountId)', async function () {
            let testContractReqBodyTest = new TestContractObj();
            delete testContractReqBodyTest['accountId'];
            respCreate = await createAssertAsync(testContractReqBodyTest, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 400);
        });
        it('abnormal: create assert (non param issueBank) ', async function () {
            let testContractReqBody = new TestContractObj();
            testContractReqBody['accountId'] = randomString();
            delete testContractReqBody['issueBank'];
            respCreate = await createAssertAsync(testContractReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 400);
        });
        it('abnormal: create assert (non param balance)', async function () {
            let testContractReqBodyTest = new TestContractObj();
            delete testContractReqBodyTest['balance'];
            respCreate = await createAssertAsync(testContractReqBodyTest, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 400);
        });
        it('abnormal: create assert (non param owner)', async function () {
            let testContractReqBodyTest = new TestContractObj();
            delete testContractReqBodyTest['owner'];
            respCreate = await createAssertAsync(testContractReqBodyTest, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 400);
        });

        it('normal: create assert (non param holderInfo) ', async function () {
            let testContractReqBody = new TestContractObj();
            testContractReqBody['accountId'] = randomString();
            delete testContractReqBody['holderInfo'];
            respCreate = await createAssertAsync(testContractReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            await verifyObjectSchemaAsync(bodyCreate.payload, assertCreateSchema);
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('normal: create assert', async function () {
            let testContractReqBody = new TestContractObj();
            testContractReqBody['accountId'] = randomString();
            respCreate = await createAssertAsync(testContractReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            await verifyObjectSchemaAsync(bodyCreate.payload, assertCreateSchema);
            Assert.deepEqual(respCreate.statusCode, 200);
        });
    });

    describe('T0:C4376075: normal user have all access for its assert', function () {
        let updateAssert;
        it('create assert', async function () {
            let testContractReqBodyTest = new TestContractObj();
            testContractReqBodyTest['accountId'] = randomString();
            respCreate = await createAssertAsync(testContractReqBodyTest, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            await verifyObjectSchemaAsync(bodyCreate.payload, assertCreateSchema);
            let resources = bodyCreate.payload.resources;
            let accountObj = resources[0];
            accountId = accountObj.accountId;
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('query asserts', async function () {
            respQuery = await getAssertsAsync(baasOrg01);
            bodyQuery = JSON.parse(respQuery.body);
            await verifyObjectSchemaAsync(bodyQuery.payload, queryAssertsSchema);
            Assert.deepEqual(respQuery.statusCode, 200);
        });
        it('update asserts', async function () {
            let testContractReqBodyTest = new TestContractObj();
            testContractReqBodyTest['accountId'] = accountId;
            testContractReqBodyTest['holderInfo'] = {
                '$class': 'cn.gezhitech.test.integration.asset.HolderInfo',
                age: 35,
                id: 'accountId',
                name: 'Steve'
            };
            updateAssert = testContractReqBodyTest;
            respUpdate = await updateAssertByIdAsync(accountId, testContractReqBodyTest, baasOrg01);
            Assert.deepEqual(respUpdate.statusCode, 200);
        });
        it('query after update asserts', async function () {
            respQuery = await getAssertsAsync(baasOrg01);
            bodyQuery = JSON.parse(respQuery.body);
            let payloadQuery = bodyQuery.payload.queryResult;
            let accountUpdateArray = payloadQuery.filter(
                accountObj => {
                    return accountObj.accountId === accountId;
                }
            );
            let accountUpdate = accountUpdateArray[0];
            await verifyObjectSchemaAsync(bodyQuery.payload, queryAssertsSchema);
            delete accountUpdate['$class'];
            Assert.deepEqual(respQuery.statusCode, 200);
            Assert.deepEqual(accountUpdate, updateAssert);
        });
        it('delete assert', async function () {
            respDelete = await deleteAssertByIdAsync(accountId, baasOrg01);
            Assert.deepEqual(respDelete.statusCode, 200);
        });
    });

    describe('T0:C4376074: super user have all access for other users assert', function () {
        let updateAssert;
        it('create assert', async function () {
            let testContractReqBodyTest = new TestContractObj();
            testContractReqBodyTest['accountId'] = randomString();
            respCreate = await createAssertAsync(testContractReqBodyTest, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            await verifyObjectSchemaAsync(bodyCreate.payload, assertCreateSchema);
            let resources = bodyCreate.payload.resources;
            let accountObj = resources[0];
            accountId = accountObj.accountId;
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('query asserts', async function () {
            respQuery = await getAssertsAsync(topadmin);
            bodyQuery = JSON.parse(respQuery.body);
            await verifyObjectSchemaAsync(bodyQuery.payload, queryAssertsSchema);
            Assert.deepEqual(respQuery.statusCode, 200);
        });
        it('update asserts', async function () {
            let testContractReqBodyTest = new TestContractObj();
            testContractReqBodyTest['accountId'] = accountId;
            testContractReqBodyTest['holderInfo'] = {
                '$class': 'cn.gezhitech.test.integration.asset.HolderInfo',
                age: 28,
                id: 'accountId',
                name: 'Steve'
            };
            updateAssert = testContractReqBodyTest;
            respUpdate = await updateAssertByIdAsync(accountId, testContractReqBodyTest, topadmin);
            Assert.deepEqual(respUpdate.statusCode, 200);
        });
        it('query after update asserts', async function () {
            respQuery = await getAssertsAsync(baasOrg01);
            bodyQuery = JSON.parse(respQuery.body);
            let payloadQuery = bodyQuery.payload.queryResult;
            let accountUpdateArray = payloadQuery.filter(
                accountObj => {
                    return accountObj.accountId === accountId;
                }
            );
            let accountUpdate = accountUpdateArray[0];
            await verifyObjectSchemaAsync(bodyQuery.payload, queryAssertsSchema);
            delete accountUpdate['$class'];
            Assert.deepEqual(respQuery.statusCode, 200);
            Assert.deepEqual(accountUpdate, updateAssert);
        });
        it('delete assert', async function () {
            respDelete = await deleteAssertByIdAsync(accountId, topadmin);
            Assert.deepEqual(respDelete.statusCode, 200);
        });
        it('query after delete asserts', async function () {
            respQuery = await getAssertsAsync(baasOrg01);
            bodyQuery = JSON.parse(respQuery.body);
            let payloadQuery = bodyQuery.payload.queryResult;
            let accountUpdateArrayLen = payloadQuery.filter(
                accountObj => {
                    return accountObj.accountId === accountId;
                }
            ).length;
            Assert.deepEqual(respQuery.statusCode, 200);
            Assert.deepEqual(accountUpdateArrayLen, 0);
        });
    });

    // TODO
    describe.skip('T0:C4376076: userA have all access for user B assert', function () {
    });

    // TODO: bug only super user can CRUD account, and can not delete assert by transaction
    describe('T0:C4376077: normal user have all access for its assert by involving transaction', function () {
        it('create assert', async function () {
            let testBankAccount = new TestContractObj();
            let testContractTransactionReq = {'$class': 'cn.gezhitech.test.integration.transaction.CreateBankAccount'};
            testBankAccount['accountId'] = randomString();
            testContractTransactionReq['bankAccount'] = testBankAccount;
            respCreate = await createByTransactionAsync(testContractTransactionReq, topadmin);
            bodyCreate = JSON.parse(respCreate.body);
            await verifyObjectSchemaAsync(bodyCreate.payload, assertCreateByTrasactionSchema);
            accountId = bodyCreate.payload.accountId;
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('query asserts by accountId', async function () {
            let getByAccountIdReq = {
                $class: 'cn.gezhitech.test.integration.transaction.QueryBankAccount',
                accountId: accountId
            };
            respGet = await getByTransactionAsync(getByAccountIdReq, topadmin);
            bodyGet = JSON.parse(respGet.body);
            await verifyObjectSchemaAsync(bodyGet.payload, queryAssertsSchema);
            Assert.deepEqual(respGet.statusCode, 200);
        });
        it.skip('delete assert', async function () {
            let deleteByAccountIdReq = {
                $class: 'cn.gezhitech.test.integration.transaction.QueryBankAccount',
                accountId: accountId
            };
            respDelete = await deleteByTransactionAsync(deleteByAccountIdReq, topadmin);
            bodyCreate = JSON.parse(respDelete.body);
            Assert.deepEqual(respDelete.statusCode, 200);
        });
    });


    //
    describe('T0:C4376078: bankAccount A and bankAccount B transfer ', function () {
        let bankAccountA;
        let bankAccountB;
        let accountIdA;
        let accountIdB;
        let accountABalance = '100';
        let accountBBalance = '50';
        let transfer = 20;
        it('create bankAccount A and bankAccount B', async function () {
            bankAccountA = new TestContractObj();
            bankAccountA['accountId'] = randomString();
            bankAccountA['balance'] = accountABalance;
            let respCreateA = await createAssertAsync(bankAccountA, baasOrg01);
            let bodyCreateA = JSON.parse(respCreateA.body);
            await verifyObjectSchemaAsync(bodyCreateA.payload, assertCreateSchema);
            Assert.deepEqual(respCreateA.statusCode, 200);
            let resourcesA = bodyCreateA.payload.resources;
            let accountObjA = resourcesA[0];
            accountIdA = accountObjA.accountId;
            bankAccountB = new TestContractObj();
            bankAccountB['accountId'] = randomString();
            bankAccountB['balance'] = accountBBalance;
            let respCreateB = await createAssertAsync(bankAccountB, baasOrg01);
            let bodyCreateB = JSON.parse(respCreateB.body);
            await verifyObjectSchemaAsync(bodyCreateB.payload, assertCreateSchema);
            Assert.deepEqual(respCreateB.statusCode, 200);
            let resourcesB = bodyCreateB.payload.resources;
            let accountObjB = resourcesB[0];
            accountIdB = accountObjB.accountId;
        });

        it('bankAccountA transfer bankAccountB', async function () {
            bankAccountA['$class'] = bankAccountB['$class'] = 'cn.gezhitech.test.integration.asset.BankAccount';
            let transferReq = {
                '$class': 'cn.gezhitech.test.integration.transaction.TransferTransaction',
                'fromAccount': bankAccountA,
                'targetAccount': bankAccountB,
                'amount': transfer
            };
            let respTransfer = await transferTransactionAsync(transferReq, topadmin);
            Assert.deepEqual(respTransfer.statusCode, 200);
        });
        it('query accountA by accountId', async function () {
            let getByAccountIdReq = {
                $class: 'cn.gezhitech.test.integration.transaction.QueryBankAccount',
                accountId: accountIdA
            };
            respGet = await getByTransactionAsync(getByAccountIdReq, topadmin);
            bodyGet = JSON.parse(respGet.body);
            let accountGetA = bodyGet.payload.queryResult;
            let accountObjA = accountGetA[0];
            await verifyObjectSchemaAsync(bodyGet.payload, queryAssertsSchema);
            Assert.deepEqual(respGet.statusCode, 200);
            Assert.deepEqual(accountObjA.balance, String(Number(accountABalance) - Number(transfer)));
        });
        it('query accountB by accountId', async function () {
            let getByAccountIdReq = {
                $class: 'cn.gezhitech.test.integration.transaction.QueryBankAccount',
                accountId: accountIdB
            };
            respGet = await getByTransactionAsync(getByAccountIdReq, topadmin);
            bodyGet = JSON.parse(respGet.body);
            let accountGetB = bodyGet.payload.queryResult;
            let accountObjB = accountGetB[0];
            await verifyObjectSchemaAsync(bodyGet.payload, queryAssertsSchema);
            Assert.deepEqual(respCreate.statusCode, 200);
            Assert.deepEqual(accountObjB.balance, String(Number(accountBBalance) + Number(transfer)));
        });
        it('T1: C4376080: Lack of balance', async function () {
            bankAccountA['$class'] = bankAccountB['$class'] = 'cn.gezhitech.test.integration.asset.BankAccount';
            let transferReq = {
                '$class': 'cn.gezhitech.test.integration.transaction.TransferTransaction',
                'fromAccount': bankAccountA,
                'targetAccount': bankAccountB,
                'amount': Number(transfer) + 2 * Number(bankAccountA['balance'])
            };
            var respTransfer = await transferTransactionAsync(transferReq, topadmin);
            Assert.deepEqual(respTransfer.statusCode, 400);
        });
        it('T1: C4376079: bankAccountA non exist', async function () {
            bankAccountA['$class'] = bankAccountB['$class'] = 'cn.gezhitech.test.integration.asset.BankAccount';
            bankAccountA['accountId'] = randomString();
            let transferReq = {
                '$class': 'cn.gezhitech.test.integration.transaction.TransferTransaction',
                'fromAccount': bankAccountA,
                'targetAccount': bankAccountB,
                'amount': transfer
            };
            var respTransfer = await transferTransactionAsync(transferReq, topadmin);
            Assert.deepEqual(respTransfer.statusCode, 404);
        });
    });
});

