//存证解决方案-异步查询文本存证-GET-/api/v1/solution/evidence/text/queue/{evidenceId}
//BCP-323 存证解决方案异步查询文本存证
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076339
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2148429
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2148430
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076338
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076337

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {verifyObjectSchemaAsync, verifyObjectPayloadSync} = require('../../../test-verify/verify');
const {evidenceSchema, evidenceQuerySchema} = require('../../../test-schema/Solution/Evidence/evidence');
const {randomString, itWait} = require('../../../test-utils/utils_comFunc');
const {getHeaders} = require('../../../test-utils/util_user');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {evidenceSolutionUrl} = require('../../../test-lib/url');


describe(`/test: GET /api/v1/text/queue/{evidenceId}`, function () {
    let org1NormalUser1Headers;
    let textEvidenceUrl = evidenceSolutionUrl.textEvidence;
    describe('T0:C2076339: query async evidence', function () {
        let evidenceReqBody = new EvidenceObj();
        let rspCreate;
        it('Pre-steps: get user1 token and assemble http header', async function () {
            org1NormalUser1Headers = await getHeaders(baasOrg1.normalUsers.user1.iamLoginBody);
            Object.assign(org1NormalUser1Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser1Headers.Authorization.length, 8);
        });

        it('create async evidence ', async function () {
            let url = textEvidenceUrl + `?async=true`;
            rspCreate = await httpRequestAsync('post', url, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 202, 'check status code');
        });


        it('wait 3s', function (done) {
            setTimeout(function () {
                done();
            }, 3000);
        });

        it('query async evidence ', async function () {
            let url = `${evidenceSolutionUrl.queryasync}/${rspCreate.evidenceId}`;
            let rspAsyncQuery = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspAsyncQuery.statusCode, 200);
            await verifyObjectSchemaAsync(rspAsyncQuery, evidenceQuerySchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    // cannot  construct this situation
    describe.skip('C2148429: query async evidence(async failed)', function () {
        let evidenceReqBody = new EvidenceObj();
        let rspCreateBody;
        let evidenceId;
        it('create evidence ', async function () {
            delete evidenceReqBody['title'];
            let url = textEvidenceUrl + `?async=true`;
            let rspCreate = await httpRequestAsync('post', url, org1NormalUser1Headers);
            rspCreateBody = JSON.parse(rspCreate.body);
            let track = rspCreateBody.track;
            evidenceId = track.split('/').pop();
        });

        itWait(500);

        it('query async evidence', async function () {
            let url = textEvidenceUrl + `?async=true`;
            let rspCreateAysn = await httpRequestAsync('post', url, evidenceReqBody);
            Assert.deepEqual(rspCreateAysn.statusCode, 202);
            let queryUrl = `${evidenceSolutionUrl.queryasync}/${evidenceId}`;
            let rspAsyncQuery = await httpRequestAsync('get', queryUrl, org1NormalUser1Headers);
            Assert.deepEqual(rspAsyncQuery.statusCode, 200);
            verifyObjectPayloadSync(rspAsyncQuery.body, {
                'status': 'FAILED',
                'response': {
                    'code': '',
                    'message': `Instance cn.gezhitech.digitalevidence.asset.TextEvidence#${evidenceId} missing required field title`
                }
            });
        });
    });

    //same with the C2076339
    describe('T1:C2076338: query async evidence(sync created evidence)', function () {
        let evidenceReqBody = new EvidenceObj();
        let evidenceId;
        it('create sync evidence ', async function () {
            let rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceSchema);
            evidenceId = rspCreate.evidenceId;
        });

        it('async query', async function () {
            let url = `${evidenceSolutionUrl.queryasync}/${evidenceId}`;
            let rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            await verifyObjectSchemaAsync(rsp, evidenceQuerySchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2076337: query async evidence(query nonexistent evidenceId)', function () {
        it('async query', async function () {
            let evidenceId = randomString();
            let url = `${evidenceSolutionUrl.queryasync}/${evidenceId}`;
            let rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 404, 'check response');
        });
    });

});

