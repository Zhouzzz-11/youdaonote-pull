//Solution-PATCH-/api/v1/solution/evidence/text/{evidenceId}
//BCP-250 
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=195477

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {
    updateTextEvidenceData_1,
    updateTextEvidenceData_2,
    updateTextEvidenceData_3
} = require('../../../test-data/Solution/Evidence/evidenceData');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');
const {
    evidenceQuerySchema,
    evidenceNonFirstUpdateIncludeBlockInfoSchema
} = require('../../../test-schema/Solution/Evidence/evidence');
const {TIDE, TIDESOL} = require('../../../test-lib/errorMessage');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getHeaders} = require('../../../test-utils/util_user');
const {evidenceSolutionUrl} = require('../../../test-lib/url');


describe(`/test: PATCH  /api/v1/text/{evidenceId}`, function () {
    let org1NormalUser1Headers;
    let textEvidenceId;
    let textEvidenceUrl = evidenceSolutionUrl.textEvidence;
    describe('T0:C2148541: update by evidenceId', function () {

        it('Pre-steps: get user token and assemble http header', async function () {
            org1NormalUser1Headers = await getHeaders(baasOrg1.normalUsers.user2.iamLoginBody);
            Object.assign(org1NormalUser1Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser1Headers.Authorization.length, 8);
        });

        it('Pre-steps: create evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('test', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspUpdate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateTextEvidenceData_1);
            Assert.deepEqual(rspUpdate.statusCode, 200);
            await verifyObjectSchemaAsync(rspUpdate, evidenceQuerySchema);
        });

    });

    describe('T0:C2162546: update by evidenceId and include blockinfo', function () {
        it('test', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeBlockInfo=true`;
            let rspUpdate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateTextEvidenceData_2);
            Assert.deepEqual(rspUpdate.statusCode, 200);
            await verifyObjectSchemaAsync(rspUpdate, evidenceNonFirstUpdateIncludeBlockInfoSchema);
        });
    });

    describe('T1:C2148542: update with null labels ', function () {
        it('test', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspUpdate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateTextEvidenceData_3);
            Assert.deepEqual(rspUpdate.statusCode, 422);
            Assert.deepEqual(rspUpdate.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2148544: update with not exist id ', function () {
        it('test', async function () {
            let url = textEvidenceUrl + `/evidenceId_test_not_exist`;
            let rspUpdate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateTextEvidenceData_1);
            Assert.deepEqual(rspUpdate.statusCode, 404);
            Assert.deepEqual(rspUpdate.code, TIDE.MscNotExistError.errorCode);
        });
    });

    describe(' T0:delete ', function () {
        it('After-steps: delete test data', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });
});

