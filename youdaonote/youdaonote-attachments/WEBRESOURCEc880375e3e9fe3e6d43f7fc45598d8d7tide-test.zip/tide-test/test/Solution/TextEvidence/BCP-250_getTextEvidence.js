//Solution-GET-/api/v1/solution/evidence/text/{evidenceId}
//BCP-250 
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=195477

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {
    verifyObjectSchemaAsync,
    verifyObjectPayloadSync
} = require('../../../test-verify/verify');
const {
    evidenceQuerySchema,
    evidenceIncludeBlockInfoQuerySchema,
    evidenceIncludeHistoryQuerySchema,
    evidenceIncludeHistoryBlockInfoQuerySchema,
    evidenceNonFirstUpdateIncludeHistorySchema,
    historySchemafirstItem,
    historySchemaRemainItems
} = require('../../../test-schema/Solution/Evidence/evidence');
const {TIDE, TIDESOL} = require('../../../test-lib/errorMessage');
const {getHeaders} = require('../../../test-utils/util_user');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {evidenceSolutionUrl} = require('../../../test-lib/url');


describe(`/test: GET  /api/v1/text/{evidenceId}`, function () {
    let org1NormalUser1Headers;
    let respCreate;
    let textEvidenceId;
    let textEvidenceUrl = evidenceSolutionUrl.textEvidence;
    describe('T0:C2076316: query by evidenceId', function () {
        let evidenceReqBody = new EvidenceObj();

        it('Pre-steps: get user token and assemble http header', async function () {
            org1NormalUser1Headers = await getHeaders(baasOrg1.normalUsers.user2.iamLoginBody);
            Object.assign(org1NormalUser1Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser1Headers.Authorization.length, 8);
        });

        it('Pre-steps: create evidence ', async function () {
            respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(respCreate.statusCode, 201);
            textEvidenceId = respCreate.evidenceId;
        });

        it('query created evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceQuerySchema);
        });
    });

    describe('T0:C2148431: query by evidenceId and include blockinfo', function () {
        it('test', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeBlockInfo=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceIncludeBlockInfoQuerySchema);
        });
    });

    describe('T1:C2076318: evidenceId is not exist', function () {
        it('test', async function () {
            let url = textEvidenceUrl + '/evidenceId_test_not_exist';
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 404);
            Assert.deepEqual(rspGet.code, TIDE.MscNotExistError.errorCode, 'check error code');
        });
    });

    describe('T1:C2076321: evidenceId include special characters', function () {
        it('test', async function () {
            let url = textEvidenceUrl + '/!@$&()~$';
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 422);
            Assert.deepEqual(rspGet.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2190178: query all evidence(null evidenceId)', function () {
        it('test', async function () {
            let url = textEvidenceUrl + '/';
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 422);
            Assert.deepEqual(rspGet.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe(' T0:delete ', function () {
        it('After-steps: delete test data', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104340: get single text evidence(non-includeHistory or includeHistory is false)', function () {
        let textEvidenceId;

        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('get single text evidence(non-includeHistory)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceQuerySchema);
        });

        it('get single text evidence(includeHistory:false)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=false`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceQuerySchema);
        });

        it('After-steps: delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });

    });

    describe('T1:C3104346: get single text evidence(steps:create,get include history)', function () {

        it('Pre-steps: create evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('get single text evidence(includeHistory:true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            let historyArray = rspGet.history;
            let createHistory = historyArray[0];
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceIncludeHistoryQuerySchema);
            await verifyObjectSchemaAsync(createHistory, historySchemafirstItem);
        });

        it('After-steps: delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104347: get single text evidence(steps:create,update labels,get include history)', function () {
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('update evidence labels ', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let updateEvidenceReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ]
            };
            let respCreate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateEvidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 200);
        });

        it('get single text evidence(includeHistory: true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            let historyArray = rspGet.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceNonFirstUpdateIncludeHistorySchema);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });


        it('After-steps: delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104348: get single text evidence(steps:create,update metadata,get include history)', function () {
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('update evidence metadata ', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let updateEvidenceReqBody = {
                'metadata': {
                    'key': 'value5'
                }
            };
            let respCreate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateEvidenceReqBody);
            Assert.deepEqual(respCreate.statusCode, 200);
        });


        it('get single text evidence(includeHistory:true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            let historyArray = rspGet.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceNonFirstUpdateIncludeHistorySchema);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });

        it('After-steps: delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104349: get single text evidence(steps:create,update labels and metadata,get include history)', function () {

        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('update evidence metadata ', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let updateEvidenceReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ],
                'metadata': {
                    'key': 'value5'
                }
            };
            let respCreate = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateEvidenceReqBody);
            Assert.deepEqual(respCreate.statusCode, 200);
        });


        it('get single text evidence(includeHistory:true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            let historyArray = rspGet.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceNonFirstUpdateIncludeHistorySchema);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });

        it('After-steps: delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104352: get single text evidence(steps:create,update labels,update metadata,update labels and metadata,get include history)', function () {

        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('update evidence metadata ', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let updateEvidenceLabelsReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ]
            };
            let updateEvidenceMetadataReqBody = {
                'metadata': {
                    'key': 'value5'
                }
            };
            let updateEvidenceBothReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ],
                'metadata': {
                    'key': 'value5'
                }
            };
            let respLabels = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateEvidenceLabelsReqBody);
            let respMetadata = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateEvidenceMetadataReqBody);
            let respBoth = await httpRequestAsync('patch', url, org1NormalUser1Headers, updateEvidenceBothReqBody);
            Assert.deepEqual(respLabels.statusCode, 200);
            Assert.deepEqual(respMetadata.statusCode, 200);
            Assert.deepEqual(respBoth.statusCode, 200);
        });

        it('get single text evidence(includeHistory:true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            let historyArray = rspGet.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceNonFirstUpdateIncludeHistorySchema, false);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });

        it('After-steps: delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104354: get single text evidence(steps:create,delete,get include history)', function () {
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });

        it('get single text evidence(includeHistory:true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true`;
            let rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 404);
            Assert.deepEqual(rspGet.code, TIDE.MscNotExistError.errorCode);
        });
    });

    describe('T1:C3104357: get single text evidence(steps:create,get include history and include blockinfo)', function () {
        let rspGet;
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('get single text evidence(includeHistory:true&includeBlockInfo:true)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=true&includeBlockInfo=true`;
            rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifyObjectSchemaAsync(rspGet, evidenceIncludeHistoryBlockInfoQuerySchema);
        });

        it('check labels,metadata,blockinfo', async function () {
            let labels = rspGet.labels;
            let metadata = rspGet.metadata;
            let blockInfo = rspGet.blockInfo;
            let historyArray = rspGet.history;
            let lastItem = historyArray.slice(-1);
            await verifyObjectPayloadSync(labels, lastItem.labels);
            await verifyObjectPayloadSync(metadata, lastItem.metadata);
            await verifyObjectPayloadSync(blockInfo, lastItem.blockInfo);
        });
        it('delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104359: get single text evidence(includeHistory:string or number,includeBlockInfo:string or number)', function () {
        let rspGet;
        it('Pre-steps: create evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            textEvidenceId = respCreate.evidenceId;
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('get single text evidence(includeBlockInfo:sting)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeBlockInfo=test`;
            rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 422);
            Assert.deepEqual(rspGet.code, TIDESOL.ParamsIllegalError.errorCode);
        });

        it('get single text evidence(includeBlockInfo:number)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeBlockInfo=123`;
            rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 422);
            Assert.deepEqual(rspGet.code, TIDESOL.ParamsIllegalError.errorCode);
        });

        it('get single text evidence(includeHistory:sting)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=test`;
            rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 422);
            Assert.deepEqual(rspGet.code, TIDESOL.ParamsIllegalError.errorCode);
        });

        it('get single text evidence(includeHistory:number)', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}?includeHistory=123`;
            rspGet = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspGet.statusCode, 422);
            Assert.deepEqual(rspGet.code, TIDESOL.ParamsIllegalError.errorCode);
        });

        it('delete text evidence', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

});