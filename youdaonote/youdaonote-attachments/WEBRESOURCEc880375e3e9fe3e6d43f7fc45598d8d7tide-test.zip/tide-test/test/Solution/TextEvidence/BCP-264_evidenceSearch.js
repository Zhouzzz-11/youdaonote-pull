//TIDE平台-根据ID查询业务资源- GET  /api/v1/solution/evidence/search
//BCP-109  存证solution: 查询各类存证
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2148587&group_by=cases:section_id&group_order=asc&group_id=195478

`use strict`;

const {resultsSort, randomString} = require('../../../test-utils/utils_comFunc');
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');
const {
    textEvidenceSchemaIgnoreUpdateIntoArrays_default,
    textEvidenceIgnoreUpdateSchemaIntoArrays
} = require('../../../test-schema/Solution/Evidence/evidence');
const {getHeaders} = require('../../../test-utils/util_user');
const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');


describe(`/test: GET  /api/v1/search`, function () {
    let org1NormalUser1Headers;
    let dataHash = 'default';
    let evidenceIdArray = [];
    let createNum = 50; //单skip时默认limit=20，所以这里要用20以上的数量
    let limitDefault = 20;
    let textEvidenceUrl = evidenceSolutionUrl.textEvidence;
    let textEvidenceSearchUrl = evidenceSolutionUrl.search;
    describe('T0:setUp_createTextEvidence', function () {

        it('Pre-steps: get user token and assemble http header', async function () {
            org1NormalUser1Headers = await getHeaders(baasOrg1.normalUsers.user2.iamLoginBody);
            Object.assign(org1NormalUser1Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser1Headers.Authorization.length, 8);
        });

        it('setUp_createTextEvidence', async () => {
            let rspPromiseArray = [];
            let rsp;
            let content = randomString();
            let evidenceIsNotPublicReqBody = new EvidenceObj({
                content: content,
                labels: ['test_lable01', 'test_lable01'],
                isPublic: false
            });

            for (let x = 0; x < createNum; x++) {
                if (x < 10) {
                    rsp = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceIsNotPublicReqBody);
                    rspPromiseArray.push(rsp);
                } else if (x > 15) {
                    let evidenceIsPublicReqBody = new EvidenceObj({
                        content: content,
                        labels: ['test_lable01', 'test_lable01']
                    });
                    rsp = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceIsPublicReqBody);
                    rspPromiseArray.push(rsp);
                } else {

                    let evidenceCommentReqBody = new EvidenceObj({
                        content: content,
                        labels: ['gbytest_lable01', 'gbytest_lable01']
                    });
                    evidenceCommentReqBody.comments = 'baasOrg1\'s comments';
                    rsp = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceCommentReqBody);
                    rspPromiseArray.push(rsp);
                }
            }

            let responses = await Promise.all(rspPromiseArray);
            for (let rsp of responses) {
                Assert.deepEqual(rsp.statusCode, 201, 'code is not 201');
                evidenceIdArray.push(rsp.evidenceId);
            }
            dataHash = responses[0].dataHash;
        }).timeout(180 * 1000);
    });

    describe('T0:C2076320: 默认查询', function () {
        let rsp;
        it('code 200 校验 ', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it('默认查询数量20校验', function () {
            Assert.deepEqual(rsp.results.length, 20, 'results size not eq 20');
        });

        it('dataHash 校验 ', function () {
            Assert.deepEqual(rsp.results[0].dataHash, dataHash, 'dataHash is not search\'s hash');
        });

        it('check schema', async function () {
            await verifyObjectSchemaAsync(rsp, textEvidenceSchemaIgnoreUpdateIntoArrays_default);
        });
    });

    describe('T0:C2148587: 全部条件查询', function () {
        let rsp;
        let skip = 10;
        let limit = 30;
        let sort = 'comments,desc';

        it('code 200 校验 ', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}&skip=${skip}&limit=${limit}&sort=${sort}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`默认查询数量${limit}校验(总数${createNum})`, function () {

            let exceptedNum = createNum >= skip + limit ? limit : createNum - skip;
            Assert.deepEqual(rsp.results.length, exceptedNum, `results size not eq ${exceptedNum}`);
        });

        it('dataHash 校验 ', function () {
            Assert.deepEqual(rsp.results[0].dataHash, dataHash, 'dataHash is not search\'s hash');
        });

        it(`comments排序校验`, function () {
            let actualResults = rsp.results;
            let exceptedResults = resultsSort(actualResults, [sort]);
            Assert.deepEqual(actualResults, exceptedResults, `commentsSort error`);
        });

        it('check schema', async function () {
            await verifyObjectSchemaAsync(rsp, textEvidenceSchemaIgnoreUpdateIntoArrays_default);
        });
    });

    describe('T1:C2076323: 必填参数缺失查询', function () {
        it('key缺失 422 ', async function () {
            let rsp = await httpRequestAsync('get', textEvidenceSearchUrl, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 422, 'code is not 422');
        });

    });

    describe('T1:C2162552: 查询的存证不存在', function () {
        let dataHash = '8dcf5e25b373e9xxxxxxxxxdc7020b74d9eccec35e0a8fa6e2d';
        let rsp;
        it('查询的存证不存在 200', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`查询的存证不存在查询数量校验 0 `, function () {
            Assert.deepEqual(rsp.results.length, 0, 'results size not eq 0');
        });
    });

    describe('T1:C2076325: 存证id查询', function () {
        let evidenceId;
        let rsp;
        it('存证id查询 200', async function () {
            evidenceId = evidenceIdArray[0];
            let url = textEvidenceSearchUrl + `?key=${evidenceId}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`查询的存证不存在查询数量校验 1 `, function () {
            Assert.deepEqual(rsp.results.length, 1, 'results size not eq 1');
        });

        it('evidenceId 校验 ', function () {
            Assert.deepEqual(rsp.results[0].evidenceId, evidenceId, 'evidenceId is not search\'s evidenceId');
        });

        it('check schema', async function () {
            await verifyObjectSchemaAsync(rsp, textEvidenceSchemaIgnoreUpdateIntoArrays_default);
        });
    });

    describe('T1:C2162548: skip查询  ', function () {
        let rsp;
        let skip = 5;
        let limit = limitDefault;
        it('code 200 校验 ', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}&skip=${skip}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`查询skip${skip}数量20校验`, function () {
            let exceptedNum = createNum >= skip + limit ? limit : createNum - skip;
            Assert.deepEqual(rsp.results.length, exceptedNum, `results size not eq ${exceptedNum}`);
        });

    });

    describe('T1:C2162548: sort=createdAt,desc单排序查询  ', function () {
        let rsp;
        let createdAtSort = 'createdAt,desc';
        it('code 200 校验 ', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}&sort=${createdAtSort}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`查询数量20校验`, function () {
            Assert.deepEqual(rsp.results.length, 20, `results size not eq 20`);
        });

        it(`创建时间排序校验`, function () {
            let actualResults = rsp.results;
            let exceptedResults = resultsSort(actualResults, [createdAtSort]);
            Assert.deepEqual(actualResults, exceptedResults, `createAtSort error`);
        });
    });

    describe('T1:C2162548: sort=evidenceId,desc单排序查询  ', function () {
        let rsp;
        let evidenceIdSort = 'evidenceId,desc';
        it('code 200 校验 ', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}&sort=${evidenceIdSort}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`查询数量20校验`, function () {
            Assert.deepEqual(rsp.results.length, 20, `results size not eq 20`);
        });

        it(`evidenceId排序校验`, function () {
            let actualResults = rsp.results;
            let exceptedResults = resultsSort(actualResults, [evidenceIdSort]);
            Assert.deepEqual(actualResults, exceptedResults, `createAtSort error`);
        });
    });

    describe('T1:C2162548: sort=createdBy,isPublic,createdAt,desc多参排序查询  ', function () {
        let rsp;
        let limit = 30;
        let commentsSort = 'createdBy';
        let isPublicSort = 'isPublic,asc';
        let createdAtSort = 'createdAt,desc';
        it('code 200 校验 ', async function () {
            let url = textEvidenceSearchUrl + `?key=${dataHash}&=${limit}&sort=${isPublicSort}&sort=${commentsSort}&sort=${createdAtSort}`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`查询数量20校验`, function () {
            Assert.deepEqual(rsp.results.length, 20, `results size not eq 20`);
        });

        it(`多维度排序校验`, function () {
            let actualResults = rsp.results;
            let exceptedResults = resultsSort(actualResults, [isPublicSort, commentsSort, createdAtSort]);
            Assert.deepEqual(actualResults, exceptedResults, `createAtSort error`);
        });
    });

    describe('T1:C3777069: includeBlockInfo查询', function () {
        let evidenceId;
        let rsp;
        it('check code 200 ', async function () {
            evidenceId = evidenceIdArray[0];
            let url = textEvidenceSearchUrl + `?key=${evidenceId}&includeBlockInfo=true`;
            rsp = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });

        it(`check includeBlockInfo result`, function () {
            let Results = rsp.results;
            let includeBlockInfoFilterLen = Results.filter(
                result => {
                    return result.blockInfo;
                }
            ).length;
            Assert.deepEqual(Results.length, includeBlockInfoFilterLen, `all result after startTime`);
        });

        it('check schema', async function () {
            await verifyObjectSchemaAsync(rsp, textEvidenceIgnoreUpdateSchemaIntoArrays);
        });

    });

    describe('T0:setDown_clearTextEvidence', function () {
        it('setDown_clearTextEvidence', async () => {
            let delResp_promise;
            let delResp_promiseStore = [];
            let url;
            for (let evidenceId of evidenceIdArray) {
                url = textEvidenceUrl + `/${evidenceId}`;
                delResp_promise = httpRequestAsync('delete', url, org1NormalUser1Headers);
                delResp_promiseStore.push(delResp_promise);
            }
            let delResps = await Promise.all(delResp_promiseStore);
            for (let delResp of delResps) {
                Assert.deepEqual(delResp.statusCode, 204, 'code is not 204');
            }
        });
    });

});