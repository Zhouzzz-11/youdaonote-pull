//存证解决方案-查询文本存证-GET-/api/v1/solution/evidence/text
//BCP-323 存证解决方案查询文本存证
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074782
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076436
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076315
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2190124
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2190125
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2190208
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2190209
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076314
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162532
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162533
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162534
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162535
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074784
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162536
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162545
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658080
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658081
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658082
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658083
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658084
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658085
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658086
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658087
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658088
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658089
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2658090
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2662317
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2662318
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2662319
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2662320


'use strict';

const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {queryEvidenceAsync, deleteEvidenceByIdAsync, createEvidenceAsync} = require('../../../test-function/Solution/Evidence/textEvidenceFunction');   //Function used in script should required from test-function
const {verifySchemaAsync} = require('../../../test-verify/verify');
const {textEvidenceSchemaIntoArrays,textEvidenceIgnoreUpdateSchemaIntoArrays} = require('../../../test-schema/Solution/Evidence/evidence');
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {getRspValue, isSorted, randomString} = require('../../../test-utils/utils_comFunc');
const {Assert} = require('@rootcloud/darjeeling');
const {TIDESOL} = require('../../../test-lib/errorMessage');
const {getUserId} = require('../../../test-function/NetworkManager/userFunction');
const {getToken} = require('../../../test-utils/util_token');

describe(`/test: GET /api/v1/text`, function () {
    let userId = 'defaultId';
    let createNum = 51;
    let limitDefault = 20;
    let evidenceIdStore = [];
    describe('T0:setUp_createTextEvidence', function () {
        it('setUp_createTextEvidence', async () => {
            let rspPromiseStore = [];
            let rsp;
            let textEvidenceObjPublic = new EvidenceObj({
                isPublic: true
            });
            let textEvidenceObjSecret = new EvidenceObj({
                isPublic: false
            });
            for (let x = 0; x < createNum; x++) {
                if (x < createNum / 2) {
                    rsp = await createEvidenceAsync(textEvidenceObjPublic, baasOrg01);
                    rspPromiseStore.push(rsp);
                } else {
                    rsp = await createEvidenceAsync(textEvidenceObjSecret, baasOrg01);
                    rspPromiseStore.push(rsp);
                }
            }

            let responses = await Promise.all(rspPromiseStore);
            for (let rsp of responses) {
                Assert.deepEqual(rsp.statusCode, 201, 'code is not 201');
                evidenceIdStore.push(getRspValue(rsp.body, 'evidenceId'));
            }
            let token = await getToken(baasOrg01);
            userId = await getUserId(token);
        }).timeout(180 * 1000);
    });

    describe('T0:C2074782: query evidence(all filter Params)', function () {
        let rspQuery;
        let exceptedNum;
        let queryObj = {
            createdBy: '',
            includeBlockInfo: 'true',
            skip: 1,
            limit: 5,
            sort: 'evidenceId'
        };
        it('get userId ', async function () {
            queryObj['createdBy'] = userId;
        });
        it('check query response statusCode', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it(`check total number`, function () {
            exceptedNum = createNum >= (queryObj['skip'] + queryObj['limit']) ? queryObj['limit'] : (createNum - queryObj['skip']);
            Assert.deepEqual(getRspValue(rspQuery.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
        it(` check evidenceId sort`, function () {
            let actualArr = getRspValue(rspQuery.body, 'results');
            let isSortedResult = isSorted(actualArr, queryObj['sort'], false);
            Assert.deepEqual(true, isSortedResult, 'check sorted result');
        });
        it('check blockInfo', function () {
            let blockInfoFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.blockInfo;
                }
            ).length;
            Assert.deepEqual(blockInfoFilter, exceptedNum, `all result have blockInfo field`);
        });
        it(`all results belong to ${userId}`, function () {
            let userIdFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) !== -1;
                }
            ).length;
            Assert.deepEqual(userIdFilter, exceptedNum, `results is not all belongs to ${userId}`);
        });
        it('check response schema ', async function () {
            await verifySchemaAsync(rspQuery, textEvidenceSchemaIntoArrays, false);
        });
    });

    describe('T1:C2076436: query evidence(default filter)', function () {
        let rspQuery;
        it('check query response statusCode', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, {});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check length of results', function () {
            Assert.deepEqual(getRspValue(rspQuery.body, 'results').length, 20, 'results size not eq 20');
        });
    });

    describe('T1:C2076315: query evidence(field type error)', function () {
        let queryObj = {skip: 'a'};
        it('check query response code', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    //bug:includeBlockInfo http://jira2.rootcloud.com:8080/browse/BCP-1722
    describe('T1:C2190124: query evidence(includeBlockInfo: true & limit:21)', function () {
        let rspQueryBody;
        let queryObj = {
            includeBlockInfo: true,
            limit: 21
        };
        it('check query status', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 200);
        }).timeout(15 * 1000);
        it('when includeBlockInfo is true limit max 20 ', function () {
            let resultsLength = rspQueryBody.results.length;
            Assert.deepEqual(resultsLength, 20, 'check length of results is larger than 1');
        });
    });

    describe('T1:C2190125: query evidence(limit 51)', function () {
        let rspQueryBody;
        let queryObj = {
            limit: 51
        };
        it('check query response', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('limit max num is 50', function () {
            let resultsLength = rspQueryBody.results.length;
            Assert.deepEqual(resultsLength, 50, 'check length of results is larger than 1');
        });
    });

    describe('T1:C2662317: query evidence(type error: startTime and endTime)', function () {
        let queryObj1 = {
            startTime: 'typeError01'
        };
        let queryObj2 = {
            endTime: 'typeError02'
        };
        it('check query response(startTime)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj1);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(endTime)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj2);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2662318: query evidence(parameter null: dataHash and title)', function () {
        let queryObj1 = {
            dataHash: ''
        };
        let queryObj2 = {
            title: ''
        };
        it('check query response(dataHash)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj1);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(title)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj2);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2662319: query evidence(parameter length limit exceeded:labels and title)', function () {
        let queryObj1 = {
            labels: randomString({length: 33})
        };
        let queryObj2 = {
            title: randomString({length: 65})
        };
        it('check query response(labels)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj1);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(title)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj2);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2662320: query evidence(parameter is special character: evidenceId and referenceId)', function () {
        let queryObj1 = {
            evidenceId: '~!@#$^&*()_+=-'
        };
        let queryObj2 = {
            referenceId: '~!@#$^&*()_+=-'
        };
        it('check query response(evidenceId)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj1);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(referenceId)', async function () {
            let rspQuery = await queryEvidenceAsync(baasOrg01, queryObj2);
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2076314: query evidence(single: createdBy)', function () {
        let rspQuery;
        let queryObj = {createdBy: 'defaultId'};
        it('get userId ', async function () {
            queryObj['createdBy'] = userId;
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200, 'code 200 校验');
        });
        it(`check if all results belong to ${userId}`, function () {
            let numsAfterFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) !== -1;
                }
            ).length;
            Assert.deepEqual(numsAfterFilter, 20, `results is not all belongs to ${userId}`);
        });
    });

    describe('T1:C2162532: query evidence(single: skip)', function () {
        let rspQuery;
        let limit = limitDefault;
        let queryObj = {skip: 1};
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it(`check skip response`, function () {
            let exceptedNum = createNum >= (queryObj['skip'] + limit) ? limit : (createNum - queryObj['skip']);
            Assert.deepEqual(getRspValue(rspQuery.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
    });

    describe('T1:C2162533: query evidence(single: limit)', function () {
        let rspQuery;
        let skip = 0;
        let queryObj = {limit: 1};
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it(`check limit response`, function () {
            let exceptedNum = (createNum >= skip + queryObj['limit']) ? queryObj['limit'] : (createNum - skip);
            Assert.deepEqual(getRspValue(rspQuery.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
    });

    //bug:includeBlockInfo http://jira2.rootcloud.com:8080/browse/BCP-1722
    describe('T1:C2162534: query evidence(single: includeBlockInfo)', function () {
        let rspQuery;
        let queryObj = {includeBlockInfo: true};
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        }).timeout(15 * 1000);
        it('check blockInfo', function () {
            let blockInfoFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.blockInfo;
                }
            ).length;
            Assert.deepEqual(blockInfoFilter, 20, `all result have blockInfo field`);
        });
    });

    describe('T1:C2162535: query evidence(single: sort)', function () {
        let rspQuery;
        let queryObj = {sort: 'title'};
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check sort result', function () {
            let actualArr = getRspValue(rspQuery.body, 'results');
            let isSortedResult = isSorted(actualArr, queryObj['sort'], false);
            Assert.deepEqual(true, isSortedResult, 'check sorted result');
        });
    });

    describe('T1:C2658080: query evidence(single: labels)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new EvidenceObj({labels: [randomString({length: 5})], isPublic: false});
        let queryObj = {labels: evidenceReqBody['labels'][0]};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check labels result', function () {
            let labelsResults = getRspValue(rspQuery.body, 'results');
            let labelsFilterLen = labelsResults.filter(
                result => {
                    return result.labels.indexOf(queryObj['labels']) !== -1;
                }
            ).length;
            Assert.deepEqual(labelsResults.length, labelsFilterLen, `all result have same labels field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658081: query evidence(single: dataHash)', function () {
        let evidenceId;
        let rspQuery;
        let queryObj = {dataHash: 'defaultHash'};
        let evidenceReqBody = new EvidenceObj({content: randomString({length: 20}), isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            queryObj['dataHash'] = getRspValue(rspCreate.body, 'dataHash');
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check dataHash result', function () {
            let dataHashResults = getRspValue(rspQuery.body, 'results');
            let dataHashFilterLen = dataHashResults.filter(
                result => {
                    return result.dataHash === queryObj['dataHash'];
                }
            ).length;
            Assert.deepEqual(dataHashResults.length, dataHashFilterLen, `all result have same dataHash field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658082: query evidence(single: evidenceId)', function () {
        let evidenceId;
        let rspQuery;
        let queryObj = {evidenceId: 'evidenceId'};
        let evidenceReqBody = new EvidenceObj({isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            queryObj['evidenceId'] = evidenceId;
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check evidenceId result', function () {
            let evidenceIdResults = getRspValue(rspQuery.body, 'results');
            let evidenceIdFilterLen = evidenceIdResults.filter(
                result => {
                    return result.evidenceId === queryObj['evidenceId'];
                }
            ).length;
            Assert.deepEqual(evidenceIdResults.length, evidenceIdFilterLen, `all result have evidenceId field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658083: query evidence(single: title)', function () {
        let evidenceId;
        let rspQuery;
        let titleRand = randomString({length: 5});
        let evidenceReqBody = new EvidenceObj({title: titleRand, isPublic: false});
        let queryObj = {title: titleRand};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check title result', function () {
            let titleResults = getRspValue(rspQuery.body, 'results');
            let titleFilterLen = titleResults.filter(
                result => {
                    return result.title === queryObj['title'];
                }
            ).length;
            Assert.deepEqual(titleResults.length, titleFilterLen, `all result have same title field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658084: query evidence(single: referenceId)', function () {
        let evidenceId;
        let rspQuery;
        let referenceIdRand = randomString({length: 8});
        let evidenceReqBody = new EvidenceObj({referenceId: referenceIdRand, isPublic: false});
        let queryObj = {referenceId: referenceIdRand};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check referenceId result', function () {
            let referenceIdResults = getRspValue(rspQuery.body, 'results');
            let referenceIdFilterLen = referenceIdResults.filter(
                result => {
                    return result.referenceId === queryObj['referenceId'];
                }
            ).length;
            Assert.deepEqual(referenceIdResults.length, referenceIdFilterLen, `all result have same title field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658085: query evidence(single: startTime)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new EvidenceObj({isPublic: false});
        let queryObj = {startTime: 'defaultStartTime'};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            queryObj['startTime'] = getRspValue(rspCreate.body, 'createdAt');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check startTime result', function () {
            let startTimeResults = getRspValue(rspQuery.body, 'results');
            let startTimeFilterLen = startTimeResults.filter(
                result => {
                    return result.createdAt >= queryObj['startTime'];
                }
            );
            Assert.deepEqual(startTimeResults.length, startTimeFilterLen.length, `all result after startTime`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658086: query evidence(single: endTime)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new EvidenceObj({isPublic: false});
        let queryObj = {endTime: 'defaultEndTime'};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            queryObj['endTime'] = getRspValue(rspCreate.body, 'createdAt');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check endTime result', function () {
            let endTimeResults = getRspValue(rspQuery.body, 'results');
            let endTimeFilterLen = endTimeResults.filter(
                result => {
                    return result.createdAt <= queryObj['endTime'];
                }
            ).length;
            Assert.deepEqual(endTimeResults.length, endTimeFilterLen, `all result after startTime`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C3777070: query evidence(single: isPublic)', function () {
        let rsp;
        it('code 200 校验 ', async function () {
            let queryObj = {
                limit: 50,
                isPublic: false,
                createdBy: userId
            };
            rsp = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it('check isPublic result', function () {
            let Results = getRspValue(rsp.body, 'results');
            let isPublicFilterLen = Results.filter(
                result => {
                    return result.isPublic <= false;
                }
            ).length;
            Assert.deepEqual(Results.length, isPublicFilterLen, `all result after startTime`);
        });
        it('check count', function () {
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, 25, 'results size not eq 26');
        });
    });

    describe('T1:C2658087: query evidence(double: title & labels)', function () {
        let evidenceId;
        let rspQuery;
        let titleRand = randomString({length: 5});
        let labelsRand = randomString({length: 6});
        let evidenceReqBody = new EvidenceObj({title: titleRand, labels: [labelsRand], isPublic: false});
        let queryObj = {title: titleRand, labels: labelsRand};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check title & labels result', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.title === titleRand && result.labels.indexOf(labelsRand) !== -1;
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check title and labels search resullt`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658088: query evidence(double: dataHash & evidenceId)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new EvidenceObj({isPublic: false});
        let queryObj = {dataHash: 'defaultDataHash', evidenceId: 'defaultEvidenceId'};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            queryObj['dataHash'] = getRspValue(rspCreate.body, 'dataHash');
            queryObj['evidenceId'] = evidenceId;
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check dataHash & evidenceId result', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.dataHash === queryObj['dataHash'] && result.evidenceId === queryObj['evidenceId'];
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check dataHash and evidenceId search result`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658089: query evidence(double: startTime & endTime)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new EvidenceObj({isPublic: false});
        let queryObj = {startTime: 'defaultStartTime', endTime: 'defaultEndTime'};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            queryObj['startTime'] = getRspValue(rspCreate.body, 'createdAt');
            queryObj['endTime'] = queryObj['startTime'];
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check startTime & endTime result', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.createdAt >= queryObj['startTime'] && result.createdAt <= queryObj['endTime'];
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check startTime and endTime search result`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658090: query evidence(double: title & referenceId)', function () {
        let evidenceId;
        let rspQuery;
        let titleRand = randomString({length: 8});
        let referenceIdRand = randomString({length: 6});
        let evidenceReqBody = new EvidenceObj({title: titleRand, referenceId: referenceIdRand, isPublic: false});
        let queryObj = {title: titleRand, referenceId: referenceIdRand};
        it('create text evidence', async function () {
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check title & referenceId referenceId', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.title === titleRand && result.referenceId === referenceIdRand;
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check title and referenceId search result`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    //bug:includeBlockInfo http://jira2.rootcloud.com:8080/browse/BCP-1722
    describe('T1:C2074784: query evidence(double: createdBy and includeBlockInfo)', function () {
        let rspQuery;
        let queryObj = {createdBy: '', includeBlockInfo: true};
        it('get userId ', async function () {
            queryObj['createdBy'] = userId;
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        }).timeout(15 * 1000);
        it(`check if all results belong to ${userId}`, function () {
            let numsAfterFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) !== -1;
                }
            ).length;
            Assert.deepEqual(numsAfterFilter, 20, `results is not all belongs to ${userId}`);
        });
        it('check blockInfo', function () {
            let blockInfoFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.blockInfo;
                }
            ).length;
            Assert.deepEqual(blockInfoFilter, 20, `all result have blockInfo field`);
        });
        it('check response schema ', async function () {
            await verifySchemaAsync(rspQuery, textEvidenceIgnoreUpdateSchemaIntoArrays, false);
        });
    });

    describe('T1:C2162536: query evidence(double: skip and limit)', function () {
        let rspQuery;
        let queryObj = {skip: 5, limit: 15};
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it(`check limit response`, function () {
            let exceptedNum = (createNum >= queryObj['skip'] + queryObj['limit']) ? queryObj['limit'] : (createNum - queryObj['skip']);
            Assert.deepEqual(getRspValue(rspQuery.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
    });

    describe('T1:C2162545: query evidence(double: createdBy and sort)', function () {
        let rspQuery;
        let queryObj = {createdBy: '', sort: 'content,desc'};
        it('get userId ', async function () {
            queryObj['createdBy'] = userId;
        });
        it('check query response status', async function () {
            rspQuery = await queryEvidenceAsync(baasOrg01, queryObj);
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it(`check if all results belong to ${userId}`, function () {
            let numsAfterFilter = getRspValue(rspQuery.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) !== -1;
                }
            ).length;
            Assert.deepEqual(numsAfterFilter, 20, `results is not all belongs to ${userId}`);
        });
        it('check sort result', function () {
            let actualArr = getRspValue(rspQuery.body, 'results');
            let isSortedResult = isSorted(actualArr, 'content', true);
            Assert.deepEqual(true, isSortedResult, 'check sorted result');
        });
    });

    describe('T0:setDown_clearTextEvidence', function () {
        it('setDown_clearTextEvidence', async () => {
            let delResp_promise;
            let delResp_promiseStore = [];
            for (let evidenceId of evidenceIdStore) {
                delResp_promise = deleteEvidenceByIdAsync(evidenceId, baasOrg01);
                delResp_promiseStore.push(delResp_promise);
            }
            let delResps = await Promise.all(delResp_promiseStore);
            for (let delResp of delResps) {
                Assert.deepEqual(delResp.statusCode, 204, 'code is not 204');
            }
        });
    });
});

