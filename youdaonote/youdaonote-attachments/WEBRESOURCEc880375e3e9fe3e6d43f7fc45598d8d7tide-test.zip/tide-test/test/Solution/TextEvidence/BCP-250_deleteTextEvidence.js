//Solution-DELETE-/api/v1/solution/evidence/text/{evidenceId}
//BCP-250 
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=202161

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {TIDE, TIDESOL} = require('../../../test-lib/errorMessage');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {getHeaders} = require('../../../test-utils/util_user');
const {evidenceSolutionUrl} = require('../../../test-lib/url');


describe(`/test: DELETE  /api/v1/text/{evidenceId}`, function () {
    let org1NormalUser1Headers;
    let respCreate, textEvidenceId;
    let textEvidenceUrl = evidenceSolutionUrl.textEvidence;

    describe('T0:C2148565: delete by evidenceId', function () {
        let evidenceReqBody = new EvidenceObj();
        it('Pre-steps: get user token and assemble http header', async function () {
            org1NormalUser1Headers = await getHeaders(baasOrg1.normalUsers.user2.iamLoginBody);
            Object.assign(org1NormalUser1Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser1Headers.Authorization.length, 8);
        });

        it('Pre-steps: create evidence ', async function () {
            respCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(respCreate.statusCode, 201);
            textEvidenceId = respCreate.evidenceId;
        });

        it('test', async function () {
            let url = textEvidenceUrl + `/${textEvidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C2148568: Required item verification(null evidenceId)', function () {
        it('test', async function () {

            let url = textEvidenceUrl + `/`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 422);
            Assert.deepEqual(rspDelete.code, TIDESOL.ParamsIllegalError.errorCode);

        });
    });

    describe('T1:C2148567: evidenceId is not exist', function () {
        it('test', async function () {
            let url = textEvidenceUrl + `/evidenceId_test_not_exist`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 404);
            Assert.deepEqual(rspDelete.code, TIDE.MscNotExistError.errorCode);
        });
    });
});

