//存证解决方案-新建文本存证-POST-/api/v1/solution/evidence/text
//BCP-309 存证解决方案新建文本存证
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074777
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2148351
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2148353
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2162531
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2148352
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074780
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076328
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2190127
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2190128
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074781
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074785
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2074786
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076317
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076319
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2076330

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
// const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {baasOrg1} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');
const {verifyObjectPayloadSync} = require('../../../test-verify/verify');
const {evidenceSchema} = require('../../../test-schema/Solution/Evidence/evidence');
const {httpRequestAsync} = require('../../../test-utils/util_httpRequest');
const {
    evidenceQuerySchema,
    evidenceIncludeBlockInfoSchema,
    evidenceUseTrustedTimestampSchema
} = require('../../../test-schema/Solution/Evidence/evidence');
const {randomString} = require('../../../test-utils/utils_comFunc');
const {TIDESOL} = require('../../../test-lib/errorMessage');
const {evidenceSolutionUrl} = require('../../../test-lib/url');
const {getHeaders} = require('../../../test-utils/util_user');


describe(`/test: POST /api/v1/text`, function () {
    let org1NormalUser1Headers, org1NormalUser2Headers;
    let textEvidenceUrl = evidenceSolutionUrl.textEvidence;
    let evidenceReqBody = new EvidenceObj();
    let rspCreate;
    describe('T0:C2074777: create evidence', function () {
        it('Pre-steps: get user1 token and assemble http header', async function () {
            org1NormalUser1Headers = await getHeaders(baasOrg1.normalUsers.user1.iamLoginBody);
            Object.assign(org1NormalUser1Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser1Headers.Authorization.length, 8);
        });

        it('Pre-steps: get user2 token and assemble http header', async function () {
            org1NormalUser2Headers = await getHeaders(baasOrg1.normalUsers.user2.iamLoginBody);
            Object.assign(org1NormalUser2Headers, {
                'RC-APP-ID': baasOrg1.superUser.consortiaInfo[0].apps[0]
            });
            Assert.isAbove(org1NormalUser2Headers.Authorization.length, 8);
        });

        it('create evidence and check response ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(rspCreate, evidenceSchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T0:C2148351: create evidence(async)', function () {
        it('create async evidence and check response ', async function () {
            let url = textEvidenceUrl + '?async=true';
            rspCreate = await httpRequestAsync('post', url, org1NormalUser1Headers, evidenceReqBody);
            let evidenceId = rspCreate.evidenceId;
            Assert.deepEqual(rspCreate.statusCode, 202, 'check status code');
            verifyObjectPayloadSync(rspCreate, {
                track: `/api/v1/text/queue/${evidenceId}`,
                evidenceId: `${evidenceId}`
            });
        });
    });

    describe('T0:C2148353: create evidence(includeBlockInfo)', function () {
        it('create evidence include includeBlockInfo and check response ', async function () {
            let url = textEvidenceUrl + `?includeBlockInfo=true`;
            rspCreate = await httpRequestAsync('post', url, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceIncludeBlockInfoSchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T0:C2162531: create evidence(useTrustedTimestamp)', function () {
        let evidenceReqBody = new EvidenceObj({useTrustedTimestamp: true});
        it('create evidence include useTrustedTimestamp and check response', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceUseTrustedTimestampSchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2148352: create evidence(missing  content)', function () {
        let evidenceReqBody = new EvidenceObj();
        delete evidenceReqBody['content'];
        it('create evidence', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422);
            Assert.deepEqual(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2074780: create evidence(missing  metadata)', function () {
        let rspCreate;
        let evidenceReqBody = new EvidenceObj();
        delete evidenceReqBody['metadata'];
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });


    describe('T1:C2076328: create evidence(label is empty array)', function () {
        let evidenceReqBody = new EvidenceObj({labels: []});
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422);
            verifyObjectPayloadSync(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2190127: create evidence(length of labels is 33)', function () {
        let labels_string = randomString({length: 33});
        let evidenceReqBody = new EvidenceObj({labels: [`${labels_string}`]});
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422);
            verifyObjectPayloadSync(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2190128: create evidence(length of content is 32769)', function () {
        let content = randomString({length: 32769});
        let evidenceReqBody = new EvidenceObj({content: content});
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422);
            verifyObjectPayloadSync(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2074781: create evidence(isPublic is true)', function () {
        let rspCreate;
        let evidenceReqBody = new EvidenceObj();
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceSchema);
        });

        it('query evindencde using other user', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}?useTrustedTimestamp=true`;
            let rspQuery = await httpRequestAsync('get', url, org1NormalUser1Headers);
            Assert.deepEqual(rspQuery.statusCode, 200);
            await verifyObjectSchemaAsync(rspQuery, evidenceQuerySchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2074785: create evidence(isPublic is false)', function () {
        let rspCreate;
        let evidenceReqBody = new EvidenceObj({isPublic: false});
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceSchema);
        });

        it('query evidence using other user ', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}?useTrustedTimestamp=true`;
            let rspQuery = await httpRequestAsync('get', url, org1NormalUser2Headers);
            Assert.deepEqual(rspQuery.statusCode, 404);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });


    describe('T1:C2076317: create evidence(Special characters)', function () {
        let rspCreate;
        let special = randomString({length: 5, chars: '!@#$%^&*()_+'});
        let evidenceReqBody = new EvidenceObj({content: special, labels: [`${special}`]});
        evidenceReqBody['metadata'] = {'key': '.*&%$#@!'};
        evidenceReqBody['signature'] = '.*&%$#@!';
        evidenceReqBody['comments'] = '.*&%$#@!';
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceSchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2076319: create evidence(parameter type error)', function () {
        let evidenceReqBody = new EvidenceObj({labels: 'labels'});
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422);
            Assert.deepEqual(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2076330: create evidence(dump labels)', function () {
        let rspCreate;
        let evidenceReqBody = new EvidenceObj({labels: ['test', 'test']});
        it('create evidence ', async function () {
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(rspCreate, evidenceSchema);
        });

        it('delete evidence', async function () {
            let url = textEvidenceUrl + `/${rspCreate.evidenceId}`;
            let rspDelete = await httpRequestAsync('delete', url, org1NormalUser1Headers);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:create text evidence with the blank space params', async function () {
        let rspCreate;
        let evidenceReqBody = new EvidenceObj();
        it('C2897955: title include only blank space', async function () {
            evidenceReqBody['title'] = '     ';
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });

        it('C2897956: labels include only blank space', async function () {
            evidenceReqBody['labels'] = ['     '];
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });

        it('C2897954: content include only blank space', async function () {
            evidenceReqBody['content'] = '     ';
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(rspCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });
    });

    // TODO bug http://jira2.rootcloud.com:8080/browse/BCP-3254
    describe.skip('T1:C2074786: create evidence(invalid user)', function () {
        let evidenceReqBody = new EvidenceObj();
        it('create evidence ', async function () {
            org1NormalUser1Headers.Authorization = 'test';
            rspCreate = await httpRequestAsync('post', textEvidenceUrl, org1NormalUser1Headers, evidenceReqBody);
            Assert.deepEqual(rspCreate.statusCode, 401);
            Assert.deepEqual(rspCreate.code, TIDESOL.UserUnauthorizedError.errorCode);
        });
    });
});