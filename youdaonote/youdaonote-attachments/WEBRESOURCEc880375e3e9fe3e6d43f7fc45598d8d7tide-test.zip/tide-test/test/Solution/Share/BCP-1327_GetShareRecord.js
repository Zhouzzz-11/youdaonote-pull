//Share -GET-/api/v1/share/record
//BCP-1327
//TestRail链接: http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=283234

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj, EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {ShareObj} = require('../../../test-data/Solution/Share/shareData');
const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {createEvidenceAsync, deleteEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/textEvidenceFunction'); 
const {createShareCode, getSharingRecord} = require('../../../test-function/Solution/Share/shareFunction');
const {recordListFileSchema, recordListTextOriginalSchema, recordListTextOriginalHistorySchema} = require('../../../test-schema/Solution/Share/share');
const {verifySchemaAsync, verifyPayloadSync} = require('../../../test-verify/verify');
const { TIDESOL } = require('../../../test-lib/errorMessage');



describe('test: GET /api/v1/share/record', function () {
    let rspFile, rspText, rspRecord_File, rspRecord_Text;
    let bodyFile, bodyText;
    let FileEvidenceReqBody = new FileEvidenceObj({persist: false});
    let TextEvidenceReqBody = new EvidenceObj();
    describe('T0:Set-up: create share', function () {
        it('create file evidence', async function () {
            rspFile = await createFileEvidenceAsync(FileEvidenceReqBody, baasOrg01);
            bodyFile = JSON.parse(rspFile.body);
            Assert.deepEqual(rspFile.statusCode, 201, 'check status code');
        }).timeout(25 * 1000);
        it('create text evidence', async function () {
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg02);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        }).timeout(25 * 1000);
        it('create share code', async function () {
            let shareReqBody_File = new ShareObj({evidenceId: bodyFile.evidenceId, includeOriginal: false});
            let shareReqBody_Text = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true});
            let rspShare_File = await createShareCode(shareReqBody_File, baasOrg01);
            Assert.deepEqual(rspShare_File.statusCode, 201, 'check status code');
            let rspShare_Text = await createShareCode(shareReqBody_Text, baasOrg02);
            Assert.deepEqual(rspShare_Text.statusCode, 201, 'check status code');
        });
    });

    describe('C3132001: get all shared record', function () {
        it('T0: get record and check response', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: 'skip=0&limit=1'});
            let body = JSON.parse(rsp.body);
            Assert.deepEqual(rsp.statusCode, 200);
            Assert.deepEqual(body.results.length, 1, 'check the result number');
        });
    });

    describe('C3132004: get shared record by evidenceId', function () {
        it('T0: get file record and check response', async function () {
            rspRecord_File = await getSharingRecord(baasOrg01, {queryString: `evidenceId=${bodyFile.evidenceId}`});
            Assert.deepEqual(rspRecord_File.statusCode, 200);
            await verifySchemaAsync(rspRecord_File, recordListFileSchema, false);
        });
        it('T0: get text record and check response', async function () {
            rspRecord_Text = await getSharingRecord(baasOrg02, {queryString: `evidenceId=${bodyText.evidenceId}`});
            Assert.deepEqual(rspRecord_Text.statusCode, 200);
            await verifySchemaAsync(rspRecord_Text, recordListTextOriginalSchema, false);
        });
    });

    describe('T1: get shared record by illegal evidenceId', function () {
        it('C3132005: evidenceId include special string', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=!!!!**`});
            Assert.deepEqual(rsp.statusCode, 422);
            verifyPayloadSync(rsp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C3132006: evidenceId include blank', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=qwe  123`});
            Assert.deepEqual(rsp.statusCode, 422);
            verifyPayloadSync(rsp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C3132007: length of evidenceId is less than 1', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=`});
            Assert.deepEqual(rsp.statusCode, 422);
            verifyPayloadSync(rsp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C3132016: length of evidenceId is more than 64(test data is 65)', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=5fe9453580c59347781c758e5fe9453580c59347781c758e5fe9453580c593477`});
            Assert.deepEqual(rsp.statusCode, 422);
            verifyPayloadSync(rsp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
    });

    describe('C3132010: get shared record by evidenceId which is created by others', function () {
        it('T1: get record and check response', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=${bodyText.evidenceId}`});
            let body = JSON.parse(rsp.body);
            Assert.deepEqual(rsp.statusCode, 200);
            Assert.deepEqual(body.total, 0, 'check the total number');
        });
    });

    describe('C3150965: get shared record by evidence title', function () {
        it('T1: get record and check response', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `title=${bodyFile.title}`});
            Assert.deepEqual(rsp.statusCode, 200);
            await verifySchemaAsync(rsp, recordListFileSchema, false);
        });
    });

    describe('Set-down: delete test data', function () {
        it('T0: delete evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyFile.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg02);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('C3132009: get shared record by deleted evidenceId', function () {
        it('T1: get record and check response', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=${bodyFile.evidenceId}`});
            let body = JSON.parse(rsp.body);
            Assert.deepEqual(rsp.statusCode, 200);
            Assert.deepEqual(body.total, 0, 'check the total number');
        });
    });

    describe('C3150966: get shared record by deleted evidence title', function () {
        it('T1: get record and check response', async function () {
            let rsp = await getSharingRecord(baasOrg01, {queryString: `title=${bodyFile.title}`});
            let body = JSON.parse(rsp.body);
            Assert.deepEqual(rsp.statusCode, 200);
            Assert.deepEqual(body.total, 0, 'check the total number');
        });
    });

    describe('C3230495: get shared record includeHistoty', function () {
        it('T1: get record and check response', async function () {
            //create text evidence
            let rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            let bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
            //create share
            let shareReqBody_Text = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, includeHistory: true});
            let rspShare_Text = await createShareCode(shareReqBody_Text, baasOrg01);
            Assert.deepEqual(rspShare_Text.statusCode, 201, 'check status code');
            //get shared record
            let rsp = await getSharingRecord(baasOrg01, {queryString: `evidenceId=${bodyText.evidenceId}`});
            Assert.deepEqual(rsp.statusCode, 200);
            await verifySchemaAsync(rsp, recordListTextOriginalHistorySchema, false);
            //delete evidence
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });
});