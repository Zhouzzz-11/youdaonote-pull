//Share -DELETE-/api/v1/share/record/{shareId}
//BCP-1327
//TestRail链接: http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=283236

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj, EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {ShareObj} = require('../../../test-data/Solution/Share/shareData');
const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {createEvidenceAsync, deleteEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/textEvidenceFunction'); 
const {createShareCode, getSharingRecord, deleteSharingRecordById} = require('../../../test-function/Solution/Share/shareFunction');
const {verifyPayloadSync} = require('../../../test-verify/verify');
const { TIDESOL } = require('../../../test-lib/errorMessage');



describe('test: DELETE /api/v1/share/record/{shareId}', function () {
    let rspFile, rspText, rspRecord_File, rspRecord_Text;
    let bodyFile, bodyText, bodyRecord_File, bodyRecord_Text;
    let FileEvidenceReqBody = new FileEvidenceObj({persist: false});
    let TextEvidenceReqBody = new EvidenceObj();
    describe('T0:Set-up: create sharing', function () {
        it('create file evidence', async function () {
            rspFile = await createFileEvidenceAsync(FileEvidenceReqBody, baasOrg01);
            bodyFile = JSON.parse(rspFile.body);
            Assert.deepEqual(rspFile.statusCode, 201, 'check status code');
        }).timeout(25 * 1000);
        it('create text evidence', async function () {
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg02);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        }).timeout(25 * 1000);
        it('create share code', async function () {
            let shareReqBody_File = new ShareObj({evidenceId: bodyFile.evidenceId, includeOriginal: false});
            let shareReqBody_Text = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true});
            let rspShare_File = await createShareCode(shareReqBody_File, baasOrg01);
            Assert.deepEqual(rspShare_File.statusCode, 201, 'check status code');
            let rspShare_Text = await createShareCode(shareReqBody_Text, baasOrg02);
            Assert.deepEqual(rspShare_Text.statusCode, 201, 'check status code');
        });
        it('get shareId', async function () {
            rspRecord_File = await getSharingRecord(baasOrg01, {queryString: `evidenceId=${bodyFile.evidenceId}`});
            bodyRecord_File = JSON.parse(rspRecord_File.body);
            Assert.deepEqual(rspRecord_File.statusCode, 200);
            rspRecord_Text = await getSharingRecord(baasOrg02, {queryString: `evidenceId=${bodyText.evidenceId}`});
            bodyRecord_Text = JSON.parse(rspRecord_Text.body);
            Assert.deepEqual(rspRecord_Text.statusCode, 200);
        });
    });

    describe('C3132024: delete share by shareId', function () {
        it('T0: delete and check response', async function () {
            let rsp = await deleteSharingRecordById(bodyRecord_File.results[0].shareId, baasOrg01);
            Assert.deepEqual(rsp.statusCode, 204);
        });
    });

    describe('C3132025: delete share by deleted shareId(duplicate elimination)', function () {
        it('T1: delete and check response', async function () {
            let rsp = await deleteSharingRecordById(bodyRecord_File.results[0].shareId, baasOrg01);
            Assert.deepEqual(rsp.statusCode, 404);
            verifyPayloadSync(rsp, TIDESOL.AssetNotFoundError.errorCode, 'code');
        });
    });

    describe('T1: delete share by illegal shareId', function () {
        it('C3132028: shareId include special string or blank', async function () {
            let rsp_1 = await deleteSharingRecordById('!!!!**', baasOrg01);
            Assert.deepEqual(rsp_1.statusCode, 422);
            verifyPayloadSync(rsp_1, TIDESOL.ParamsIllegalError.errorCode, 'code');
            let rsp_2 = await deleteSharingRecordById('qwe  1234', baasOrg01);
            Assert.deepEqual(rsp_2.statusCode, 422);
            verifyPayloadSync(rsp_2, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C3132026: length of shareId is less than 6', async function () {
            let rsp = await deleteSharingRecordById('abc', baasOrg01);
            Assert.deepEqual(rsp.statusCode, 422);
            verifyPayloadSync(rsp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C3132027: length of shareId is more than 64(test data is 65)', async function () {
            let rsp = await deleteSharingRecordById('5fe9453580c59347781c758e5fe9453580c59347781c758e5fe9453580c593477', baasOrg01);
            Assert.deepEqual(rsp.statusCode, 422);
            verifyPayloadSync(rsp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
    });

    describe('C3132029: delete share by shareId which is created by others', function () {
        it('T1: delete and check response', async function () {
            let rsp = await deleteSharingRecordById(bodyRecord_Text.results[0].shareId, baasOrg01);
            Assert.deepEqual(rsp.statusCode, 404);
            verifyPayloadSync(rsp, TIDESOL.AssetNotFoundError.errorCode, 'code');
        });
    });

    describe('Set-down: delete test data', function () {
        it('T0: delete evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyFile.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg02);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('C3151049: delete share after evidence has been deleted', function () {
        it('T1: delete and check response', async function () {
            let rsp = await deleteSharingRecordById(bodyRecord_Text.results[0].shareId, baasOrg02);
            Assert.deepEqual(rsp.statusCode, 404);
            verifyPayloadSync(rsp, TIDESOL.AssetNotFoundError.errorCode, 'code');
        });
    });
});