//Share -GET-/api/v1/share/{code}
//BCP-926
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=266466


'use strict';

const path = require('path');
const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj, EvidenceObj, updateFileEvidenceData_1, updateTextEvidenceData_1} = require('../../../test-data/Solution/Evidence/evidenceData');
const {ShareObj} = require('../../../test-data/Solution/Share/shareData');
const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync, updateFileEvidenceByIdAsync, getFileName, getFileSize, getFileHash, getFileMd5, readFile, uploadFileAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {createEvidenceAsync, deleteEvidenceByIdAsync, updateEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/textEvidenceFunction');
const {createShareCode, getSharedEvidence} = require('../../../test-function/Solution/Share/shareFunction');
const {
    shareTextEvidenceNonOriginalSchema,
    shareTextEvidenceOriginalSchema,
    shareFileEvidenceSchema,
    shareFileEvidenceOriginalSchema,
    shareFileEvidenceUploadSOriginalSchema,
    shareTextEvidenceHistorySchema,
    shareTextEvidenceOriginalHistorySchema,
    shareFileEvidenceHistorySchema
} = require('../../../test-schema/Solution/Share/share');
const {verifySchemaAsync, verifyPayloadSync} = require('../../../test-verify/verify');
const {TIDESOL} = require('../../../test-lib/errorMessage');


describe('test: GET /api/v1/share/{code}', function () {
    let bodyFile_1, bodyFile_2, bodyFile_3, bodyText;
    describe('test for getShare-Setup:create evidence and sharing code', function () {
        let rspFile_1, rspFile_2, rspFile_3, rspText;
        let FileEvidenceReqBody_1 = new FileEvidenceObj({persist: false});
        let FileEvidenceReqBody_2 = new FileEvidenceObj({persist: true});
        let FileEvidenceReqBody_3 = new FileEvidenceObj({persist: true});
        let TextEvidenceReqBody = new EvidenceObj();
        it('T0:create file evidence', async function () {
            let filePath = path.join(__dirname, '../../../.env');
            let fileName = getFileName(filePath);
            let fileSize = getFileSize(filePath);
            let fileHash = getFileHash(filePath);
            FileEvidenceReqBody_3.fileName = fileName;
            FileEvidenceReqBody_3.fileSize = fileSize;
            FileEvidenceReqBody_3.fileHash = fileHash;
            //create fileEvidence 1
            rspFile_1 = await createFileEvidenceAsync(FileEvidenceReqBody_1, baasOrg01);
            bodyFile_1 = JSON.parse(rspFile_1.body);
            Assert.deepEqual(rspFile_1.statusCode, 201, 'check status code');
            //create fileEvidence 2
            rspFile_2 = await createFileEvidenceAsync(FileEvidenceReqBody_2, baasOrg01);
            bodyFile_2 = JSON.parse(rspFile_2.body);
            Assert.deepEqual(rspFile_2.statusCode, 201, 'check status code');
            //create fileEvidence 3
            rspFile_3 = await createFileEvidenceAsync(FileEvidenceReqBody_3, baasOrg01);
            bodyFile_3 = JSON.parse(rspFile_3.body);
            let uploadUrl = bodyFile_3.uploadUrl;
            Assert.deepEqual(rspFile_3.statusCode, 201, 'check status code');
            //upload file.
            let fileContent = readFile(filePath);
            let fileMd5 = getFileMd5(filePath);
            let rspUpload = await uploadFileAsync(uploadUrl, fileContent, fileMd5);
            Assert.deepEqual(rspUpload.statusCode, 200, 'check status code');
        }).timeout(35 * 1000);
        it('T0:create text evidence', async function () {
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        });
    });


    describe('C2915397: get sharing evidence(evidenceType:fileEvidence, persist: false,includeOriginal: true)', function () {
        let shareReqBody, resp_create, bodyShare, resp;
        it('T0:get sharing evidence and check response', async function () {
            //create share
            shareReqBody = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: true});
            resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
            //get share
            resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareFileEvidenceSchema, false);
        });
        it('T1:C3104244-1: get sharing evidence before file evidence updated', async function () {
            //update evidence
            let rspUpdate = await updateFileEvidenceByIdAsync(bodyFile_1.evidenceId, updateFileEvidenceData_1, baasOrg01);
            Assert.deepEqual(rspUpdate.statusCode, 200);
            //create sharing code
            let shareReqBody_u = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: true});
            let resp_create_u = await createShareCode(shareReqBody_u, baasOrg01);
            Assert.deepEqual(resp_create_u.statusCode, 201, 'check status code');
            let bodyShare_u = JSON.parse(resp_create_u.body);
            //compare to the code
            Assert.notStrictEqual(bodyShare.code, bodyShare_u.code, 'Check for equality');
            let resp_u = await getSharedEvidence(bodyShare_u.code);
            Assert.deepEqual(resp_u.statusCode, 200, 'check status code');
            //compare to the sharing msg
            Assert.notStrictEqual(JSON.parse(resp.body), JSON.parse(resp_u.body), 'Check for equality');
        });
    });

    describe('C2917435: get sharing evidence(evidenceType:fileEvidence, persist: true, upload file failed, includeOriginal: true)', function () {
        it('T0:get sharing evidence and check response', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyFile_2.evidenceId, includeOriginal: true});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            //get share
            let resp_1 = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp_1.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp_1, shareFileEvidenceOriginalSchema, false);
        });
    });

    describe('C2915389: get sharing evidence(evidenceType:fileEvidence, persist: false,includeOriginal: false)', function () {
        it('T0:get sharing evidence and check response', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            //get share
            let resp_1 = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp_1.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp_1, shareFileEvidenceSchema, false);
        });
    });

    describe('C2917436: get sharing evidence(evidenceType:fileEvidence, persist: true, upload file failed,includeOriginal: false)', function () {
        it('T0:get sharing evidence and check response', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyFile_2.evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            //get share
            let resp_1 = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp_1.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp_1, shareFileEvidenceSchema, false);
        });
    });

    describe('C2915388: get sharing evidence(evidenceType:fileEvidence, persist: true, upload file successed,includeOriginal: true)', function () {
        it('T0:get sharing evidence and check response', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyFile_3.evidenceId, includeOriginal: true});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            //get share
            let resp_1 = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp_1.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp_1, shareFileEvidenceUploadSOriginalSchema, false);
        });
    });

    describe('C2915385: get sharing evidence(evidenceType:fileEvidence, persist: true, upload file successed,includeOriginal: false)', function () {
        it('T0:get sharing evidence and check response', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyFile_3.evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            //get share
            let resp_1 = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp_1.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp_1, shareFileEvidenceSchema, false);
        });
    });

    describe('get sharing evidence and check response', function () {
        let shareReqBody, resp_create, bodyShare, resp;
        it('T0:C2915390: get sharing evidence(evidenceType:textEvidence, includeOriginal: true)', async function () {
            //create share
            shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true});
            resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
            //get share
            resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareTextEvidenceOriginalSchema, false);
        });
        it('T1:C3104244-2: get sharing evidence before text evidence updated', async function () {
            //update evidence
            let rspUpdate = await updateEvidenceByIdAsync(bodyText.evidenceId, updateTextEvidenceData_1, baasOrg01);
            Assert.deepEqual(rspUpdate.statusCode, 200);
            //create sharing code
            let shareReqBody_u = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true});//evidenceType:textEvidence, includeOriginal: false
            let resp_create_u = await createShareCode(shareReqBody_u, baasOrg01);
            Assert.deepEqual(resp_create_u.statusCode, 201, 'check status code');
            let bodyShare_u = JSON.parse(resp_create_u.body);
            //compare to the code
            Assert.notStrictEqual(bodyShare.code, bodyShare_u.code, 'Check for equality');
            let resp_u = await getSharedEvidence(bodyShare_u.code);
            Assert.deepEqual(resp_u.statusCode, 200, 'check status code');
            //compare to the sharing msg
            Assert.notStrictEqual(JSON.parse(resp.body), JSON.parse(resp_u.body), 'Check for equality');
        });
    });

    describe('C2915393: get sharing evidence(evidenceType:textEvidence, includeOriginal: false)', function () {
        it('T0:get sharing evidence and check response', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            //get share
            let resp_1 = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp_1.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp_1, shareTextEvidenceNonOriginalSchema, false);
        });
    });

    describe('T1: get sharing evidence by error code', function () {
        it('C2915399: length of the code is less than 16', async function () {
            let resp = await getSharedEvidence('0000');
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C2915400: length of the code is more than 32', async function () {
            let resp = await getSharedEvidence('0123456789ABCDEFG0123456789ABCDEFGH');
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C2915401: the code includes special string or blank space', async function () {
            let resp = await getSharedEvidence('!!!  ****1111100000');
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('C2915402: the code have correct format but not exist or expired', async function () {
            let resp = await getSharedEvidence('KMZZZTAK6XII3DDS');
            Assert.deepEqual(resp.statusCode, 404, 'check status code');
            verifyPayloadSync(resp, TIDESOL.AssetNotFoundError.errorCode, 'code');
        });
    });

    describe('C3104245: get sharing evidence after delete evidence', function () {
        it('T1:get sharing evidence and check response(FileEvidence)', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: false});
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
            //delete evidence
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyFile_1.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
            //get share
            let resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 404, 'check status code');
        });
        it('T1:get sharing evidence and check response(TextEvidence)', async function () {
            //create share
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: false});
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            let bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
            //delete evidence
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
            //get share
            let resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 404, 'check status code');
        });
    });

    describe('test for Share-Setdown:delete evidence', function () {
        it('T0:delete test data', async function () {
            let rspFileDelete_2 = await deleteFileEvidenceByIdAsync(bodyFile_2.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete_2.statusCode, 204);
            let rspFileDelete_3 = await deleteFileEvidenceByIdAsync(bodyFile_3.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete_3.statusCode, 204);
        });
    });
});

describe('test: GET /api/v1/share/{code} include history', function () {

    describe('T1:C3104436: get sharing evidence(evidenceType:textEvidence, includeOriginal: false,includeHistory:false)', function () {
        let bodyCreate;
        let bodyShare;
        let evidenceReqBody = new EvidenceObj();
        it('Pre-steps: create text evidence ', async function () {
            let respCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share text evidence(includeOriginal:false,includeHistory:false) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: false,
                includeHistory: false
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing text evidence and check response(TextEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareTextEvidenceNonOriginalSchema, false);
        });
        it('delete text evidence', async function () {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('T1:C3104445: get sharing evidence(evidenceType:textEvidence, includeOriginal: false,includeHistory:true)', function () {
        let bodyCreate;
        let bodyShare;
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share text evidence(includeOriginal:false,includeHistory:true) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: false,
                includeHistory: true
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing text evidence and check response(TextEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareTextEvidenceHistorySchema, false);
        });
        it('delete text evidence', async function () {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('T1:C3104446: get sharing evidence(evidenceType:textEvidence, includeOriginal: true,includeHistory:false)', function () {
        let bodyCreate;
        let bodyShare;
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share text evidence(includeOriginal:true,includeHistory:false) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: true,
                includeHistory: false
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing text evidence and check response(TextEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareTextEvidenceOriginalSchema, false);
        });
        it('delete text evidence', async function () {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('T1:C3104447: get sharing evidence(evidenceType:textEvidence, includeOriginal: true,includeHistory:true)', function () {
        let bodyCreate;
        let bodyShare;
        it('Pre-steps: create text evidence ', async function () {
            let evidenceReqBody = new EvidenceObj();
            let respCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share text evidence(includeOriginal:true,includeHistory:true) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: true,
                includeHistory: true
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing text evidence and check response(TextEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareTextEvidenceOriginalHistorySchema, false);
        });
        it('delete text evidence', async function () {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('T1:C3104449: get sharing evidence(evidenceType:fileEvidence, includeOriginal: false,includeHistory:false)', function () {
        let bodyCreate;
        let bodyShare;
        let evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create file evidence ', async function () {
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share file evidence(includeOriginal:false,includeHistory:false) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: false,
                includeHistory: false
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing file evidence and check response(FileEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            let bodyResp = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareFileEvidenceSchema, false);
            Assert.notStrictEqual(bodyResp.evidence.fileName, evidenceReqBody.fileName);
            Assert.deepEqual(bodyResp.evidence.fileSize, 0);
        });
        it('delete file evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
        });
    });

    describe('T1:C3104451: get sharing evidence(evidenceType:fileEvidence, includeOriginal: false,includeHistory:true)', function () {
        let bodyCreate;
        let bodyShare;
        let evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create file evidence ', async function () {
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share file evidence(includeOriginal:false,includeHistory:true) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: false,
                includeHistory: true
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing file evidence and check response(FileEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            let bodyResp = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareFileEvidenceHistorySchema, false);
            Assert.notStrictEqual(bodyResp.evidence.fileName, evidenceReqBody.fileName);
            Assert.deepEqual(bodyResp.evidence.fileSize, 0);
        });
        it('delete file evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
        });
    });

    describe('T1:C3104452: get sharing evidence(evidenceType:fileEvidence, includeOriginal: true,includeHistory:false)', function () {
        let bodyCreate;
        let bodyShare;
        let evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create file evidence ', async function () {
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share file evidence(includeOriginal:true,includeHistory:false) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: true,
                includeHistory: false
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing file evidence and check response(FileEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            let bodyResp = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareFileEvidenceSchema, false);
            Assert.deepEqual(bodyResp.evidence.fileName, evidenceReqBody.fileName);
            Assert.deepEqual(bodyResp.evidence.fileSize, evidenceReqBody.fileSize);
        });
        it('delete file evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
        });
    });

    describe('T1:C3104453: get sharing evidence(evidenceType:fileEvidence, includeOriginal: true,includeHistory:true)', function () {
        let bodyCreate;
        let bodyShare;
        let evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create file evidence ', async function () {
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share file evidence(includeOriginal:true,includeHistory:true) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: true,
                includeHistory: true
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            bodyShare = JSON.parse(resp_create.body);
            Assert.deepEqual(resp_create.statusCode, 201, 'check status code');
        });
        it('get sharing file evidence and check response(FileEvidence)', async function () {
            let resp = await getSharedEvidence(bodyShare.code);
            let bodyResp = JSON.parse(resp.body);
            Assert.deepEqual(resp.statusCode, 200, 'check status code');
            await verifySchemaAsync(resp, shareFileEvidenceHistorySchema, false);
            Assert.deepEqual(bodyResp.evidence.fileName, evidenceReqBody.fileName);
            Assert.deepEqual(bodyResp.evidence.fileSize, evidenceReqBody.fileSize);
        });
        it('delete file evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
        });
    });
    
    describe('T1:C3104458: get sharing evidence(evidenceType:fileEvidence, includeOriginal: string or number,includeHistory:string or number)', function () {
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create file evidence ', async function () {
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('share file evidence(includeOriginal:string,includeHistory:true) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: 'test',
                includeHistory: true
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp_create.statusCode, 422, 'check status code');
            verifyPayloadSync(resp_create, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('share file evidence(includeOriginal:number,includeHistory:true) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: 123,
                includeHistory: true
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp_create.statusCode, 422, 'check status code');
            verifyPayloadSync(resp_create, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('share file evidence(includeOriginal:true,includeHistory:string) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: true,
                includeHistory: 'test'
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp_create.statusCode, 422, 'check status code');
            verifyPayloadSync(resp_create, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('share file evidence(includeOriginal:number,includeHistory:number) ', async function () {
            let shareReqBody = new ShareObj({
                evidenceId: bodyCreate.evidenceId,
                includeOriginal: true,
                includeHistory: 123
            });
            let resp_create = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp_create.statusCode, 422, 'check status code');
            verifyPayloadSync(resp_create, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('delete file evidence', async function () {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
        });
    });
});
