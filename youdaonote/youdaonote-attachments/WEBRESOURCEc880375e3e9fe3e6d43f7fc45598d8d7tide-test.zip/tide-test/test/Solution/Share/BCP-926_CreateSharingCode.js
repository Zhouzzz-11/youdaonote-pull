//Share -POST-/api/v1/share
//BCP-926
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=266464

'use strict';

const path = require('path');
const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj, EvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {ShareObj} = require('../../../test-data/Solution/Share/shareData');
const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync, getFileName, getFileSize, getFileHash, getFileMd5, readFile, uploadFileAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {createEvidenceAsync, deleteEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/textEvidenceFunction'); 
const {createShareCode} = require('../../../test-function/Solution/Share/shareFunction');
const {shareCodeSchema} = require('../../../test-schema/Solution/Share/share');
const {verifySchemaAsync, verifyPayloadSync} = require('../../../test-verify/verify');
const { TIDE, TIDESOL } = require('../../../test-lib/errorMessage');


describe('test: POST /api/v1/share', function(){
    let rspFile_1, rspFile_2, rspFile_3, rspText_1, rspText_2;
    let bodyFile_1, bodyFile_2, bodyFile_3, bodyText_1, bodyText_2;
    let FileEvidenceReqBody_1 = new FileEvidenceObj({persist: false});
    let FileEvidenceReqBody_2 = new FileEvidenceObj({persist: true});
    let FileEvidenceReqBody_3 = new FileEvidenceObj({persist: false});
    let TextEvidenceReqBody = new EvidenceObj();
    describe('/test for Share-Setup:create evidence', function() {
        it('T0:create file evidence', async function() {
            rspFile_1 = await createFileEvidenceAsync(FileEvidenceReqBody_1, baasOrg01);
            bodyFile_1 = JSON.parse(rspFile_1.body);
            Assert.deepEqual(rspFile_1.statusCode, 201, 'check status code');
            rspFile_2 = await createFileEvidenceAsync(FileEvidenceReqBody_2, baasOrg01);
            bodyFile_2 = JSON.parse(rspFile_2.body);
            Assert.deepEqual(rspFile_2.statusCode, 201, 'check status code');
            rspFile_3 = await createFileEvidenceAsync(FileEvidenceReqBody_3, baasOrg01);
            bodyFile_3 = JSON.parse(rspFile_3.body);
            Assert.deepEqual(rspFile_3.statusCode, 201, 'check status code');
        }).timeout(25 * 1000);
        it('T0:create text evidence', async function() {
            rspText_1 = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText_1 = JSON.parse(rspText_1.body);
            Assert.deepEqual(rspText_1.statusCode, 201, 'check status code');
            rspText_2 = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText_2 = JSON.parse(rspText_2.body);
            Assert.deepEqual(rspText_2.statusCode, 201, 'check status code');
        });
    });

    describe('C3709069: share with other user created evidence', function() {
        it('T1:create sharing code and check response(evidenceType:FileEvidence, persist: false,includeOriginal:false)', async function() {
            let shareReqBody_1 = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: false});
            let resp_1 = await createShareCode(shareReqBody_1, baasOrg02);
            Assert.deepEqual(resp_1.statusCode, 403, 'check status code');
            verifyPayloadSync(resp_1, TIDESOL.ForbiddenError.errorCode, 'code');
        }).timeout(10*1000);
        it('T1:create sharing code and check response(evidenceType:TextEvidence, includeOriginal:false)', async function() {
            let shareReqBody_2 = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: false});
            let resp_2 = await createShareCode(shareReqBody_2, baasOrg02);
            Assert.deepEqual(resp_2.statusCode, 403, 'check status code');
            verifyPayloadSync(resp_2, TIDESOL.ForbiddenError.errorCode, 'code');
        }).timeout(10*1000);
    });

    describe('C2915380: create sharing code(evidenceType:FileEvidence, includeOriginal:true)', function() {
        it('T0: create sharing code and check response', async function() {
            let shareReqBody_1 = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: true});
            let shareReqBody_2 = new ShareObj({evidenceId: bodyFile_2.evidenceId, includeOriginal: true});
            let resp_1 = await createShareCode(shareReqBody_1, baasOrg01);
            Assert.deepEqual(resp_1.statusCode, 201, 'check status code');
            await verifySchemaAsync(resp_1, shareCodeSchema, false);
            let resp_2 = await createShareCode(shareReqBody_2, baasOrg01);
            Assert.deepEqual(resp_2.statusCode, 201, 'check status code');
            await verifySchemaAsync(resp_2, shareCodeSchema, false);
        });
    });

    describe('C2915381: create sharing code(evidenceType:FileEvidence, includeOriginal:false)', function() {
        it('T0:create sharing code and check response', async function() {
            let shareReqBody_1 = new ShareObj({evidenceId: bodyFile_1.evidenceId, includeOriginal: false});
            let shareReqBody_2 = new ShareObj({evidenceId: bodyFile_2.evidenceId, includeOriginal: false});
            let resp_1 = await createShareCode(shareReqBody_1, baasOrg01);
            Assert.deepEqual(resp_1.statusCode, 201, 'check status code');
            await verifySchemaAsync(resp_1, shareCodeSchema, false);
            let resp_2 = await createShareCode(shareReqBody_2, baasOrg01);
            Assert.deepEqual(resp_2.statusCode, 201, 'check status code');
            await verifySchemaAsync(resp_2, shareCodeSchema, false);
        });
    });

    describe('C2915382: create sharing code(evidenceType:TextEvidence, includeOriginal:true)', function() {
        it('T0:create sharing code and check response', async function() {
            let shareReqBody = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: true});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            await verifySchemaAsync(resp, shareCodeSchema, false);
        });
    });

    describe('C2915383: create sharing code(evidenceType:TextEvidence, includeOriginal:false)', function() {
        it('T0:create sharing code and check response', async function() {
            let shareReqBody = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
            await verifySchemaAsync(resp, shareCodeSchema, false);
        });
    });

    describe('C2915384: create sharing code by not exist evidenceId', function() {
        it('T1:create sharing code and check response', async function() {
            let shareReqBody = new ShareObj({evidenceId: 'NotExistEvidenceId', includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 404, 'check status code');
            verifyPayloadSync(resp, TIDE.MscNotExistError.errorCode, 'code');
        });
    });

    describe('C3104475: create sharing code by a deleted evidenceId', function() {
        it('T1:create sharing code and check response(FileEvidence)', async function() {
            //delete evidence
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyFile_3.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
            //create sharing code
            let shareReqBody = new ShareObj({evidenceId: bodyFile_3.evidenceId, includeOriginal: false});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 404, 'check status code');
            verifyPayloadSync(resp, TIDE.MscNotExistError.errorCode, 'code');
        });
        it('T1:create sharing code and check response(TextEvidence)', async function() {
            //delete evidence
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText_2.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
            //create sharing code
            let shareReqBody = new ShareObj({evidenceId: bodyText_2.evidenceId, includeOriginal: true});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 404, 'check status code');
            verifyPayloadSync(resp, TIDE.MscNotExistError.errorCode, 'code');
        });
    });

    describe('C3104489: check the type of includeOriginal', function() {
        it('T1:includeOriginal is a number type', async function() {
            let shareReqBody_1 = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: 11111});
            let resp_1 = await createShareCode(shareReqBody_1, baasOrg01);
            Assert.deepEqual(resp_1.statusCode, 422, 'check status code');
            verifyPayloadSync(resp_1, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1:includeOriginal is a string type', async function() {
            let shareReqBody_2 = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: 'test'});
            let resp_2 = await createShareCode(shareReqBody_2, baasOrg01);
            Assert.deepEqual(resp_2.statusCode, 422, 'check status code');
            verifyPayloadSync(resp_2, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
    });

    describe('C2915407: many times to create sharing code for a evidence in 24h', function() {
        it('T1:create sharing code and check the code', async function() {
            let shareReqBody_1 = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: true});
            let shareReqBody_2 = new ShareObj({evidenceId: bodyText_1.evidenceId, includeOriginal: true});
            let resp_1 = await createShareCode(shareReqBody_1, baasOrg01);
            let resp_2 = await createShareCode(shareReqBody_2, baasOrg01);
            let body_1 = JSON.parse(resp_1.body);
            let body_2 = JSON.parse(resp_2.body);
            Assert.deepEqual(resp_1.statusCode, 201, 'check status code');
            Assert.deepEqual(resp_2.statusCode, 201, 'check status code');
            Assert.notStrictEqual(body_1.code, body_2.code);
        });
    });

    describe('C3162660: set expire time between 300s and 15552000s', function() {
        let FileEvidenceReqBody, TextEvidenceReqBody;
        let rspFile, rspText;
        let bodyFile, bodyText;
        it('T1: create evidence', async function() {
            //create fileEvidence
            FileEvidenceReqBody = new FileEvidenceObj({persist: true});
            let filePath = path.join(__dirname, '../../../.env');
            let fileName = getFileName(filePath);
            let fileSize = getFileSize(filePath);
            let fileHash = getFileHash(filePath);
            FileEvidenceReqBody.fileName = fileName;
            FileEvidenceReqBody.fileSize = fileSize;
            FileEvidenceReqBody.fileHash = fileHash;
            rspFile = await createFileEvidenceAsync(FileEvidenceReqBody, baasOrg01);
            bodyFile = JSON.parse(rspFile.body);
            let uploadUrl = bodyFile.uploadUrl;
            Assert.deepEqual(rspFile.statusCode, 201, 'check status code');
            //upload file.
            let fileContent = readFile(filePath);
            let fileMd5 = getFileMd5(filePath);
            let rspUpload = await uploadFileAsync(uploadUrl, fileContent, fileMd5);
            Assert.deepEqual(rspUpload.statusCode, 200, 'check status code');
            //create textEvidence
            TextEvidenceReqBody = new EvidenceObj();
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        });
        it('T1: fileEvidence/includeOriginal/expiresAfter 1h', async function() {
            //evidenceType:fileEvidence, expiresAfter:1h
            let shareReqBody = new ShareObj({evidenceId: bodyFile.evidenceId, includeOriginal: true, expiresAfter: 3600});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: fileEvidence/includeOriginal/expiresAfter 24h', async function() {
            //evidenceType:fileEvidence, expiresAfter:24h
            let shareReqBody = new ShareObj({evidenceId: bodyFile.evidenceId, includeOriginal: true, expiresAfter: 86400});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: fileEvidence/includeOriginal/expiresAfter 7d', async function() {
            //evidenceType:fileEvidence, expiresAfter:7d
            let shareReqBody = new ShareObj({evidenceId: bodyFile.evidenceId, includeOriginal: true, expiresAfter: 604800});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: fileEvidence/includeOriginal/expiresAfter 1mth', async function() {
            //evidenceType:fileEvidence, expiresAfter:1mth
            let shareReqBody = new ShareObj({evidenceId: bodyFile.evidenceId, includeOriginal: true, expiresAfter: 2592000});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 1h', async function() {
            //evidenceType:textEvidence, expiresAfter:1h
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 3600});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 24h', async function() {
            //evidenceType:textEvidence, expiresAfter:24h
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 86400});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 7d', async function() {
            //evidenceType:textEvidence, expiresAfter:7d
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 604800});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 1mth', async function() {
            //evidenceType:textEvidence, expiresAfter:1mth
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 2592000});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: delete test data', async function() {
            let rspFileDelete = await deleteFileEvidenceByIdAsync(bodyFile.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete.statusCode, 204);
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('C3162695: set expire time but not between 300s and 15552000s', function() {
        let TextEvidenceReqBody;
        let rspText;
        let bodyText;
        it('T1: create evidence', async function() {
            //create textEvidence
            TextEvidenceReqBody = new EvidenceObj();
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 299s', async function() {
            //evidenceType:textEvidence, expiresAfter:299s
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 299});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 15552001s', async function() {
            //evidenceType:textEvidence, expiresAfter:15552001s
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 15552001});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1: delete test data', async function() {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('C3162696: set expire time as a decimal number between 300s and 15552000s', function() {
        let TextEvidenceReqBody;
        let rspText;
        let bodyText;
        it('T1: create evidence', async function() {
            //create textEvidence
            TextEvidenceReqBody = new EvidenceObj();
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter 300.9s', async function() {
            //evidenceType:textEvidence, expiresAfter:300.9s
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 300.9});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 201, 'check status code');
        });
        it('T1: delete test data', async function() {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('C3162697: set expire time as a negative number or type of string/boolean/special string', function() {
        let TextEvidenceReqBody;
        let rspText;
        let bodyText;
        it('T1: create evidence', async function() {
            //create textEvidence
            TextEvidenceReqBody = new EvidenceObj();
            rspText = await createEvidenceAsync(TextEvidenceReqBody, baasOrg01);
            bodyText = JSON.parse(rspText.body);
            Assert.deepEqual(rspText.statusCode, 201, 'check status code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter -500s', async function() {
            //evidenceType:textEvidence, expiresAfter:-500s
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: -500});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter abc', async function() {
            //evidenceType:textEvidence, expiresAfter:abc
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: 'abc'});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter true', async function() {
            //evidenceType:textEvidence, expiresAfter:true
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: true});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1: textEvidence/includeOriginal/expiresAfter !!@@', async function() {
            //evidenceType:textEvidence, expiresAfter:!!@@
            let shareReqBody = new ShareObj({evidenceId: bodyText.evidenceId, includeOriginal: true, expiresAfter: '!!@@'});
            let resp = await createShareCode(shareReqBody, baasOrg01);
            Assert.deepEqual(resp.statusCode, 422, 'check status code');
            verifyPayloadSync(resp, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('T1: delete test data', async function() {
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });

    describe('test for Share-Setdown:delete evidence', function() {
        it('T0:delete test data', async function() {
            let rspFileDelete_1 = await deleteFileEvidenceByIdAsync(bodyFile_1.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete_1.statusCode, 204);
            let rspFileDelete_2 = await deleteFileEvidenceByIdAsync(bodyFile_2.evidenceId, baasOrg01);
            Assert.deepEqual(rspFileDelete_2.statusCode, 204);
            let rspTextDelete = await deleteEvidenceByIdAsync(bodyText_1.evidenceId, baasOrg01);
            Assert.deepEqual(rspTextDelete.statusCode, 204);
        });
    });
});