//Evidence Solution-get evidence total number-GET-/api/v1/solution/evidence/metrics/statistics
//BCP-485
//TestRail link：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2581720
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2581721
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2581722

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {baasOrg01} = require('../../test-data/NetworkManager/BCP-60_auth_login_data');
const {EvidenceObj} = require('../../test-data/Solution/Evidence/evidenceData');
const {FileEvidenceObj} = require('../../test-data/Solution/Evidence/evidenceData');
const {getEvidenceTotalNum, createEvidenceAsync,deleteEvidenceByIdAsync} = require('../../test-function/Solution/Evidence/textEvidenceFunction');   //Function used in script should required from test-function
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync} = require('../../test-function/Solution/Evidence/fileEvidenceFunction');
const {verifyObjectSchemaAsync} = require('../../test-verify/verify');
const {evidenceTotalNumSchema} = require('../../test-schema/Solution/Evidence/evidence');

describe(`/test: GET /api/v1/metrics/statistics`, function () {

    describe(`T0:C2581720: get the total number of evidence`, function () {
        it(`check status code `, async function () {
            let rsp = await getEvidenceTotalNum(baasOrg01);
            Assert.deepEqual(rsp.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(JSON.parse(rsp.body), evidenceTotalNumSchema);
        }).timeout(25 * 1000);
    });

    describe(`T1:C2581723: create text evidence and file evidence then check num`, function () {
        let totalEvidenceNum;
        let textEvidenceNum;
        let fileEvidenceNum;
        let textEvidenceBodyCreate;
        let fileEvidenceBodyCreate;
        it(`get total evidence num `, async function () {
            let rsp = await getEvidenceTotalNum(baasOrg01);
            let rspBody = JSON.parse(rsp.body);
            totalEvidenceNum= rspBody.total;
            textEvidenceNum = rspBody.detail.text;
            fileEvidenceNum = rspBody.detail.file;
            Assert.deepEqual(rsp.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(rspBody, evidenceTotalNumSchema);
        });
        it('create text evidence and check response ', async function () {
            let evidenceReqBody= new EvidenceObj();
            let rspCreate = await createEvidenceAsync(evidenceReqBody, baasOrg01);
            textEvidenceBodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('create file evidence and check response ', async function () {
            let evidenceReqBody= new FileEvidenceObj();
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            fileEvidenceBodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it(`check total evidence num and text evidence num `, async function () {
            let rsp = await getEvidenceTotalNum(baasOrg01);
            let rspBody = JSON.parse(rsp.body);
            let totalEvidenceNumNew= rspBody.total;
            let textEvidenceNumNew = rspBody.detail.text;
            let fileEvidenceNumNew = rspBody.detail.file;
            Assert.deepEqual(rsp.statusCode, 200, 'check status code');
            Assert.deepEqual(totalEvidenceNumNew, totalEvidenceNum+2, 'check total evidence number');
            Assert.deepEqual(textEvidenceNumNew, textEvidenceNum+1, 'check total text evidence number');
            Assert.deepEqual(fileEvidenceNumNew, fileEvidenceNum+1, 'check total text evidence number');
        });
        it('delete evidence', async function () {
            let rspDeleteText = await deleteEvidenceByIdAsync(textEvidenceBodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteText.statusCode, 204, 'check status code');
            let rspDeleteFile = await deleteFileEvidenceByIdAsync(fileEvidenceBodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteFile.statusCode, 204, 'check status code');
        });
    });

});