//Solution-GET-api/v1/solution/evidence/file
// BCP-432
// TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414122&group_by=cases:section_id&group_order=asc&group_id=224497

'use strict';

const {getRspValue, resultsSort, randomString} = require('../../../test-utils/utils_comFunc');
const {FileEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {createFileEvidenceAsync, searchFileEvidenceAsync, deleteFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {Assert} = require('@rootcloud/darjeeling');
const {verifySchemaAsync} = require('../../../test-verify/verify');
const {fileEvidenceSchemaIntoArrays, fileEvidencePersistSchemaIntoArrays} = require('../../../test-schema/Solution/Evidence/evidence');
const {getUserId} = require('../../../test-function/NetworkManager/userFunction');
const {TIDESOL} = require('../../../test-lib/errorMessage');
const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {getToken} = require('../../../test-utils/util_token');

describe(`/test: GET /api/v1/file`, function () {
    let evidenceIdStore = [];
    let createNum = 51; //单skip时默认limit=20，所以这里要用20以上的数量
    let limitDefault = 20;
    let userId = 'defaultId';
    describe('T0:setUp_createFileEvidence', function () {
        it('setUp_createFileEvidence', async () => {
            let rspPromiseStore = [];
            let rsp;
            let fileEvidenceObjSecret = new FileEvidenceObj({
                isPublic: false
            });
            let fileEvidenceObjLargeSize = new FileEvidenceObj({
                fileSize: 2048
            });
            for (let x = 0; x < createNum; x++) {
                if (x < createNum / 2) {
                    rsp = await createFileEvidenceAsync(fileEvidenceObjSecret, baasOrg01);
                    rspPromiseStore.push(rsp);
                } else {
                    rsp = await createFileEvidenceAsync(fileEvidenceObjLargeSize, baasOrg01);
                    rspPromiseStore.push(rsp);
                }
            }

            let responses = await Promise.all(rspPromiseStore);
            for (let rsp of responses) {
                Assert.deepEqual(rsp.statusCode, 201, 'code is not 201');
                evidenceIdStore.push(getRspValue(rsp.body, 'evidenceId'));
            }
            let token = await getToken(baasOrg01);
            userId = await getUserId(token);
        }).timeout(180 * 1000);
    });

    describe('T0:C2414122: all filterParams search fileEvidences', function () {
        let rsp;
        let skip = 10;
        let limit = 5;
        let sort = 'createdAt,desc';
        let includeBlockInfo = true;
        it('code 200 校验 ', async function () {
            let queryString = `createdBy=${userId}&skip=${skip}&limit=${limit}&sort=${sort}&includeBlockInfo=${includeBlockInfo}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`默认查询数量${limit}校验(总数${createNum}以上)`, function () {
            let exceptedNum = createNum >= skip + limit ? limit : createNum - skip;
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
        it(`evidenceId 排序校验`, function () {
            let actualResults = getRspValue(rsp.body, 'results');
            let exceptedResults = resultsSort(actualResults, ['createdAt,desc']);
            Assert.deepEqual(actualResults, exceptedResults, `createdAtSort error`);
        });
        it('schema 校验 ', async function () {
            await verifySchemaAsync(rsp, fileEvidenceSchemaIntoArrays, false);
        });
    });

    describe('T0:C2414123: default filter search ', function () {
        let rsp;
        it('code 200 校验 ', async function () {
            rsp = await searchFileEvidenceAsync({tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it('默认查询数量20校验', function () {
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, 20, 'results size not eq 20');
        });
    });

    describe('T1:C2414124: filterParams type error', function () {
        let rsp;
        let skip = 'a';
        it('code TIDESOL-91002 校验 ', async function () {
            let queryString = `skip=${skip}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(getRspValue(rsp.body, 'code'), TIDESOL.ParamsIllegalError.errorCode, 'code TIDESOL-91002 校验 fail');
        });
    });

    //bug:includeBlockInfo http://jira2.rootcloud.com:8080/browse/BCP-1722
    describe('T1:C2414125: results max num is 20 while searching includeBlockInfo', function () {
        let rsp;
        let limit = 21;
        let includeBlockInfo = true;
        it('code 200 校验 ', async function () {
            let queryString = `limit=${limit}&includeBlockInfo=${includeBlockInfo}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code 200 校验');
        }).timeout(15 * 1000);
        it('includeBlockInfo时limit最大返回20', function () {
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, 20, 'results size not eq 20');
        });
    });

    describe('T1:C2414126: limit max num is 50', function () {
        let rsp;
        let limit = 51;
        it('code 200 校验 ', async function () {
            let queryString = `limit=${limit}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code 200 校验');
        });
        it('limit max num is 50', function () {
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, 50, 'results size not eq 50');
        });
    });

    describe('T1:C2662331: query evidence(type error: startTime and endTime)', function () {
        let startTime = 'typeError01';
        let endTime = 'typeError02';
        it('check query response(startTime)', async function () {
            let queryString = `startTime=${startTime}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(endTime)', async function () {
            let queryString = `endTime=${endTime}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2662332: query evidence(parameter null: dataHash and title)', function () {
        let dataHash = '';
        let title = '';
        it('check query response(dataHash)', async function () {
            let queryString = `dataHash=${dataHash}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(title)', async function () {
            let queryString = `title=${title}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2662333: query evidence(parameter length limit exceeded:labels and title)', function () {
        let labels = randomString({length: 33});
        let title = randomString({length: 65});
        it('check query response(labels)', async function () {
            let queryString = `labels=${labels}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(title)', async function () {
            let queryString = `title=${title}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2662334: query evidence(parameter is special character: evidenceId and referenceId)', function () {
        let evidenceId = '~!@#$^&*()_+=-';
        let referenceId = '~!@#$^&*()_+=-';
        it('check query response(evidenceId)', async function () {
            let queryString = `evidenceId=${evidenceId}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
        it('check query response(referenceId)', async function () {
            let queryString = `referenceId=${referenceId}`;
            let rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            let rspQueryBody = JSON.parse(rspQuery.body);
            Assert.deepEqual(rspQuery.statusCode, 422);
            Assert.deepEqual(rspQueryBody.code, TIDESOL.ParamsIllegalError.errorCode, 'check status code');
        });
    });

    describe('T1:C2414128: createdBy filterParams', function () {
        let rsp;
        it('code 200 校验 ', async function () {
            let queryString = `createdBy=${userId}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code 200 校验');
        });
        it(`all results belong to ${userId}`, function () {
            let numsAfterFilte = getRspValue(rsp.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) > -1;
                }
            ).length;
            Assert.deepEqual(numsAfterFilte, 20, `results is not all belongs to ${userId}`);
        });
    });

    describe('T1:C2414129: skip < 20  filterParams', function () {
        let rsp;
        let skip = 5;
        let limit = limitDefault;
        it('code 200 校验 ', async function () {
            let queryString = `&skip=${skip}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`skip ${skip}  查询数量${limit}校验(总数${createNum}以上)`, function () {
            let exceptedNum = createNum >= skip + limit ? limit : createNum - skip;
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
    });

    describe('T1:C2414130: limit < 20  filterParams', function () {
        let rsp;
        let skip = 0;
        let limit = 10;
        it('code 200 校验 ', async function () {
            let queryString = `limit=${limit}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`skip ${skip} 查询数量${limit}校验(总数${createNum}以上)`, function () {
            let exceptedNum = createNum >= skip + limit ? limit : createNum - skip;
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
    });

    describe('T1:C2414132-1: evidenceId sort', function () {
        let rsp;
        let evidenceIdSort = 'evidenceId';
        it('code 200 校验 ', async function () {
            let queryString = `sort=${evidenceIdSort}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`evidenceId 排序校验`, function () {
            let actualResults = getRspValue(rsp.body, 'results');
            let exceptedResults = resultsSort(actualResults, [evidenceIdSort]);
            Assert.deepEqual(actualResults, exceptedResults, `evidenceIdSort error`);
        });

    });

    describe('T1:C2414132-2: evidenceId desc sort', function () {
        let rsp;
        let evidenceIdSort = 'evidenceId,desc';
        it('code 200 校验 ', async function () {
            let queryString = `sort=${evidenceIdSort}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`evidenceId 排序校验`, function () {
            let actualResults = getRspValue(rsp.body, 'results');
            let exceptedResults = resultsSort(actualResults, [evidenceIdSort]);
            Assert.deepEqual(actualResults, exceptedResults, `evidenceIdDescSort error`);
        });

    });

    describe('T1:C2414132-3: fileName sort', function () {
        let rsp;
        let fileNameSort = 'fileName';
        it('code 200 校验 ', async function () {
            let queryString = `sort=${fileNameSort}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`fileName 排序校验`, function () {
            let actualResults = getRspValue(rsp.body, 'results');
            let exceptedResults = resultsSort(actualResults, [fileNameSort]);
            Assert.deepEqual(actualResults, exceptedResults, `fileNameSort error`);
        });

    });

    describe('T1:C2414132-3: fileName desc sort', function () {
        let rsp;
        let fileNameSort = 'fileName,desc';
        it('code 200 校验 ', async function () {
            let queryString = `sort=${fileNameSort}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`fileName 排序校验`, function () {
            let actualResults = getRspValue(rsp.body, 'results');
            let exceptedResults = resultsSort(actualResults, [fileNameSort]);
            Assert.deepEqual(actualResults, exceptedResults, `fileNameDescSort error`);
        });
    });

    describe('T1:C2658091: query evidence(single: labels)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new FileEvidenceObj({labels: [randomString({length: 5})], isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `labels=${evidenceReqBody['labels'][0]}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check labels result', function () {
            let labelsResults = getRspValue(rspQuery.body, 'results');
            let labelsFilterLen = labelsResults.filter(
                result => {
                    return result.labels.indexOf(evidenceReqBody['labels'][0]) !== -1;
                }
            ).length;
            Assert.deepEqual(labelsResults.length, labelsFilterLen, `all result have same labels field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658092: query evidence(single: dataHash)', function () {
        let evidenceId;
        let rspQuery;
        let dataHash;
        let evidenceReqBody = new FileEvidenceObj({content: randomString({length: 20}), isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            dataHash = getRspValue(rspCreate.body, 'dataHash');
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `dataHash=${dataHash}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});

            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check dataHash result', function () {
            let dataHashResults = getRspValue(rspQuery.body, 'results');
            let dataHashFilterLen = dataHashResults.filter(
                result => {
                    return result.dataHash === dataHash;
                }
            ).length;
            Assert.deepEqual(dataHashResults.length, dataHashFilterLen, `all result have same dataHash field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658093: query evidence(single: evidenceId)', function () {
        let evidenceId;
        let rspQuery;
        let evidenceReqBody = new FileEvidenceObj({isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `evidenceId=${evidenceId}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});

            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check evidenceId result', function () {
            let evidenceIdResults = getRspValue(rspQuery.body, 'results');
            let evidenceIdFilterLen = evidenceIdResults.filter(
                result => {
                    return result.evidenceId === evidenceId;
                }
            ).length;
            Assert.deepEqual(evidenceIdResults.length, evidenceIdFilterLen, `all result have evidenceId field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658094: query evidence(single: title)', function () {
        let evidenceId;
        let rspQuery;
        let titleRand = randomString({length: 5});
        let evidenceReqBody = new FileEvidenceObj({title: titleRand, isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `title=${titleRand}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});

            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check title result', function () {
            let titleResults = getRspValue(rspQuery.body, 'results');
            let titleFilterLen = titleResults.filter(
                result => {
                    return result.title === titleRand;
                }
            ).length;
            Assert.deepEqual(titleResults.length, titleFilterLen, `all result have same title field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658095: query evidence(single: referenceId)', function () {
        let evidenceId;
        let rspQuery;
        let referenceIdRand = randomString({length: 8});
        let evidenceReqBody = new FileEvidenceObj({referenceId: referenceIdRand, isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `referenceId=${referenceIdRand}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});

            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check referenceId result', function () {
            let referenceIdResults = getRspValue(rspQuery.body, 'results');
            let referenceIdFilterLen = referenceIdResults.filter(
                result => {
                    return result.referenceId === referenceIdRand;
                }
            ).length;
            Assert.deepEqual(referenceIdResults.length, referenceIdFilterLen, `all result have same title field`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658096: query evidence(single: startTime)', function () {
        let evidenceId;
        let rspQuery;
        let startTime;
        let evidenceReqBody = new FileEvidenceObj({isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            startTime = getRspValue(rspCreate.body, 'createdAt');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `startTime=${startTime}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check startTime result', function () {
            let startTimeResults = getRspValue(rspQuery.body, 'results');
            let startTimeFilterLen = startTimeResults.filter(
                result => {
                    return result.createdAt >= startTime;
                }
            ).length;
            Assert.deepEqual(startTimeResults.length, startTimeFilterLen, `all result after startTime`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658097: query evidence(single: endTime)', function () {
        let evidenceId;
        let endTime;
        let rspQuery;
        let evidenceReqBody = new FileEvidenceObj({isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            endTime = getRspValue(rspCreate.body, 'createdAt');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `endTime=${endTime}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check endTime result', function () {
            let endTimeResults = getRspValue(rspQuery.body, 'results');
            let endTimeFilterLen = endTimeResults.filter(
                result => {
                    return result.createdAt <= endTime;
                }
            ).length;
            Assert.deepEqual(endTimeResults.length, endTimeFilterLen, `all result after startTime`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658216: query evidence(single: fileName)', function () {
        let evidenceId;
        let rspQuery;
        let fileNameRand = randomString({length: 5});
        let evidenceReqBody = new FileEvidenceObj({fileName: fileNameRand, isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `fileName=${fileNameRand}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check endTime result', function () {
            let fileNameResults = getRspValue(rspQuery.body, 'results');
            let fileNameFilterLen = fileNameResults.filter(
                result => {
                    return result.fileName <= fileNameRand;
                }
            ).length;
            Assert.deepEqual(fileNameResults.length, fileNameFilterLen, `all result after startTime`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C3777071: query evidence(single: isPublic)', function () {
        let rsp;
        it('code 200 校验 ', async function () {
            let queryString = `limit=50&isPublic=false&createdBy=${userId}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it('check isPublic result', function () {
            let Results = getRspValue(rsp.body, 'results');
            let isPublicFilterLen = Results.filter(
                result => {
                    return result.isPublic <= false;
                }
            ).length;
            Assert.deepEqual(Results.length, isPublicFilterLen, `all result after startTime`);
        });
        it('check count', function () {
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, 26, 'results size not eq 26');
        });
    });

    describe('T1:C2658098: query evidence(double: title & labels)', function () {
        let evidenceId;
        let rspQuery;
        let titleRand = randomString({length: 5});
        let labelsRand = randomString({length: 6});
        let evidenceReqBody = new FileEvidenceObj({title: titleRand, labels: [labelsRand], isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `title=${titleRand}&labels=${labelsRand}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check title & labels result', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.title === titleRand && result.labels.indexOf(labelsRand) !== -1;
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check title and labels search resullt`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658099: query evidence(double: dataHash & evidenceId)', function () {
        let evidenceId;
        let dataHash;
        let rspQuery;
        let evidenceReqBody = new FileEvidenceObj({isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            dataHash = getRspValue(rspCreate.body, 'dataHash');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `evidenceId=${evidenceId}&dataHash=${dataHash}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check dataHash & evidenceId result', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.dataHash === dataHash && result.evidenceId === evidenceId;
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check dataHash and evidenceId search result`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658100: query evidence(double: startTime & endTime)', function () {
        let evidenceId;
        let rspQuery;
        let startTime;
        let endTime;
        let evidenceReqBody = new FileEvidenceObj({isPublic: false});
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            startTime = getRspValue(rspCreate.body, 'createdAt');
            endTime = startTime;
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `startTime=${startTime}&endTime=${endTime}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check startTime & endTime result', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.createdAt >= startTime && result.createdAt <= endTime;
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check startTime and endTime search result`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2658101: query evidence(double: fileName & referenceId)', function () {
        let evidenceId;
        let rspQuery;
        let fileNameRand = randomString({length: 8});
        let referenceIdRand = randomString({length: 6});
        let evidenceReqBody = new FileEvidenceObj({
            fileName: fileNameRand,
            referenceId: referenceIdRand,
            isPublic: false
        });
        it('create text evidence', async function () {
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            evidenceId = getRspValue(rspCreate.body, 'evidenceId');
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('check query response status', async function () {
            let queryString = `fileName=${fileNameRand}&referenceId=${referenceIdRand}`;
            rspQuery = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rspQuery.statusCode, 200);
        });
        it('check title & referenceId referenceId', function () {
            let results = getRspValue(rspQuery.body, 'results');
            let filterResultsLen = results.filter(
                result => {
                    return result.fileName === fileNameRand && result.referenceId === referenceIdRand;
                }
            ).length;
            Assert.deepEqual(results.length, filterResultsLen, `check title and referenceId search result`);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });


    //bug:includeBlockInfo http://jira2.rootcloud.com:8080/browse/BCP-1722
    describe('T1:C2414133: createdBy and includeBlockInfo filterParams', function () {
        let rsp;
        let includeBlockInfo = true;
        it('code 200 校验 ', async function () {
            let queryString = `createdBy=${userId}&includeBlockInfo=${includeBlockInfo}&persist=false`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code 200 校验');
        }).timeout(15 * 1000);
        it(`all results belong to ${userId}`, function () {
            let numsAfterFilter = getRspValue(rsp.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) > -1;
                }
            ).length;
            Assert.deepEqual(numsAfterFilter, 20, `results is not all belongs to ${userId}`);
        });
        it('schema 校验 ', async function () {
            await verifySchemaAsync(rsp, fileEvidencePersistSchemaIntoArrays, false);
        });
    });

    describe('T1:C2414134: skip and limit  filterParams', function () {
        let rsp;
        let skip = 15;
        let limit = 15;
        it('code 200 校验 ', async function () {
            let queryString = `&skip=${skip}&limit=${limit}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code is not 200');
        });
        it(`skip ${skip}  查询数量${limit}校验(总数${createNum}以上)`, function () {
            let exceptedNum = createNum >= (skip + limit) ? limit : (createNum - skip);
            Assert.deepEqual(getRspValue(rsp.body, 'results').length, exceptedNum, `results size not eq ${exceptedNum}`);
        });
    });

    describe('T1:C2414135: createdBy and sort filterParams', function () {
        let rsp;
        let fileSizeSort = 'fileSize,desc';
        it('code 200 校验 ', async function () {
            let queryString = `createdBy=${userId}&sort=${fileSizeSort}`;
            rsp = await searchFileEvidenceAsync({queryString: queryString, tokenOrUserData: baasOrg01});
            Assert.deepEqual(rsp.statusCode, 200, 'code 200 校验');
        });
        it(`all results belong to ${userId}`, function () {
            let numsAfterFilter = getRspValue(rsp.body, 'results').filter(
                result => {
                    return result.createdBy.indexOf(userId) > -1;
                }
            ).length;
            Assert.deepEqual(numsAfterFilter, 20, `results is not all belongs to ${userId}`);
        });
        it(`fileSize 排序校验`, function () {
            let actualResults = getRspValue(rsp.body, 'results');
            let exceptedResults = resultsSort(actualResults, [fileSizeSort]);
            Assert.deepEqual(actualResults, exceptedResults, `fileSizeDescSort error`);
        });
    });

    describe('T0:setDown_clearFileEvidence', function () {
        it('setDown_clearFileEvidence', async () => {
            let delResp_promise;
            let delResp_promiseStore = [];
            for (let evidenceId of evidenceIdStore) {
                delResp_promise = deleteFileEvidenceByIdAsync(evidenceId, baasOrg01);
                delResp_promiseStore.push(delResp_promise);
            }
            let delResps = await Promise.all(delResp_promiseStore);
            for (let delResp of delResps) {
                Assert.deepEqual(delResp.statusCode, 204, 'code is not 204');
            }
        });
    });
});