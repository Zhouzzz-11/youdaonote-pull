//FileEvidence Solution -create file evidence and upload & download -POST-/api/v1/solution/evidence/file
//BCP-854
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2881802
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2883165
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2883164

'use strict';

const path = require('path');
const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {getFileName, getFileSize, getFileHash, getFileMd5, readFile, uploadFileAsync, downloadFileAsync, createFileEvidenceAsync, getFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {FileEvidenceUploadSchema, FileEvidenceDownloadTrueSchema, FileEvidenceDownloadFalseSchema} = require('../../../test-schema/Solution/Evidence/evidence');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');

describe(`/test: POST /api/v1/file & upload file`, function () {
    describe('T0:C2881802: create file evidence & upload file & getDownloadUrl & download file', function () {
        let filePath = path.join(__dirname, '../../../.env');
        let fileContent;
        let fileName;
        let fileSize;
        let fileHash;
        let fileMd5;
        let bodyCreate;
        let rspCreate;
        let rspGet;
        let bodyGet;
        let uploadUrl;
        let downloadUrl;
        let evidenceReqBody = new FileEvidenceObj({persist: true});
        it('create evidence and check response ', async function () {
            fileName = getFileName(filePath);
            fileSize = getFileSize(filePath);
            fileHash = getFileHash(filePath);
            evidenceReqBody.fileName = fileName;
            evidenceReqBody.fileSize = fileSize;
            evidenceReqBody.fileHash = fileHash;
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            uploadUrl = bodyCreate.uploadUrl;
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceUploadSchema);
        });
        it('C2883165-1: get evidence and check response (includeDownloadUrl=true)', async function () {
            let queryString = 'includeDownloadUrl=true';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            bodyGet = JSON.parse(rspGet.body);
            Assert.deepEqual(rspGet.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyGet, FileEvidenceDownloadFalseSchema);
        });
        it('C2883165-2: get evidence and check response (includeDownloadUrl=false)', async function () {
            let queryString = 'includeDownloadUrl=false';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            bodyGet = JSON.parse(rspGet.body);
            Assert.deepEqual(rspGet.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyGet, FileEvidenceDownloadFalseSchema);
        });
        it('upload file to bucket', async function () {
            fileContent = readFile(filePath);
            fileMd5 = getFileMd5(filePath);
            let rspUpload = await uploadFileAsync(uploadUrl, fileContent, fileMd5);
            Assert.deepEqual(rspUpload.statusCode, 200, 'check status code');
        }).timeout(20 * 1000);
        it('C2883164: get evidence and check response (includeDownloadUrl=false)', async function () {
            let queryString = 'includeDownloadUrl=false';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            bodyGet = JSON.parse(rspGet.body);
            Assert.deepEqual(rspGet.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyGet, FileEvidenceDownloadFalseSchema);
        });
        it('get evidence and check response(includeDownloadUrl=true) ', async function () {
            let queryString = 'includeDownloadUrl=true';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            bodyGet = JSON.parse(rspGet.body);
            downloadUrl = bodyGet.downloadUrl;
            Assert.deepEqual(rspGet.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyGet, FileEvidenceDownloadTrueSchema);
        });
        it('download file', async function () {
            fileContent = readFile(filePath);
            fileMd5 = getFileMd5(filePath);
            let rspDownload = await downloadFileAsync(downloadUrl);
            let bodyDownload = rspDownload.body;
            Assert.deepEqual(rspDownload.statusCode, 200, 'check status code');
            Assert.deepEqual(bodyDownload, fileContent.toString(), 'check file content');
        }).timeout(20 * 1000);
    });
});