//Solution-DELETE-/api/v1/solution/evidence/file/{evidenceId}
//BCP-432 
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=224488

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {TIDE, TIDESOL} = require('../../../test-lib/errorMessage');
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');


describe(`/test: DELETE  /api/v1/file/{evidenceId}`, function () {

    describe('T0:C2414109: delete by evidenceId', function () {
        let respCreate;
        let bodyCreate;
        var evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create evidence ', async function () {
            respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        }).timeout(25 * 1000);
        it('test', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C2414110: Required item verification(null evidenceId)', function () {
        it('test', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync('', baasOrg01);
            let body = JSON.parse(rspDelete.body);
            Assert.deepEqual(rspDelete.statusCode, 422);
            Assert.deepEqual(body.code, TIDESOL.ParamsIllegalError.errorCode);
        });
    });

    describe('T1:C2414111: evidenceId is not exist', function () {
        it('test', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync('evidenceId_test_not_exist', baasOrg01);
            let body = JSON.parse(rspDelete.body);
            Assert.deepEqual(rspDelete.statusCode, 404);
            Assert.deepEqual(body.code, TIDE.MscNotExistError.errorCode);
        });
    });

    describe('T1:C2414121: delete other user evidence', function () {
        let respCreate;
        let bodyCreate;
        var evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create evidence ', async function () {
            respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        }).timeout(25 * 1000);
        it('test', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg02);
            let body = JSON.parse(rspDelete.body);
            Assert.deepEqual(rspDelete.statusCode, 400);
            Assert.deepEqual(body.code, TIDE.MscUnCategorizedError.errorCode);
        });
    });
});

