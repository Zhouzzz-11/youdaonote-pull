//FileEvidence Solution -get file evidence-GET-/api/v1/solution/evidence/file/{evidenceId}
//BCP-431
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414140
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414141
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414143
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414144
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414145

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg01} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {TIDE,TIDESOL} = require('../../../test-lib/errorMessage');
const {createFileEvidenceAsync, updateFileEvidenceByIdAsync,deleteFileEvidenceByIdAsync, getFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {historySchemafirstItem,historySchemaRemainItems,FileEvidenceNonFirstUpdateIncludeHistorySchema,FileEvidenceIncludeHistoryBlockInfoQuerySchema,FileEvidenceSchema, FileEvidenceIncludeHistorySchema,FileEvidenceIncludeBlockInfoQuerySchema} = require('../../../test-schema/Solution/Evidence/evidence');
const {verifyObjectPayloadSync,verifyPayloadSync,verifyObjectSchemaAsync,verifySchemaAsync} = require('../../../test-verify/verify');

describe(`/test: GET /api/v1/file/{evidenceId}`, function () {
    describe('T0:C2414140: get file evidence(with evidenceId)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceSchema);
        }).timeout(25 * 1000);
        it('get evidence and check response ', async function () {
            rspCreate = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceSchema);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T0:C2414141: get file evidence(includeBlockInfo=true)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceSchema);
        });
        it('get evidence and check response ', async function () {
            rspCreate = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: 'includeBlockInfo=true'});
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 200, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceIncludeBlockInfoQuerySchema);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2414143: get file evidence(file evidence not exist)', function () {
        let rspCreate;
        it('get evidence and check response ', async function () {
            rspCreate = await getFileEvidenceByIdAsync('test_non_exist', baasOrg01);
            Assert.deepEqual(rspCreate.statusCode, 404, 'check status code');
        });
    });

    describe('T1:C2414144: get file evidence(evidencdId contains special characters)', function () {
        let rspCreate;
        it('get evidence and check response ', async function () {
            rspCreate = await getFileEvidenceByIdAsync(encodeURI('!@#$%^&*()'), baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C2414145: get file evidence(evidencdId is null)', function () {
        let rspCreate;
        it('get evidence and check response ', async function () {
            rspCreate = await getFileEvidenceByIdAsync(encodeURI(''), baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check status code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C3104365: get single file evidence(non-includeHistory or includeHistory:false)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('get single file evidence(non-includeHistory)', async function () {
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceSchema, false);
        });
        it('get single file evidence(includeHistory:false)', async function () {
            let queryString = 'includeHistory=false';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceSchema, false);
        });
        it('After-steps: delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104366: get single file evidence(steps:create,get include history)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('get single file evidence(includeHistory:true)', async function () {
            let queryString = 'includeHistory=true';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            let historyBody = JSON.parse(rspGet.body);
            let historyArray = historyBody.history;
            let createHistory = historyArray[0];
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceIncludeHistorySchema, false);
            await verifyObjectSchemaAsync(createHistory, historySchemafirstItem);
        });
        it('After-steps: delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104367: get single file evidence(steps:create,update labels,get include history)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('update evidence labels ', async function () {
            let updateEvidenceReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ]
            };
            let respCreate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateEvidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('get single file evidence(includeHistory:true)', async function () {
            let queryString = 'includeHistory=true';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            let historyBody = JSON.parse(rspGet.body);
            let historyArray = historyBody.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceNonFirstUpdateIncludeHistorySchema, false);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });
        it('After-steps: delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104368: get single file evidence(steps:create,update metadata,get include history)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('update evidence metadata ', async function () {
            let updateEvidenceReqBody = {
                'metadata': {
                    'key': 'value5'
                }
            };
            let respCreate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateEvidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('get single file evidence(includeHistory:true)', async function () {
            let queryString = 'includeHistory=true';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            let historyBody = JSON.parse(rspGet.body);
            let historyArray = historyBody.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceNonFirstUpdateIncludeHistorySchema, false);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });
        it('After-steps: delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104369: get single file evidence(steps:create,update labels and metadata,get include history)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('update evidence metadata ', async function () {
            let updateEvidenceReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ],
                'metadata': {
                    'key': 'value5'
                }
            };
            let respCreate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateEvidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 200);
        });
        it('get single file evidence(includeHistory:true)', async function () {
            let queryString = 'includeHistory=true';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            let historyBody = JSON.parse(rspGet.body);
            let historyArray = historyBody.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceNonFirstUpdateIncludeHistorySchema, false);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });
        it('After-steps: delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104370: get single file evidence(steps:create,update labels,update metadata,update labels and metadata,get include history)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('update evidence metadata ', async function () {
            let updateEvidenceLabelsReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ]
            };
            let updateEvidenceMetadataReqBody = {
                'metadata': {
                    'key': 'value5'
                }
            };
            let updateEvidenceBothReqBody = {
                'labels': [
                    'test_3',
                    'test_4'
                ],
                'metadata': {
                    'key': 'value5'
                }
            };
            let respLabels = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateEvidenceLabelsReqBody, baasOrg01);
            let respMetadata = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateEvidenceMetadataReqBody, baasOrg01);
            let respBoth = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateEvidenceBothReqBody, baasOrg01);
            Assert.deepEqual(respLabels.statusCode, 200);
            Assert.deepEqual(respMetadata.statusCode, 200);
            Assert.deepEqual(respBoth.statusCode, 200);
        });
        it('get single file evidence(includeHistory:true)', async function () {
            let queryString = 'includeHistory=true';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            let historyBody = JSON.parse(rspGet.body);
            let historyArray = historyBody.history;
            let updateHistoryArray = historyArray.slice(1);
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceNonFirstUpdateIncludeHistorySchema, false);
            await verifyObjectSchemaAsync(updateHistoryArray, historySchemaRemainItems);
        });
        it('After-steps: delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104371: get single file evidence(steps:create,delete,get include history)', function () {
        let bodyCreate;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
        it('get single file evidence(includeHistory:true)', async function () {
            let queryString = 'includeHistory=true';
            let rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 404);
            verifyPayloadSync(rspGet, TIDE.MscNotExistError.errorCode, 'code');
        });
    });

    describe('T1:C3104372: get single file evidence(steps:create,get include history and include blockinfo)', function () {
        let bodyCreate;
        let rspGet;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });

        it('get single file evidence(includeHistory:true&includeBlockInfo:true)', async function () {
            let queryString = 'includeHistory=true&includeBlockInfo=true';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 200);
            await verifySchemaAsync(rspGet, FileEvidenceIncludeHistoryBlockInfoQuerySchema, false);
        });
        it('check labels,metadata,blockinfo', async function () {
            let bodyGet = JSON.parse(rspGet.body);
            let labels = bodyGet.labels;
            let metadata = bodyGet.metadata;
            let blockInfo = bodyGet.blockInfo;
            let historyArray = bodyGet.history;
            let lastItem = historyArray.slice(-1);
            await verifyObjectPayloadSync(labels, lastItem.labels);
            await verifyObjectPayloadSync(metadata, lastItem.metadata);
            await verifyObjectPayloadSync(blockInfo, lastItem.blockInfo);
        });
        it('delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C3104373: get single file evidence(includeHistory:string or number,includeBlockInfo:string or number)', function () {
        let bodyCreate;
        let rspGet;
        it('Pre-steps: create file evidence ', async function () {
            let evidenceReqBody = new FileEvidenceObj();
            let respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        });
        it('get single file evidence(includeBlockInfo:sting)', async function () {
            let queryString = 'includeBlockInfo=test';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 422);
            verifyPayloadSync(rspGet, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('get single file evidence(includeBlockInfo:number)', async function () {
            let queryString = 'includeBlockInfo=123';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 422);
            verifyPayloadSync(rspGet, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('get single file evidence(includeHistory:sting)', async function () {
            let queryString = 'includeHistory=test';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 422);
            verifyPayloadSync(rspGet, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('get single file evidence(includeHistory:number)', async function () {
            let queryString = 'includeHistory=123';
            rspGet = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: queryString});
            Assert.deepEqual(rspGet.statusCode, 422);
            verifyPayloadSync(rspGet, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
        it('delete file evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });
});