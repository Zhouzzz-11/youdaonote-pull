//Solution-patch-/api/v1/solution/evidence/file/{evidenceId}
//BCP-432 
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/suites/view/722&group_by=cases:section_id&group_order=asc&group_id=224487

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {createFileEvidenceAsync, updateFileEvidenceByIdAsync, deleteFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');   //Function used in script should required from test-function
const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data');
const {updateFileEvidenceData_1, updateFileEvidenceData_2, updateFileEvidenceData_3} = require('../../../test-data/Solution/Evidence/evidenceData');
const {verifySchemaAsync, verifyPayloadSync} = require('../../../test-verify/verify');
const {FileEvidenceSchema, FileEvidenceNonFirstUpdateIncludeBlockInfoSchema} = require('../../../test-schema/Solution/Evidence/evidence');
const {TIDE, TIDESOL} = require('../../../test-lib/errorMessage');


describe(`/test: PATCH  /api/v1/file/{evidenceId}`, function () {

    let respCreate;
    let bodyCreate;
    describe('T0:C2414103: update by evidenceId', function () {
        var evidenceReqBody = new FileEvidenceObj();
        it('Pre-steps: create evidence ', async function () {
            respCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(respCreate.body);
            Assert.deepEqual(respCreate.statusCode, 201);
        }).timeout(25 * 1000);
        it('test', async function () {
            let rspUpdate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateFileEvidenceData_1, baasOrg01);
            Assert.deepEqual(rspUpdate.statusCode, 200);
            await verifySchemaAsync(rspUpdate, FileEvidenceSchema, false);
        });
    });

    describe('T0:C2414104: update by evidenceId and include blockinfo', function () {
        it('test', async function () {
            let rspUpdate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateFileEvidenceData_2, baasOrg01, {queryString: 'includeBlockInfo=true'});
            Assert.deepEqual(rspUpdate.statusCode, 200);
            await verifySchemaAsync(rspUpdate, FileEvidenceNonFirstUpdateIncludeBlockInfoSchema, false);
        });
    });

    describe('T1:C2414105: update with null labels ', function () {
        it('test', async function () {
            let rspUpdate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateFileEvidenceData_3, baasOrg01);
            Assert.deepEqual(rspUpdate.statusCode, 422);
            verifyPayloadSync(rspUpdate, TIDESOL.ParamsIllegalError.errorCode, 'code');
        });
    });

    describe('T1:C2414106: update with not exist id ', function () {
        it('test', async function () {
            let rspUpdate = await updateFileEvidenceByIdAsync('evidenceId_test_not_exist', updateFileEvidenceData_1, baasOrg01);
            let rspUpdateBody = JSON.parse(rspUpdate.body);
            Assert.deepEqual(rspUpdate.statusCode, 404);
            Assert.deepEqual(rspUpdateBody.code, TIDE.MscNotExistError.errorCode, 'check error code');
        });
    });

    describe('T1:C2414138: update other user evidence', function () {
        it('test', async function () {
            let rspUpdate = await updateFileEvidenceByIdAsync(bodyCreate.evidenceId, updateFileEvidenceData_1, baasOrg02);
            let body = JSON.parse(rspUpdate.body);
            Assert.deepEqual(rspUpdate.statusCode, 400);
            Assert.deepEqual(body.code, TIDE.MscUnCategorizedError.errorCode);
        }).timeout(25 * 1000);
    });

    describe(' T0:delete ', function () {
        it('After-steps: delete test data', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });
});

