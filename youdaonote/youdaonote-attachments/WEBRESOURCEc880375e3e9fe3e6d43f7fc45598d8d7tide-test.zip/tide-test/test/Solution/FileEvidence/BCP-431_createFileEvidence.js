//FileEvidence Solution -create file evidence-POST-/api/v1/solution/evidence/file
//BCP-431
//TestRail链接：http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414083
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414084
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414085
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414225
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414086
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414087
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414088
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414095
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414096
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414090
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414091
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414219
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414092
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414093
//             http://testrail.irootechapp.com/testrail/index.php?/cases/view/2414094

'use strict';

const {Assert} = require('@rootcloud/darjeeling'); // The main darjeeling lib MUST be required in your root test, even if not using the DataStore.
const {FileEvidenceObj} = require('../../../test-data/Solution/Evidence/evidenceData');
const {baasOrg01, baasOrg02} = require('../../../test-data/NetworkManager/BCP-60_auth_login_data'); //Choose user rc_tide_2811.
const {TIDESOL} = require('../../../test-lib/errorMessage');
const {createFileEvidenceAsync, deleteFileEvidenceByIdAsync, getFileEvidenceByIdAsync} = require('../../../test-function/Solution/Evidence/fileEvidenceFunction');
const {FileEvidenceSchema, FileEvidenceIncludeBlockInfoSchema, FileEvidenceUseTrustedTimestampSchema} = require('../../../test-schema/Solution/Evidence/evidence');
const {verifyObjectSchemaAsync} = require('../../../test-verify/verify');
const {randomString} = require('../../../test-utils/utils_comFunc');

describe(`/test: POST /api/v1/file`, function () {
    let labelsBegin = 1;
    let labelsEnd = 32;
    let referenceIdBegin = 1;
    let referenceIdEnd = 64;
    let fileSizeBegin = 1;
    let fileSizeEnd = 52428800;
    describe('T0:C2414083: create file evidence', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceSchema);
        }).timeout(25 * 1000);
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T0:C2414084: create file evidence(includeBlockInfo=true)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01, 'includeBlockInfo=true');
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceIncludeBlockInfoSchema);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T0:C2414085: create file evidence(useTrustedTimestamp=true)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj({useTrustedTimestamp:true});
        it('create evidence and check response ', async function () {
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceUseTrustedTimestampSchema);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2414225: create file evidence(repeat create)', function () {
        let rspCreate1;
        let rspCreate2;
        let bodyCreate1;
        let bodyCreate2;
        let evidenceReqBody1 = new FileEvidenceObj();
        let evidenceReqBody2 = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            rspCreate1 = await createFileEvidenceAsync(evidenceReqBody1, baasOrg01);
            bodyCreate1 = JSON.parse(rspCreate1.body);
            Assert.deepEqual(rspCreate1.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate1, FileEvidenceSchema);
        });
        it('create evidence and check response(duplicate) ', async function () {
            rspCreate2 = await createFileEvidenceAsync(evidenceReqBody2, baasOrg01);
            bodyCreate2 = JSON.parse(rspCreate2.body);
            Assert.deepEqual(rspCreate2.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreate2, FileEvidenceSchema);
        });
        it('delete evidence', async function () {
            let rspDelete1 = await deleteFileEvidenceByIdAsync(bodyCreate1.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete1.statusCode, 204, 'check status code');
            let rspDelete2 = await deleteFileEvidenceByIdAsync(bodyCreate2.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete2.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2414086: create file evidence(missing required field)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBodyTitle = new FileEvidenceObj();
        let evidenceReqBodyFileName = new FileEvidenceObj();
        let evidenceReqBodyFileSize = new FileEvidenceObj();
        let evidenceReqBodyFileHash = new FileEvidenceObj();
        it('create evidence and check response(missing title) ', async function () {
            delete evidenceReqBodyTitle['title'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyTitle, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it('create evidence and check response(missing fileName) ', async function () {
            delete evidenceReqBodyFileName['fileName'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyFileName, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it('create evidence and check response(missing fileSize) ', async function () {
            delete evidenceReqBodyFileSize['fileSize'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyFileSize, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it('create evidence and check response(missing fileHash) ', async function () {
            delete evidenceReqBodyFileHash['fileHash'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyFileHash, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });

    });

    describe('T1:C2414087: create file evidence(missing optional field)', function () {
        let rspCreate;
        let bodyCreateReferenceId;
        let bodyCreateLabels;
        let bodyCreateIsPublic;
        let bodyCreatePersist;
        let evidenceReqBodyReferenceId = new FileEvidenceObj();
        let evidenceReqBodyLabels = new FileEvidenceObj();
        let evidenceReqBodyIsPublic = new FileEvidenceObj();
        let evidenceReqBodyPersist = new FileEvidenceObj();
        it('create evidence and check response(missing referenceId) ', async function () {
            delete evidenceReqBodyReferenceId['referenceId'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyReferenceId, baasOrg01);
            bodyCreateReferenceId = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('create evidence and check response(missing labels) ', async function () {
            delete evidenceReqBodyLabels['labels'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyLabels, baasOrg01);
            bodyCreateLabels = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
        });
        it('create evidence and check response(missing isPublic)', async function () {
            delete evidenceReqBodyIsPublic['isPublic'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyIsPublic, baasOrg01);
            bodyCreateIsPublic = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateIsPublic, FileEvidenceSchema);
        });
        it('create evidence and check response(missing persist) ', async function () {
            delete evidenceReqBodyPersist['persist'];
            rspCreate = await createFileEvidenceAsync(evidenceReqBodyPersist, baasOrg01);
            bodyCreatePersist = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201, 'check http response code');
            await verifyObjectSchemaAsync(bodyCreatePersist, FileEvidenceSchema);
        });
        it('delete evidence', async function () {
            let rspDeleteReferenceId = await deleteFileEvidenceByIdAsync(bodyCreateReferenceId.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteReferenceId.statusCode, 204, 'check status code');
            let rspDeleteLabels = await deleteFileEvidenceByIdAsync(bodyCreateLabels.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteLabels.statusCode, 204, 'check status code');
            let rspDeleteIsPublic = await deleteFileEvidenceByIdAsync(bodyCreateIsPublic.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteIsPublic.statusCode, 204, 'check status code');
            let rspDeleteIsPersist = await deleteFileEvidenceByIdAsync(bodyCreatePersist.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteIsPersist.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2414088: create file evidence(labels empty)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            evidenceReqBody['labels'] = [];
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
    });

    describe('T1:C2414095: create file evidence(fileName Special characters)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            evidenceReqBody['fileName'] = '\\/:*?"<>|.pdf';
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check special fileName');
        });
    });

    describe('T1:C2414096: create file evidence(wrong field type)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            evidenceReqBody['labels'] = 'labels';
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
    });

    describe(`T1:C2414090: create file evidence(labels length range ${labelsBegin}~${labelsEnd})`, function () {
        let bodyCreateBegin;
        let bodyCreateMiddle;
        let bodyCreateEnd;
        let evidenceReqBody = new FileEvidenceObj();
        let evidenceReqBodyBegin = new FileEvidenceObj();
        let evidenceReqBodyMiddle = new FileEvidenceObj();
        let evidenceReqBodyEnd = new FileEvidenceObj();
        it(`create evidence and check response(labels length:${labelsBegin-1})`, async function () {
            evidenceReqBody['labels'] = [''];
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it(`create evidence and check response(labels length:${labelsBegin})`, async function () {
            evidenceReqBodyBegin['labels'] = [randomString({length: labelsBegin})];
            let rspCreateBegin = await createFileEvidenceAsync(evidenceReqBodyBegin, baasOrg01);
            bodyCreateBegin = JSON.parse(rspCreateBegin.body);
            Assert.deepEqual(rspCreateBegin.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateBegin, FileEvidenceSchema);
        });
        it(`create evidence and check response(labels length:${labelsEnd/2})`, async function () {
            evidenceReqBodyMiddle['labels'] = [randomString({length: labelsEnd/2})];
            let rspCreateMiddle = await createFileEvidenceAsync(evidenceReqBodyMiddle, baasOrg01);
            bodyCreateMiddle = JSON.parse(rspCreateMiddle.body);
            Assert.deepEqual(rspCreateMiddle.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateMiddle, FileEvidenceSchema);
        });
        it(`create evidence and check response(labels length:${labelsEnd})`, async function () {
            evidenceReqBodyEnd['labels'] = [randomString({length: labelsEnd})];
            let rspCreateEnd = await createFileEvidenceAsync(evidenceReqBodyEnd, baasOrg01);
            bodyCreateEnd = JSON.parse(rspCreateEnd.body);
            Assert.deepEqual(rspCreateEnd.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateEnd, FileEvidenceSchema);
        });
        it(`create evidence and check response(labels length:${labelsEnd+1})`, async function () {
            evidenceReqBody['labels'] = [randomString({length: labelsEnd+1})];
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it('delete evidence', async function () {
            let rspDeleteBegin = await deleteFileEvidenceByIdAsync(bodyCreateBegin.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteBegin.statusCode, 204, 'check status code');
            let rspDeleteMiddle = await deleteFileEvidenceByIdAsync(bodyCreateMiddle.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteMiddle.statusCode, 204, 'check status code');
            let rspDeleteEnd = await deleteFileEvidenceByIdAsync(bodyCreateEnd.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteEnd.statusCode, 204, 'check status code');
        });
    });

    describe(`T1:C2414091: create file evidence(referenceId length range ${referenceIdBegin}~${referenceIdEnd})`, function () {
        let bodyCreateBegin;
        let bodyCreateMiddle;
        let bodyCreateEnd;
        let evidenceReqBody = new FileEvidenceObj();
        let evidenceReqBodyBegin = new FileEvidenceObj();
        let evidenceReqBodyMiddle = new FileEvidenceObj();
        let evidenceReqBodyEnd = new FileEvidenceObj();
        it(`create evidence and check response(referenceId length:${referenceIdBegin-1})`, async function () {
            evidenceReqBody['referenceId'] = '';
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it(`create evidence and check response(referenceId length:${referenceIdBegin})`, async function () {
            evidenceReqBodyBegin['referenceId'] = randomString({length: referenceIdBegin});
            let rspCreateBegin = await createFileEvidenceAsync(evidenceReqBodyBegin, baasOrg01);
            bodyCreateBegin = JSON.parse(rspCreateBegin.body);
            Assert.deepEqual(rspCreateBegin.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateBegin, FileEvidenceSchema);
        });
        it(`create evidence and check response(referenceId length:${referenceIdEnd/2})`, async function () {
            evidenceReqBodyMiddle['referenceId'] = randomString({length: referenceIdEnd/2});
            let rspCreateMiddle = await createFileEvidenceAsync(evidenceReqBodyMiddle, baasOrg01);
            bodyCreateMiddle = JSON.parse(rspCreateMiddle.body);
            Assert.deepEqual(rspCreateMiddle.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateMiddle, FileEvidenceSchema);
        });
        it(`create evidence and check response(referenceId length:${referenceIdEnd})`, async function () {
            evidenceReqBodyEnd['referenceId'] = randomString({length: referenceIdEnd});
            let rspCreateEnd = await createFileEvidenceAsync(evidenceReqBodyMiddle, baasOrg01);
            bodyCreateEnd = JSON.parse(rspCreateEnd.body);
            Assert.deepEqual(rspCreateEnd.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateEnd, FileEvidenceSchema);
        });
        it(`create evidence and check response(referenceId length:${referenceIdEnd+1})`, async function () {
            evidenceReqBody['referenceId'] = randomString({length: referenceIdEnd+1});
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it('delete evidence', async function () {
            let rspDeleteBegin = await deleteFileEvidenceByIdAsync(bodyCreateBegin.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteBegin.statusCode, 204, 'check status code');
            let rspDeleteMiddle = await deleteFileEvidenceByIdAsync(bodyCreateMiddle.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteMiddle.statusCode, 204, 'check status code');
            let rspDeleteEnd = await deleteFileEvidenceByIdAsync(bodyCreateEnd.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteEnd.statusCode, 204, 'check status code');
        });
    });

    describe(`T1:C2414219: create file evidence(fizeSize length range ${fileSizeBegin}~${fileSizeEnd})`, function () {
        let bodyCreateBegin;
        let bodyCreateMiddle;
        let bodyCreateEnd;
        let evidenceReqBody = new FileEvidenceObj();
        let evidenceReqBodyBegin = new FileEvidenceObj();
        let evidenceReqBodyMiddle = new FileEvidenceObj();
        let evidenceReqBodyEnd = new FileEvidenceObj();
        it(`create evidence and check response(fileSize length:${fileSizeBegin-1})`, async function () {
            evidenceReqBody['fileSize'] = 0;
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it(`create evidence and check response(fileSize length:${fileSizeBegin})`, async function () {
            evidenceReqBodyBegin['fileSize'] = fileSizeBegin;
            let rspCreateBegin = await createFileEvidenceAsync(evidenceReqBodyBegin, baasOrg01);
            bodyCreateBegin = JSON.parse(rspCreateBegin.body);
            Assert.deepEqual(rspCreateBegin.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateBegin, FileEvidenceSchema);
        });
        it(`create evidence and check response(fileSize length:${fileSizeEnd/2})`, async function () {
            evidenceReqBodyMiddle['fileSize'] = fileSizeEnd/2;
            let rspCreateMiddle = await createFileEvidenceAsync(evidenceReqBodyMiddle, baasOrg01);
            bodyCreateMiddle = JSON.parse(rspCreateMiddle.body);
            Assert.deepEqual(rspCreateMiddle.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateMiddle, FileEvidenceSchema);
        });
        it(`create evidence and check response(fileSize length:${fileSizeEnd})`, async function () {
            evidenceReqBodyEnd['fileSize'] = fileSizeEnd;
            let rspCreateEnd = await createFileEvidenceAsync(evidenceReqBodyEnd, baasOrg01);
            bodyCreateEnd = JSON.parse(rspCreateEnd.body);
            Assert.deepEqual(rspCreateEnd.statusCode, 201, 'check status code');
            await verifyObjectSchemaAsync(bodyCreateEnd, FileEvidenceSchema);
        });
        it(`create evidence and check response(fileSize length:${fileSizeEnd+1})`, async function () {
            evidenceReqBody['fileSize'] = fileSizeEnd+1;
            let rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            let bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check customized error code');
        });
        it('delete evidence', async function () {
            let rspDeleteBegin = await deleteFileEvidenceByIdAsync(bodyCreateBegin.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteBegin.statusCode, 204, 'check status code');
            let rspDeleteMiddle = await deleteFileEvidenceByIdAsync(bodyCreateMiddle.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteMiddle.statusCode, 204, 'check status code');
            let rspDeleteEnd = await deleteFileEvidenceByIdAsync(bodyCreateEnd.evidenceId, baasOrg01);
            Assert.deepEqual(rspDeleteEnd.statusCode, 204, 'check status code');
        });
    });

    describe('T1:C2414092: create evidence(isPublic is true)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence ', async function () {
            evidenceReqBody['isPublic'] = true;
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceSchema);
        });
        it('query evindencde using other user', async function () {
            let rspQuery = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg02, {queryString: 'useTrustedTimestamp=true'});
            Assert.deepEqual(rspQuery.statusCode, 200);
            await verifyObjectSchemaAsync(JSON.parse(rspQuery.body), FileEvidenceSchema);
        }).timeout(20 * 1000);
        it('query evindencde using current user', async function () {
            let rspQuery = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: 'useTrustedTimestamp=true'});
            Assert.deepEqual(rspQuery.statusCode, 200);
            await verifyObjectSchemaAsync(JSON.parse(rspQuery.body), FileEvidenceSchema);
        });
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C2414093: create evidence(isPublic is false)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence ', async function () {
            evidenceReqBody['isPublic'] = false;
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 201);
            await verifyObjectSchemaAsync(bodyCreate, FileEvidenceSchema);
        });
        it('query evindencde using current user', async function () {
            let rspQuery = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01, {queryString: 'useTrustedTimestamp=true'});
            Assert.deepEqual(rspQuery.statusCode, 200);
            await verifyObjectSchemaAsync(JSON.parse(rspQuery.body), FileEvidenceSchema);
        });
        it('query evindencde using other user', async function () {
            let rspQuery = await getFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg02, {queryString: 'useTrustedTimestamp=true'});
            Assert.deepEqual(rspQuery.statusCode, 404);
        }).timeout(20 * 1000);
        it('delete evidence', async function () {
            let rspDelete = await deleteFileEvidenceByIdAsync(bodyCreate.evidenceId, baasOrg01);
            Assert.deepEqual(rspDelete.statusCode, 204);
        });
    });

    describe('T1:C2414094: create file evidence(wrong token)', function () {
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('create evidence and check response ', async function () {
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, {'token': 'invalid'});
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 400, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.InvalidTokenError.errorCode, 'check customized error code');
        });
    });

    describe('T1:create file evidence with the blank space params', async function(){
        let rspCreate;
        let bodyCreate;
        let evidenceReqBody = new FileEvidenceObj();
        it('C2897952: title include only blank space', async function () {
            evidenceReqBody['title'] = '     ';
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });
        it('C2897953: labels include only blank space', async function () {
            evidenceReqBody['labels'] = ['     '];
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });
        it('C2899494: fileHash include only blank space', async function () {
            evidenceReqBody['fileHash'] = '     ';
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });
        it('C2990609: fileHash is illegal', async function () {
            evidenceReqBody['fileHash'] = 'wrong_format';
            rspCreate = await createFileEvidenceAsync(evidenceReqBody, baasOrg01);
            bodyCreate = JSON.parse(rspCreate.body);
            Assert.deepEqual(rspCreate.statusCode, 422, 'check http response code');
            Assert.deepEqual(bodyCreate.code, TIDESOL.ParamsIllegalError.errorCode, 'check error code');
        });
    });
});