'use strict';

const Joi = require('@hapi/joi');

// Overrides the handling of unknown keys for the scope of the current object only (does not apply to children) where:
// allow - if false, unknown keys are not allowed, otherwise unknown keys are ignored.
const createAppSchema = Joi.object({
    id: Joi.string().required(),
    channelCode: Joi.string().required()
}).unknown(false);


module.exports = {
    createAppSchema
};