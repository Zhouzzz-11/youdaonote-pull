'use strict';

const Joi = require('@hapi/joi');

// Overrides the handling of unknown keys for the scope of the current object only (does not apply to children) where:
// allow - if false, unknown keys are not allowed, otherwise unknown keys are ignored.
const createConsortiaSchema = Joi.object({
    id: Joi.string().required(),
    networkCode: Joi.string().required()
}).unknown(false);

const consortiaOrg = Joi.object({
    id: Joi.string().required(),
    name: Joi.string().required(),
    adminName: Joi.string().required(),
    mobile: Joi.string().required(),
    email: Joi.string().email().required(),
    joinedAt: Joi.any(),
    stateCode: Joi.string().required(),
    adminFlag: Joi.boolean().required()
}).unknown(false);

const consortiaInfo = Joi.object({
    id: Joi.string().required(),
    displayName: Joi.string().required(),
    networkCode: Joi.string().required(),
    joinedOrgNum: Joi.number().required(),
    createdBy: Joi.string().required(),
    createdByName: Joi.string().required(),
    createdAt: Joi.number().required(),
    joinedAt: null,
    stateCode: Joi.string().required(),
    createdByOrgId: Joi.string().required(),
    createdByOrgName: Joi.string().required(),
    description: Joi.string().required(),
    resourceState: Joi.string().required()
}).unknown(false);

const consortiaBasicInfoSchema = Joi.object({
    apps: Joi.array().items().required(),
    orgs: Joi.array().items(consortiaOrg).required()
}).unknown(false);

const invitedOrgInfoSchema = Joi.object({
    inviteLimit: Joi.any(),
    orgNames: Joi.array().items(Joi.string()).required(),
    inviterOrgName: Joi.string().required(),
    inviterName: Joi.string().required(),
    inviterMobile: Joi.string().required(),
    inviteAt: Joi.number().required(),
    reason: Joi.string().required()
});

const queryCurrentUserConsortiaInfoSchema = Joi.object({
    code: Joi.any(),
    message: Joi.any(),
    payload: Joi.array().items(consortiaInfo).required(),
    httpStatus: Joi.number().required(),
    success: Joi.any(),
    statusCode: Joi.number().required()
});



module.exports = {
    createConsortiaSchema,
    consortiaBasicInfoSchema,
    invitedOrgInfoSchema,
    queryCurrentUserConsortiaInfoSchema
};