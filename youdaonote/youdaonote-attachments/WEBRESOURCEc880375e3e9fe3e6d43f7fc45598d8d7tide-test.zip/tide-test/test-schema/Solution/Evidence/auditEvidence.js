'use strict';

const Joi = require('@hapi/joi');

let auditDataEvidenceFunc = function ({
    dataForm = false,
    data = false
} = {}) {
    let innerObj = {
        evidenceId: Joi.string().required(),
        type: Joi.string().required(),
        labels: Joi.array(),
        comments: Joi.string(),
        referenceId: Joi.string(),
        signature: Joi.string(),
        isPublic: Joi.boolean().required(),
        dataHash: Joi.string().required(),
        submittedAt: Joi.string().required(),
        title: Joi.string().required(),
        createdBy: Joi.string().required(),
        createdAt: Joi.string().required(),
        metadata: Joi.object(),
        blockInfo: Joi.object({
            height: Joi.number().required(),
            blockHash: Joi.string().required()
        }).required(),
        source: Joi.object({
            service: Joi.string().required(),
            component: Joi.string().required()
        }).required(),
        info: Joi.object({
            operateObject: Joi.string().required(),
            operateTime: Joi.string().required(),
            operator: Joi.string().required(),
            ipAddress: Joi.string().required()
        }),
        companyName: Joi.string().required()
    };
    if (dataForm) {
        innerObj.logId = Joi.string().required()
    }
    if (data) {
        innerObj.data = Joi.object().required()
    }
    let outObj = {
        success: Joi.boolean().required(),
        response: Joi.object(innerObj).required()
    };
    return Joi.array().items(outObj);
};

let verifyAuditEvidenceFunc = function ({
    dataForm = false,
    source = false,
    diff = false
} = {}) {
    let innerObj = {
        evidenceId: Joi.string().required(),
        identical: Joi.boolean().required(),
        target: Joi.object().required()
    };
    if (dataForm) {
        innerObj.logId = Joi.string().required()
    }
    if (source) {
        innerObj.source = Joi.object().required()
    }
    if (diff) {
        innerObj.diff = Joi.array().required()
    }
    let outObj = {
        success: Joi.boolean().required(),
        response: Joi.object(innerObj).required()
    }
    return Joi.array().items(outObj);
}

//上链
const auditEvidenceCreateSchema = auditDataEvidenceFunc({data: true});
const auditEvidenceCreateHashSchema = auditDataEvidenceFunc({dataForm: true});
const auditEvidenceCreateRawSchema = auditDataEvidenceFunc({dataForm: true, data: true});

//验真
const auditEvidenceVerifySchema = verifyAuditEvidenceFunc({source: true}); //dataForm=null时，验证通过
const auditEvidenceVerifyHashSchema = verifyAuditEvidenceFunc({dataForm: true});  //dataForm=hash时，验证通过/失败
const auditEvidenceVerifyRawSchema = verifyAuditEvidenceFunc({dataForm: true, source: true});  //dataForm=raw时，验证通过
const auditEvidenceVerifyFSchema = verifyAuditEvidenceFunc({source: true, diff: true});  //dataForm=null时，验证失败
const auditEvidenceVerifyRawFSchema = verifyAuditEvidenceFunc({dataForm: true,  source: true, diff: true});  //dataForm=raw时，验证失败


module.exports = {
    auditDataEvidenceFunc,
    verifyAuditEvidenceFunc,
    auditEvidenceCreateSchema,
    auditEvidenceCreateHashSchema,
    auditEvidenceCreateRawSchema,
    auditEvidenceVerifySchema,
    auditEvidenceVerifyHashSchema,
    auditEvidenceVerifyRawSchema,
    auditEvidenceVerifyFSchema,
    auditEvidenceVerifyRawFSchema
}

