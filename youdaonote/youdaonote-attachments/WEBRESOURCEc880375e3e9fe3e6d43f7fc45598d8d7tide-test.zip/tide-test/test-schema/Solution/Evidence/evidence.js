'use strict';

const Joi = require('@hapi/joi');

let pageMetaDataSchema = Joi.object({
    limit: Joi.number().required(),
    skip: Joi.number().required()
}).required();

let blockInfoSchema = Joi.object({
    height: Joi.number().required(),
    blockHash: Joi.string().required()
}).required();
let historySchema = Joi.array().items(
    Joi.object({
        metadata: Joi.object().required(),
        labels: Joi.array().items(Joi.string().required()).required(),
        updatedBy: Joi.string(),
        updatedAt: Joi.string(),
        blockInfo: blockInfoSchema
    })
).required();
let historySchemafirstItem = Joi.object({
    metadata: Joi.object().required(),
    labels: Joi.array().items(Joi.string().required()),
    blockInfo: blockInfoSchema
});
let historySchemaRemainItems = Joi.array().items(
    Joi.object({
        metadata: Joi.object().required(),
        labels: Joi.array().items(Joi.string().required()),
        updatedBy: Joi.string().required(),
        updatedAt: Joi.string().required(),
        blockInfo: blockInfoSchema
    })
).required();
let trustedTimestamp = Joi.object({
    trustedTime: Joi.string().required(),
    algorithm: Joi.string().required(),
    timestampHash: Joi.string().required()
}).required();

let ossFileInfo = Joi.object({
    fileId: Joi.any(),
    objectKey: Joi.string().required(),
    bucketName: Joi.string().required()
}).required();

let getUploadUrlSchema = Joi.object({
    uploadUrl: Joi.string().required()
});


let evidenceFunc = function ({
    includeBlockInfo = false,
    includeHistory = false,
    useTrustedTimestamp = false,
    nonFirstUpdate = false,
    ignoreUpdate = false,
    fileEvidence = false,
    content = false,
    persist = false,
    uploadUrl = false,
    downloadUrl = false
} = {}) {
    let obj = {
        evidenceId: Joi.string().required(),
        type: Joi.string().required(),
        dataHash: Joi.string().required(),
        labels: Joi.array(),
        submittedAt: Joi.string().required(),
        isPublic: Joi.boolean(),
        metadata: Joi.object(),
        signature: Joi.string(),
        comments: Joi.string(),
        title: Joi.string().required(),
        createdBy: Joi.string().required(),
        referenceId: Joi.string(),
        createdAt: Joi.string().required(),
    };
    if (includeBlockInfo) {
        obj.blockInfo = blockInfoSchema;
    }
    if (includeHistory) {
        obj.history = historySchema;
    }
    if (useTrustedTimestamp) {
        obj.trustedTimestamp = trustedTimestamp;
    }
    if (nonFirstUpdate) {
        obj.updatedAt = Joi.string().required();
        obj.updatedBy = Joi.string().required();
    }
    if (ignoreUpdate) {
        obj.updatedAt = Joi.string();
        obj.updatedBy = Joi.string();
    }
    if (fileEvidence) {
        obj.fileName = Joi.string().required();
        obj.fileSize = Joi.number().required();
        obj.persist = Joi.boolean();
    }
    if (content) {
        obj.content = Joi.string().required();
    }
    if (persist) {
        obj.ossFileInfo = ossFileInfo;
    }
    if (uploadUrl) {
        obj.uploadUrl = Joi.string().required();
    }
    if (downloadUrl) {
        obj.downloadUrl = Joi.string().required();
    }
    return Joi.object(obj);
};

//TextEvidence
const evidenceSchema = evidenceFunc({content: true});
const evidenceIgnoreUpdateSchema = evidenceFunc({content: true, ignoreUpdate: true});
const evidenceIncludeBlockInfoSchema = evidenceFunc({includeBlockInfo: true, content: true});
const evidenceUseTrustedTimestampSchema = evidenceFunc({useTrustedTimestamp: true, content: true});
const evidenceQuerySchema = evidenceFunc({content: true});
const evidenceIncludeHistoryQuerySchema = evidenceFunc({content: true, includeHistory: true});
const evidenceIncludeHistoryBlockInfoQuerySchema = evidenceFunc({
    content: true,
    includeHistory: true,
    includeBlockInfo: true
});
const evidenceIncludeBlockInfoQuerySchema = evidenceFunc({includeBlockInfo: true, content: true});
const evidenceIncludeBlockInfoIgnoreUpdateQuerySchema = evidenceFunc({
    includeBlockInfo: true,
    content: true,
    ignoreUpdate: true
});
const evidenceUseTrustedTimestampQuerySchema = evidenceFunc({useTrustedTimestamp: true, content: true});
const evidenceNonFirstUpdateSchema = evidenceFunc({nonFirstUpdate: true, content: true});
const evidenceNonFirstUpdateIncludeBlockInfoSchema = evidenceFunc({
    includeBlockInfo: true,
    nonFirstUpdate: true,
    content: true
});
const evidenceNonFirstUpdateIncludeHistorySchema = evidenceFunc({
    nonFirstUpdate: true,
    content: true,
    includeHistory: true
});
let textEvidenceSchemaIntoArrays = Joi.object(
    {
        results: Joi.array().items(evidenceIncludeBlockInfoQuerySchema).required(),
        total: Joi.number().required(),
        pageMetadata: pageMetaDataSchema,
    }
);
let textEvidenceIgnoreUpdateSchemaIntoArrays = Joi.object(
    {
        results: Joi.array().items(evidenceIncludeBlockInfoIgnoreUpdateQuerySchema).required(),
        total: Joi.number().required(),
        pageMetadata: Joi.object().required(),
    }
);
let textEvidenceSchemaIntoArrays_default = Joi.object(
    {
        results: Joi.array().items(evidenceSchema).required(),
        total: Joi.number().required(),
        pageMetadata: pageMetaDataSchema,
    }
);
let textEvidenceSchemaIgnoreUpdateIntoArrays_default = Joi.object(
    {
        results: Joi.array().items(evidenceIgnoreUpdateSchema).required(),
        total: Joi.number().required(),
        pageMetadata: pageMetaDataSchema,
    }
);

//FileEvidence
const FileEvidenceSchema = evidenceFunc({fileEvidence: true});
const FileEvidenceIncludeHistorySchema = evidenceFunc({fileEvidence: true, includeHistory: true});
const FileEvidenceIncludeBlockInfoSchema = evidenceFunc({fileEvidence: true, includeBlockInfo: true});
const FileEvidenceIncludeHistoryBlockInfoQuerySchema = evidenceFunc({
    fileEvidence: true,
    includeHistory: true,
    includeBlockInfo: true
});
const FileEvidenceUseTrustedTimestampSchema = evidenceFunc({fileEvidence: true, useTrustedTimestamp: true});
const FileEvidenceIncludeBlockInfoQuerySchema = evidenceFunc({
    fileEvidence: true,
    includeBlockInfo: true
});
const FileEvidenceIncludeBlockInfoPersistQuerySchema = evidenceFunc({
    fileEvidence: true,
    includeBlockInfo: true
});
const FileEvidenceNonFirstUpdateSchema = evidenceFunc({fileEvidence: true, nonFirstUpdate: true});
const FileEvidenceNonFirstUpdateIncludeBlockInfoSchema = evidenceFunc({
    fileEvidence: true,
    includeBlockInfo: true,
    nonFirstUpdate: true
});
const FileEvidenceNonFirstUpdateIncludeHistorySchema = evidenceFunc({
    fileEvidence: true,
    nonFirstUpdate: true,
    includeHistory: true
});
const FileEvidenceUploadSchema = evidenceFunc({fileEvidence: true, persist: true, uploadUrl: true});
const FileEvidenceDownloadTrueSchema = evidenceFunc({fileEvidence: true, persist: true, downloadUrl: true});
const FileEvidenceDownloadFalseSchema = evidenceFunc({fileEvidence: true, persist: true});

let fileEvidenceSchemaIntoArrays = Joi.object(
    {
        results: Joi.array().items(FileEvidenceIncludeBlockInfoQuerySchema).required(),
        total: Joi.number().required(),
        pageMetadata: pageMetaDataSchema,
    }
);

let fileEvidencePersistSchemaIntoArrays = Joi.object(
    {
        results: Joi.array().items(FileEvidenceIncludeBlockInfoPersistQuerySchema).required(),
        total: Joi.number().required(),
        pageMetadata: pageMetaDataSchema,
    }
);

let fileEvidenceSchemaIntoArrays_default = Joi.object(
    {
        results: Joi.array().items(FileEvidenceSchema).required(),
        total: Joi.number().required(),
        pageMetadata: pageMetaDataSchema,
    }
);

let evidenceTotalDetailSchema = Joi.object(
    {
        text: Joi.number().required(),
        file: Joi.number().required()
    }
);

let evidenceTotalNumSchema = Joi.object(
    {
        total: Joi.number().required(),
        detail: evidenceTotalDetailSchema
    }
);


module.exports = {
    evidenceFunc,
    evidenceSchema,
    historySchema,
    trustedTimestamp,
    ossFileInfo,
    historySchemafirstItem,
    historySchemaRemainItems,
    evidenceIncludeBlockInfoSchema,
    evidenceIncludeHistoryQuerySchema,
    evidenceIncludeHistoryBlockInfoQuerySchema,
    evidenceNonFirstUpdateIncludeHistorySchema,
    evidenceUseTrustedTimestampSchema,
    evidenceQuerySchema,
    evidenceIncludeBlockInfoQuerySchema,
    evidenceUseTrustedTimestampQuerySchema,
    evidenceNonFirstUpdateSchema,
    evidenceNonFirstUpdateIncludeBlockInfoSchema,
    textEvidenceSchemaIgnoreUpdateIntoArrays_default,
    textEvidenceSchemaIntoArrays,
    textEvidenceSchemaIntoArrays_default,
    textEvidenceIgnoreUpdateSchemaIntoArrays,
    fileEvidencePersistSchemaIntoArrays,
    FileEvidenceSchema,
    FileEvidenceIncludeHistorySchema,
    FileEvidenceIncludeBlockInfoSchema,
    FileEvidenceIncludeHistoryBlockInfoQuerySchema,
    FileEvidenceUseTrustedTimestampSchema,
    FileEvidenceIncludeBlockInfoQuerySchema,
    FileEvidenceNonFirstUpdateSchema,
    FileEvidenceNonFirstUpdateIncludeBlockInfoSchema,
    FileEvidenceNonFirstUpdateIncludeHistorySchema,
    fileEvidenceSchemaIntoArrays,
    fileEvidenceSchemaIntoArrays_default,
    FileEvidenceUploadSchema,
    FileEvidenceDownloadTrueSchema,
    FileEvidenceDownloadFalseSchema,
    getUploadUrlSchema,
    evidenceTotalNumSchema,
};