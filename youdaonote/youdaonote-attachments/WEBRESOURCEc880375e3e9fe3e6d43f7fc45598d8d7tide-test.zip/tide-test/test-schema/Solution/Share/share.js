'use strict';

const Joi = require('@hapi/joi');
const {historySchema, trustedTimestamp, ossFileInfo} = require('../Evidence/evidence');

let shareCode = {
    shareId: Joi.string().required(),
    evidenceId: Joi.string().required(),
    evidenceType: Joi.string().required(),
    includeOriginal: Joi.boolean().required(),
    includeHistory: Joi.boolean().required(),
    code: Joi.string().required(),
    createdAt: Joi.string().required(),
    expiresAfter: Joi.number().required(),
    shareType: Joi.string().required(),
    createdBy: Joi.string().required(),
    expiresAt: Joi.string().required()
};

let shareCodeSchema = Joi.object(shareCode).unknown(false);

let shareEvidenceFunc = function ({
    shareObj = false,
    recordListObj = false,
    recordObj = false,
    fileEvidence = false,
    content = false,
    oss_File_Info = false,
    downloadUrl = false,
    includeHistory = false,
    labels = false,
    useTrustedTimestamp = false,
    isPublic = false,
    comments = false
} = {}) {
    let innerObj = {
        evidenceId: Joi.string().required(),
        type: Joi.string().required(),
        dataHash: Joi.string().required(),
        submittedAt: Joi.string().required(),
        signature: Joi.string(),
        title: Joi.string().required(),
        referenceId: Joi.string(),
        createdBy: Joi.string().required(),
        createdAt: Joi.string().required(),
        updatedAt: Joi.string(),
        updatedBy: Joi.string(),
        metadata: Joi.object().required(),
        blockInfo: Joi.object({
            height: Joi.number().required(),
            blockHash: Joi.string().required()
        }).required(),
    };
    if (fileEvidence) {
        innerObj.fileName = Joi.string().required();
        innerObj.fileSize = Joi.number().required();
        innerObj.persist = Joi.boolean().required();
    }
    if (content) {
        innerObj.content = Joi.string().required();
    }
    if (oss_File_Info) {
        innerObj.ossFileInfo = ossFileInfo;
    }
    if (downloadUrl) {
        innerObj.downloadUrl = Joi.string().required();
    }
    if (includeHistory) {
        innerObj.history = historySchema;
    }
    if (labels) {
        innerObj.labels = Joi.array().required();
    }
    if (useTrustedTimestamp) {
        innerObj.trustedTimestamp = trustedTimestamp;
    }
    if (isPublic) {
        innerObj.isPublic = Joi.boolean().required();
    }
    if (comments) {
        innerObj.comments = Joi.string().required();
    }
    let outsideObj_share = {
        evidence: Joi.object(innerObj).required(),
        shareInfo: Joi.object({
            includeOriginal: Joi.boolean().required(),
            includeHistory: Joi.boolean().required(),
            shareType: Joi.string().required(),
            createdAt: Joi.string().required()
        }).required()
    };
    let outsideObj_record = {
        ...shareCode,
        shareType: Joi.string().required(),
        createdBy: Joi.string().required(),
        expiresAt: Joi.string().required(),
        shareId: Joi.string().required(),
        evidence: Joi.object(innerObj).required()
    };
    let outsideObj_recordList = {
        results: Joi.array().items(outsideObj_record).required(),
        total: Joi.number().required(),
        pageMetadata: Joi.object({
            limit: Joi.number().required(),
            skip: Joi.number().required()
        }).required()
      };
    if (shareObj){
        return Joi.object(outsideObj_share);
    }
    if (recordListObj){
        return Joi.object(outsideObj_recordList);
    }
    if (recordObj){
        return Joi.object(outsideObj_record);
    }
};

let recordListFileSchema = shareEvidenceFunc({recordListObj: true, fileEvidence: true, labels: true, isPublic: true, comments: true});//fileEvidence,includeOriginal:false,includeHistory:false
let recordListTextSchema = shareEvidenceFunc({recordListObj: true, labels: true, isPublic: true, comments: true});//textEvidence,includeOriginal:false,includeHistory:false
let recordListTextOriginalSchema = shareEvidenceFunc({recordListObj: true, content: true, labels: true, isPublic: true, comments: true});//textEvidence,includeOriginal:true,includeHistory:false
let recordListFileHistorySchema = shareEvidenceFunc({recordListObj: true, fileEvidence: true, labels: true, isPublic: true, comments: true, includeHistory: true});//fileEvidence,includeOriginal:false,includeHistory:true
let recordListTextHistorySchema = shareEvidenceFunc({recordListObj: true, labels: true, isPublic: true, comments: true, includeHistory: true});//textEvidence,includeOriginal:false,includeHistory:true
let recordListTextOriginalHistorySchema = shareEvidenceFunc({recordListObj: true, content: true, labels: true, isPublic: true, comments: true, includeHistory: true});//textEvidence,includeOriginal:true,includeHistory:true

let recordFileSchema = shareEvidenceFunc({recordObj: true, fileEvidence: true, labels: true, isPublic: true, comments: true});//fileEvidence,includeOriginal:false,includeHistory:false
let recordTextOriginalSchema = shareEvidenceFunc({recordObj: true, content: true, labels: true, isPublic: true, comments: true});//textEvidence,includeOriginal:true,includeHistory:false
let recordFileHistorySchema = shareEvidenceFunc({recordObj: true, fileEvidence: true, labels: true, isPublic: true, comments: true, includeHistory: true});//fileEvidence,includeOriginal:false,includeHistory:true
let recordFileOriginalHistorySchema = shareEvidenceFunc({recordObj: true, fileEvidence: true, labels: true, isPublic: true, comments: true, oss_File_Info: true, includeHistory: true});//fileEvidence,includeOriginal:true,includeHistory:true
let recordTextHistorySchema = shareEvidenceFunc({recordObj: true, labels: true, isPublic: true, comments: true, includeHistory: true});//textEvidence,includeOriginal:false,includeHistory:true
let recordTextOriginalHistorySchema = shareEvidenceFunc({recordObj: true, content: true, labels: true, isPublic: true, comments: true, includeHistory: true});//textEvidence,includeOriginal:true,includeHistory:true

const shareTextEvidenceNonOriginalSchema = shareEvidenceFunc({shareObj: true});
const shareTextEvidenceHistorySchema = shareEvidenceFunc({shareObj: true, includeHistory: true});
const shareTextEvidenceOriginalSchema = shareEvidenceFunc({shareObj: true, content: true});
const shareTextEvidenceOriginalHistorySchema = shareEvidenceFunc({shareObj: true, content: true, includeHistory: true});
const shareFileEvidenceSchema = shareEvidenceFunc({shareObj: true, fileEvidence: true});
const shareFileEvidenceOriginalSchema = shareEvidenceFunc({shareObj: true, fileEvidence: true, oss_File_Info: true});
const shareFileEvidenceHistorySchema = shareEvidenceFunc({shareObj: true, fileEvidence: true, includeHistory: true});
const shareFileEvidenceUploadSOriginalSchema = shareEvidenceFunc({
    shareObj: true,
    fileEvidence: true,
    oss_File_Info: true,
    downloadUrl: true
});


module.exports = {
    shareCodeSchema,
    shareTextEvidenceNonOriginalSchema,
    shareTextEvidenceOriginalSchema,
    shareTextEvidenceOriginalHistorySchema,
    shareFileEvidenceSchema,
    shareFileEvidenceOriginalSchema,
    shareFileEvidenceHistorySchema,
    shareFileEvidenceUploadSOriginalSchema,
    shareTextEvidenceHistorySchema,
    recordListFileSchema,
    recordListTextSchema,
    recordListTextOriginalSchema,
    recordListFileHistorySchema,
    recordListTextHistorySchema,
    recordListTextOriginalHistorySchema,
    recordFileSchema,
    recordTextOriginalSchema,
    recordFileHistorySchema,
    recordFileOriginalHistorySchema,
    recordTextHistorySchema,
    recordTextOriginalHistorySchema,
};