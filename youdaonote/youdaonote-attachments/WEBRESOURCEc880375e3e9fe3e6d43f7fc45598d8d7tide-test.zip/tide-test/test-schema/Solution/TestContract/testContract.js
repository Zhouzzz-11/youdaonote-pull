'use strict';

const Joi = require('@hapi/joi');

let resourcesSchema = Joi.object(
    {
        $class: Joi.string().required(),
        owner: Joi.string().required(),
        accountId: Joi.string().required(),
        balance: Joi.string().required(),
        issueBank: Joi.string().required(),
        holderInfo: Joi.object()
    }
);
let assertCreateSchema = Joi.object({
    $class: Joi.string().required(),
    submitter: Joi.string().required(),
    blockHash: Joi.string().required(),
    updateExisting: Joi.boolean(),
    blockNumber: Joi.number().required(),
    resources: Joi.array().items(resourcesSchema).required(),
    targetRegistry: Joi.string().required(),
    transactionId: Joi.string().required(),
    timestamp: Joi.string().required()
});

let queryAssertsSchema = Joi.object({
    $class: Joi.string().required(),
    bookmark: Joi.number().required(),
    blockHash: Joi.string(),
    blockNumber: Joi.number(),
    queryResult: Joi.array().items(resourcesSchema).required(),
    total: Joi.string().required()
});

// payload: {
//     '$class': 'cn.gezhitech.test.integration.asset.BankAccount',
//         owner: 'resource:cn.gezhitech.tidemsc.model.User#Steve',
//         accountId: 'test_20210428_88782189',
//         blockHash: '7fc7196c30e8c4cb7d773a9efafbcb83ae19e6d6a76d6ff7cc6d97e1034a79b9',
//         balance: '0.00',
//         blockNumber: 485,
//         issueBank: 'BANK_OF_CHINA'
// }
let assertCreateByTrasactionSchema = Joi.object({
    $class: Joi.string().required(),
    owner: Joi.string().required(),
    accountId: Joi.string().required(),
    blockHash: Joi.string().required(),
    balance: Joi.string().required(),
    blockNumber: Joi.number().required(),
    issueBank: Joi.string().required()
});

module.exports = {
    assertCreateSchema,
    queryAssertsSchema,
    assertCreateByTrasactionSchema
};