'use strict';

const Joi = require('@hapi/joi');

const activateCompanySchema = Joi.object({
    orgAdmin: Joi.string().required(),
    orgId: Joi.string().required()
}).unknown(false);

const activateUserSchema = Joi.object({
    id: Joi.string().required()
}).unknown(false);

const getCompanySchema = Joi.object({
    id: Joi.string().required(),
    orgName: Joi.string().required(),
    adminName: Joi.string().required(),
    adminDisplayName: Joi.any().required(),
    email: Joi.string().empty(''),
    cellphone: Joi.string().empty(''),
    networkId: Joi.string().required(),
    activeTide: Joi.boolean().required(),
}).unknown(false);

const getEmployeeSchema = Joi.object({
    id: Joi.string().required(),
    username: Joi.string().required(),
    email: Joi.string().required(),
    cellphone: Joi.string().required(),
    displayName: Joi.string().required(),
    permTide: Joi.boolean().required(),
    companyAdmin: Joi.boolean().required(),
    activeTide: Joi.boolean().required()
}).unknown(false);

const getAllEmployeesSchema = Joi.object({
    total: Joi.number().required(),
    results: Joi.array().items(getEmployeeSchema).required(),
}).unknown(false);

const getOrgSchema = Joi.object({
    orgId: Joi.string().required(),
    peerNum: Joi.number().required(),
    orgName: Joi.string().required(),
    ancestorOrgs: Joi.any().required(),
    trustedOrgs: Joi.array().required(),
    orgAdmin: Joi.object({
        id: Joi.string().required(),
        userId: Joi.string().required(),
        userName: Joi.string().required(),
        displayName: Joi.any().required(),
        password: Joi.any().required(),
        networkId: Joi.string().required(),
        channelName: Joi.string().required(),
        orgId: Joi.string().required(),
        identityId: Joi.string().required(),
        privateKey: Joi.string().required(),
        certificate: Joi.string().required(),
        fakeObject: Joi.boolean().required(),
        userRole: Joi.array().required(),
        networks: Joi.array().required(),
        salt: Joi.any().required(),
        digest: Joi.any().required(),
        lastModifiedBy: Joi.string().required(),
        mobile: Joi.any().required(),
        email: Joi.any().required(),
        lastModifiedTime: Joi.number().required(),
        createdTime: Joi.number().required(),
    }).required(),
    mspId: Joi.string().required(),
    cert: Joi.string().required(),
    key: Joi.string().required(),
    orderer: Joi.boolean().required(),
    admin: Joi.boolean().required()
}).unknown(false);

const networkSchema = Joi.object({
    id: Joi.string().required(),
    name: Joi.string().required()
})
const getNetworkSchema = Joi.array().required(networkSchema);


module.exports = {
    activateCompanySchema,
    activateUserSchema,
    getCompanySchema,
    getEmployeeSchema,
    getAllEmployeesSchema,
    getOrgSchema,
    getNetworkSchema,
};