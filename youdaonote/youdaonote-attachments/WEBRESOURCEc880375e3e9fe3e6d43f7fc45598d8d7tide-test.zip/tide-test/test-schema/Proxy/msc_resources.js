'use strict';

const Joi = require('@hapi/joi');

var mscResourcesUserFunc = function (resolve = false) {
    let obj = {
        $class: Joi.string().required(),
        id: Joi.string().required(),
        name: Joi.string().required(),
        roles: Joi.array().required()
    };
    if (resolve) {
        obj.org = Joi.any().required();
    } else {
        obj.org = Joi.string().required();
    }
    return Joi.object(
        obj
    );
};


var postMscResourcesSchemaFunc = function name(classType) {
    let msc_resources_schema;
    let msc_resources;
    switch (classType) {
        case 'User':
            msc_resources = mscResourcesUserFunc;
            break;
        // TODO  need add different classtype
        case 'Role':
            msc_resources = Joi.object({});
            break;
        default:
            msc_resources = Joi.object({});
    }
    msc_resources_schema = Joi.object({
        $class: Joi.string().required(),
        resources: Joi.array().items(mscResourcesUserFunc),
        submitter: Joi.string().required(),
        transactionId: Joi.string().required(),
        timestamp: Joi.string().required()
    });
    return msc_resources_schema;

};
var getMscResourcesUserResolveSchemaFun = function (resolve) {
    return Joi.object({
        bookmark: Joi.string().required(),
        queryResult: Joi.array().items(mscResourcesUserFunc(resolve)),
        total: Joi.string().required()
    });
};
const getMscResourcesUserResolveSchema = getMscResourcesUserResolveSchemaFun(true);
const getMscResourcesUserSchema = getMscResourcesUserResolveSchemaFun();
const getMscResourcesUserByIdSchema = mscResourcesUserFunc();
const postMscResourcesUserSchema = postMscResourcesSchemaFunc('User');

module.exports = {
    postMscResourcesUserSchema,
    getMscResourcesUserByIdSchema,
    getMscResourcesUserResolveSchema,
    getMscResourcesUserSchema
};