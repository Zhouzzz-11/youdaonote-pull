'use strict';

const Joi = require('@hapi/joi');

const invokeSchema = Joi.object({
    //TODO: need to add schema
}).unknown(false);

module.exports = {
    invokeSchema
};