'use strict';

const Joi = require('@hapi/joi');

const provenanceSchema = Joi.array().items(
    Joi.object({
        $class: Joi.string().required(),
        txId: Joi.string().required(),
        value: Joi.object({
            $class: Joi.string().required(),
            name: Joi.string().required(),
            id: Joi.string().required(),
            org: Joi.string().required(),
            roles: Joi.array().required()
        }),
        timestamp: Joi.string(),
        isDelete: Joi.boolean(),
        number: Joi.number(),
        dataHash: Joi.string().required(),
        height: Joi.number(),
        blockHash: Joi.string().required()
    }).unknown(false)
);

module.exports = {
    provenanceSchema
};