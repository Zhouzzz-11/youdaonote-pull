'use strict';

const Joi = require('@hapi/joi');

const blockBrowserSchema = Joi.array().items(
    Joi.object({
        channelID: Joi.string(),
        previousHash: Joi.string(),
        dataHash: Joi.string(),
        blockHash: Joi.string(),
        height: Joi.number().required(),
        transactionCount: Joi.number(),
        $class: Joi.string(),
        timestamp: Joi.string().required()
    }).unknown(false)
);

module.exports = {
    blockBrowserSchema,
};