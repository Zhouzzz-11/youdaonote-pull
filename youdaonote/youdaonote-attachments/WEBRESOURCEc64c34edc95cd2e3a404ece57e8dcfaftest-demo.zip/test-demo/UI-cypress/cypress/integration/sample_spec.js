describe('create evidence', () => {
    it('Login', () => {
      cy.visit('https://console-pre.rootcloudapp.com/login')

      cy.get('#userId').type('superAdmin_1612494355')
      cy.get('#password').type('123321')
      cy.get('[type=submit]').click()
      cy.wait(4000)
      cy.contains('工业区块链').click()
      cy.contains('可信存证').click()
      cy.contains('存证中心').click()
      cy.contains('新建存证').click()
      cy.get('#name').type('TextEvidence')
      cy.get('#content').type('test ui automation')
      cy.get('button[class="ant-btn ant-btn-primary"').click()
      cy.get('button[class="ant-btn"').click()
      //退出登录
      cy.get('#ADMIN').click()
      cy.contains('退出').click()
    });
  })
  