  
//var PLM = JSON.parse(responseBody);
let arr = [];
let arr1 = [];
var i;
APS.map(item=>{
    let obj = {};
    obj.evidenceId = item.response.evidenceId;
    obj.target = dataAPS;
    obj.logId = item.response.logId;
    arr.push(obj);
    if (arr.length>50){
        arr1.push(obj);
    }
});
console.log(JSON.stringify(arr1));
