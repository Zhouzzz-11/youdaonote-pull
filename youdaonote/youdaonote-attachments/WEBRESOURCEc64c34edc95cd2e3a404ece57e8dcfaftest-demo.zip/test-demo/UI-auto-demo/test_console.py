import allure
from selenium import webdriver
import pytest
import yaml
import time

from selenium.webdriver.common.keys import Keys


@allure.testcase('https://console-pre.rootcloudapp.com')
@allure.feature('创建文本存证')
# indirect=True,可以把传过来的参数当做函数来执行
# @pytest.mark.parametrize('data', yaml.safe_load(open("data.yaml", encoding='utf-8')))
@pytest.mark.parametrize('name,psw', [("superAdmin_1612494355", "123321")])
def test_evidence(name, psw):
    with allure.step("打开根云首页"):
        driver = webdriver.Chrome()
        driver.get("https://console-pre.rootcloudapp.com/login")
        driver.maximize_window()

    with allure.step("用户登录"):
        driver.find_element_by_id('userId').send_keys(name)
        time.sleep(1)
        driver.find_element_by_id('password').send_keys(psw)
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="__next"]/div/div/section/div/div/form/div[3]/div/div/span/button') \
            .click()
        time.sleep(2)
    with allure.step("进入工业区块链"):
        # 点击左上角menu
        driver.find_element_by_id('rootcloudHeaderIconAppstore').click()
        time.sleep(3)
        # 点击工业区块链
        driver.find_element_by_xpath(
            '/html/body/div[3]/div/div/div/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[1]').click()
        time.sleep(2)
        # 点击可信存证
        driver.find_element_by_xpath('//*[@id="__next"]/div/section/section/aside/div[1]/span/ul/li[4]/div[1]/'
                                     'span/span').click()
        time.sleep(2)
        # 点击存证中心
        driver.find_element_by_xpath('//*[@id="EVENDICE$Menu"]/li[1]').click()
        # 截图
        driver.save_screenshot("screenshot/" + name + ".png")
        allure.attach.file("screenshot/" + name + ".png")
        time.sleep(4)
    with allure.step("创建存证"):
        # 创建存证
        driver.find_element_by_xpath('//*[@id="search_com"]/div[2]').click()
        driver.find_element_by_id('name').send_keys('TextEvidence')
        driver.find_element_by_id('content').send_keys('test ui automation')
        driver.find_element_by_xpath('//*[@id="create"]/div/div/form/div[6]/div/div/span/button[2]').click()
        time.sleep(2)
        # 查看存证
        driver.find_element_by_xpath('//*[@id="create"]/div[2]/div/div[2]/div/div[2]/div/div/div[2]/button[1]').click()
        time.sleep(2)
        # 查询存证
        driver.find_element_by_link_text('返回').click()
        driver.find_element_by_id('search').send_keys('fileEvidence', Keys.ENTER)
    with allure.step("退出登录"):
        # 退出登录
        time.sleep(2)
        driver.find_element_by_id('ADMIN').click()
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="ADMIN"]/div/div/div/ul/li[4]/a').click()

    with allure.step("关闭浏览器"):
        driver.quit()
