import allure
from selenium import webdriver
import pytest
import yaml
import time


@allure.testcase('http://www.github.com')
@allure.feature('百度搜索')
@pytest.mark.parametrize('data', "123")
def test_steps_demo(data):
    with allure.step("打开百度首页"):
        driver = webdriver.Chrome()
        driver.get("http://www.baidu.com")
        driver.maximize_window()

    with allure.step(f"输入关键词：{data}"):
        driver.find_element_by_id('kw').send_keys(data)
        time.sleep(2)
        driver.find_element_by_id('su').click()
        time.sleep(2)

    with allure.step("保存图片"):
        driver.save_screenshot("screenshot/" + data + ".png")
        allure.attach.file("screenshot/" + data + ".png")
        # attachment_type = allure.attachment_type.PNG

    with allure.step("关闭浏览器"):
        driver.quit()
