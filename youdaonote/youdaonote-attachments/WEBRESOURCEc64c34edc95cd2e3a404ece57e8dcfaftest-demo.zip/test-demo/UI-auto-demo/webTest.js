const {Builder} = require('selenium-webdriver');

(async function myFunction() {
    let driver = await new Builder().forBrowser('chrome').build();
    //chrome.setDefaultService(new chrome.ServiceBuilder('/Users/sghl-11/opt/WebDriver/bin').build());
    await driver.get('https://console-qa.rootcloudapp.com/login');
    await driver.getCurrentUrl();
    await driver.quit();
})();